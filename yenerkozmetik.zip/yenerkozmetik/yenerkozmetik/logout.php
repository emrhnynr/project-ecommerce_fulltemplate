
<?php 

session_start();

if (empty($_SESSION['kullanicioturum'])) {
	
	Header("Location:index");
};


$kullanici_id=$_GET['kullanici_id'];



     $url=$_GET['url'];	
	unset($_SESSION['kullanicioturum']);
unset($_SESSION['kullanici_id']);

Header("Location:$url");






 ?>