<?php require_once 'header.php'; ?>
        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              

             
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Slayt Galeri</h2>

                    <ul class="nav navbar-right panel_toolbox">
                      <a class="btn btn-success"  href="slayt-ekle">Slayt Ekle +</a>
                      
                     
                      
                    </ul>


                    
                    <div class="clearfix"></div>
                    
                  </div>
                  <div class="x_content">

                    <?php $slaytsec=$db->prepare("SELECT * from slaytlar order by slayt_sira ASC");
                      $slaytsec->execute();
                      $slaytsay = $slaytsec->rowCount();

                      if ($slaytsay==0) { ?>
                         

  <h4 align="center">Henüz slayt eklenmemiş.</h4> 

                       <?php } else { ?>

                        <div class="row">

                      <?php 

                      while ($slaytcek=$slaytsec->fetch(PDO::FETCH_ASSOC)) { 

                        $slayt_id = $slaytcek['slayt_id']; 
                        $slayt_sira = $slaytcek['slayt_sira']; 

                        ?>

                        <div class="col-md-55 slayt_<?php echo $slayt_id; ?>">
                        <div class="thumbnail">
                          <div class="image view view-first">
                            <img style="width: 100%; display: block;" src="../../<?php echo $slaytcek['slayt_foto']; ?>" alt="slayt" />
                            <div class="mask no-caption">
                              <div class="tools tools-bottom">
                                
                                <a href="slayt-duzenle?slayt_id=<?php echo $slayt_id; ?>"><i class="fa fa-pencil"></i></a>
                                <a class="slaytsil" name="slayt_<?php echo $slayt_id; ?>" href="javascript:void(0);"><i class="fa fa-times"></i></a>
                              </div>
                            </div>
                          </div>
                          <div class="caption">
                            <p><strong>Slayt <?php echo $slayt_sira; ?></strong>
                            </p>
                            
                          </div>
                        </div>
                      </div>
                         
                       <?php } ?>

                     

                     
                      
                    </div>


                      <?php } ?>

                    
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <?php require_once 'footer.php'; ?>
        <script type="text/javascript">
          
          $('.slaytsil').click(function(){

             var id1=$(this).attr("name");
                var slayt_id=id1.substring(6);

                swal({
  title: "Bu slayt ögesini silmek istiyor musunuz?",
  icon: "warning",
  buttons: ["Cancel", "Sil"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

    $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'slaytogesil':'ok','slayt_id':slayt_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              if (sonuc=="ok") {

                $('.slayt_'+slayt_id).remove();
              }

               }

             });

     }

     })



          })

        </script>