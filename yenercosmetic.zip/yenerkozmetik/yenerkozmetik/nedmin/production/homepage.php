<?php require_once 'header.php';

$genelayarsec=$db->prepare("SELECT * from genelayarlar");
$genelayarsec->execute();

 $genelayarcek=$genelayarsec->fetch(PDO::FETCH_ASSOC);

 

$ayar_girisfoto = $genelayarcek['ayar_girisfoto'];
$ayar_girisfotolink = $genelayarcek['ayar_girisfotolink'];
$ayar_reelbanner = $genelayarcek['ayar_reelbanner'];


  ?>



        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              

              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Homepage Ayarları</h2>

                    <ul class="nav navbar-right panel_toolbox">
                     
                      <a target="_blank" class="btn btn-success" href="../../">Website Anasayfa</a>
                    </ul>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />

                  <div style="margin-bottom: 30px;" class="col-xs-12 col-md-12 col-sm-12">

                    

                   
                    <h4 style="font-weight: bold;" align="center">Homepage Banner <br><br><span>(Önerilen genişlik : 1366px)</span><hr></h4>

                    <label>Mevcut Banner <i class="fa fa-sort-desc"></i></label><br><br>
                    <div style="position: relative;" class="col-md-12 col-xs-12 col-lg-12">
                    
                    <?php if (empty($ayar_girisfoto)) { ?>

                    <h4 align="center">Henüz banner yüklenmemiş. Aşağıdan yükleyebilirsiniz.</h4>
                    <br>
                     
                    <?php } else { ?>

                      <img  class="img-responsive" src="../../<?php echo $ayar_girisfoto; ?>">

                    <a href="javascript:void(0);" class="girisfotokaldir"><i style="color:red;position: absolute;top:-15px;right: 0;font-size: 30px;" class="fa fa-times"></i></a>

                    <?php } ?>

                    </div>

                   

                   
                    <input type="file" id="ayar_girisfoto" class="form-control" name="ayar_girisfoto">

                    <label style="margin-top:15px;" class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Resim Link
                        </label>

                    <input  placeholder="Resime verilecek linki yazın. (Doldurmazsanız resim tıklanamaz olur.)" type="text" id="ayar_girisfotolink" value="<?php echo $ayar_girisfotolink; ?>" maxlength="500" class="form-control" name="ayar_girisfotolink">

                    <br>

                    <div style="display: none;" class="alert alert-warning uyari"></div>

                    <a id="fotoguncellebuton" class="btn btn-success" href="javascript:void(0);">Güncelle</a>
                  </div>
                 

                    

                    



                   

                 

                    <form id="footertextduzenleform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

                      <h3 align="center">Footer Başlık</h3><hr>


                     
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Text

                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="ayar_footertext" placeholder="Footer kısmının üzerinde yer alacak başlığı girin." value="<?php echo $genelayarcek['ayar_footertext']; ?>" name="ayar_footertext" maxlength="300"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      

                    

                     

                      

                     

                

                      <input type="hidden" name="footertextduzenleadmin">


                      
                      
                      <div class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">

                          
                          
                          <button type="submit" class="btn btn-success footertextduzenlebuton">Düzenle</button>
                        </div>
                      </div>

                    </form>

                    <form id="footerdescduzenleform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

                      <h3 align="center">Footer Açıklama</h3><hr>


                     
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Açıklama

                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="ayar_footerdesc" placeholder="Footer kısmının üzerindeki açıklama metnini girin." value="<?php echo $genelayarcek['ayar_footerdesc']; ?>" name="ayar_footerdesc" maxlength="400"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      

                    

                     

                      

                     

                

                      <input type="hidden" name="footerdescduzenleadmin">


                      
                      
                      <div class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">

                          
                          
                          <button type="submit" class="btn btn-success footerdescduzenlebuton">Düzenle</button>
                        </div>
                      </div>

                    </form>

                    
                  </div>
                </div>
              </div>
            </div>

            <?php require_once 'footer.php'; ?>



            <script type="text/javascript">

              $('#fotoguncellebuton').click(function(){

var input = $('#ayar_girisfoto');
var foto = $('#ayar_girisfoto').val();
var filevalue = $('#ayar_girisfoto').get(0).files[0];
var fotouzanti = foto.split('.').pop();
var link = $('#ayar_girisfotolink').val();

var data = new FormData();
data.append('girisfotoguncelle',"ok");
data.append("file",filevalue);
data.append("ayar_girisfotolink",link);





    if ($('#ayar_girisfoto').val().length>0 && (fotouzanti!='jpg' && fotouzanti!='jpeg' && fotouzanti!='png')){

$('.uyari').show();
$('.uyari').html('<i class="fa fa-info-circle"></i> Sadece <b>.jpg</b>, <b>.png</b>, <b>.jpeg</b> uzantılı dosyaları yükleyebilirsiniz.');

} else {

  $('#fotoguncellebuton').prop('disabled',true);
  $('#fotoguncellebuton').html('Güncelleniyor...');

   $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            enctype : 'multipart/form-data',
            data : data,
            processData: false,
            contentType: false,
            cache: false,
            success : function(sonuc){

      sonuc=$.trim(sonuc);
      
      if (sonuc=="ok") {

        location.reload();
      }

 }

 });


}

});

              $('.girisfotokaldir').click(function(){

    swal({
  title: "Emin misiniz?",
  text: "Giriş fotoğrafı silinecek ve sitede görünmeyecek.",
  icon: "warning",
  buttons: ["Vazgeç", "Kaldır"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

    $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : {'girisfotokaldir':'ok'},
            success : function(sonuc){

      sonuc=$.trim(sonuc);

      
      
      if (sonuc=="ok") {

        location.reload();
      }

 }

 });

     }

     })

              })

            


             $('#girisbaslikduzenleform').submit(function(){

              var ayar_hometext = $.trim($('#ayar_hometext').val());
              


              $('.girisbaslikduzenlebuton').prop('disabled',true);

               

                $('.uyarigirisbaslik').hide();

                $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : $('#girisbaslikduzenleform').serialize(),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

              if (sonuc=="ok") {

               
                $('.girisbaslikduzenlebuton').prop('disabled',false);


                swal({

  title: "Başarılı",
  text: "Banner Başlığı Düzenlendi!",
  icon: "success",
  button: "OK",
});



              }
                

              }


            })
              

               });

             $('#reelbannerguncellebuton').click(function(){

var input = $('#ayar_reelbanner');
var foto = $('#ayar_reelbanner').val();
var filevalue = $('#ayar_reelbanner').get(0).files[0];
var fotouzanti = foto.split('.').pop();

var data = new FormData();
data.append('reelbannerguncelle',"ok");
data.append("file",filevalue);



if ($('#ayar_reelbanner').val().length==0){

 $('.uyarireelbanner').show();
$('.uyarireelbanner').html('<i class="fa fa-info-circle"></i> Lütfen bir video banner yükleyin.');

  } else if (fotouzanti!='jpg' && fotouzanti!='jpeg' && fotouzanti!='png'){

$('.uyarireelbanner').show();
$('.uyarireelbanner').html('<i class="fa fa-info-circle"></i> Sadece <b>.jpg</b>, <b>.png</b>, <b>.jpeg</b> uzantılı dosyaları yükleyebilirsiniz.');

} else {

  $('#reelbannerguncellebuton').prop('disabled',true);
  $('#reelbannerguncellebuton').html('Düzenleniyor...');

   $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            enctype : 'multipart/form-data',
            data : data,
            processData: false,
            contentType: false,
            cache: false,
            success : function(sonuc){

      sonuc=$.trim(sonuc);
      
      if (sonuc=="ok") {

        location.reload();
      }

 }

 });


}

});

             $('#anasayfadescriptionform').submit(function(){

              var anasayfa_description = $.trim($('#anasayfa_description').val());
              


              $('.anasayfadescriptionbuton').prop('disabled',true);

              

                

                $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : $('#anasayfadescriptionform').serialize(),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

              if (sonuc=="ok") {

               
                $('.anasayfadescriptionbuton').prop('disabled',false);


                swal({

  title: "Başarılı",
  text: "Site description başarıyla güncellendi!",
  icon: "success",
  button: "OK",
});



              }
                

              }


            })
              

               });

              $('#reelkodduzenleform').submit(function(){

              var ayar_reelkod = $.trim($('#ayar_reelkod').val());
              


              $('.reelkodduzenlebuton').prop('disabled',true);

              

                $('.uyarireelkod').hide();

                $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : $('#reelkodduzenleform').serialize(),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

              if (sonuc=="ok") {

               
                $('.reelkodduzenlebuton').prop('disabled',false);


                swal({

  title: "Başarılı",
  text: "Homepage video başarıyla güncellendi!",
  icon: "success",
  button: "OK",
});



              }
                

              }


            })
              

               });

               $('#footertextduzenleform').submit(function(){

              var ayar_footertext = $.trim($('#ayar_footertext').val());
              
              


              $('.footertextduzenlebuton').prop('disabled',true);

               

                

                $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : $('#footertextduzenleform').serialize(),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

              if (sonuc=="ok") {

               
                $('.footertextduzenlebuton').prop('disabled',false);


                swal({

  title: "Başarılı",
  text: "Footer başlığı düzenlendi!",
  icon: "success",
  button: "OK",
});



              }
                

              }


            })
              

               });

               $('#footerdescduzenleform').submit(function(){

              var ayar_footerdesc = $.trim($('#ayar_footerdesc').val());
              
              


              $('.footerdescduzenlebuton').prop('disabled',true);

               

                

                $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : $('#footerdescduzenleform').serialize(),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

              if (sonuc=="ok") {

               
                $('.footerdescduzenlebuton').prop('disabled',false);


                swal({

  title: "Başarılı",
  text: "Footer açıklama metni düzenlendi!",
  icon: "success",
  button: "OK",
});



              }
                

              }


            })
              

               });

              

            

            </script>

              
             