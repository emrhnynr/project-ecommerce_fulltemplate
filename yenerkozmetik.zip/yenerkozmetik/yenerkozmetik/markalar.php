
<?php require_once 'header.php'; ?>

  <style type="text/css">
    
 .square {
   background: #fff;
   border:1px solid rgba(112,112,112,0.2);
   display: flex;
  justify-content: center;
  align-items: center;
  height: 200px;
}

.colyapisi {
    margin-top: 20px !important;
}  




</style>

<title>Markalar | Yener Kozmetik</title>


        

        <!--==================== Registration Form Start ====================-->
        <div style="padding-top: 40px;" class="full-row">
            <div class="container">
                
         <h3 style="font-family: arial;font-weight: 300;" align="center">MARKALAR</h3><hr>
                
                <div class="row">

                    <?php 

                    $markasec=$db->prepare("SELECT * from markalar order by marka_ad ASC");
                    $markasec->execute();

                    while ($markacek=$markasec->fetch(PDO::FETCH_ASSOC)) { 

                        $marka_ad = $markacek['marka_ad'];
                        $marka_logo = $markacek['marka_logo']; ?>
                        
                        <div style="position: relative;" class="col-lg-2 col-md-3 col-sm-6 col-xs-6 col-xxs-6 colyapisi">

                           
                                <div class="square">
                                 <a href='markalar-<?php echo seo($marka_ad);?>'><img style="width: 100%;" class="img-responsive" src="<?php echo $marka_logo; ?>"></a>
                            </div>
                        
                        
                    </div>

                    <?php } ?>

                     

                    
                    
                </div>  

            

            </div>
        </div>
        <!--==================== Registration Form Start ====================-->

       <?php require_once 'footer.php'; ?>

       