<?php require_once 'header.php';

$kullanici_id=$_GET['uye_id'];

$kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_id=:id and kullanici_yetki=:yetki");
$kullanicisec->execute(array(
"id" => $kullanici_id,
"yetki" => 1
));

$kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

$kullanicisay=$kullanicisec->rowCount();

if ($kullanicisay==0) {
  
  header("Location:index");
  exit;
}

            $kullanici_zaman = $kullanicicek['kullanici_kayitzaman'];
                 $d = new DateTime($kullanici_zaman);
                 $zamanson =  $d->format('d/m/Y H:i');


                 $siparissec=$db->prepare("SELECT * from siparisler where kullanici_id=:id");
                 $siparissec->execute(array(

                  "id" => $kullanici_id
                 ));

                 $siparissay=$siparissec->rowCount();

 ?>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
           

            <div class="clearfix"></div>

            <div class="row">
             

              <div class="clearfix"></div>

              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Üye Detayları</h2>





                    
                    
                    <div class="clearfix"></div>
                  </div>

                  <div class="x_content">

                    <?php if ($kullanicicek['kullanici_ban']==1) { 
                      echo '<h4 align="center" style="color:#b40505;"><i class="fa fa-ban"></i> Bu üyeyi engellediniz.</h4>';
                      
                     } ?>

                     <div class="row">
           
           <div style="margin-top:20px;" class="col-md-6 col-xs-12 col-sm-12">
            <label>Ad & Soyad</label>
             <input class="form-control" value="<?php echo $kullanicicek['kullanici_ad']." ".$kullanicicek['kullanici_soyad']; ?>" readonly="" type="text" name="">
           </div>

          

           <div style="margin-top:20px;" class="col-md-6 col-xs-12 col-sm-12">
            <label>Kayıt Tarihi</label>
             <input class="form-control" value="<?php echo $zamanson; ?>" readonly="" type="text" name="">
           </div>

           <div style="margin-top:20px;" class="col-md-6 col-xs-12 col-sm-12">
            <label>E-Posta Adresi</label>
             <input class="form-control" value="<?php echo $kullanicicek['kullanici_mail']; ?>" readonly="" type="text" name="">
           </div>

           <div style="margin-top:20px;" class="col-md-6 col-xs-12 col-sm-12">
            <label>Sipariş Sayısı</label>
             <input class="form-control" value="<?php echo $kullanicicek['kullanici_siparissayisi']; ?>" readonly="" type="text" name="">
           </div>



          

       


         </div>

         <hr>

         <h3>Siparişler</h3>

        <?php if ($kullanicicek['kullanici_siparissayisi']==0) { ?>
        
         <h4 align="center">Bu üye henüz sipariş vermemiş.</h4>

       <?php } else { 

$siparislerimsec=$db->prepare("SELECT * from siparisler where kullanici_id=:id order by siparis_zaman DESC");
$siparislerimsec->execute(array(
"id" => $kullanici_id
));

$siparislerimsay=$siparislerimsec->rowCount(); ?>



        

        <div class="table-responsive">
                      <table class="table table-striped jambo_table bulk_action">
                        <thead>
                          <tr class="headings">
                           
                            <th class="column-title">Sipariş No. </th>
                            <th class="column-title">Sipariş Tarihi </th>
                            <th class="column-title">Ürün Sayısı</th>
                            <th class="column-title">Ara Toplam</th>
                            <th class="column-title">Toplam</th>
                            <th class="column-title">Teslimat</th>
                            <th class="column-title">#</th>



                            

                            
                            
                          </tr>
                        </thead>

                        <tbody>

                          <?php while ($siparislerimcek=$siparislerimsec->fetch(PDO::FETCH_ASSOC)) {

                            $siparis_id=$siparislerimcek['siparis_id'];
                       $siparis_zaman = $siparislerimcek['siparis_zaman'];
                       $d = new DateTime($siparis_zaman);
                        $zamanson =  $d->format('d/m/Y H:i');
                      
                      $siparisitemsec=$db->prepare("SELECT * from siparisitem where siparis_id=:id");
                      $siparisitemsec->execute(array(

                        "id" => $siparis_id

                      ));

                      $siparisitemsay=$siparisitemsec->rowCount();

                      $siparis_aratoplam=$siparislerimcek['siparis_aratoplam'];
                      $siparis_toplam=$siparislerimcek['siparis_toplam'];
                      $siparis_teslimat=$siparislerimcek['siparis_ulasmis'];
 
?>

                       <tr>
            
            <td><?php echo $siparis_id; ?></td>
            <td><?php echo $zamanson; ?></td>
            
            <td><?php echo $siparisitemsay; ?></td>
             <td>₺ <?php echo $siparis_aratoplam; ?></td>
            <td>₺ <?php echo $siparis_toplam; ?></td>
            
            <?php if ($siparis_teslimat==0) { ?>

              <td><div style="background: orange;" class="badge badge-warning">Hazırlanıyor</div></td>
              
            <?php } else { ?>
                           
                           <td><div style="background: green;" class="badge badge-success">Teslim Edildi</div></td>

            <?php } ?>

            <td><a target="_blank" style="color: white;" href="siparis-detay?siparis_id=<?php echo $siparis_id; ?>" class="btn btn-info btn-xs">Detaylar</a></td>
            
          </tr>

<?php } ?>


                        </tbody>
                      </table>
                    </div>


                    

                    


      <?php } ?>

      <hr>

      <?php if ($kullanicicek['kullanici_ban']=='0') { ?>
        
      

      <h4 align="center"><a class="kullanicisil" name="kullanici_<?php echo $kullanicicek['kullanici_id']; ?>" style="color: #b40505;" href="javascript:void(0);"><i class="fa fa-minus-circle"></i> Üyeyi Engelle</a></h4>

    <?php } ?>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->


      </div>
    </div>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="../vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- Sweet Alert -->

    <script type="text/javascript" src="../../sweetalert.min.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
  </body>
</html>

 <script type="text/javascript">
         
         $('.kullanicisil').click(function(){

var id1=$(this).attr("name");
     var kullanici_id=id1.substring(10);

              swal({
  title: "Bu üyeyi silmek istediğinize emin misiniz?",
  text: "Bu üyenin yaptığı tüm yorumlar silinecek ve giriş yapması engellenecek.",
  icon: "warning",
  buttons: ["Vazgeç", "Sil"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

    $('.kullanicisil').prop('disabled',true);

    $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'kullanicisiladmin':'ok','kullanici_id':kullanici_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

             if (sonuc=="ok") {


              location.reload();

             }

               }

             });


     }

     })

})

       </script>