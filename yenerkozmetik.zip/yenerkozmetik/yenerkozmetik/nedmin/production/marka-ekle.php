<?php require_once 'header.php'; ?>

        

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Marka Ekle</h3>
              </div>

              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                 
                  <div class="x_content">
                    <br />
                    <form id="markaekleform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

                      <div class="form-group">
                       
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">
                        Marka Logo (300x300px) <span class="required">*</span></label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="file" id="marka_logo" name="marka_logo"  class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Marka İsmi <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" id="marka_ad" name="marka_ad"  placeholder="Marka ismini girin." maxlength="200" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>

                      
                       

                      <input type="hidden" name="markaekleadmin">
                      

                      
                     
                      
                      <div class="form-group">


                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">

                           <div style="display: none;" class="alert alert-warning uyari"></div>
                         
                          
                          <button type="submit" class="btn btn-success submitbuton">Ekle</button>
                        </div>
                      </div>

                    </form>
                  </div>
                </div>
              </div>
            </div>

            <?php require_once 'footer.php'; ?>
            <script type="text/javascript">
              
              $('#markaekleform').submit(function(){

          var input = $('#marka_logo');
          var foto = $('#marka_logo').val();
       var filevalue = $('#marka_logo').get(0).files[0];
         var fotouzanti = foto.split('.').pop();
          var marka_ad = $.trim($('#marka_ad').val());
        


          var data = new FormData();
data.append('markaekleadmin',"ok");
data.append('marka_ad',marka_ad);
data.append("file",filevalue);
         
          $('.submitbuton').prop('disabled',true);

        if ($('#marka_logo').val().length==0){

 $('.uyari').show();
$('.uyari').html('<i class="fa fa-info-circle"></i> Lütfen bir logo yükleyin.');
$('.submitbuton').prop('disabled',false);

  } else if (fotouzanti!='jpg' && fotouzanti!='jpeg' && fotouzanti!='png' && fotouzanti!='JPG' && fotouzanti!='PNG'){

$('.uyari').show();
$('.uyari').html('<i class="fa fa-info-circle"></i> Sadece <b>.jpg, .jpeg, .png</b> uzantılı dosyaları yükleyebilirsiniz.');
$('.submitbuton').prop('disabled',false);

} else if (marka_ad.length<2) {

        
        $('.uyari').show();
        $('.uyari').html("Marka ismi 2 karakterden kısa olamaz.");
        $('.submitbuton').prop('disabled',false);

        } else {

          $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            enctype : 'multipart/form-data',
            data : data,
            processData: false,
            contentType: false,
            cache: false,
            success : function(sonuc){

              sonuc = $.trim(sonuc);

             

              if (sonuc=="ok") {

swal({

  title: "Başarılı",
  text: "Marka eklendi!",
  icon: "success",
  button: "OK",
}).then((willDelete) => {
  if (willDelete) {

    window.location = 'marka-ayarlari';

     }

   });

              }

             
              }
        })
        }

              })

            </script>


            