<?php 

ob_start();
session_start();

if (empty($_POST) and empty($_GET)) {
    
    header("Location:/");
    exit;
}


require_once 'db.php';
include 'fonksiyon.php';
include('SimpleImage.php');

 $ip_adresi=$_SERVER['REMOTE_ADDR'];
 date_default_timezone_set('Europe/Istanbul');


 if (isset($_POST['uyekayit'])) {

    

    $rand = strtoupper(substr(md5(microtime()),rand(0,26),5)); 
    
    $kullanici_ad = trim($_POST['kullanici_ad']);
    $kullanici_soyad = trim($_POST['kullanici_soyad']);
    $kullanici_mail = trim($_POST['kullanici_mail']);
    $kullanici_password = $_POST['kullanici_password'];

    //Hack Önleme -----

    botkontrol();

    if (mb_strlen($kullanici_ad,'UTF-8')>100 or mb_strlen($kullanici_soyad,'UTF-8')>100 or mb_strlen($kullanici_mail,'UTF-8')>100 or mb_strlen($kullanici_password,'UTF-8')>100  or !isset($_POST['kullanici_ad']) or !isset($_POST['kullanici_soyad']) or !isset($_POST['kullanici_mail']) or !isset($_POST['kullanici_password']) or filter_var($kullanici_mail, FILTER_VALIDATE_EMAIL) == false) {
        
        exit;
    }



    //-----------

    $kullanicisor=$db->prepare("SELECT * from kullanici where kullanici_mail=:mail");
    $kullanicisor->execute(array(
 
 "mail" => $kullanici_mail
    ));

     $kullanicisay=$kullanicisor->rowCount();

    if ($kullanicisay==1) {
        
        echo "mevcutmail";

    } else {

        $hazirla=$db->prepare("INSERT into kullanici set


kullanici_ad=:kullanici_ad,
kullanici_soyad=:kullanici_soyad,
kullanici_mail=:kullanici_mail,
kullanici_password=:kullanici_password,
kullanici_yetki=:kullanici_yetki,
kullanici_mailonay=:kullanici_mailonay,
kullanici_aktivasyonkod=:kullanici_aktivasyonkod,
kullanici_kayitzaman=:kullanici_kayitzaman
            ");

        $derle=$hazirla->execute(array(

"kullanici_ad" => htmlspecialchars($kullanici_ad),
"kullanici_soyad" => htmlspecialchars($kullanici_soyad),
"kullanici_mail" => htmlspecialchars($kullanici_mail),
"kullanici_password" => md5($kullanici_password),
"kullanici_yetki" => 1,
"kullanici_mailonay" => 0,
"kullanici_aktivasyonkod" => $rand,
"kullanici_kayitzaman" => date('Y-m-d H:i:s')

        ));

        $kullanici_id = $db->lastInsertId();

        if ($derle) {

            

            $ipsepetsec=$db->prepare("SELECT * from sepetitem where kullanici_ip='$ip_adresi'");
    $ipsepetsec->execute();

    $ipsepetsay = $ipsepetsec->rowCount();

    if ($ipsepetsay>0) {

        
        
        while ($ipsepetcek=$ipsepetsec->fetch(PDO::FETCH_ASSOC)) {

            $sepetitem_id = $ipsepetcek['sepetitem_id'];
           
           $hazirla=$db->prepare("UPDATE sepetitem set

kullanici_id=:kullanici_id,
kullanici_ip=:kullanici_ip

where sepetitem_id='$sepetitem_id'

            ");

           $derle=$hazirla->execute(array(
"kullanici_id" => $kullanici_id,
"kullanici_ip" => NULL
           ));

           $hazirla2=$db->prepare("UPDATE sepetitemsecenekler set

kullanici_id=:kullanici_id

where sepetitem_id='$sepetitem_id'

            ");

           $derle2=$hazirla2->execute(array(
            
"kullanici_id" => $kullanici_id

           ));
        }
    }

            $genelayarsec=$db->prepare("SELECT * from genelayarlar");
            $genelayarsec->execute();

            $genelayarcek=$genelayarsec->fetch(PDO::FETCH_ASSOC);
            $ayar_mail = $genelayarcek['ayar_mail'];
            $ayar_mailsifre = $genelayarcek['ayar_mailsifre'];
            $ayar_mailbaslik = $genelayarcek['ayar_mailbaslik'];
            $ayar_logo = $genelayarcek['ayar_logo'];
            $ayar_telno = $genelayarcek['ayar_telno'];

            

            

    //------------------------------ Müşteriye Hoşgeldin Mesajı ---------------------

            require("phpmailer/class/class.phpmailer.php");


    $mail2 = new PHPMailer(); // Sinifimizi $mail degiskenine atadik
 $mail2->CharSet  ="utf-8";
 $mail2->Encoding="base64";
$mail2->IsSMTP();  // Mailimizin SMTP ile gönderilecegini belirtiyoruz
$mail2->Host     = "smtpout.secureserver.net";//"localhost"; //SMTP server adresi
$mail2->Port     = '80'; 
$mail2->SMTPAuth = true; //SMTP server'a kullanici adi ile baglanilcagini belirtiyoruz.
$mail2->Username = $ayar_mail;//"admin@localhost"; //SMTP kullanici adi
$mail2->Password = $ayar_mailsifre;//""; //SMTP mailinizin sifresi
$mail2->SMTPSecure = 'SSL';
$mail2->From     = $ayar_mail;//"admin@localhost"; //Gönderen kisminda yer alacak e-mail adresi
$mail2->FromName = $ayar_mailbaslik;//"PHP Mailer";//gönderenin ismi
$mail2->AddEmbeddedImage($ayar_logo, 'logo');
$mail2->AddAddress($kullanici_mail); // Mail gönderilecek adresleri ekliyoruz.
$mail2->IsHTML(true); //Mailimizin HTML formatinda hazirlanacagini bildiriyoruz.
$mail2->Subject  = 'Hoş geldiniz';//"Deneme Maili"; // Mailin Konusu Konu


    $mail2->Body = "<div align='center'>

    <div style='width:90%;padding:20px;'>

 <div style='width:100%;'>
 <img src='cid:logo'>
 </div>
 <hr>

 <p style='text-align:center;'><b>Merhaba ".$kullanici_ad.",</b> <br><br> Üyeliğin başarıyla tamamlandı. Seni aramızda görmekten mutluluk duyuyoruz. <br><br> Ayrıcalıklı alışveriş deneyimi yaşamak için ".$ayar_mailbaslik." web sitesini ziyaret edebilirsin.</p>

    </div>

    

    
</div>

    ";

    $mail2->Send();

            $_SESSION['kullanicioturum']=$kullanici_mail;
            echo "ok";
        }



    }


 } else if (isset($_POST['uyeguncelle'])) {

    

    $rand = strtoupper(substr(md5(microtime()),rand(0,26),5)); 
    
    $kullanici_ad = trim($_POST['kullanici_ad']);
    $kullanici_soyad = trim($_POST['kullanici_soyad']);
    $kullanici_mail = trim($_POST['kullanici_mail']);
    $kullanici_id = $_SESSION['kullanici_id'];

    //Hack Önleme

    botkontrol();


     if (mb_strlen($kullanici_ad,'UTF-8')>100 or mb_strlen($kullanici_soyad,'UTF-8')>100 or mb_strlen($kullanici_mail,'UTF-8')>100 or !isset($_POST['kullanici_ad']) or !isset($_POST['kullanici_soyad']) or !isset($_POST['kullanici_mail']) or filter_var($kullanici_mail, FILTER_VALIDATE_EMAIL) == false) {
        
        exit;
    }


    //------------

    $kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_id='$kullanici_id'");
    $kullanicisec->execute();
    $kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

    $kullanicisor=$db->prepare("SELECT * from kullanici where kullanici_mail=:mail");
    $kullanicisor->execute(array(
 
 "mail" => $kullanici_mail
    ));

     $kullanicisay=$kullanicisor->rowCount();

    if ($kullanicisay==1 and $kullanici_mail!=$kullanicicek['kullanici_mail']) {
        
        echo "mevcutmail";

    } else {

        $hazirla=$db->prepare("UPDATE kullanici set


kullanici_ad=:kullanici_ad,
kullanici_soyad=:kullanici_soyad,
kullanici_mail=:kullanici_mail

where kullanici_id='$kullanici_id'
            ");

        $derle=$hazirla->execute(array(

"kullanici_ad" => htmlspecialchars($kullanici_ad),
"kullanici_soyad" => htmlspecialchars($kullanici_soyad),
"kullanici_mail" => htmlspecialchars($kullanici_mail)

        ));

        if ($derle) {

        
        unset($_SESSION['kullanicioturum']);
unset($_SESSION['kullanici_id']);
            $_SESSION['kullanicioturum']=$kullanici_mail;
            $_SESSION['kullanici_id'] = $kullanici_id;
            echo "ok";
        }



    }


 } else if(isset($_POST['sifreguncelle'])){

   

    $kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_id=:id");
    $kullanicisec->execute(array(
"id" => $_SESSION['kullanici_id']
    ));

    $kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

    $kullanici_id=$_SESSION['kullanici_id'];

$mevcut_sifre=$_POST['kullanici_mevcutsifre'];
$yeni_sifre=$_POST['kullanici_password'];


//Hack Önleme

    botkontrol();


     if (mb_strlen($mevcut_sifre,'UTF-8')>100 or mb_strlen($yeni_sifre,'UTF-8')>100 or !isset($_POST['kullanici_mevcutsifre']) or !isset($_POST['kullanici_password'])) {
        
        exit;
    }


    //------------

if ($kullanicicek['kullanici_password']!=md5($mevcut_sifre)) {
    
    echo "yanlissifre";

} else {

    $hazirla=$db->prepare("UPDATE kullanici set

kullanici_password=:kullanici_password

where kullanici_id='$kullanici_id'
        ");

    $derle=$hazirla->execute(array(

"kullanici_password" => htmlspecialchars(md5($yeni_sifre))
    ));

    if ($derle) {

        echo "ok";

    } 

    
}



} else if (isset($_POST['uyelogin'])){

$kullanici_mail=htmlspecialchars(trim($_POST['kullanici_mail']));
$kullanici_password=$_POST['kullanici_password'];

//Hack Önleme -----

    botkontrol();

    if (!isset($_POST['kullanici_mail']) or !isset($_POST['kullanici_password'])) {
        
        exit;
    }



    //-----------

$kullanicisor=$db->prepare("SELECT * from kullanici where kullanici_mail=:mail and kullanici_ban=:ban and kullanici_yetki=:yetki and kullanici_password=:password");

$kullanicisor->execute(array(

"mail" => $kullanici_mail,
"yetki" => 1,
"password" => md5($kullanici_password),
"ban" => 0

));

$kullanicisay=$kullanicisor->rowCount();

if ($kullanicisay==1) {

    $ipsepetsec=$db->prepare("SELECT * from sepetitem where kullanici_ip='$ip_adresi'");
    $ipsepetsec->execute();

    $ipsepetsay = $ipsepetsec->rowCount();

    if ($ipsepetsay>0) {

        $kullanicicek = $kullanicisor->fetch(PDO::FETCH_ASSOC);
        $kullanici_id = $kullanicicek['kullanici_id'];
        
        while ($ipsepetcek=$ipsepetsec->fetch(PDO::FETCH_ASSOC)) {

            $sepetitem_id = $ipsepetcek['sepetitem_id'];
           
           $hazirla=$db->prepare("UPDATE sepetitem set

kullanici_id=:kullanici_id,
kullanici_ip=:kullanici_ip

where sepetitem_id='$sepetitem_id'

            ");

           $derle=$hazirla->execute(array(
"kullanici_id" => $kullanici_id,
"kullanici_ip" => NULL
           ));

           $hazirla2=$db->prepare("UPDATE sepetitemsecenekler set

kullanici_id=:kullanici_id

where sepetitem_id='$sepetitem_id'

            ");

           $derle2=$hazirla2->execute(array(

"kullanici_id" => $kullanici_id

           ));
        }
    }
    
    $_SESSION['kullanicioturum'] = $kullanici_mail;
    echo "ok";
} else {

    echo "yanlisbilgiler";
}
 } else if (isset($_POST['yorumyap'])){

 $urun_id=$_POST['urun_id'];
 $kullanici_id=$_SESSION['kullanici_id'];
 $yorum_icerik=trim($_POST['yorum_icerik']);
 $yorum_konu=trim($_POST['yorum_konu']);


 //Hack Önleme -----

    botkontrol();

    $urunsec = $db->prepare("SELECT * from urunler where urun_id='$urun_id' and urun_kaldirildi='0'");
    $urunsec->execute();
    $urunsay = $urunsec->rowCount();

    
    if (!isset($_POST['urun_id']) or !isset($_POST['yorum_icerik']) or !isset($_POST['yorum_konu']) or mb_strlen($yorum_konu,'UTF-8')<3 or mb_strlen($yorum_icerik,'UTF-8')<3 or mb_strlen($yorum_konu,'UTF-8')>100 or mb_strlen($yorum_icerik,'UTF-8')>1000 or $urunsay == 0) {
        
        exit;
    }


    //-----------

 $hazirla=$db->prepare("INSERT into yorumlar set

urun_id=:urun_id,
kullanici_id=:kullanici_id,
yorum_icerik=:yorum_icerik,
yorum_zaman=:yorum_zaman,
yorum_konu=:yorum_konu
    ");

 $derle=$hazirla->execute(array(

"urun_id" => $urun_id,
"kullanici_id" => $kullanici_id,
"yorum_icerik" => htmlspecialchars($yorum_icerik),
"yorum_zaman" => date('Y-m-d H:i:s'),
"yorum_konu" => htmlspecialchars($yorum_konu)
 ));

 

 

 } else if (isset($_POST['hemensepeteekle'])){

    $urun_id = $_POST['urun_id'];
    $urun_miktar = 1;

    //Hack Kontrol ---------

    $urunsec = $db->prepare("SELECT * from urunler where urun_id='$urun_id' and urun_stok>'0' and urun_kaldirildi='0'");

    $urunsec->execute();
    $urunsay = $urunsec->fetch(PDO::FETCH_ASSOC);

    $urunseceneklersec = $db->prepare("SELECT * from urunsecenekler where urun_id='$urun_id'");
    $urunseceneklersec->execute();
    $urunseceneklersay = $urunseceneklersec->rowCount();

    if ($urunsay==0 or $urunseceneklersay>0) {
        
        exit;
    }

    //--------------


 if (isset($_SESSION['kullanicioturum'])) {

    $kullanici_id = $_SESSION['kullanici_id'];

    $hazirla=$db->prepare("INSERT into sepetitem set

urun_id=:urun_id,
urun_miktar=:urun_miktar,
kullanici_id=:kullanici_id
    ");

 $derle=$hazirla->execute(array(
"urun_id" => $urun_id,
"urun_miktar" => $urun_miktar,
"kullanici_id" => $kullanici_id
 ));


     } else {

        $kullanici_ip = $ip_adresi;

        $hazirla=$db->prepare("INSERT into sepetitem set

urun_id=:urun_id,
urun_miktar=:urun_miktar,
kullanici_ip=:kullanici_ip
    ");

 $derle=$hazirla->execute(array(
"urun_id" => $urun_id,
"urun_miktar" => $urun_miktar,
"kullanici_ip" => $kullanici_ip
 ));



     }


 } else if (isset($_POST['sepeteurunekle'])){


    $urun_id = $_POST['urun_id'];
 $urun_miktar = $_POST['urun_miktar'];

  botkontrol();

  //Hack Kontrol -----

  $hackurunseceneksec = $db->prepare("SELECT * from urunsecenekler where urun_id='$urun_id'");
  $hackurunseceneksec->execute();
  $hackurunseceneksay=$hackurunseceneksec->rowCount();

  if ($hackurunseceneksay==0) {

    $urunsec = $db->prepare("SELECT * from urunler where urun_id='$urun_id' and urun_kaldirildi='0'");
    $urunsec->execute();
    $urunsay=$urunsec->rowCount();


    if ($urunsay==0 or ctype_digit($urun_miktar)==false or $urun_miktar < 1 or $urun_miktar > 10) {
        
        echo "gecersizistek";
        exit;
    }    
      
  } else {


    $urunsec = $db->prepare("SELECT * from urunler where urun_id='$urun_id' and urun_kaldirildi='0'");
    $urunsec->execute();
    $urunsay=$urunsec->rowCount();
    $eslesme = 'normal';


   while ($hackurunsecenekcek=$hackurunseceneksec->fetch(PDO::FETCH_ASSOC)) {
       
       $secenek_id = $hackurunsecenekcek['secenek_id'];
       $secenek_ad = $_POST['altsecenek_id_'.$secenek_id];

       
   
    
    $urunaltseceneklersec = $db->prepare("SELECT * from urunaltsecenekler where urun_id='$urun_id' and secenek_id='$secenek_id' and altsecenek_ad='$secenek_ad'");
    $urunaltseceneklersec->execute();
    $urunaltseceneklersay=$urunaltseceneklersec->rowCount();

    if ($urunaltseceneklersay==0) {
        
        $eslesme='sikintili';
    }

    }



   

    if ($urunsay==0 or ctype_digit($urun_miktar)==false or $urun_miktar < 1 or $urun_miktar > 10 or $eslesme=='sikintili') {
        
        echo "gecersizistek";
        exit;
    }   

   


  }


  //------


 if (isset($_SESSION['kullanicioturum'])) {
     
     
 $kullanici_id = $_SESSION['kullanici_id'];



 $urunsec2=$db->prepare("SELECT * from urunler where urun_id=:id");
 $urunsec2->execute(array(
"id" => $urun_id
 ));

 $uruncek2=$urunsec2->fetch(PDO::FETCH_ASSOC);

 $urun_stok = $uruncek2['urun_stok'];

 if (($urun_stok-$urun_miktar)<0) {
    
    echo "stokyok";

 } else {

     $hazirla=$db->prepare("INSERT into sepetitem set

urun_id=:urun_id,
urun_miktar=:urun_miktar,
kullanici_id=:kullanici_id
    ");

 $derle=$hazirla->execute(array(
"urun_id" => $urun_id,
"urun_miktar" => $urun_miktar,
"kullanici_id" => $kullanici_id
 ));

 $sepetitem_id = $db->lastInsertId();

 if ($derle) {

    if ($hackurunseceneksay>0) {
    

 $tumseceneklersec=$db->prepare("SELECT * from secenekler");
$tumseceneklersec->execute();
while ($tumseceneklercek=$tumseceneklersec->fetch(PDO::FETCH_ASSOC)) {

    $secenek_id = $tumseceneklercek['secenek_id'];
    $secenek_ad = $tumseceneklercek['secenek_ad'];

    if (!empty($_POST['altsecenek_id_'.$secenek_id])) {
       
       $hazirla=$db->prepare("INSERT into sepetitemsecenekler set

secenek_ad=:secenek_ad,
sepetitem_id=:sepetitem_id,
altsecenek_ad=:altsecenek_ad,
kullanici_id=:kullanici_id

        ");

       $derle=$hazirla->execute(array(

        "altsecenek_ad" => $_POST['altsecenek_id_'.$secenek_id],
        "sepetitem_id" => $sepetitem_id,
        "secenek_ad" => $secenek_ad,
        "kullanici_id" => $kullanici_id

    ));
    } 
    
    
} 

}
    

$sepeturunsecheader = $db->prepare("SELECT * from sepetitem where kullanici_id=:id order by urun_id DESC");
 $sepeturunsecheader->execute(array(

"id" => $_SESSION['kullanici_id']

 ));

 $sepeturunsayheader=$sepeturunsecheader->rowCount(); ?>

  
                            
        

        
                       
                            
                        
                    

                    <ul class="cart_list product_list_widget ">

                                            <?php

                                                        $urun_toplam=0;

                                                        while ($sepeturuncekheader=$sepeturunsecheader->fetch(PDO::FETCH_ASSOC)) { 

                $urunsec=$db->prepare("SELECT * from urunler where urun_id=:id");
                        $urunsec->execute(array(

                            "id" => $sepeturuncekheader['urun_id']
                        ));

                        $uruncek = $urunsec->fetch(PDO::FETCH_ASSOC);

                        $urun_marka = $uruncek['marka_id'];

                        if ($uruncek['urun_indirim']==1) {
                            
                            $urun_fiyat = $uruncek['urun_fiyat'];

                        } else {

                            $urun_fiyat = $uruncek['urun_indirimsizfiyat'];
                        };

                        $urun_toplamfiyat = $sepeturuncekheader['urun_miktar']*$urun_fiyat;
                        $sepetitem_id = $sepeturuncekheader['sepetitem_id'];

                        $sepetitemseceneksec = $db->prepare("SELECT * from sepetitemsecenekler where sepetitem_id='$sepetitem_id'");

                          $sepetitemseceneksec->execute();

                        $urun_toplam+=$urun_toplamfiyat;

                        $urun_ad=$uruncek['urun_ad'];

                         $urunfotosec=$db->prepare("SELECT * from urunfoto where urun_id=:id and urunfoto_kapak=:kapak");
                $urunfotosec->execute(array(
                    "id" => $sepeturuncekheader['urun_id'],
                    "kapak" => 1

                ));

                $urunfotocek=$urunfotosec->fetch(PDO::FETCH_ASSOC);

                $markasec=$db->prepare("SELECT * from markalar where marka_id='$urun_marka'");
                        $markasec->execute();
                        $markacek=$markasec->fetch(PDO::FETCH_ASSOC);
                        $marka_ad=$markacek['marka_ad'];

                ?>
                                            
                                            <li class="mini-cart-item">
                                                
                                                <a href="urun-<?php echo seo($urun_ad)."-".$uruncek['urun_id']; ?>" class="product-image bg-light"><img src="<?php echo $urunfotocek['urunfoto_yol']; ?>" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="ürün"></a>
                                                <span style="font-weight: 500;"><?php echo $marka_ad; ?></span>
                                                <a href="urun-<?php echo seo($urun_ad)."-".$uruncek['urun_id']; ?>" class="product-name"><?php if (strlen($urun_ad)>36) { ?>
                            <?php echo substr($urun_ad,0,36)."..."; ?>
                        <?php } else { 

                         echo $urun_ad; 
                         } ?></a>


                         <?php while ($sepetitemsecenekcek=$sepetitemseceneksec->fetch(PDO::FETCH_ASSOC)) { 
                $secenek_ad = $sepetitemsecenekcek['secenek_ad'];
                $altsecenek_ad = $sepetitemsecenekcek['altsecenek_ad']; ?> 


                                           <div class="variation">
                                                    <span><?php echo $secenek_ad; ?>:</span>
                                                    <span><?php echo $altsecenek_ad; ?></span>
                                                </div>
                            

              <?php } ?>


                                                
                                                
                                                <div class="cart-item-quantity"><?php echo $sepeturuncekheader['urun_miktar']; ?> ×
                                                    <span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">₺</span><?php echo $urun_fiyat; ?></bdi>
                                                    </span>
                                                </div>
                                            </li>

                                        <?php } ?>
                                        </ul>
                                        <div class="total-cart">
                                            <div class="title">Toplam: </div>
                                            <div class="price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol"></span><?php echo $urun_toplam; ?> TL</span>
                                            </div>
                                        </div>
                                        <div class="buttons">
                                            <a href="sepetim" class="btn btn-primary rounded-0 view-cart">Sepete Git</a>
                                            <a href="odeme" class="btn btn-secondary rounded-0 checkout">Ödeme Yap</a>
                                        </div>
    
    
 <?php } }


 } else {



 $kullanici_ip = $ip_adresi;

 $urunsec2=$db->prepare("SELECT * from urunler where urun_id=:id");
 $urunsec2->execute(array(
"id" => $urun_id
 ));

 $uruncek2=$urunsec2->fetch(PDO::FETCH_ASSOC);

 $urun_stok = $uruncek2['urun_stok'];

 if (($urun_stok-$urun_miktar)<0) {
    
    echo "stokyok";

 } else {

     $hazirla=$db->prepare("INSERT into sepetitem set

urun_id=:urun_id,
urun_miktar=:urun_miktar,
kullanici_ip=:kullanici_ip
    ");

 $derle=$hazirla->execute(array(
"urun_id" => $urun_id,
"urun_miktar" => $urun_miktar,
"kullanici_ip" => $kullanici_ip
 ));

 $sepetitem_id = $db->lastInsertId();

 if ($derle) {

    if ($hackurunseceneksay>0) {

 $tumseceneklersec=$db->prepare("SELECT * from secenekler");
$tumseceneklersec->execute();
while ($tumseceneklercek=$tumseceneklersec->fetch(PDO::FETCH_ASSOC)) {

    $secenek_id = $tumseceneklercek['secenek_id'];
    $secenek_ad = $tumseceneklercek['secenek_ad'];

    if (!empty($_POST['altsecenek_id_'.$secenek_id])) {
       
       $hazirla=$db->prepare("INSERT into sepetitemsecenekler set

secenek_ad=:secenek_ad,
sepetitem_id=:sepetitem_id,
altsecenek_ad=:altsecenek_ad

        ");

       $derle=$hazirla->execute(array(

        "altsecenek_ad" => $_POST['altsecenek_id_'.$secenek_id],
        "sepetitem_id" => $sepetitem_id,
        "secenek_ad" => $secenek_ad

    ));
    } 
    
    
} 

}
    

$sepeturunsecheader = $db->prepare("SELECT * from sepetitem where kullanici_ip=:ip order by urun_id DESC");
 $sepeturunsecheader->execute(array(

"ip" => $kullanici_ip

 ));

 $sepeturunsayheader=$sepeturunsecheader->rowCount(); ?>

  
                            
<ul class="cart_list product_list_widget ">

                                            <?php

                                                        $urun_toplam=0;

                                                        while ($sepeturuncekheader=$sepeturunsecheader->fetch(PDO::FETCH_ASSOC)) { 

                $urunsec=$db->prepare("SELECT * from urunler where urun_id=:id");
                        $urunsec->execute(array(

                            "id" => $sepeturuncekheader['urun_id']
                        ));

                        $uruncek = $urunsec->fetch(PDO::FETCH_ASSOC);

                        $urun_marka = $uruncek['marka_id'];

                        if ($uruncek['urun_indirim']==1) {
                            
                            $urun_fiyat = $uruncek['urun_fiyat'];

                        } else {

                            $urun_fiyat = $uruncek['urun_indirimsizfiyat'];
                        };

                        $urun_toplamfiyat = $sepeturuncekheader['urun_miktar']*$urun_fiyat;
                        $sepetitem_id = $sepeturuncekheader['sepetitem_id'];

                        $sepetitemseceneksec = $db->prepare("SELECT * from sepetitemsecenekler where sepetitem_id='$sepetitem_id'");

                          $sepetitemseceneksec->execute();

                        $urun_toplam+=$urun_toplamfiyat;

                        $urun_ad=$uruncek['urun_ad'];

                         $urunfotosec=$db->prepare("SELECT * from urunfoto where urun_id=:id and urunfoto_kapak=:kapak");
                $urunfotosec->execute(array(
                    "id" => $sepeturuncekheader['urun_id'],
                    "kapak" => 1

                ));

                $urunfotocek=$urunfotosec->fetch(PDO::FETCH_ASSOC);

                $markasec=$db->prepare("SELECT * from markalar where marka_id='$urun_marka'");
                        $markasec->execute();
                        $markacek=$markasec->fetch(PDO::FETCH_ASSOC);
                        $marka_ad=$markacek['marka_ad'];

                ?>
                                            
                                            <li class="mini-cart-item">
                                                
                                                <a href="urun-<?php echo seo($urun_ad)."-".$uruncek['urun_id']; ?>" class="product-image bg-light"><img src="<?php echo $urunfotocek['urunfoto_yol']; ?>" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="ürün"></a>
                                                <span style="font-weight: 500;"><?php echo $marka_ad; ?></span>
                                                <a href="urun-<?php echo seo($urun_ad)."-".$uruncek['urun_id']; ?>" class="product-name"><?php if (strlen($urun_ad)>36) { ?>
                            <?php echo substr($urun_ad,0,36)."..."; ?>
                        <?php } else { 

                         echo $urun_ad; 
                         } ?></a>


                         <?php while ($sepetitemsecenekcek=$sepetitemseceneksec->fetch(PDO::FETCH_ASSOC)) { 
                $secenek_ad = $sepetitemsecenekcek['secenek_ad'];
                $altsecenek_ad = $sepetitemsecenekcek['altsecenek_ad']; ?> 


                                           <div class="variation">
                                                    <span><?php echo $secenek_ad; ?>:</span>
                                                    <span><?php echo $altsecenek_ad; ?></span>
                                                </div>
                            

              <?php } ?>


                                                
                                                
                                                <div class="cart-item-quantity"><?php echo $sepeturuncekheader['urun_miktar']; ?> ×
                                                    <span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">₺</span><?php echo $urun_fiyat; ?></bdi>
                                                    </span>
                                                </div>
                                            </li>

                                        <?php } ?>
                                        </ul>
                                        <div class="total-cart">
                                            <div class="title">Toplam: </div>
                                            <div class="price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol"></span><?php echo $urun_toplam; ?> TL</span>
                                            </div>
                                        </div>
                                        <div class="buttons">
                                            <a href="sepetim" class="btn btn-primary rounded-0 view-cart">Sepete Git</a>
                                            <a href="odeme" class="btn btn-secondary rounded-0 checkout">Ödeme Yap</a>
                                        </div>

 

    
    
 <?php } }

 }
 





 } else if (isset($_POST['sepeteuruneklefavori'])){

     
     $urun_id = $_POST['urun_id'];
 $urun_miktar = 1;
 $kullanici_id = $_SESSION['kullanici_id'];

 //Hack Kontrol ---------

    $urunsec = $db->prepare("SELECT * from urunler where urun_id='$urun_id' and urun_stok>'0' and urun_kaldirildi='0'");

    $urunsec->execute();
    $urunsay = $urunsec->fetch(PDO::FETCH_ASSOC);

    $urunseceneklersec = $db->prepare("SELECT * from urunsecenekler where urun_id='$urun_id'");
    $urunseceneklersec->execute();
    $urunseceneklersay = $urunseceneklersec->rowCount();

    if ($urunsay==0 or $urunseceneklersay>0) {
        
        echo "gecersizistek";
        exit;
    }

    //--------------

 $urunsec2=$db->prepare("SELECT * from urunler where urun_id=:id");
 $urunsec2->execute(array(
"id" => $urun_id
 ));

 $uruncek2=$urunsec2->fetch(PDO::FETCH_ASSOC);

 $urun_stok = $uruncek2['urun_stok'];

 

     $hazirla=$db->prepare("INSERT into sepetitem set

urun_id=:urun_id,
urun_miktar=:urun_miktar,
kullanici_id=:kullanici_id
    ");

 $derle=$hazirla->execute(array(
"urun_id" => $urun_id,
"urun_miktar" => $urun_miktar,
"kullanici_id" => $kullanici_id
 ));

 $sepetitem_id = $db->lastInsertId();

 if ($derle) {

 
    

$sepeturunsecheader = $db->prepare("SELECT * from sepetitem where kullanici_id=:id order by urun_id DESC");
 $sepeturunsecheader->execute(array(

"id" => $_SESSION['kullanici_id']

 ));

 $sepeturunsayheader=$sepeturunsecheader->rowCount(); ?>

  
                        
<ul class="cart_list product_list_widget ">

                                            <?php

                                                        $urun_toplam=0;

                                                        while ($sepeturuncekheader=$sepeturunsecheader->fetch(PDO::FETCH_ASSOC)) { 

                $urunsec=$db->prepare("SELECT * from urunler where urun_id=:id");
                        $urunsec->execute(array(

                            "id" => $sepeturuncekheader['urun_id']
                        ));

                        $uruncek = $urunsec->fetch(PDO::FETCH_ASSOC);

                        $urun_marka = $uruncek['marka_id'];

                        if ($uruncek['urun_indirim']==1) {
                            
                            $urun_fiyat = $uruncek['urun_fiyat'];

                        } else {

                            $urun_fiyat = $uruncek['urun_indirimsizfiyat'];
                        };

                        $urun_toplamfiyat = $sepeturuncekheader['urun_miktar']*$urun_fiyat;
                        $sepetitem_id = $sepeturuncekheader['sepetitem_id'];

                        $sepetitemseceneksec = $db->prepare("SELECT * from sepetitemsecenekler where sepetitem_id='$sepetitem_id'");

                          $sepetitemseceneksec->execute();

                        $urun_toplam+=$urun_toplamfiyat;

                        $urun_ad=$uruncek['urun_ad'];

                         $urunfotosec=$db->prepare("SELECT * from urunfoto where urun_id=:id and urunfoto_kapak=:kapak");
                $urunfotosec->execute(array(
                    "id" => $sepeturuncekheader['urun_id'],
                    "kapak" => 1

                ));

                $urunfotocek=$urunfotosec->fetch(PDO::FETCH_ASSOC);

                $markasec=$db->prepare("SELECT * from markalar where marka_id='$urun_marka'");
                        $markasec->execute();
                        $markacek=$markasec->fetch(PDO::FETCH_ASSOC);
                        $marka_ad=$markacek['marka_ad'];

                ?>
                                            
                                            <li class="mini-cart-item">
                                                
                                                <a href="urun-<?php echo seo($urun_ad)."-".$uruncek['urun_id']; ?>" class="product-image bg-light"><img src="<?php echo $urunfotocek['urunfoto_yol']; ?>" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="ürün"></a>
                                                <span style="font-weight: 500;"><?php echo $marka_ad; ?></span>
                                                <a href="urun-<?php echo seo($urun_ad)."-".$uruncek['urun_id']; ?>" class="product-name"><?php if (strlen($urun_ad)>36) { ?>
                            <?php echo substr($urun_ad,0,36)."..."; ?>
                        <?php } else { 

                         echo $urun_ad; 
                         } ?></a>


                         <?php while ($sepetitemsecenekcek=$sepetitemseceneksec->fetch(PDO::FETCH_ASSOC)) { 
                $secenek_ad = $sepetitemsecenekcek['secenek_ad'];
                $altsecenek_ad = $sepetitemsecenekcek['altsecenek_ad']; ?> 


                                           <div class="variation">
                                                    <span><?php echo $secenek_ad; ?>:</span>
                                                    <span><?php echo $altsecenek_ad; ?></span>
                                                </div>
                            

              <?php } ?>


                                                
                                                
                                                <div class="cart-item-quantity"><?php echo $sepeturuncekheader['urun_miktar']; ?> ×
                                                    <span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">₺</span><?php echo $urun_fiyat; ?></bdi>
                                                    </span>
                                                </div>
                                            </li>

                                        <?php } ?>
                                        </ul>
                                        <div class="total-cart">
                                            <div class="title">Toplam: </div>
                                            <div class="price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol"></span><?php echo $urun_toplam; ?> TL</span>
                                            </div>
                                        </div>
                                        <div class="buttons">
                                            <a href="sepetim" class="btn btn-primary rounded-0 view-cart">Sepete Git</a>
                                            <a href="odeme" class="btn btn-secondary rounded-0 checkout">Ödeme Yap</a>
                                        </div>
 

    
    
 


 
 





  <?php } } else if (isset($_POST['sepetitemsil'])){


$sepetitem_id=$_POST['sepetitem_id'];
$kullanici_id = $_SESSION['kullanici_id'];


//Hack Önleme ---------

if (isset($_SESSION['kullanicioturum'])) { 





$hackkontrolsec = $db->prepare("SELECT * from sepetitem where sepetitem_id='$sepetitem_id' and kullanici_id='$kullanici_id'");

$hackkontrolsec->execute();



} else {


$hackkontrolsec = $db->prepare("SELECT * from sepetitem where sepetitem_id='$sepetitem_id' and kullanici_ip='$ip_adresi'");
$hackkontrolsec->execute();

}

 $hackkontrolsay = $hackkontrolsec->rowCount();

if ($hackkontrolsay==0) {
    
    exit;
}

//--------------








$silsepetitem=$db->prepare("DELETE from sepetitem where sepetitem_id=:id");
$sepetitemsil=$silsepetitem->execute(array(

"id" => $sepetitem_id

));

$sepetitemseceneksil = $db->prepare("DELETE  from sepetitemsecenekler where sepetitem_id='$sepetitem_id'");
$sepetitemseceneksil->execute();

if ($sepetitemsil) {
    
    echo "ok";
}


 } else if (isset($_POST['sepetitemsilheader'])){

 $sepetitem_id=$_POST['sepetitem_id'];

 $sepetitemsil=$db->prepare("DELETE from sepetitem where sepetitem_id=:id");
 $silsepetitem=$sepetitemsil->execute(array(
"id" => $sepetitem_id
 ));

 if ($silsepetitem) {
    
$sepeturunsecheader = $db->prepare("SELECT * from sepetitem where kullanici_id=:id order by urun_id DESC");
 $sepeturunsecheader->execute(array(

"id" => $_SESSION['kullanici_id']

 ));

 $sepeturunsayheader=$sepeturunsecheader->rowCount(); ?>


                                                <a href="#"><i class="fa fa-shopping-cart" aria-hidden="true"></i><span id="sepetitemsayisi"><?php echo $sepeturunsayheader; ?></span></a>
                                                <ul>
                                                    <?php if ($sepeturunsayheader==0) { ?>
                                                        
                                                        <h4 style="color:#707070;" align="center">Sepetiniz henüz boş.</h4>

                                                    <?php } else { 

                                                        $urun_toplam=0;

                                                        while ($sepeturuncekheader=$sepeturunsecheader->fetch(PDO::FETCH_ASSOC)) { 

                $urunsec=$db->prepare("SELECT * from urunler where urun_id=:id");
                        $urunsec->execute(array(

                            "id" => $sepeturuncekheader['urun_id']
                        ));

                        $uruncek = $urunsec->fetch(PDO::FETCH_ASSOC);

                        $urun_fiyat = $uruncek['urun_fiyat'];

                        $urun_toplamfiyat = $sepeturuncekheader['urun_miktar']*$uruncek['urun_fiyat'];

                        $urun_toplam+=$urun_toplamfiyat;

                        $urun_ad=$uruncek['urun_ad'];

                         $urunfotosec=$db->prepare("SELECT * from urunfoto where urun_id=:id and urunfoto_kapak=:kapak");
                $urunfotosec->execute(array(
                    "id" => $sepeturuncekheader['urun_id'],
                    "kapak" => 1

                ));

                $urunfotocek=$urunfotosec->fetch(PDO::FETCH_ASSOC);

                                                        ?>


                                                    
                                                    <li class="urunsingle">
                                                        <div class="cart-single-product">
                                                            <div class="media">
                                                                <div class="pull-left cart-product-img">
                                                                    <a href="urun-<?php echo seo($urun_ad)."-".$uruncek['urun_id']; ?>">
                                                                        <img class="img-responsive" alt="product" src="<?php echo $urunfotocek['urunfoto_yol']; ?>">
                                                                    </a>
                                                                </div>
                                                                <div class="media-body cart-content">
                                                                    <ul>
                                                                        <li>
                                                                            <h1><a href="urun-<?php echo seo($urun_ad)."-".$uruncek['urun_id']; ?>"><?php if (strlen($urun_ad)>36) { ?>
                            <?php echo substr($urun_ad,0,36)."..."; ?>
                        <?php } else { 

                         echo $urun_ad; 
                         } ?></a></h1>
                                                                            
                                                                        </li>
                                                                        <li>
                                                                            <p>X<?php echo $sepeturuncekheader['urun_miktar']; ?></p>
                                                                        </li>
                                                                        <li>
                                                                            <p style="font-size:13px;">₺<?php echo $uruncek['urun_fiyat']; ?></p>
                                                                        </li>
                                                                        
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>

                                                    <?php } ?>                                                   
                                                    <li>
                                                        <table class="table table-bordered sub-total-area">
                                                            <tbody>
                                                                <tr>
                                                                    <td>Ara Toplam</td>
                                                                    <td><?php echo $urun_toplam." TL"; ?></td>
                                                                </tr>
                                                                                                                            
                                                            </tbody>
                                                        </table>
                                                    </li>
                                                    <li>
                                                        <ul class="cart-checkout-btn">
                                                            <li><a href="sepetim" class="btn-find"><i class="fa fa-shopping-cart" aria-hidden="true"></i>Sepete Git</a></li>
                                                            <li><a href="odeme" class="btn-find"><i class="fa fa-share" aria-hidden="true"></i>Ödeme Yap</a></li>
                                                        </ul>
                                                    </li>
                                                


                                                    <?php } ?>
                                                </ul>

                                                <script type="text/javascript">
                                                    $('.headersepetitemsil').click(function(){

 var id1=$(this).attr("name");
       var sepetitem_id=id1.substring(10);
       

        swal({
  title: "Emin misiniz?",
  text: "Bu ürünü sepetinizden kaldırmak istediğinize emin misiniz?",
  icon: "info",
  buttons: ["Vazgeç", "Sil"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

      $.ajax({

   type : 'POST',
            url : 'musteriislem.php',
            data : {'sepetitemsilheader':'ok','sepetitem_id':sepetitem_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

             

             $('.cart-area').html(sonuc);



                





               }

             });


     }

     })

})
                                                </script>
                                            
 

 <?php }

 } else if (isset($_POST['odemesehirsec'])){

$sehir_id = $_POST['sehir_id'];

$hackkontrolsec = $db->prepare("SELECT * from sehirler where sehir_id='$sehir_id'");
$hackkontrolsec->execute();
$hackkontrolsay = $hackkontrolsec->rowCount();

if ($hackkontrolsay==0) {
    
    echo "gecersizsehirid";
    exit;
}

$ilcesec=$db->prepare("SELECT * from ilceler where sehir_id=:id order by ilce_isim ASC");
$ilcesec->execute(array(
"id" => $sehir_id
));


while ($ilcecek=$ilcesec->fetch(PDO::FETCH_ASSOC)) { ?>
    
    <option><?php echo $ilcecek['ilce_isim']; ?></option>

<?php }





 } else if (isset($_POST['checkout'])){


$kartnumarasi=trim(tum_bosluk_sil(str_replace("-","",$_POST['kartnumarasi'])));
$kart_ay = trim($_POST['sonkullanimayi']);
$kart_yil = trim($_POST['sonkullanimyili']);
$kartsahibi = ucwords(strtolower(trim($_POST['kartsahibi'])));
$cvc=trim($_POST['cvc']);
$siparis_ad = trim($_POST['siparis_ad']);
$siparis_soyad = trim($_POST['siparis_soyad']);
$siparis_telno = trim($_POST['siparis_telno']);
$siparis_sehir = trim($_POST['siparis_sehir']);
$siparis_ilce = trim($_POST['siparis_ilce']);
$siparis_adres = trim($_POST['siparis_adres']);
$siparis_not = trim($_POST['siparis_not']);
$kullanici_id=$_SESSION['kullanici_id'];
$siparis_zaman = date('Y-m-d H:i:s');

$kullanicimailsec = $db->prepare("SELECT * from kullanici where kullanici_id='$kullanici_id'");
$kullanicimailsec->execute();
$kullanicimailcek=$kullanicimailsec->fetch(PDO::FETCH_ASSOC);

$taksitsecenegi = $kullanicimailcek['cart_taksitsecenegi'];
$kargoucreti = $kullanicimailcek['cart_kargoucreti'];
$vade_farki = $kullanicimailcek['cart_vadefarki'];
$siparis_aratoplam = $kullanicimailcek['cart_aratoplam'];
$siparis_toplam = $kullanicimailcek['cart_toplam']+$kullanicimailcek['cart_vadefarki'];

$siparis_mail = $kullanicimailcek['kullanici_mail'];


// Hack Kontrol ------------

botkontrol();

//Genel Form İnputlarını test ediyoruz.

if (mb_strlen($siparis_ad,'UTF-8')<2 or mb_strlen($siparis_ad,'UTF-8')>100 or mb_strlen($siparis_soyad,'UTF-8')<2 or mb_strlen($siparis_soyad,'UTF-8')>100 or ctype_digit(tum_bosluk_sil($siparis_telno)) == false or mb_strlen(tum_bosluk_sil($siparis_telno),'UTF-8') < 10 or mb_strlen($siparis_telno,'UTF-8') > 20 or mb_strlen($siparis_ilce,'UTF-8') > 50 or mb_strlen($siparis_ilce,'UTF-8') < 2 or !isset($_POST['siparis_sehir']) or mb_strlen($siparis_adres,'UTF-8') > 1000 or mb_strlen($siparis_adres,'UTF-8') < 15 or !isset($_POST['siparis_not']) or mb_strlen($siparis_not,'UTF-8') > 500 or mb_strlen($kartnumarasi,'UTF-8') < 16 or mb_strlen(trim($_POST['kartnumarasi']),'UTF-8') > 22 or mb_strlen($kartsahibi,'UTF-8') < 4 or mb_strlen($_POST['kartsahibi'],'UTF-8') > 150 or mb_strlen($kart_ay,'UTF-8') != 2 or mb_strlen($kart_yil,'UTF-8') != 4 or mb_strlen($cvc,'UTF-8') != 3) {
    
    echo "gecersizistek";
    exit;

}

//---------

//Dizi halinde gelen hidden input değerlerini test ediyoruz.

$eslesme = "normal";

$sepetitemlerhack = $_POST['sepetitem_id'];
$miktarlarhack = $_POST['urun_miktar'];
$fiyatlarhack = $_POST['urun_fiyat'];

$sayxx=0;

$sepetitemhacksec = $db->prepare("SELECT * from sepetitem where kullanici_id='$kullanici_id'");
$sepetitemhacksec->execute();
$sepetitemhacksay = $sepetitemhacksec->rowCount();

if (($sepetitemhacksay!=count($sepetitemlerhack)) or ($sepetitemhacksay!=count($miktarlarhack)) or ($sepetitemhacksay!=count($fiyatlarhack))) {

$eslesme = "sikintili";
  
} else {

foreach ($sepetitemlerhack as $sepetitem_id) {

    

    $urun_miktar = $miktarlarhack[$sayxx];
    $urun_fiyat = $fiyatlarhack[$sayxx];


    
$sepetitemkontrolsec = $db->prepare("SELECT * from sepetitem where sepetitem_id='$sepetitem_id' and kullanici_id='$kullanici_id' and urun_miktar='$urun_miktar'");
$sepetitemkontrolsec->execute();
$sepetitemkontrolsay = $sepetitemkontrolsec->rowCount();

if ($sepetitemkontrolsay == 0) {
    
    $eslesme = "sikintili";

}  else {

$sepetitemkontrolcek=$sepetitemkontrolsec->fetch(PDO::FETCH_ASSOC);
$urunmiktardb = $sepetitemkontrolcek['urun_miktar'];
$urun_id=$sepetitemkontrolcek['urun_id'];
$urunsecx = $db->prepare("SELECT * from urunler where urun_id='$urun_id' and urun_kaldirildi='0'");
$urunsecx->execute();
$uruncekx = $urunsecx->fetch(PDO::FETCH_ASSOC);

if (($uruncekx['urun_nihaifiyat'] != $urun_fiyat) or ($urun_miktar != $urunmiktardb)) {
   
   $eslesme = "sikintili";
}

}

$sayxx++;

}

}


if ($eslesme=='sikintili') {
    
    echo $eslesme;
    exit;
}


//----------------

$sehirsec=$db->prepare("SELECT * from sehirler where sehir_id=:id");
$sehirsec->execute(array(
"id" => $siparis_sehir
));

$sehircek=$sehirsec->fetch(PDO::FETCH_ASSOC);

$hazirla=$db->prepare("INSERT into siparisler set

siparis_ad=:siparis_ad,
siparis_soyad=:siparis_soyad,
siparis_telno=:siparis_telno,
siparis_sehir=:siparis_sehir,
siparis_ilce=:siparis_ilce,
siparis_adres=:siparis_adres,
siparis_taksit=:siparis_taksit,
siparis_kargoucreti=:siparis_kargoucreti,
siparis_vadefarki=:siparis_vadefarki,
siparis_not=:siparis_not,
siparis_aratoplam=:siparis_aratoplam,
siparis_toplam=:siparis_toplam,
kullanici_id=:kullanici_id,
siparis_zaman=:siparis_zaman,
siparis_mail=:siparis_mail

    ");


$derle=$hazirla->execute(array(

"siparis_ad" => htmlspecialchars($siparis_ad),
"siparis_soyad" => htmlspecialchars($siparis_soyad),
"siparis_telno" => htmlspecialchars($siparis_telno),
"siparis_sehir" => $sehircek['sehir_isim'],
"siparis_ilce" => htmlspecialchars($siparis_ilce),
"siparis_taksit" => $taksitsecenegi,
"siparis_kargoucreti" => $kargoucreti,
"siparis_vadefarki" => $vade_farki,
"siparis_adres" => htmlspecialchars($siparis_adres),
"siparis_not" => htmlspecialchars($siparis_not),
"siparis_aratoplam" => $siparis_aratoplam,
"siparis_toplam" => $siparis_toplam,
"kullanici_id" => $kullanici_id,
"siparis_zaman" => $siparis_zaman,
"siparis_mail" => htmlspecialchars($siparis_mail)

));

if ($derle) {
    
    $sonsiparisid = $db->lastInsertId();

    $kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_id=:id");
    $kullanicisec->execute(array(
"id" => $kullanici_id
    ));

    $kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

    $kullanici_siparissayisi = $kullanicicek['kullanici_siparissayisi'];
    $kullanici_siparissayisiyeni = $kullanici_siparissayisi+1;

    $hazirla=$db->prepare("UPDATE kullanici set

kullanici_siparissayisi=:kullanici_siparissayisi,
cart_taksitsecenegi=:cart_taksitsecenegi,
cart_vadefarki=:cart_vadefarki,
cart_kargoucreti=:cart_kargoucreti,
cart_aratoplam=:cart_aratoplam,
cart_toplam=:cart_toplam

where kullanici_id='$kullanici_id'
        ");

    $derle=$hazirla->execute(array(

"kullanici_siparissayisi" => $kullanici_siparissayisiyeni,
"cart_taksitsecenegi" => NULL,
"cart_vadefarki" => NULL,
"cart_kargoucreti" => NULL,
"cart_aratoplam" => NULL,
"cart_toplam" => NULL


    ));


$sepetitemler = $_POST['sepetitem_id'];
$miktarlar = $_POST['urun_miktar'];
$fiyatlar = $_POST['urun_fiyat'];


$say=0;
$says=0;


foreach ($sepetitemler as $sepetitem_id) {

    $says++;

     $sepetitemsec = $db->prepare("SELECT * from sepetitem where sepetitem_id='$sepetitem_id'");
    $sepetitemsec->execute();
    $sepetitemcek=$sepetitemsec->fetch(PDO::FETCH_ASSOC);
    $urun_id = $sepetitemcek['urun_id'];

    $urun_miktar = $miktarlar[$say];
    $urun_fiyat = $fiyatlar[$say];
    $urun_toplam = $urun_miktar*$urun_fiyat;
    $secenekler = $_POST['secenek_ad_'.$says];
    $altsecenekler = $_POST['altsecenek_ad_'.$says];
    
    

    $urunsec=$db->prepare("SELECT * from urunler where urun_id=:id");
    $urunsec->execute(array(
        "id" => $urun_id
    ));

    $uruncek=$urunsec->fetch(PDO::FETCH_ASSOC);

    $urun_stok = $uruncek['urun_stok'];

    $hazirla=$db->prepare("UPDATE urunler set

           urun_stok=:urun_stok

           where urun_id='$urun_id'
                            ");

                        $derle=$hazirla->execute(array(
           "urun_stok" => $urun_stok-$urun_miktar
                        ));

                        $hazirla=$db->prepare("INSERT into siparisitem set

kullanici_id=:kullanici_id,
urun_id=:urun_id,
urun_miktar=:urun_miktar,
urun_fiyat=:urun_fiyat,
urun_toplam=:urun_toplam,
siparis_id=:siparis_id
                            ");

                        $derle=$hazirla->execute(array(

"kullanici_id" => $kullanici_id,
"urun_id" => $urun_id,
"urun_miktar" => $urun_miktar,
"urun_fiyat" => $urun_fiyat,
"urun_toplam" =>  $urun_toplam,
"siparis_id" => $sonsiparisid

                        ));

                        $siparisitem_id = $db->lastInsertId();

                        $say2=0;

                        if (!empty($secenekler) and !empty($altsecenekler)) {


                        foreach ($secenekler as $secenek_ad) {
                            
                            $altsecenek_ad = $altsecenekler[$say2];

                            $hazirla=$db->prepare("INSERT into siparisitemsecenekler set

secenek_ad=:secenek_ad,
altsecenek_ad=:altsecenek_ad,
siparisitem_id=:siparisitem_id
                                ");

                            $derle=$hazirla->execute(array(

"secenek_ad" => $secenek_ad,
"altsecenek_ad" => $altsecenek_ad,
"siparisitem_id" => $siparisitem_id

                            ));

                            $say2++;

                        }

                       }


                        





                        


    
    $say++;

}




   

    $sepetsil=$db->prepare("DELETE from sepetitem where kullanici_id=:id");
    $sepetsil->execute(array(

    "id" => $kullanici_id

    ));

    $sepetitemseceneklersil=$db->prepare("DELETE from sepetitemsecenekler where kullanici_id=:id");
    $sepetitemseceneklersil->execute(array(

    "id" => $kullanici_id

    ));

    

                        $genelayarsec=$db->prepare("SELECT * from genelayarlar");
            $genelayarsec->execute();

            $genelayarcek=$genelayarsec->fetch(PDO::FETCH_ASSOC);
            $ayar_mail = $genelayarcek['ayar_mail'];
            $ayar_mailsifre = $genelayarcek['ayar_mailsifre'];
            $ayar_mailbaslik = $genelayarcek['ayar_mailbaslik'];

                        require("phpmailer/class/class.phpmailer.php");

            $mail = new PHPMailer(); // Sinifimizi $mail degiskenine atadik
 $mail->CharSet  ="utf-8";
 $mail->Encoding="base64";
$mail->IsSMTP();  // Mailimizin SMTP ile gönderilecegini belirtiyoruz
$mail->Host     = "smtpout.secureserver.net";//"localhost"; //SMTP server adresi
$mail->Port     = '80'; 
$mail->SMTPAuth = true; //SMTP server'a kullanici adi ile baglanilcagini belirtiyoruz.
$mail->Username = $ayar_mail;//"admin@localhost"; //SMTP kullanici adi
$mail->Password = $ayar_mailsifre;//""; //SMTP mailinizin sifresi
$mail->SMTPSecure = 'SSL';
$mail->From     = $ayar_mail;//"admin@localhost"; //Gönderen kisminda yer alacak e-mail adresi
$mail->FromName = $ayar_mailbaslik;//"PHP Mailer";//gönderenin ismi
$mail->AddAddress($ayar_mail); // Mail gönderilecek adresleri ekliyoruz.
$mail->IsHTML(true); //Mailimizin HTML formatinda hazirlanacagini bildiriyoruz.
$mail->Subject  = 'Yeni Sipariş Var!';//"Deneme Maili"; // Mailin Konusu Konu


    $mail->Body = "<div align='center' style='width:100%;height:450px;background-color:#EFEEEA;padding-top:50px;padding-bottom:50px;'>
    
    <div align='left' style='width:65%;background-color:#ffffff;height:350px;padding:19px;'>

    <h1 style='text-align:center;'>Yeni bir sipariş var!</h1><p style='font-size:19px;'>
    <b>Ad : </b>".$siparis_ad."<br>
    <b>Soyad : </b>".$siparis_soyad."<br>
    <b>GSM : </b>".$siparis_telno."<br>
    <b>İl : </b>".$sehircek['sehir_isim']."<br>
    <b>İlçe : </b>".$siparis_ilce."<br>
    <b>Ara Toplam : </b>".$siparis_aratoplam." TL <br>
    <b>Toplam : </b>".$siparis_toplam." TL <br>
    <p style='font-size:14.5px;'>Detaylara yönetim panelinizden ulaşabilirsiniz.</p>
    </p><h2><h2></div>

    

    

    </div>";

    $mail->Send();

        echo "ok";

} else {

    echo "hata";
}

 } else if (isset($_POST['siparisturusecajax'])){

 $siparis_turu=$_POST['siparis_turu'];
 $kullanici_id=$_SESSION['kullanici_id'];

 if ($siparis_turu=='tumu') {
    
    $siparislerimsec=$db->prepare("SELECT * from siparisler where kullanici_id=:id order by siparis_zaman DESC");
$siparislerimsec->execute(array(
"id" => $kullanici_id
));



 } else if ($siparis_turu=='teslimedildi'){

    $siparislerimsec=$db->prepare("SELECT * from siparisler where kullanici_id=:id and siparis_ulasmis=:ulasmis order by siparis_zaman DESC");
$siparislerimsec->execute(array(
"id" => $_SESSION['kullanici_id'],
"ulasmis" => 1
));



 } else if ($siparis_turu=='bekleniyor'){

    $siparislerimsec=$db->prepare("SELECT * from siparisler where kullanici_id=:id and siparis_ulasmis=:ulasmis order by siparis_zaman DESC");
$siparislerimsec->execute(array(
"id" => $_SESSION['kullanici_id'],
"ulasmis" => 0
));


 } else if ($siparis_turu=='kargoyaverildi'){

    $siparislerimsec=$db->prepare("SELECT * from siparisler where kullanici_id=:id and siparis_ulasmis=:ulasmis order by siparis_zaman DESC");
$siparislerimsec->execute(array(
"id" => $_SESSION['kullanici_id'],
"ulasmis" => 2
));


 } else {

echo "gecersizfiltre";
exit;

 } ;

 $siparislerimsay=$siparislerimsec->rowCount();

  ?>


<?php if ($siparislerimsay==0) { ?>
    
    <h4 style="font-family: Arial;" align="center">Sipariş Geçmişi Bulunamadı.</h4>

<?php } else { ?>



                            
                            <table class="shop_table cart wishlist_table wishlist_view traditional table">
                                <thead>
                                    <tr>
                                       
                                        <th class="product-name"><span class="nobr">Sipariş No</span></th>
                                        <th class="product-name"><span class="nobr">Sipariş Tarihi</span></th>
                                        <th class="product-name"><span class="nobr">Ürün Sayısı</span></th>
                                        <th class="product-name"><span class="nobr">Ara Toplam</span></th>
                                        <th class="product-price"> <span class="nobr">Kargo Ücreti</span></th>
                                        <th class="product-price"> <span class="nobr">Taksit</span></th>
                                        <th class="product-price"> <span class="nobr">Vade Farkı</span></th>
                                        <th class="product-price"> <span class="nobr">Toplam</span></th>
                                        <th class="product-stock-status"> <span class="nobr"> Teslimat </span></th>
                                        <th class="product-add-to-cart"> <span class="nobr"> </span></th>
                                        
                                        
                                    </tr>
                                </thead>
                                <tbody class="wishlist-items-wrapper">

                                     <?php while ($siparislerimcek=$siparislerimsec->fetch(PDO::FETCH_ASSOC)) {

                                    $siparis_kargoucreti = $siparislerimcek['siparis_kargoucreti'];
                      $siparis_taksit = $siparislerimcek['siparis_taksit'];
                      $siparis_vadefarki = $siparislerimcek['siparis_vadefarki']; 

$siparis_id=$siparislerimcek['siparis_id'];
                       $siparis_zaman = $siparislerimcek['siparis_zaman'];
                       $d = new DateTime($siparis_zaman);
                        $zamanson =  $d->format('d/m/Y');
                      
                      $siparisitemsec=$db->prepare("SELECT * from siparisitem where siparis_id=:id");
                      $siparisitemsec->execute(array(

                        "id" => $siparis_id

                      ));

                      $siparisitemsay=$siparisitemsec->rowCount();

                      $siparis_aratoplam=$siparislerimcek['siparis_aratoplam'];
                      $siparis_toplam=$siparislerimcek['siparis_toplam'];
                      $siparis_teslimat=$siparislerimcek['siparis_ulasmis'];

                ?>
                                    
                                    <tr>
                                        
                                        <td class="product-name"> <?php echo $siparis_id; ?></td>
                                        <td class="product-name"> <?php echo $zamanson; ?></td>
                                        <td class="product-name"> <?php echo $siparisitemsay; ?></td>
                                        <td class="product-name"> <?php echo $siparis_aratoplam; ?> TL</td>
                                        <td class="product-name"> <?php echo $siparis_kargoucreti; ?> TL</td>
                                        <td class="product-name"> <?php echo $siparis_taksit; ?></td>
                                        <td class="product-name"> <?php echo $siparis_vadefarki; ?> TL</td>
                                        <td class="product-name"> <?php echo $siparis_toplam; ?> TL</td>

                                        <?php if ($siparis_teslimat==0) { ?>

                                            <td class="product-name"><span style="color:#FA3B12;" class="wishlist-in-stock"><i class="far fa-clock"></i> Hazırlanıyor</span></td>

                            
                            
                        <?php } else if ($siparis_teslimat==1) { ?>

                            <td class="product-name"><span style="color:green;" class="wishlist-in-stock"><i class="fas fa-check"></i> Teslim Edildi</span></td>
                           
                           
                        <?php } else if ($siparis_teslimat==2){ ?>

                           
                      <td class="product-name"><span style="color:#225E88;" class="wishlist-in-stock"><i class="fas fa-truck"></i> Kargoya Verildi</span></td>
                        

                        <?php } ?>

                        <td class="product-add-to-cart">
                                            <!-- Date added -->
                                            <!-- Add to cart button --><a href="siparis-detay?siparis_id=<?php echo $siparis_id; ?>" class="button add_to_cart_button add_to_cart alt"
                                                 aria-label="">Detaylar</a>
                                            <!-- Change wishlist -->
                                            <!-- Remove from wishlist -->
                                        </td>



                                    </tr>

                         <?php } ?>

                                </tbody>
                            </table>
                        
                        







 <?php }  } else if (isset($_POST['kullanicimailgonder'])){

 $kullanici_mail = trim($_POST['kullanici_mail']);
 $kullanici_adsoyad = trim($_POST['kullanici_adsoyad']);
 $mail_icerik = trim($_POST['mail_icerik']);

 //Hack Önleme -----

    botkontrol();

    if (mb_strlen($kullanici_adsoyad,'UTF-8')>150 or mb_strlen($kullanici_mail,'UTF-8')>150 or mb_strlen($kullanici_adsoyad,'UTF-8')<2 or mb_strlen($kullanici_mail,'UTF-8')<6 or mb_strlen($mail_icerik,'UTF-8')<6 or !isset($_POST['kullanici_adsoyad']) or !isset($_POST['mail_icerik']) or !isset($_POST['kullanici_mail']) or filter_var($kullanici_mail, FILTER_VALIDATE_EMAIL) == false) {
        
        exit;
    }



    //-----------

 $genelayarsec=$db->prepare("SELECT * from genelayarlar");
            $genelayarsec->execute();

            $genelayarcek=$genelayarsec->fetch(PDO::FETCH_ASSOC);
            $ayar_mail = $genelayarcek['ayar_mail'];
            $ayar_mailsifre = $genelayarcek['ayar_mailsifre'];
            $ayar_logo = $genelayarcek['ayar_logo'];
            $ayar_mailbaslik = $genelayarcek['ayar_mailbaslik'];

 require("phpmailer/class/class.phpmailer.php");

            $mail = new PHPMailer(); // Sinifimizi $mail degiskenine atadik
 $mail->CharSet  ="utf-8";
 $mail->Encoding="base64";
$mail->IsSMTP();  // Mailimizin SMTP ile gönderilecegini belirtiyoruz
$mail->Host     = "smtpout.secureserver.net";//"localhost"; //SMTP server adresi
$mail->Port     = '80'; 
$mail->SMTPAuth = true; //SMTP server'a kullanici adi ile baglanilcagini belirtiyoruz.
$mail->Username = $ayar_mail;//"admin@localhost"; //SMTP kullanici adi
$mail->Password = $ayar_mailsifre;//""; //SMTP mailinizin sifresi
$mail->SMTPSecure = 'SSL';
$mail->From     = $kullanici_mail;//"admin@localhost"; //Gönderen kisminda yer alacak e-mail adresi
$mail->FromName = $ayar_mailbaslik;//"PHP Mailer";//gönderenin ismi
$mail->AddEmbeddedImage($ayar_logo, 'logo');
$mail->AddAddress($ayar_mail); // Mail gönderilecek adresleri ekliyoruz.
$mail->IsHTML(true); //Mailimizin HTML formatinda hazirlanacagini bildiriyoruz.
$mail->Subject  = "Website Mail Form";//"Deneme Maili"; // Mailin Konusu Konu


    $mail->Body = "<div align='center'>

    <div style='width:90%;padding:20px;'>

 <div style='width:100%;'>
 <img src='cid:logo'>
 </div>
 <hr>

 <p style='text-align:center;'>".$ayar_mailbaslik." web sitenizin iletişim sayfasından yeni bir mail var.
 <br><br>
 Ad & Soyad : ".$kullanici_adsoyad."<br>
 Mail Adresi : ".$kullanici_mail."<br><br>
 Mesaj : ".$mail_icerik."
 </p>

    </div>

    

    
</div>

    ";

    $mail->Send();

    echo "ok";







 } else if (isset($_POST['favorilereekle'])){

$urun_id = $_POST['urun_id'];
$kullanici_id = $_SESSION['kullanici_id'];

 //Hack Kontrol

$urunsec = $db->prepare("SELECT * from urunler where urun_id='$urun_id' and urun_kaldirildi='0'");
$urunsec->execute();
$urunsay = $urunsec->rowCount();

$favorilersec = $db->prepare("SELECT * from favoriler where kullanici_id='$kullanici_id' and urun_id='$urun_id'");
$favorilersec->execute();
$favorilersay = $favorilersec->rowCount();

if ($urunsay==0 or $favorilersay==1) {
    
    exit;
}

 //Hack Kontrol

$hazirla=$db->prepare("INSERT into favoriler set

kullanici_id=:kullanici_id,
urun_id=:urun_id
  ");

$derle=$hazirla->execute(array(

"kullanici_id" => $kullanici_id,
"urun_id" => $urun_id

));

if ($derle) {
  echo "ok";
}

 } else if (isset($_POST['favorilerdencikar'])){

 $urun_id = $_POST['urun_id'];
 $kullanici_id = $_SESSION['kullanici_id'];

 //Hack Kontrol


 $urunsec = $db->prepare("SELECT * from urunler where urun_id='$urun_id' and urun_kaldirildi='0'");
$urunsec->execute();
$urunsay = $urunsec->rowCount();

$favorilersec = $db->prepare("SELECT * from favoriler where kullanici_id='$kullanici_id' and urun_id='$urun_id'");
$favorilersec->execute();
$favorilersay = $favorilersec->rowCount();

if ($urunsay==0 or $favorilersay==0) {
    
    exit;
}

//

 $favorisil=$db->prepare("DELETE from favoriler where kullanici_id='$kullanici_id' and urun_id='$urun_id'");
 $silfavori = $favorisil->execute();

if ($silfavori) {
  echo "ok";
}


 } else if (isset($_POST['favorisil2'])){

$favori_id = $_POST['favori_id'];

//Hack Kontrol

$favorisec = $db->prepare("SELECT * from favoriler where favori_id='$favori_id'");
$favorisec->execute();
$favorisay = $favorisec->rowCount();
$favoricek = $favorisec->fetch(PDO::FETCH_ASSOC);

if ($favorisay==0 or ($_SESSION['kullanici_id'])!=$favoricek['kullanici_id']) {
    
    exit;
}

//

$favorisil=$db->prepare("DELETE from favoriler where favori_id=:id");
$silfavori=$favorisil->execute(array(
"id" => $favori_id
));

if ($silfavori) {
    
    echo "ok";
}

 } else if (isset($_POST['urunmiktarplus'])){

$kullanici_id = $_SESSION['kullanici_id'];
$sepetitem_id = $_POST['sepetitem_id'];

// Hack Kontrol --------

if (isset($_SESSION['kullanicioturum'])) {
    
$hackkontrolsec = $db->prepare("SELECT * from sepetitem where kullanici_id='$kullanici_id' and sepetitem_id='$sepetitem_id'");
$hackkontrolsec->execute();

} else {

$hackkontrolsec = $db->prepare("SELECT * from sepetitem where kullanici_ip='$ip_adresi' and sepetitem_id='$sepetitem_id'");
$hackkontrolsec->execute();

}

$hackkontrolsay = $hackkontrolsec->rowCount();

if ($hackkontrolsay == 0) {
    
    echo "gecersizid";
    exit;
}

//

$sepetitemsec=$db->prepare("SELECT * from sepetitem where sepetitem_id=:id");
$sepetitemsec->execute(array(

"id" => $sepetitem_id

));

$sepetitemcek=$sepetitemsec->fetch(PDO::FETCH_ASSOC);

$urun_miktar = $sepetitemcek['urun_miktar'];
$urunmiktaryeni =  $urun_miktar+1;

$urunsec=$db->prepare("SELECT * from urunler where urun_id=:id");
$urunsec->execute(array(
"id" => $sepetitemcek['urun_id']
));

$uruncek=$urunsec->fetch(PDO::FETCH_ASSOC);

if (($uruncek['urun_stok']-$urunmiktaryeni)<0) {
    
    echo "stokyok";
    exit;

} else {

    $hazirla=$db->prepare("UPDATE sepetitem set

urun_miktar=:urun_miktar

where sepetitem_id='$sepetitem_id'
    ");

$derle=$hazirla->execute(array(

"urun_miktar" => $urunmiktaryeni

));

if (isset($_SESSION['kullanicioturum'])) {
    
    $sepeturunsec=$db->prepare("SELECT * from sepetitem where kullanici_id=:id");
$sepeturunsec->execute(array(
"id" => $kullanici_id 
));

} else {

    $sepeturunsec=$db->prepare("SELECT * from sepetitem where kullanici_ip=:ip");
$sepeturunsec->execute(array(
"ip" => $ip_adresi 
));


}

$sepeturunsay = $sepeturunsec->rowCount();

 ?>

 
        
        
        <div class="row">
                    <div class="col-xl-8 col-lg-12 col-md-12 col-12">
                        <form class="woocommerce-cart-form">
                            <table class="shop_table cart">
                                <tr>
                                    <th class="product-thumbnail">&nbsp;</th>
                                    <th class="product-name">Ürün</th>
                                    <th class="product-price">Birim Fiyat</th>
                                    <th class="product-quantity">Adet</th>
                                    <th class="product-subtotal">Toplam</th>
                                    <th class="product-remove">&nbsp;</th>
                                </tr>
                                

                <?php 

          if (isset($_SESSION['kullanicioturum'])) {
            
            $sepeturunsec=$db->prepare("SELECT * from sepetitem where kullanici_id=:id order by urun_id DESC");
                    $sepeturunsec->execute(array(

                        "id" => $_SESSION['kullanici_id']
                    ));

          } else {

            $sepeturunsec=$db->prepare("SELECT * from sepetitem where kullanici_ip=:ip order by urun_id DESC");
                    $sepeturunsec->execute(array(

                        "ip" => $ip_adresi
                    ));


          }

                    $urun_toplam = 0;
                    $toplam_desi = 0;

                     

                    while ($sepeturuncek=$sepeturunsec->fetch(PDO::FETCH_ASSOC)) {

                    $sepetitem_id = $sepeturuncek['sepetitem_id'];  

                        $urunsec=$db->prepare("SELECT * from urunler where urun_id=:id");
                        $urunsec->execute(array(

                            "id" => $sepeturuncek['urun_id']
                        ));

                        $uruncek = $urunsec->fetch(PDO::FETCH_ASSOC);

                        $urun_marka = $uruncek['marka_id'];

                        if (($uruncek['urun_stok']-$sepeturuncek['urun_miktar']<0)) {

                            $sepetitemsil=$db->prepare("DELETE from sepetitem where sepetitem_id=:id");
                            $sepetitemsil->execute(array(

                                "id" => $sepeturuncek['sepetitem_id']
                            ));
                            

                        } else {

                          $sepetitemseceneksec = $db->prepare("SELECT * from sepetitemsecenekler where sepetitem_id='$sepetitem_id'");

                          $sepetitemseceneksec->execute();

                          

                             $urun_fiyat = $uruncek['urun_nihaifiyat'];

                            $urun_desi = $uruncek['urun_desi'];

                        $urun_toplamfiyat = $sepeturuncek['urun_miktar']*$urun_fiyat;
                        $urun_toplamdesi = $sepeturuncek['urun_miktar']*$urun_desi;

                        $urun_toplam+=$urun_toplamfiyat;
                        $toplam_desi+=$urun_toplamdesi;

                        $urun_ad=$uruncek['urun_ad'];

                $urunfotosec=$db->prepare("SELECT * from urunfoto where urun_id=:id and urunfoto_kapak=:kapak");
                $urunfotosec->execute(array(
                    "id" => $sepeturuncek['urun_id'],
                    "kapak" => 1

                ));

                $urunfotocek=$urunfotosec->fetch(PDO::FETCH_ASSOC);

                $markasec=$db->prepare("SELECT * from markalar where marka_id='$urun_marka'");
                        $markasec->execute();
                        $markacek=$markasec->fetch(PDO::FETCH_ASSOC);
                        $marka_ad=$markacek['marka_ad'];

                ?>

                                <tr id="sepetitem_<?php echo $sepeturuncek['sepetitem_id']; ?>" class="woocommerce-cart-form__cart-item cart_item">
                                    <td class="product-thumbnail">
                                        <a target="_blank" href='urun-<?php echo seo($urun_ad)."-".$uruncek['urun_id']; ?>'><img src="<?php echo $urunfotocek['urunfoto_yol']; ?>" alt="Ürün"></a>
                                    </td>
                                    <td class="product-name">
                                        <span style="font-weight: 500;"><?php echo $marka_ad; ?></span><br>
                                        <a target="_blank" href="urun-<?php echo seo($urun_ad)."-".$uruncek['urun_id']; ?>" class="product-name"><?php if (strlen($urun_ad)>36) { ?>
                            <?php echo substr($urun_ad,0,36)."..."; ?>
                        <?php } else { 

                         echo $urun_ad; 
                         } ?></a>
                                        <?php while ($sepetitemsecenekcek=$sepetitemseceneksec->fetch(PDO::FETCH_ASSOC)) { 
                $secenek_ad = $sepetitemsecenekcek['secenek_ad'];
                $altsecenek_ad = $sepetitemsecenekcek['altsecenek_ad']; ?> 


                                           <div class="variation">
                                                    <span><b><?php echo $secenek_ad; ?>:</b></span>
                                                    <span><?php echo $altsecenek_ad; ?></span>
                                                </div>
                            

              <?php } ?>
                                    </td>
                                    <td class="product-price">
                                        <span><bdi><?php echo $urun_fiyat." TL"; ?></bdi>
                                        </span>
                                    </td>
                                    <td class="product-quantity">
                                        
                                        <?php if ($sepeturuncek['urun_miktar']!=1) { ?>
                                <a style="font-size: 13px;" name="sepetitem_<?php echo $sepeturuncek['sepetitem_id']; ?>" class="quantity-minus" href="javascript:void(0);"><i class="fa fa-minus-circle"></i></a>

                                <?php  } ?>
                                <?php echo $sepeturuncek['urun_miktar']; ?> <a style="font-size: 13px;" class="quantity-plus" href="javascript:void(0);" name="sepetitem_<?php echo $sepeturuncek['sepetitem_id']; ?>"><i class="fa fa-plus-circle"></i></a>
                                    </td>
                                    <td class="product-subtotal">
                                        <span><bdi><?php echo $urun_toplamfiyat. " TL"; ?></bdi>
                                        </span>
                                    </td>
                                    <td name="sepetitem_<?php echo $sepeturuncek['sepetitem_id']; ?>" class="product-remove sepetitemsil">
                                        <a href="javascript:void(0);" class="remove">×</a>
                                    </td>
                                </tr>

                            <?php } } ?>
                                
                            </table>
                        </form>
                    </div>

                    <?php

              $genelayarsec=$db->prepare("SELECT * from genelayarlar");
              $genelayarsec->execute();
              $genelayarcek=$genelayarsec->fetch(PDO::FETCH_ASSOC);

               if (!empty($genelayarcek['kargobedava_limit'])) {
                              
                              if ($urun_toplam>$genelayarcek['kargobedava_limit']) {

               $kargo_ucreti = 0.00;

               
                                

                              } else {


                                $kargoucretisec=$db->prepare("SELECT * from kargoucretleri where 
                                  min_desi<='$toplam_desi' and max_desi>'$toplam_desi'");
                                $kargoucretisec->execute();

                                $kargoucreticek=$kargoucretisec->fetch(PDO::FETCH_ASSOC);

                                


                   $kargo_ucreti = $kargoucreticek['kargo_ucreti'];

                              }

                            } else {

                              $kargoucretisec=$db->prepare("SELECT * from kargoucretleri where 
                                  min_desi<='$toplam_desi' and max_desi>'$toplam_desi'");
                                $kargoucretisec->execute();

                                $kargoucreticek=$kargoucretisec->fetch(PDO::FETCH_ASSOC);

                                

                               $kargo_ucreti = $kargoucreticek['kargo_ucreti'];


                            } ?>


                    <div class="col-xl-4 col-lg-12 col-md-12 col-12">
                        <div class="cart-collaterals">
                            <div class="cart_totals ">
                                <h2>Sepet</h2>
                                <table>
                                    <tr>
                                        <th>Ara Toplam</th>
                                        <td>
                                            <span><bdi><?php echo $urun_toplam." TL"; ?></bdi>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Kargo Ücreti</th>
                                       <td>
                                            <span><bdi><?php echo $kargo_ucreti." TL"; ?></bdi>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr class="order-total">
                                        <th>Toplam</th>
                                        <td><strong><span class="woocommerce-Price-amount amount"><bdi><?php echo $urun_toplam+$kargo_ucreti; ?> TL</bdi></span></strong> </td>
                                    </tr>
                                </table>
                                <div class="wc-proceed-to-checkout">
                                    <a href="odeme" class="checkout-button">Ödemeyi Tamamla</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
    



             <script type="text/javascript">

            $('.quantity-plus').click(function(){

var id1=$(this).attr("name");
         var sepetitem_id=id1.substring(10);

         $.ajax({

   type : 'POST',
            url : 'musteriislem.php',
            data : {'urunmiktarplus':'ok','sepetitem_id':sepetitem_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              if (sonuc=="stokyok") {

                 swal({
  title: "Stok Yetersiz",
  text: "Ürünü almak istediğiniz adet kadar stok mevcut değil.",
  icon: "info",
  dangerMode: true,
});


              } else {

                $('.cart-page-area').html('<h4 style="font-family:Arial;" align="center">Sepet Güncelleniyor...</h4>');

                $('.cart-page-area').html(sonuc);

              }

            

               }

               });



});

            $('.quantity-minus').click(function(){

var id1=$(this).attr("name");
         var sepetitem_id=id1.substring(10);

         $.ajax({

   type : 'POST',
            url : 'musteriislem.php',
            data : {'urunmiktarminus':'ok','sepetitem_id':sepetitem_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              $('.cart-page-area').html('<h3 align="center">Sepet Güncelleniyor...</h3>');

                $('.cart-page-area').html(sonuc);

            

               }

               });

         

});
            
            $('.sepetitemsil').click(function(){


         var id1=$(this).attr("name");
         var sepetitem_id=id1.substring(10);

         swal({
  title: "Emin misiniz?",
  text: "Bu ürünü sepetinizden kaldırmak istediğinize emin misiniz?",
  icon: "info",
  buttons: ["Vazgeç", "Kaldır"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

    $.ajax({

   type : 'POST',
            url : 'musteriislem.php',
            data : {'sepetitemsil':'ok','sepetitem_id':sepetitem_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

             if (sonuc=="ok") {

                 location.reload();

             }
               }

             });


     }

     })

         

    });


        </script>
                    





 <?php } } else if (isset($_POST['urunmiktarminus'])){

$kullanici_id = $_SESSION['kullanici_id'];
$sepetitem_id = $_POST['sepetitem_id'];

// Hack Kontrol --------

if (isset($_SESSION['kullanicioturum'])) {
    
$hackkontrolsec = $db->prepare("SELECT * from sepetitem where kullanici_id='$kullanici_id' and sepetitem_id='$sepetitem_id'");
$hackkontrolsec->execute();

} else {

$hackkontrolsec = $db->prepare("SELECT * from sepetitem where kullanici_ip='$ip_adresi' and sepetitem_id='$sepetitem_id'");
$hackkontrolsec->execute();

}

$hackkontrolsay = $hackkontrolsec->rowCount();

if ($hackkontrolsay == 0) {
    
    echo "gecersizid";
    exit;
}

//

$sepetitemsec=$db->prepare("SELECT * from sepetitem where sepetitem_id=:id");
$sepetitemsec->execute(array(

"id" => $sepetitem_id

));

$sepetitemcek=$sepetitemsec->fetch(PDO::FETCH_ASSOC);

$urun_miktar = $sepetitemcek['urun_miktar'];
$urunmiktaryeni =  $urun_miktar-1;

$hazirla=$db->prepare("UPDATE sepetitem set

urun_miktar=:urun_miktar

where sepetitem_id='$sepetitem_id'
    ");

$derle=$hazirla->execute(array(

"urun_miktar" => $urunmiktaryeni

));

if (isset($_SESSION['kullanicioturum'])) {
    
    $sepeturunsec=$db->prepare("SELECT * from sepetitem where kullanici_id=:id");
$sepeturunsec->execute(array(
"id" => $kullanici_id 
));

} else {

    $sepeturunsec=$db->prepare("SELECT * from sepetitem where kullanici_ip=:ip");
$sepeturunsec->execute(array(
"ip" => $ip_adresi
));

}

$sepeturunsay = $sepeturunsec->rowCount();

?>

<div class="row">
                    <div class="col-xl-8 col-lg-12 col-md-12 col-12">
                        <form class="woocommerce-cart-form">
                            <table class="shop_table cart">
                                <tr>
                                    <th class="product-thumbnail">&nbsp;</th>
                                    <th class="product-name">Ürün</th>
                                    <th class="product-price">Birim Fiyat</th>
                                    <th class="product-quantity">Adet</th>
                                    <th class="product-subtotal">Toplam</th>
                                    <th class="product-remove">&nbsp;</th>
                                </tr>
                                

                <?php 

          if (isset($_SESSION['kullanicioturum'])) {
            
            $sepeturunsec=$db->prepare("SELECT * from sepetitem where kullanici_id=:id order by urun_id DESC");
                    $sepeturunsec->execute(array(

                        "id" => $_SESSION['kullanici_id']
                    ));

          } else {

            $sepeturunsec=$db->prepare("SELECT * from sepetitem where kullanici_ip=:ip order by urun_id DESC");
                    $sepeturunsec->execute(array(

                        "ip" => $ip_adresi
                    ));


          }

                    $urun_toplam = 0;
                    $toplam_desi = 0;

                     

                    while ($sepeturuncek=$sepeturunsec->fetch(PDO::FETCH_ASSOC)) {

                    $sepetitem_id = $sepeturuncek['sepetitem_id'];  

                        $urunsec=$db->prepare("SELECT * from urunler where urun_id=:id");
                        $urunsec->execute(array(

                            "id" => $sepeturuncek['urun_id']
                        ));

                        $uruncek = $urunsec->fetch(PDO::FETCH_ASSOC);

                        $urun_marka = $uruncek['marka_id'];

                        if (($uruncek['urun_stok']-$sepeturuncek['urun_miktar']<0)) {

                            $sepetitemsil=$db->prepare("DELETE from sepetitem where sepetitem_id=:id");
                            $sepetitemsil->execute(array(

                                "id" => $sepeturuncek['sepetitem_id']
                            ));
                            

                        } else {

                          $sepetitemseceneksec = $db->prepare("SELECT * from sepetitemsecenekler where sepetitem_id='$sepetitem_id'");

                          $sepetitemseceneksec->execute();

                          

                            $urun_fiyat = $uruncek['urun_nihaifiyat'];

                            $urun_desi = $uruncek['urun_desi'];

                        $urun_toplamfiyat = $sepeturuncek['urun_miktar']*$urun_fiyat;
                        $urun_toplamdesi = $sepeturuncek['urun_miktar']*$urun_desi;

                        $urun_toplam+=$urun_toplamfiyat;
                        $toplam_desi+=$urun_toplamdesi;

                        $urun_ad=$uruncek['urun_ad'];

                $urunfotosec=$db->prepare("SELECT * from urunfoto where urun_id=:id and urunfoto_kapak=:kapak");
                $urunfotosec->execute(array(
                    "id" => $sepeturuncek['urun_id'],
                    "kapak" => 1

                ));

                $urunfotocek=$urunfotosec->fetch(PDO::FETCH_ASSOC);

                $markasec=$db->prepare("SELECT * from markalar where marka_id='$urun_marka'");
                        $markasec->execute();
                        $markacek=$markasec->fetch(PDO::FETCH_ASSOC);
                        $marka_ad=$markacek['marka_ad'];

                ?>

                                <tr id="sepetitem_<?php echo $sepeturuncek['sepetitem_id']; ?>" class="woocommerce-cart-form__cart-item cart_item">
                                    <td class="product-thumbnail">
                                        <a target="_blank" href='urun-<?php echo seo($urun_ad)."-".$uruncek['urun_id']; ?>'><img src="<?php echo $urunfotocek['urunfoto_yol']; ?>" alt="Ürün"></a>
                                    </td>
                                    <td class="product-name">
                                        <span style="font-weight: 500;"><?php echo $marka_ad; ?></span><br>
                                        <a target="_blank" href="urun-<?php echo seo($urun_ad)."-".$uruncek['urun_id']; ?>" class="product-name"><?php if (strlen($urun_ad)>36) { ?>
                            <?php echo substr($urun_ad,0,36)."..."; ?>
                        <?php } else { 

                         echo $urun_ad; 
                         } ?></a>
                                        <?php while ($sepetitemsecenekcek=$sepetitemseceneksec->fetch(PDO::FETCH_ASSOC)) { 
                $secenek_ad = $sepetitemsecenekcek['secenek_ad'];
                $altsecenek_ad = $sepetitemsecenekcek['altsecenek_ad']; ?> 


                                           <div class="variation">
                                                    <span><b><?php echo $secenek_ad; ?>:</b></span>
                                                    <span><?php echo $altsecenek_ad; ?></span>
                                                </div>
                            

              <?php } ?>
                                    </td>
                                    <td class="product-price">
                                        <span><bdi><?php echo $urun_fiyat." TL"; ?></bdi>
                                        </span>
                                    </td>
                                    <td class="product-quantity">
                                        
                                        <?php if ($sepeturuncek['urun_miktar']!=1) { ?>
                                <a style="font-size: 13px;" name="sepetitem_<?php echo $sepeturuncek['sepetitem_id']; ?>" class="quantity-minus" href="javascript:void(0);"><i class="fa fa-minus-circle"></i></a>

                                <?php  } ?>
                                <?php echo $sepeturuncek['urun_miktar']; ?> <a style="font-size: 13px;" class="quantity-plus" href="javascript:void(0);" name="sepetitem_<?php echo $sepeturuncek['sepetitem_id']; ?>"><i class="fa fa-plus-circle"></i></a>
                                    </td>
                                    <td class="product-subtotal">
                                        <span><bdi><?php echo $urun_toplamfiyat. " TL"; ?></bdi>
                                        </span>
                                    </td>
                                    <td name="sepetitem_<?php echo $sepeturuncek['sepetitem_id']; ?>" class="product-remove sepetitemsil">
                                        <a href="javascript:void(0);" class="remove">×</a>
                                    </td>
                                </tr>

                            <?php } } ?>
                                
                            </table>
                        </form>
                    </div>

                    <?php

                    $genelayarsec=$db->prepare("SELECT * from genelayarlar");
              $genelayarsec->execute();
              $genelayarcek=$genelayarsec->fetch(PDO::FETCH_ASSOC);

               if (!empty($genelayarcek['kargobedava_limit'])) {
                              
                              if ($urun_toplam>$genelayarcek['kargobedava_limit']) {

               $kargo_ucreti = 0.00;

               
                                

                              } else {


                                $kargoucretisec=$db->prepare("SELECT * from kargoucretleri where 
                                  min_desi<='$toplam_desi' and max_desi>'$toplam_desi'");
                                $kargoucretisec->execute();

                                $kargoucreticek=$kargoucretisec->fetch(PDO::FETCH_ASSOC);

                                


                   $kargo_ucreti = $kargoucreticek['kargo_ucreti'];

                              }

                            } else {

                              $kargoucretisec=$db->prepare("SELECT * from kargoucretleri where 
                                  min_desi<='$toplam_desi' and max_desi>'$toplam_desi'");
                                $kargoucretisec->execute();

                                $kargoucreticek=$kargoucretisec->fetch(PDO::FETCH_ASSOC);

                                

                               $kargo_ucreti = $kargoucreticek['kargo_ucreti'];


                            } ?>


                    <div class="col-xl-4 col-lg-12 col-md-12 col-12">
                        <div class="cart-collaterals">
                            <div class="cart_totals ">
                                <h2>Sepet</h2>
                                <table>
                                    <tr>
                                        <th>Ara Toplam</th>
                                        <td>
                                            <span><bdi><?php echo $urun_toplam." TL"; ?></bdi>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Kargo Ücreti</th>
                                       <td>
                                            <span><bdi><?php echo $kargo_ucreti." TL"; ?></bdi>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr class="order-total">
                                        <th>Toplam</th>
                                        <td><strong><span class="woocommerce-Price-amount amount"><bdi><?php echo $urun_toplam+$kargo_ucreti; ?> TL</bdi></span></strong> </td>
                                    </tr>
                                </table>
                                <div class="wc-proceed-to-checkout">
                                    <a href="odeme" class="checkout-button">Ödemeyi Tamamla</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <script type="text/javascript">

            $('.quantity-plus').click(function(){

var id1=$(this).attr("name");
         var sepetitem_id=id1.substring(10);

         $.ajax({

   type : 'POST',
            url : 'musteriislem.php',
            data : {'urunmiktarplus':'ok','sepetitem_id':sepetitem_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              if (sonuc=="stokyok") {

                 swal({
  title: "Stok Yetersiz",
  text: "Ürünü almak istediğiniz adet kadar stok mevcut değil.",
  icon: "info",
  dangerMode: true,
});


              } else {

                $('.cart-page-area').html('<h4 style="font-family:Arial;" align="center">Sepet Güncelleniyor...</h4>');

                $('.cart-page-area').html(sonuc);

              }

            

               }

               });



});

            $('.quantity-minus').click(function(){

var id1=$(this).attr("name");
         var sepetitem_id=id1.substring(10);

         $.ajax({

   type : 'POST',
            url : 'musteriislem.php',
            data : {'urunmiktarminus':'ok','sepetitem_id':sepetitem_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              $('.cart-page-area').html('<h3 align="center">Sepet Güncelleniyor...</h3>');

                $('.cart-page-area').html(sonuc);

            

               }

               });

         

});
            
            $('.sepetitemsil').click(function(){


         var id1=$(this).attr("name");
         var sepetitem_id=id1.substring(10);

         swal({
  title: "Emin misiniz?",
  text: "Bu ürünü sepetinizden kaldırmak istediğinize emin misiniz?",
  icon: "info",
  buttons: ["Vazgeç", "Kaldır"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

    $.ajax({

   type : 'POST',
            url : 'musteriislem.php',
            data : {'sepetitemsil':'ok','sepetitem_id':sepetitem_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

             if (sonuc=="ok") {

                 location.reload();

             }
               }

             });


     }

     })

         

    });


        </script>


                        

                    




 <?php } else if (isset($_POST['uruniadeform'])){

    
$kullanici_id = $_SESSION['kullanici_id'];
$siparisitem_id = $_POST['siparisitem_id'];
$iade_text = trim($_POST['iade_text']);
$iade_miktar = $_POST['iade_miktar'];
$urun_fiyat = $_POST['urun_fiyat'];


//Hack Kontrol ----------

botkontrol();

$siparisitemsec = $db->prepare("SELECT * from siparisitem where kullanici_id='$kullanici_id' and urun_fiyat='$urun_fiyat' and siparisitem_id='$siparisitem_id'");
$siparisitemsec->execute();
$siparisitemcek=$siparisitemsec->fetch(PDO::FETCH_ASSOC);
$urun_miktar = $siparisitemcek['urun_miktar'];
$siparisitemsay = $siparisitemsec->rowCount();


if (!isset($_POST['iade_text']) or mb_strlen($iade_text,'UTF-8')>1000 or $siparisitemsay==0 or ctype_digit($urun_miktar)==false or $iade_miktar < 1 or $iade_miktar > $urun_miktar) {
    
    exit;
}



//--------

$iade_tutar = $urun_fiyat*$iade_miktar;

$hazirla=$db->prepare("UPDATE siparisitem set

urun_iade=:urun_iade,
iade_text=:iade_text,
iade_goruldu=:iade_goruldu,
iade_tarihi=:iade_tarihi,
iade_miktar=:iade_miktar,
iade_tutar=:iade_tutar

where siparisitem_id='$siparisitem_id'
    ");

$derle = $hazirla->execute(array(
"urun_iade" => 1,
"iade_text" => htmlspecialchars($iade_text),
"iade_goruldu" => 0,
"iade_tarihi" => date('Y-m-d H:i:s'),
"iade_miktar" => $iade_miktar,
"iade_tutar" => $iade_tutar
));

if ($derle) {

    $genelayarsec=$db->prepare("SELECT * from genelayarlar");
            $genelayarsec->execute();

            $genelayarcek=$genelayarsec->fetch(PDO::FETCH_ASSOC);
            $ayar_mail = $genelayarcek['ayar_mail'];
            $ayar_mailsifre = $genelayarcek['ayar_mailsifre'];
            $ayar_mailbaslik = $genelayarcek['ayar_mailbaslik'];
            $ayar_logo = $genelayarcek['ayar_logo'];

            require("phpmailer/class/class.phpmailer.php");

    $mail = new PHPMailer(); // Sinifimizi $mail degiskenine atadik
 $mail->CharSet  ="utf-8";
 $mail->Encoding="base64";
$mail->IsSMTP();  // Mailimizin SMTP ile gönderilecegini belirtiyoruz
$mail->Host     = "smtpout.secureserver.net";//"localhost"; //SMTP server adresi
$mail->Port     = '80'; 
$mail->SMTPAuth = true; //SMTP server'a kullanici adi ile baglanilcagini belirtiyoruz.
$mail->Username = $ayar_mail;//"admin@localhost"; //SMTP kullanici adi
$mail->Password = $ayar_mailsifre;//""; //SMTP mailinizin sifresi
$mail->SMTPSecure = 'SSL';
$mail->From     = $ayar_mail;//"admin@localhost"; //Gönderen kisminda yer alacak e-mail adresi
$mail->FromName = $ayar_mailbaslik;//"PHP Mailer";//gönderenin ismi
$mail->AddEmbeddedImage($ayar_logo, 'logo');
$mail->AddAddress($ayar_mail); // Mail gönderilecek adresleri ekliyoruz.
$mail->IsHTML(true); //Mailimizin HTML formatinda hazirlanacagini bildiriyoruz.
$mail->Subject  = 'Yeni İade Talebi';//"Deneme Maili"; // Mailin Konusu Konu


    $mail->Body = "<div align='center'>

    <div style='width:90%;padding:20px;'>

 <div style='width:100%;'>
 <img src='cid:logo'>
 </div>
 <hr>

 <p style='text-align:center;'>Yeni bir ürün iade talebi yapıldı.<br> Yönetim panelinizden tüm detaylara ulaşabilirsiniz.</p>

    </div>

    

    
</div>

    ";

    $mail->Send();
    
    echo "ok";
}

 } else if (isset($_POST['sifremiunuttum'])){

    

$kullanici_mail = trim($_POST['kullanici_mail']);

// Hack Kontrol ---------

botkontrol();

if (!isset($_POST['kullanici_mail']) or mb_strlen($kullanici_mail,'UTF-8')>100) {
   
exit;

}

// -----------

$kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_mail=:mail and kullanici_yetki='1'");
$kullanicisec->execute(array(
"mail" => $kullanici_mail
));

$kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

$kullanicisay=$kullanicisec->rowCount();

if ($kullanicisay==0) {
    
    echo "kullanicibulunamadi";

} else {

    
$domain = $_POST['domain'];
    

        $kullanici_id=$kullanicicek['kullanici_id'];

    $uniq=uniqid();

    $hazirla=$db->prepare("UPDATE kullanici set

kullanici_uniq=:kullanici_uniq

where kullanici_id='$kullanici_id'
        ");

    $derle=$hazirla->execute(array(

"kullanici_uniq" =>  $uniq
    ));

    if ($derle) {

        $genelayarsec=$db->prepare("SELECT * from genelayarlar");
            $genelayarsec->execute();

            $genelayarcek=$genelayarsec->fetch(PDO::FETCH_ASSOC);
            $ayar_mail = $genelayarcek['ayar_mail'];
            $ayar_mailsifre = $genelayarcek['ayar_mailsifre'];
            $ayar_mailbaslik = $genelayarcek['ayar_mailbaslik'];
            $ayar_logo = $genelayarcek['ayar_logo'];
        
        require("phpmailer/class/class.phpmailer.php");

    $mail = new PHPMailer(); // Sinifimizi $mail degiskenine atadik
 $mail->CharSet  ="utf-8";
 $mail->Encoding="base64";
$mail->IsSMTP();  // Mailimizin SMTP ile gönderilecegini belirtiyoruz
$mail->Host     = "smtpout.secureserver.net";//"localhost"; //SMTP server adresi
$mail->Port     = '80'; 
$mail->SMTPAuth = true; //SMTP server'a kullanici adi ile baglanilcagini belirtiyoruz.
$mail->Username = $ayar_mail;//"admin@localhost"; //SMTP kullanici adi
$mail->Password = $ayar_mailsifre;//""; //SMTP mailinizin sifresi
$mail->SMTPSecure = 'SSL';
$mail->From     = $ayar_mail;//"admin@localhost"; //Gönderen kisminda yer alacak e-mail adresi
$mail->FromName = $ayar_mailbaslik;//"PHP Mailer";//gönderenin ismi
$mail->AddEmbeddedImage($ayar_logo, 'logo');
$mail->AddAddress($kullanici_mail); // Mail gönderilecek adresleri ekliyoruz.
$mail->IsHTML(true); //Mailimizin HTML formatinda hazirlanacagini bildiriyoruz.
$mail->Subject  = 'Şifrenizi Yenileyin';//"Deneme Maili"; // Mailin Konusu Konu


  $mail->Body = "<div align='center'>

    <div style='width:90%;padding:20px;'>

 <div style='width:100%;'>
 <img src='cid:logo'>
 </div>
 <hr>

 <p style='text-align:center;font-size:19px;'>Aşağıdaki linke tıklayıp şifrenizi yenileyebilirsiniz.
 <br><br>
 
 <a style='font-size:18px;' href='https://".$domain."/sifre-yenile?u=".$uniq."&id=".$kullanici_id."'>".$domain."/sifre-yenile?u=".$uniq."&id=".$kullanici_id."</a>

 </p>

    </div>

    

    
</div>

    ";


   
    
 



 


 

$mail->Send();

echo "ok";
    }

    }

} else if(isset($_POST['sifreyenile'])){

    

$kullanici_id=$_POST['kullanici_id'];
$kullanici_uniq=$_POST['kullanici_uniq'];

// Hack Kontrol -------

botkontrol();

$kullanicikontrolsec = $db->prepare("SELECT * from kullanici where kullanici_id='$kullanici_id' and kullanici_uniq='$kullanici_uniq'");
$kullanicikontrolsec->execute();
$kullanicikontrolsay=$kullanicikontrolsec->rowCount();

if ($kullanicikontrolsay==0 or mb_strlen($_POST['yeni_sifre'],'UTF-8')>100 or !isset($_POST['yeni_sifre']) or !isset($_POST['kullanici_id']) or !isset($_POST['kullanici_uniq'])) {
    
    exit;
}

//---------

$kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_id=:id");
    $kullanicisec->execute(array(
"id" => $kullanici_id
    ));

    $kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

    $kullanici_mail=$kullanicicek['kullanici_mail'];

    $yeni_sifre=$_POST['yeni_sifre'];
$yeni_sifre_tekrar=$_POST['yeni_sifre_tekrar'];

 if(strlen($yeni_sifre)<8){

echo "kisasifre";

} else if($yeni_sifre!=$yeni_sifre_tekrar){

    echo "uyusmayansifre";

} else {

    $hazirla=$db->prepare("UPDATE kullanici set

kullanici_password=:kullanici_password

where kullanici_id='$kullanici_id'
        ");

    $derle=$hazirla->execute(array(

"kullanici_password" => htmlspecialchars(md5($yeni_sifre))
    ));

    if ($derle) {

 $_SESSION['kullanicioturum'] = $kullanici_mail;
        echo "ok";

    } else {

echo "hata";
    }

    
}


} else if (isset($_POST['taksitsecenekdegistir'])){

$secenek_id = $_POST['secenek_id'];
$kullanici_id = $_SESSION['kullanici_id'];
$kullanicisec = $db->prepare("SELECT * from kullanici where kullanici_id='$kullanici_id'");
$kullanicisec->execute();
$kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

// Hack Kontrol ---------

$cart_aratoplamhack = $kullanicicek['cart_aratoplam'];

$taksitaraliksec=$db->prepare("SELECT * from taksitler where taksit_altdeger<='$cart_aratoplamhack' and taksit_ustdeger>'$cart_aratoplamhack'");
$taksitaraliksec->execute();

$taksitaralikcek=$taksitaraliksec->fetch(PDO::FETCH_ASSOC);

$taksit_id = $taksitaralikcek['taksit_id'];

$taksitimkansec=$db->prepare("SELECT * from taksitaraliksecenekleri where taksit_id='$taksit_id' and secenek_id='$secenek_id'");

$taksitimkansec->execute();

$taksitimkansay = $taksitimkansec->rowCount();

if ($secenek_id!='0' and ($taksitimkansay==0 or !isset($_POST['secenek_id']))) {
  
  echo "gecersiztaksitid";
  exit;

}

//---------------

if ($secenek_id=='0') {
  
    $hazirla = $db->prepare("UPDATE kullanici set

cart_taksitsecenegi=:cart_taksitsecenegi,
cart_vadefarki=:cart_vadefarki

where kullanici_id='$kullanici_id'

        ");

    $derle = $hazirla->execute(array(

"cart_taksitsecenegi" => 1,
"cart_vadefarki" => 0

    )); ?>
                                                                
                            <tr class="order-total toplamtutartr">
            <th>Toplam</th>
        <td><strong><span class="woocommerce-Price-amount amount"><bdi><?php echo $kullanicicek['cart_aratoplam']+$kullanicicek['cart_kargoucreti']; ?> TL</bdi></span></strong> </td>
                </tr>


<?php } else {


$taksitseceneksec = $db->prepare("SELECT * from taksitsecenekleri where secenek_id='$secenek_id'");
$taksitseceneksec->execute();
$taksitsecenekcek=$taksitseceneksec->fetch(PDO::FETCH_ASSOC);
$secenek_ad = $taksitsecenekcek['secenek_ad'];
$secenek_vadefarki = $taksitsecenekcek['secenek_vadefarki']." ";
$kullanicicek['cart_aratoplam']." ";
$vadefarkitl = ($kullanicicek['cart_aratoplam']/100)*$secenek_vadefarki." ";
$taksitlifiyat = $kullanicicek['cart_aratoplam']+$vadefarkitl." ";
$cart_kargoucreti = $kullanicicek['cart_kargoucreti']." ";
$bigprice = $taksitlifiyat+$cart_kargoucreti;

$hazirla = $db->prepare("UPDATE kullanici set

cart_taksitsecenegi=:cart_taksitsecenegi,
cart_vadefarki=:cart_vadefarki

where kullanici_id='$kullanici_id'

    ");

$derle = $hazirla->execute(array(

"cart_taksitsecenegi" => $secenek_ad,
"cart_vadefarki" => $vadefarkitl

)); ?>




<tr class="cart-shippingfee vadefarkitr">
                                                                   <th>Vade Farkı</th>
                                                                    <td><span class="woocommerce-Price-amount amount"><bdi><?php echo round($vadefarkitl,2); ?> TL</bdi>
                                                                        </span>
                                                                    </td>
                                                                </tr>
                                                                
                                                                <tr class="order-total toplamtutartr">
                                                                    <th>Toplam</th>
                                                                    <td><strong><span class="woocommerce-Price-amount amount"><bdi><?php echo round($bigprice,2); ?> TL</bdi></span></strong> </td>
                                                                </tr>




<?php } } ?>

 