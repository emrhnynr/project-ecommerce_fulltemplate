<?php require_once 'header.php';

$urun_id=$_GET['urun_id'];

$urunsec=$db->prepare("SELECT * from urunler where urun_id=:id and urun_kaldirildi=:kaldirildi");
$urunsec->execute(array(
"id" => $urun_id,
"kaldirildi" => 0

));

$urunsay=$urunsec->rowCount();

$uruncek=$urunsec->fetch(PDO::FETCH_ASSOC);



if ($urunsay==0) {
  
  header("Location:index");
  exit;
}
 ?>
        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Ürün Fotoğrafları</h3>
              </div>

             
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2><?php echo $uruncek['urun_ad']; ?></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <a target="_blank" class="btn btn-primary" href="urun-duzenle?urun_id=<?php echo $uruncek['urun_id'] ?>">Ürün Düzenle </a>
                      <a target="_blank" class="btn btn-success" href="../../urun-<?php echo seo($uruncek['urun_ad'])."-".$urun_id; ?>">Ürün Sayfası </a>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <div class="row">

                      <input type="hidden" value="<?php echo $urun_id; ?>" id="urun_id" name="">
                      

           <?php 
           $urunfotosec=$db->prepare("SELECT * from urunfoto where urun_id=:id order by urunfoto_kapak DESC, foto_sira ASC");
           $urunfotosec->execute(array(
            "id" => $urun_id
          ));

          while ($urunfotocek=$urunfotosec->fetch(PDO::FETCH_ASSOC)) { 
            $urunfoto_id=$urunfotocek['urunfoto_id'];
            $urunfoto_kapak = $urunfotocek['urunfoto_kapak'];
            $foto_sira = $urunfotocek['foto_sira']; ?>
             <div style="margin-bottom:50px;" class="col-md-3 col-sm-3 col-xs-12">

              <div class="col-md-12 col-xs-12 col-sm-12">

                <?php if ($urunfoto_kapak==1) { ?> 

                  <input class="form-control" type="text"  value='Kapak' disabled=''>

                 <?php } else { ?>

                  <input class="form-control" type="number" min="1" id="urunfoto_<?php echo $urunfoto_id; ?>" value='<?php echo $foto_sira; ?>' name='' >


                 <?php } ?>

                 <button <?php if ($urunfoto_kapak==1) { ?>
                   disabled=''
                <?php } ?> class="btn btn-success btn-block fotosiraguncelle" name='urunfoto_<?php echo $urunfoto_id; ?>' >Sıra Güncelle</button>
                
              </div>
              
               <div style="position: relative;margin-top:15px;" class="col-md-12 col-sm-12 col-xs-12 image">
                <a class="urunfotosil" name="urunfoto_<?php echo $urunfoto_id; ?>" href="javascript:void(0);"><i class="fa fa-times-circle" style="position: absolute;top:-5px;right: 5px;font-size:20px;color:red;"></i></a>
                 <img class="img-responsive" src="../../<?php echo $urunfotocek['urunfoto_yol']; ?>">
               </div>
               <div style="margin-top:15px;" class='col-md-12 col-xs-12 col-sm-12'>
                 
                  <?php if ($urunfoto_kapak==1) { ?>

                   <h4 style="color:#707070;" align="center">Kapak Fotoğrafı</h4>
                    
                 <?php } else { ?>

                   <a name="urunfoto_<?php echo $urunfoto_id; ?>" class="btn btn-primary btn-block kapakfotodegistir" href="javascript:void(0);">Kapak Fotoğrafı Yap</a>


                  <?php } ?>
               
               </div>
             </div>
                      
          <?php } ?>

          <div style="margin-bottom:50px;" class="col-md-3 col-sm-3 col-xs-12">
              
               <div style="position: relative;border:1px dashed;height: 200px;" class="col-md-12 col-sm-12 col-xs-12 imageadd">

                <div class="col-md-12 col-xs-12 col-sm-12" style="height: 130px;">
                  <h3 align="center">Yükle <i class="fa fa-upload"></i></h3>
                  <p style="font-size:14px;" align="center">Resim yüklemek için aşağıdan resmi seçin veya aşağıya sürükleyip bırakın. (800x800px)</p>
                </div>
                
                 <input style="height: 55px;" class="form-control urunfotoekle" type="file"   name="">
               </div>
              
             </div>
            

                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
       
       <?php require_once 'footer.php'; ?>
       <script type="text/javascript">

        $('.fotosiraguncelle').click(function(){

          var id1=$(this).attr("name");
                var urunfoto_id=id1.substring(9);
                var urun_id = $('#urun_id').val();
                var sira = $('#urunfoto_'+urunfoto_id).val();

                $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'urunfotosiraguncelle':'ok','urunfoto_id':urunfoto_id,'sira':sira},
            success : function(sonuc){

              $('.x_content').html('<h3 align="center">Yükleniyor...</h3>');

              $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'urunfotoreload':'ok','urun_id':urun_id},
            success : function(sonuc){

             var sonuc = $.trim(sonuc);
              
              $('.x_content').html(sonuc);

              

               }

             });

               }

               });


        });

        $('.kapakfotodegistir').click(function(){

          var id1=$(this).attr("name");
                var urunfoto_id=id1.substring(9);
                var urun_id = $('#urun_id').val();

                swal({
  title: "Emin misiniz?",
  text: "Bu fotoğraf kapak fotoğrafı yapılsın mı?",
  icon: "info",
  buttons: ["Vazgeç", "Evet"]
})
.then((willDelete) => {
  if (willDelete) {

$.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'urunfotokapakdegistir':'ok','urunfoto_id':urunfoto_id,'urun_id':urun_id},
            success : function(sonuc){

              $('.x_content').html('<h3 align="center">Yükleniyor...</h3>');

              $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'urunfotoreload':'ok','urun_id':urun_id},
            success : function(sonuc){

             var sonuc = $.trim(sonuc);
              
              $('.x_content').html(sonuc);

              

               }

             });

               }

               })
     }

     })


        });


         
         $('.urunfotosil').click(function(){

          var id1=$(this).attr("name");
                var urunfoto_id=id1.substring(9);
                var urun_id = $('#urun_id').val();

                swal({
  title: "Emin misiniz?",
  text: "Ürünün bu fotoğrafını silmek istiyor musunuz?",
  icon: "warning",
  buttons: ["Vazgeç", "Sil"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

    $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'urunfotosil':'ok','urunfoto_id':urunfoto_id},
            success : function(sonuc){

              $('.x_content').html('<h3 align="center">Yükleniyor...</h3>');

               $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'urunfotoreload':'ok','urun_id':urun_id},
            success : function(sonuc){

             var sonuc = $.trim(sonuc);
              
              $('.x_content').html(sonuc);

              

               }

             });



               }

             });


     }

     })
         });


         $('.urunfotoekle').change(function(){

          var input = $(this);
            
           
       var urun_id = $('#urun_id').val();
      var foto = $(this).val();
      var filevalue = $(this).get(0).files[0];

      if (foto.length!=0) {

        swal({
  title: "Emin misiniz?",
  text: "Bu fotoğraf ürün galerisine eklenecek.",
  icon: "info",
  buttons: ["Vazgeç", "Ekle"]
})
.then((willDelete) => {
  if (willDelete) {


    var fotouzanti=foto.split('.').pop();

      

      var data = new FormData();
      data.append('urunfotoekle',"ok");
      data.append("file",filevalue);
      data.append('urun_id',urun_id);

      if (fotouzanti!='jpg' && fotouzanti!='jpeg' && fotouzanti!='png'){


           swal({

  title: "Bilgi",
  text: "Sadece .jpg, .jpeg, .png uzantılı dosyaları yükleyebilirsiniz.",
  icon: "info",
  button: "OK",
});


               } else {

                $('.imageadd').html('<h3 style="margin-top:80px;" align="center">Ekleniyor...</h3>');

               $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            enctype : 'multipart/form-data',
            data : data,
            processData: false,
            contentType: false,
            cache: false,
            success : function(sonuc){

            sonuc=$.trim(sonuc);

           if (sonuc=="ok") {

 $('.x_content').html('<h3 align="center">Yükleniyor...</h3>');

               $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'urunfotoreload':'ok','urun_id':urun_id},
            success : function(sonuc){

             var sonuc = $.trim(sonuc);
              
              $('.x_content').html(sonuc);

              

               }

             });

           } else {

            location.reload();
           }

             }

          })

                 }



     }

     })

        
      
        }

         })

       </script>