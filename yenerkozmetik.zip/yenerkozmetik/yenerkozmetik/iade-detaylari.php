<?php require_once 'header.php'; 

$siparisitem_id=$_GET['siparisurun'];

$siparisitemsec=$db->prepare("SELECT * from siparisitem where siparisitem_id=:id and urun_iade!='0'");
$siparisitemsec->execute(array(
"id" => $siparisitem_id
));

$siparisitemsay=$siparisitemsec->rowCount();

$siparisitemcek=$siparisitemsec->fetch(PDO::FETCH_ASSOC);

$urun_id = $siparisitemcek['urun_id'];
$urun_iade = $siparisitemcek['urun_iade'];
$siparis_id = $siparisitemcek['siparis_id'];

$kargo_iadekodu = $genelayarcek['kargo_iadekodu'];
$iade_text = $siparisitemcek['iade_text'];
$iade_adsoyad = $genelayarcek['iade_adsoyad'];
$iade_adres = $genelayarcek['iade_adres'];
$ayar_kargosirketi = $genelayarcek['ayar_kargosirketi'];

if ($siparisitemsay==0 or empty($_SESSION['kullanicioturum'])) {
    
    header("location:index");
    exit;
}


$urunsecc=$db->prepare("SELECT * from urunler where urun_id='$urun_id'");
$urunsecc->execute();
$uruncekk=$urunsecc->fetch(PDO::FETCH_ASSOC);

$urun_ad=$uruncekk['urun_ad']; 

$iade_miktar = $siparisitemcek['iade_miktar']; 
$iade_tutar = $siparisitemcek['iade_tutar'];                    


                     ?>


                     <title>Ürün İade Detayları | Yener Kozmetik</title>




        

        <!--==================== Checkout Section Start ====================-->
        <div id="main-content" class="full-row site-content">
            <div class="container">
                <div class="row ">
                    <div id="primary" class="content-area col-md-12">
                        <article id="post-19" class="post-19 page type-page status-publish hentry">
                            <div class="entry-content">
                                <div class="woocommerce">
                                    
                                    

                    
                                   

                                    <form onsubmit="return false;" class="checkout woocommerce-checkout" id="checkoutform">
                                        <div class="row">

                                            

                                            <div class="col-lg-12">
                                                <div class="col2-set" id="customer_details">
                                                    <div class="woocommerce-billing-fields">
                                                        <h3 style="font-family: Arial;font-weight: 200;">Ürün İade Detayları</h3>
                                                        <?php switch ($urun_iade) {
                            case '1': ?>
                                <h5 style="color:orange;font-family: arial;font-weight: 200;"><i class="far fa-clock"></i> Ürün Bekleniyor</h5>
                                <?php break;
                            
                            case '2': ?>
                                <h5 style="color:green;font-family: arial;font-weight: 200;"><i class="fas fa-check"></i> İade Edildi</h5>
                               <?php break;

                                case '3': ?>
                                <h5 style="color:#CA0725;font-family: arial;font-weight: 200;"><i class="fas fa-times"></i> İade Reddedildi</h5>
                                <?php break;
                        } ?>
                                                        <nav aria-label="breadcrumb" class="d-flex 
                                                         justify-content-sm-end align-items-center h-100">
                            <ol class="breadcrumb mb-0 d-inline-flex bg-transparent p-0">
                                <li class="breadcrumb-item"><a target="_blank" href="siparis-detay?siparis_id=<?php echo $siparis_id; ?>">Sipariş no : <?php echo $siparis_id; ?></a></li>
                                <li class="breadcrumb-item" aria-current="page"><a target="_blank" href="urun-<?php echo seo($urun_ad)."-".$urun_id; ?>">Ürün : <?php echo $urun_ad; ?></a></li>
                                <li class="breadcrumb-item active" aria-current="page">İade Detayları</li>

                            </ol>
                        </nav>

                        <hr>

                        <?php if ($urun_iade==1) { ?>
                
                <h5 style="line-height: 25px;color: black;font-family: Arial;font-weight: 200;" align="center">Ürünü faturasıyla birlikte <b style="font-weight: 600;"><?php echo $kargo_iadekodu; ?></b> iade kargo kodu ile aşağıdaki bilgiler doğrultusunda <b style="font-weight: 600;"><?php echo $ayar_kargosirketi ?></b> şubesinden iade incelemesi için ücretsiz gönderebilirsiniz.</h5>

        <br>

            <?php } ?>
                                                        <div class="woocommerce-billing-fields__field-wrapper">

                                                            <div class="row">

                                                                <?php if ($urun_iade==1) { ?>

                                                            <div class="col-lg-6 col-md-6 col-xs-12">


                                                            <p class="form-row form-row-first validate-required" id="billing_first_name_field" data-priority="10">
                                                                <label for="billing_first_name" class="">Kargo Şirketi&nbsp;<abbr class="required" title="required"></abbr></label>
                                                                <span class="woocommerce-input-wrapper">
                                                                    <input type="text" readonly="" class="input-text" value="<?php echo $ayar_kargosirketi; ?>">
                                                                </span>
                                                            </p>

                                                            </div>

                                                            <div class="col-lg-6 col-md-6 col-xs-12">


                                                            <p class="form-row form-row-first validate-required" id="billing_first_name_field" data-priority="10">
                                                                <label for="billing_first_name" class="">Kargo İade Kodu&nbsp;<abbr class="required" title="required"></abbr></label>
                                                                <span class="woocommerce-input-wrapper">
                                                                    <input type="text" readonly="" class="input-text" value="<?php echo $kargo_iadekodu; ?>">
                                                                </span>
                                                            </p>

                                                            </div>

                                                            <div class="col-lg-12 col-md-12 col-xs-12">


                                                            <p class="form-row form-row-first validate-required" id="billing_first_name_field" data-priority="10">
                                                                <label for="billing_first_name" class="">Alıcı Ad & Soyad&nbsp;<abbr class="required" title="required"></abbr></label>
                                                                <span class="woocommerce-input-wrapper">
                                                                    <input type="text" readonly="" class="input-text" value="<?php echo $iade_adsoyad; ?>">
                                                                </span>
                                                            </p>

                                                            </div>

                                                            <div class="col-lg-12 col-md-12 col-xs-12">


                                                            <p class="form-row form-row-first validate-required" id="billing_first_name_field" data-priority="10">
                                                                <label for="billing_first_name" class="">İade Adresi&nbsp;<abbr class="required" title="required"></abbr></label>
                                                                <span class="woocommerce-input-wrapper">
                                                                    <textarea readonly="" class="input-text" rows="3" cols="5"><?php echo $iade_adres; ?></textarea>
                                                                </span>
                                                            </p>

                                                            </div>

                                                        <?php } ?>


                                                        <div class="col-lg-12 col-md-12 col-xs-12">


                                                            <p class="form-row form-row-first validate-required" id="billing_first_name_field" data-priority="10">
                                                                <label for="billing_first_name" class="">İade Sebebi&nbsp;<abbr class="required" title="required"></abbr></label>
                                                                <span class="woocommerce-input-wrapper">
                                                                    <textarea readonly="" class="input-text" rows="3" cols="5"><?php echo $iade_text; ?></textarea>
                                                                </span>
                                                            </p>

                                                            </div>

                                                            <hr><br>

                                                            <h5 style="font-weight: 200;font-family: arial;">İade Talebi Yapılan Ürün</h5>

                                                            <form action="#" id="yith-wcwl-form" class="table-responsive-lg">
                            <table class="shop_table cart wishlist_table wishlist_view traditional table" data-pagination="no" data-per-page="5" data-page="1" data-id="3989" data-token="G5CZRAZPRKEY">
                                <thead>
                                    <tr>
                                        
                                        <th class="product-name">Ürün No.</th>
                                        <th class="product-name">Ürün</th>
                                        <th class="product-name">İade Adedi</th>
                                        <th class="product-name">Birim Fiyatı</th>
                                        <th class="product-name">İade Tutarı</th>
                                        
                                </thead>
                                <tbody class="wishlist-items-wrapper">

                                    <?php


                              

                             $siparisitemseceneksec = $db->prepare("SELECT * from siparisitemsecenekler where siparisitem_id='$siparisitem_id'");

                          $siparisitemseceneksec->execute();


      $urunsec=$db->prepare("SELECT * from urunler where urun_id=:id");
                        $urunsec->execute(array(

                            "id" => $siparisitemcek['urun_id']
                        ));

                        $uruncek = $urunsec->fetch(PDO::FETCH_ASSOC);

                        $urun_id = $siparisitemcek['urun_id'];

                        $urun_fiyat = $siparisitemcek['urun_fiyat'];

                        $urun_toplamfiyat = $siparisitemcek['urun_toplam'];

                        

                        $urun_ad=$uruncek['urun_ad'];
                            ?>
                                    
                                    <tr id="yith-wcwl-row-97" data-row-id="97">
                                        
                                        <td class="product-name"><?php echo $urun_id; ?></td>
                                        <td class="product-name">
                                         <a target="_blank" href='urun-<?php echo seo($urun_ad)."-".$uruncek['urun_id']; ?>'><?php if (strlen($urun_ad)>85) { ?>
                            <?php echo substr($urun_ad,0,85)."..."; ?>
                        <?php } else { 

                         echo $urun_ad; 
                         } ?></a><br>

                        <?php while ($siparisitemsecenekcek=$siparisitemseceneksec->fetch(PDO::FETCH_ASSOC)) { 
                $secenek_ad = $siparisitemsecenekcek['secenek_ad'];
                $altsecenek_ad = $siparisitemsecenekcek['altsecenek_ad']; ?> 


                <?php echo "<span style='font-weight:500;'>".$secenek_ad."</span> : ".$altsecenek_ad."<br>"; ?>
                            

              <?php } ?>

                     </td>

                     <td class="product-name"><?php echo $iade_miktar; ?></td>

                     <td class="product-name"><?php echo $urun_fiyat; ?> TL</td>

                     <td class="product-name"><?php echo $iade_tutar; ?> TL</td>

                                    </tr>
                                </tbody>
                            </table>
                        </form>

                                                            
                                                           



                                                           


                                                           
                                                            


                                                            </div>
                                                            
                                                        </div>
                                                    </div>

                                                    
                                                    
                                                </div>
                                            </div>
                                            
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <!-- .entry-content -->
                        </article>
                        <!-- #post-## -->
                    </div>
                    <!-- .entry-content-wrapper -->
                </div>
                <!-- .row -->
            </div>
            <!-- .container -->
        </div>
        <!--==================== Checkout Section End ====================-->


        



        <?php require_once 'footer.php'; ?>

        