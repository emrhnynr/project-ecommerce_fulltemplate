<?php require_once 'header.php'; ?>

<head>

<meta name="description" content="<?php echo $seoayarcek['sss_description']; ?>">

</head>

<title><?php echo $seoayarcek['sss_title']; ?></title>

        <!-- breadcrumb -->
        <div class="full-row bg-light py-5">
            <div class="container">
                <div class="row text-secondary">
                    <div class="col-sm-6">
                        <h3 class="mb-2 text-secondary"><?php echo $genelayarcek['ayar_sssbaslik']; ?></h3>
                    </div>
                    <div class="col-sm-6">
                        <nav aria-label="breadcrumb" class="d-flex justify-content-sm-end align-items-center h-100">
                            <ol class="breadcrumb mb-0 d-inline-flex bg-transparent p-0">
                                <li class="breadcrumb-item"><a href="../"><i class="fas fa-home me-1"></i>Anasayfa</a></li>
                                
                                <li class="breadcrumb-item active" aria-current="page"><?php echo $seoayarcek['menu_sss'] ?></li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <!-- breadcrumb -->

        <div class="full-row">
            <div class="container">
                <div class="row">
                    
                    <div class="col-lg-12">

                        <?php $sorusec=$db->prepare("SELECT * from sss order by soru_sira ASC");
                  $sorusec->execute();

                  $say=0;

                  while ($sorucek=$sorusec->fetch(PDO::FETCH_ASSOC)) { $say++; ?>
                        
                        <div class="simple-collaps bg-light px-4 py-3 border mb-3">
                            <span class="accordion text-secondary d-block"><?php echo $sorucek['soru_baslik']; ?></span>
                            <div class="panel">
                               <p><?php echo $sorucek['soru_aciklama']; ?></p>
                            </div>
                        </div>

                    <?php } ?>
                    </div>
                </div>
            </div>
        </div>

        <?php require_once 'footer.php'; ?>