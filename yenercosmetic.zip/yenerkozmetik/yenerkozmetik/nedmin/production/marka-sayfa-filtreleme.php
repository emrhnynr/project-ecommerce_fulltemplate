<?php require_once 'header.php'; ?>

<style type="text/css">
   /* Customize the label (the container) */
.checklabell {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 12px;
  cursor: pointer;
  font-size: 22px;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

/* Hide the browser's default checkbox */
.checklabell input {
  position: absolute;
  opacity: 0;
  cursor: pointer;
  height: 0;
  width: 0;
}

/* Create a custom checkbox */
.checkmark {
  position: absolute;
  top: 0;
  left: 0;
  height: 25px;
  width: 25px;
  background-color: #eee;
}

/* On mouse-over, add a grey background color */
.checklabell:hover input ~ .checkmark {
  background-color: #ccc;
}

/* When the checkbox is checked, add a blue background */
.checklabell input:checked ~ .checkmark {
  background-color: #43DE09;
}

/* Create the checkmark/indicator (hidden when not checked) */
.checkmark:after {
  content: "";
  position: absolute;
  display: none;
}

/* Show the checkmark when checked */
.checklabell input:checked ~ .checkmark:after {
  display: block;
}

/* Style the checkmark/indicator */
.checklabell .checkmark:after {
  left: 9px;
  top: 5px;
  width: 5px;
  height: 10px;
  border: solid white;
  border-width: 0 3px 3px 0;
  -webkit-transform: rotate(45deg);
  -ms-transform: rotate(45deg);
  transform: rotate(45deg);
}
}



</style>


        

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Marka Sayfası Filtreleri</h3>
              </div>

              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                 
                  <div class="x_content">
                    
                    <h4 style="font-size: 17px;" align="center">Bu seçilen filtreler marka sayfalarının her birinde filtreleme seçenekleri olarak açılacak. Fiyat aralığı seçeneği otomatik olarak gelecek.<hr></h4>

                    <?php $filtrebasliksec=$db->prepare("SELECT * from filtrebasliklar order by filtrebaslik_sira ASC");
                          $filtrebasliksec->execute();
                          $filtrebasliksay = $filtrebasliksec->rowCount();

                          if ($filtrebasliksay==0) { ?>
                             
                             <h4 align="center">Bu mesajı alıyorsanız Yener Digital tarafından eklenmesi gereken filtreler eklenmemiştir. Lütfen bizi uyarın.</h4>

                          <?php } else { ?>


                            <form id="markafiltreduzenleform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">

                          <h3 align="center">Filtre Seçenekleri<hr></h3>

                          <?php $filtrebasliksec=$db->prepare("SELECT * from filtrebasliklar order by filtrebaslik_sira ASC");
                          $filtrebasliksec->execute();

                          while ($filtrebaslikcek=$filtrebasliksec->fetch(PDO::FETCH_ASSOC)) { 

                            $filtrebaslik_id = $filtrebaslikcek['filtrebaslik_id'];
                            $filtrebaslik_ad = $filtrebaslikcek['filtrebaslik_ad'];


                            $sor=$db->prepare("SELECT * from markafiltreler where filtrebaslik_id='$filtrebaslik_id'");
                            $sor->execute();

                            $varmi = $sor->rowCount(); ?>

                            <div align="left" class="col-lg-4 col-md-4 col-sm-4 col-xs-6" > 

     <label class="checklabell"><?php echo $filtrebaslik_ad; ?>
  <input <?php if ($varmi==1) { ?>
    checked=''
  <?php } ?> name="filtreler[]" value="<?php  echo $filtrebaslik_id; ?>"  type="checkbox">
  <span class="checkmark"></span>
</label>

<br>




</div>
                             


                           <?php } ?>

                           
                           <input type="hidden" name="markafiltreduzenle">



                           <div  class="form-group">
                        
                        <div align="right" class="col-md-12 col-sm-12 col-xs-12 ">

                          
                          
                          <button style="margin-top:40px;" type="submit" class="btn btn-success markafiltreduzenlebuton">Düzenle</button>
                        </div>
                      </div>

                        </div>
                      </div>

                    </form>


                         <?php } ?>


                    

                    


                   


                    
                  </div>
                </div>
              </div>
            </div>

            <?php require_once 'footer.php'; ?>
            <script type="text/javascript">
              
              $('#markafiltreduzenleform').submit(function(){



             
              


              $('.markafiltreduzenlebuton').prop('disabled',true);
                
              


                $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : $('#markafiltreduzenleform').serialize(),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

              

             

                

               if (sonuc=="ok") {

                
                $('.markafiltreduzenlebuton').prop('disabled',false);


                swal({

  title: "Başarılı",
  text: "Filtreler güncellendi!",
  icon: "success",
  button: "OK",
});



              }

              

              

              

                        

              }


            })

                 

              

                 });

            </script>
            


            