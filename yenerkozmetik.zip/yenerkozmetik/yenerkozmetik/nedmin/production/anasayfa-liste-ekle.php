<?php require_once 'header.php'; 




?>


        

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Anasayfa Liste Ekle</h3>
              </div>

              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                 
                  <div class="x_content">
                    <br />
                   <form id="anasayfalisteekleform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

                      
                       

                       <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Liste Başlık 
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input  type="text" maxlength="300" id="liste_baslik" name="liste_baslik"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                     
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Sıra <span class="required">*</span>
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="number" id="liste_sira" name="liste_sira" step='any'  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Liste Türü <span class="required">*</span>
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <select id="liste_turu" name="liste_turu" class="form-control">
                            
                            <option selected="" value="secilmedi">Seçiniz</option>
                            <option value="liste">Normal Liste</option>
                            <option value="slayt">Tek Sıra Slayt</option>

                          </select>
                        </div>
                      </div>

                      

                     

                

                      
                      


                      
                      
                      

                    

                    

                    <h3 id="listeurunekle" style="margin-top:100px;" align="center">Listeye Ürün Ekle<hr></h3>

                    


                      <h4 align="center">Ürün no. larına <a target="_blank" href='urun-ayarlari'>buradan</a> ulaşabilirsiniz.</h4>



                      <div style="margin-bottom:40px;" class="urunno">
                      
                       

                       <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Ürün No. <span class="required">*</span>
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input  type="text" maxlength="30"  name="urun_id[]"  placeholder="Ürün no. sunu yazın"  class="form-control col-md-10 col-xs-12 inputt">
                        </div>
                      </div>

                     
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Sıra <span class="required">*</span>
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="number" placeholder="Ürünün bu listede kaçıncı sırada listeleneceğini girin"  name="urun_sira[]" step='any'  class="form-control col-md-10 col-xs-12 inputt">
                        </div>
                      </div>

                    </div>


                      <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name"></span>
                        </label>
                        <a href="javascript:void(0);" class="dahafazlaurun"><div align="center" class="form-group">
                        <div style="margin-bottom: 80px;border:1px solid #d7d7d7;" class="col-md-7 col-sm-7 col-xs-12">
                          <h3>Daha Fazla Ürün +</h3>
                        </div></a>

                      

                     

                      

                     

                

                      <input type="hidden" name="anasayfalisteekle">
                      


                      
                      
                      <div style="margin-top:30px;" class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">

                          <div style="display: none;" class="alert alert-warning uyari"></div>
                          
                          <button type="submit" class="btn btn-success listeeklebuton">Ekle</button>
                        </div>
                      </div>

                    </form>

                    
                  </div>
                </div>
              </div>
            </div>

            <?php require_once 'footer.php'; ?>
            <script type="text/javascript">
              
              


            


              $('.dahafazlaurun').click(function(){

                var urunsayisi = $('.urunno').length;
                var yeniurunsayisi = urunsayisi+1;

                $('.urunno').last().after('<div style="margin-bottom:40px;" class="urunno urunno_'+yeniurunsayisi+'"><div class="form-group"><label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Ürün No. <span class="required">*</span></label><div class="col-md-7 col-sm-7 col-xs-12"><input  type="text" maxlength="30"  name="urun_id[]"  placeholder="Ürün no. sunu yazın"  class="form-control col-md-10 col-xs-12 inputt"></div></div><div class="form-group"><label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Sıra <span class="required">*</span></label><div class="col-md-7 col-sm-7 col-xs-12"><input type="number" placeholder="Ürünün bu listede kaçıncı sırada listeleneceğini girin"  name="urun_sira[]" step="any"  class="form-control col-md-10 col-xs-12 inputt"></div></div><div class="form-group"><label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name"></label><div align="center" class="col-md-7 col-sm-7 col-xs-12"><a class="btn btn-danger urunkaldir" name="urunkaldir_'+yeniurunsayisi+'" href="javascript:void(0);"><i class="fa fa-trash-o"></i> Kaldır</a></div></div></div>');

                $('.urunkaldir').click(function(){

           var buton = $(this);
            var id1=$(this).attr("name");
                var urunno=id1.substring(11);

                $('.urunno_'+urunno).remove();

                });

              });


             


              $('#anasayfalisteekleform').submit(function(){
          
          var liste_sira = $('#liste_sira').val();
          var liste_turu = $('#liste_turu').val();
        
    
      var form = $('#anasayfalisteduzenleform')[0];
             var data = new FormData(form);

             var bosinputsayisi = $('.inputt').filter(function(){
    return !$.trim($(this).val());
}).length;
                
                

               if (liste_sira.length==0){

$('.uyari').show();
$('.uyari').html('<i class="fa fa-info-circle"></i> Lütfen listenin kaçıncı sırada listeleneceğini belirtin.');

      } else if (liste_turu=='secilmedi'){

$('.uyari').show();
$('.uyari').html('<i class="fa fa-info-circle"></i> Lütfen liste türünü belirtin.');

      } else if (bosinputsayisi>0){


$('.uyari').show();
  $('.uyari').html('<i class="fa fa-info-circle"></i> Tüm ürün ekleme alanlarını doldurmanız gerekmektedir.');


      } else {

       
       $('.uyari').hide();
$('.listeeklebuton').prop('disabled',true);
$('.listeeklebuton').html('Ekleniyor...');

$.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : $('#anasayfalisteekleform').serialize(),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

             

              

              if (sonuc=="ok") {

                swal({

  title: "Başarılı",
  text: "Liste eklendi!",
  icon: "success",
  button: "OK",
}).then((willDelete) => {
  if (willDelete) {

    window.location = 'anasayfa-urun-listeler';

     }

   });
              }

               
              }
        })

      }





              });



            </script>


            