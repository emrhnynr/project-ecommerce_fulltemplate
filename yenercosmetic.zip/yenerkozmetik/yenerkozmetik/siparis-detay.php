<?php require_once 'header.php'; 


$siparis_id=$_GET['siparis_id'];

$siparissec=$db->prepare("SELECT * from siparisler where siparis_id=:id");
$siparissec->execute(array(
"id" => $siparis_id
));

$siparissay=$siparissec->rowCount();

$sipariscek=$siparissec->fetch(PDO::FETCH_ASSOC);

if ($siparissay==0 or empty($_SESSION['kullanicioturum'])) {
    
    header("location:index");
    exit;
}

             $siparis_zaman = $sipariscek['siparis_zaman'];
                       $d = new DateTime($siparis_zaman);
                        $zamanson =  $d->format('d/m/Y');

                         $siparisitemsec=$db->prepare("SELECT * from siparisitem where siparis_id=:id order by urun_fiyat DESC");
                      $siparisitemsec->execute(array(

                        "id" => $siparis_id

                      ));

                      $siparisitemsay=$siparisitemsec->rowCount();

                     ?>


                     <title>Sipariş Detayları | Yener Kozmetik</title>




        

        <!--==================== Checkout Section Start ====================-->
        <div id="main-content" class="full-row site-content">
            <div class="container">
                <div class="row ">
                    <div id="primary" class="content-area col-md-12">
                        <article id="post-19" class="post-19 page type-page status-publish hentry">
                            <div class="entry-content">
                                <div class="woocommerce">
                                    
                                    

                    
                                   

                                    <form onsubmit="return false;" class="checkout woocommerce-checkout" id="checkoutform">
                                        <div class="row">

                                            

                                            <div class="col-lg-6">
                                                <div class="col2-set" id="customer_details">
                                                    <div class="woocommerce-billing-fields">
                                                        <h3 style="font-family: Arial;font-weight: 200;">Sipariş Detayları</h3>
                                                        <?php switch ($sipariscek['siparis_ulasmis']) {
                            case '0': ?>
                                <h5 style="color:#FA3B12;font-family: Arial;font-weight: 200;"><i class="far fa-clock"></i> Hazırlanıyor</h5>
                                <?php break;
                            
                            case '1': ?>
                                <h5 style="color:green;font-family: Arial;font-weight: 200;"><i class="fas fa-check"></i> Teslim Edildi</h5>
                               <?php break;

                                case '2': ?>
                                <h5 style="color:#225E88;font-family: Arial;font-weight: 200;"><i class="fas fa-truck"></i> Kargoya Verildi</h5>
                                <?php break;
                        } ?>

                        <hr>
                                                        <div class="woocommerce-billing-fields__field-wrapper">

                                                            <div class="row">

                                                                <div class="col-lg-6 col-md-6 col-xs-12">


                                                            <p class="form-row form-row-first validate-required" id="billing_first_name_field" data-priority="10">
                                                                <label for="billing_first_name" class="">Sipariş No.&nbsp;<abbr class="required" title="required"></abbr></label>
                                                                <span class="woocommerce-input-wrapper">
                                                                    <input type="text" readonly="" class="input-text" value="<?php echo $sipariscek['siparis_id']; ?>">
                                                                </span>
                                                            </p>

                                                            </div>

                                                            <div class="col-lg-6 col-md-6 col-xs-12">


                                                            <p class="form-row form-row-first validate-required" id="billing_first_name_field" data-priority="10">
                                                                <label for="billing_first_name" class="">Sipariş Tarihi&nbsp;<abbr class="required" title="required"></abbr></label>
                                                                <span class="woocommerce-input-wrapper">
                                                                    <input type="text" readonly="" class="input-text" value="<?php echo $zamanson; ?>">
                                                                </span>
                                                            </p>

                                                            </div>

                                                            <div class="col-lg-6 col-md-6 col-xs-12">


                                                            <p class="form-row form-row-first validate-required" id="billing_first_name_field" data-priority="10">
                                                                <label for="billing_first_name" class="">Ürün Sayısı&nbsp;<abbr class="required" title="required"></abbr></label>
                                                                <span class="woocommerce-input-wrapper">
                                                                    <input type="text" readonly="" class="input-text" value="<?php echo $siparisitemsay; ?>">
                                                                </span>
                                                            </p>

                                                            </div>

                                                            <div class="col-lg-6 col-md-6 col-xs-12">


                                                            <p class="form-row form-row-first validate-required" id="billing_first_name_field" data-priority="10">
                                                                <label for="billing_first_name" class="">Cep Telefonu&nbsp;<abbr class="required" title="required"></abbr></label>
                                                                <span class="woocommerce-input-wrapper">
                                                                    <input type="text" readonly="" class="input-text" value="<?php echo $sipariscek['siparis_telno']; ?>">
                                                                </span>
                                                            </p>

                                                            </div>

                                                            <div class="col-lg-6 col-md-6 col-xs-12">


                                                            <p class="form-row form-row-first validate-required" id="billing_first_name_field" data-priority="10">
                                                                <label for="billing_first_name" class="">Adınız&nbsp;<abbr class="required" title="required"></abbr></label>
                                                                <span class="woocommerce-input-wrapper">
                                                                    <input type="text" readonly="" class="input-text" value="<?php echo $sipariscek['siparis_ad']; ?>">
                                                                </span>
                                                            </p>

                                                            </div>

                                                            <div class="col-lg-6 col-md-6 col-xs-12">


                                                            <p class="form-row form-row-first validate-required" id="billing_first_name_field" data-priority="10">
                                                                <label for="billing_first_name" class="">Soyadınız&nbsp;<abbr class="required" title="required"></abbr></label>
                                                                <span class="woocommerce-input-wrapper">
                                                                    <input type="text" readonly="" class="input-text" value="<?php echo $sipariscek['siparis_soyad']; ?>">
                                                                </span>
                                                            </p>

                                                            </div>

                                                            <div class="col-lg-6 col-md-6 col-xs-12">


                                                            <p class="form-row form-row-first validate-required" id="billing_first_name_field" data-priority="10">
                                                                <label for="billing_first_name" class="">Kargo Ücreti&nbsp;<abbr class="required" title="required"></abbr></label>
                                                                <span class="woocommerce-input-wrapper">
                                                                    <input type="text" readonly="" class="input-text" value="<?php echo $sipariscek['siparis_kargoucreti']; ?>">
                                                                </span>
                                                            </p>

                                                            </div>

                                                            <div class="col-lg-6 col-md-6 col-xs-12">


                                                            <p class="form-row form-row-first validate-required" id="billing_first_name_field" data-priority="10">
                                                                <label for="billing_first_name" class="">Şehir / İlçe&nbsp;<abbr class="required" title="required"></abbr></label>
                                                                <span class="woocommerce-input-wrapper">
                                                                    <input type="text" readonly="" class="input-text" value="<?php echo $sipariscek['siparis_sehir']." / ".$sipariscek['siparis_ilce']; ?>">
                                                                </span>
                                                            </p>

                                                            </div>

                                                            <div class="col-lg-12 col-md-12 col-xs-12">


                                                            <p class="form-row form-row-first validate-required" id="billing_first_name_field" data-priority="10">
                                                                <label for="billing_first_name" class="">Sipariş Adresi&nbsp;<abbr class="required" title="required"></abbr></label>
                                                                <span class="woocommerce-input-wrapper">
                                                                    <textarea readonly="" class="input-text" rows="3" cols="5">
                                                                        <?php echo $sipariscek['siparis_adres']; ?>
                                                                    </textarea>
                                                                </span>
                                                            </p>

                                                            </div>

                                                            <?php if (!empty($sipariscek['siparis_not'])) { ?>


                                                            <div class="col-lg-12 col-md-12 col-xs-12">


                                                            <p class="form-row form-row-first validate-required" id="billing_first_name_field" data-priority="10">
                                                                <label for="billing_first_name" class="">Sipariş Notu&nbsp;<abbr class="required" title="required"></abbr></label>
                                                                <span class="woocommerce-input-wrapper">
                                                                    <textarea readonly="" class="input-text" rows="3" cols="5">
                                                                        <?php echo $sipariscek['siparis_not']; ?>
                                                                    </textarea>
                                                                </span>
                                                            </p>

                                                            </div>

                                                        <?php } ?>




                                                           


                                                           
                                                            


                                                            </div>
                                                            
                                                        </div>
                                                    </div>

                                                    
                                                    
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                
                                                <div class="order-review-inner">
                                                    <h3 style="font-family: arial;font-weight: 200;" id="order_review_heading">Ürünler</h3>
                                                    <div id="order_review" class="woocommerce-checkout-review-order">
                                                        <table class="shop_table woocommerce-checkout-review-order-table">
                                                            <thead>
                                                                <tr>
                                                                    <th class="product-name">Ürün</th>
                                                                    <th class="product-total">Fiyat</th>

                                                                    <?php if ($sipariscek['siparis_ulasmis']==1) { ?>


                                                                        <th class="product-total"></th>

                                                                    <?php  } ?>
                                                                </tr>
                                                            </thead>
                                                            <tbody>

                                                                <?php while ($siparisitemcek=$siparisitemsec->fetch(PDO::FETCH_ASSOC)) { 


                             $siparisitem_id = $siparisitemcek['siparisitem_id']; 

                             $siparisitemseceneksec = $db->prepare("SELECT * from siparisitemsecenekler where siparisitem_id='$siparisitem_id'");

                          $siparisitemseceneksec->execute();


      $urunsec=$db->prepare("SELECT * from urunler where urun_id=:id");
                        $urunsec->execute(array(

                            "id" => $siparisitemcek['urun_id']
                        ));

                        $uruncek = $urunsec->fetch(PDO::FETCH_ASSOC);

                        $urun_id = $siparisitemcek['urun_id'];

                        $urun_fiyat = $siparisitemcek['urun_fiyat'];

                        $urun_toplamfiyat = $siparisitemcek['urun_toplam'];

                        

                        $urun_ad=$uruncek['urun_ad'];
                            ?>
                                                                
                                                                <tr class="cart_item">
                                                                    <td class="product-name">
                                                                        <a target="_blank" href='urun-<?php echo seo($urun_ad)."-".$uruncek['urun_id']; ?>'><?php if (strlen($urun_ad)>85) { ?>
                            <?php echo substr($urun_ad,0,85)."..."; ?>
                        <?php } else { 

                         echo $urun_ad; 
                         } ?></a> <strong class="product-quantity">×&nbsp;<?php echo $siparisitemcek['urun_miktar']; ?></strong> 

                     <?php while ($siparisitemsecenekcek=$siparisitemseceneksec->fetch(PDO::FETCH_ASSOC)) { 
                $secenek_ad = $siparisitemsecenekcek['secenek_ad'];
                $altsecenek_ad = $siparisitemsecenekcek['altsecenek_ad']; ?> 


                <?php echo "<span style='font-weight:500;'>".$secenek_ad."</span> : ".$altsecenek_ad."<br>"; ?>
                            

              <?php } ?>
                    </td>
                                                                    <td class="product-total">
                                                                        <span class="woocommerce-Price-amount amount"><bdi><?php echo $urun_toplamfiyat; ?> TL</bdi>
                                                                        </span>
                                                                    </td>

                                                                    <?php if ($sipariscek['siparis_ulasmis']==1) { 
                                                                        $urun_iade = $siparisitemcek['urun_iade'];

                                                                          ?>

                                                                        

                                                                       <?php switch ($urun_iade) {
                                                                           case '0': ?>
                                                                               
                                                                               <td align="center" class="product-name">
                                                                               <a href="iade-et?siparisurun=<?php echo $siparisitem_id; ?>"><u>İade Et</u></a>

                                                                                 

                                                                               </td>

                                                                             



                                                                              <?php break;

                                                                              case '1': ?>
                                                                               
                                                                               <td align="center" class="product-name">
                                                                               <a href="iade-detaylari?siparisurun=<?php echo $siparisitem_id; ?>"><u>İade Detayları</u></a>
                                                                              </td>

                                                                               

                                                                              <?php break;

                                                                              case '2': ?>
                                                                               
                                                                               <td align="center" class="product-name">
                                                                               <a style='color:green;' href="iade-detaylari?siparisurun=<?php echo $siparisitem_id; ?>"><i class="fas fa-check"></i> İade Edildi</a>
                                                                               </td>

                                                                               

                                                                              <?php break;

                                                                              case '3': ?>
                                                                               
                                                                               <td align="center" class="product-name">
                                                                               <a style='color:#CA0725;' href="iade-detaylari?siparisurun=<?php echo $siparisitem_id; ?>"><i class="fas fa-times"></i> İade Reddedildi</a>
                                                                              </td>

                                                                               

                                                                              <?php break;
                                                                           
                                                                           
                                                                      
                                                                            
                                                                     } } ?>

                                                                </tr>

                                                            <?php } ?>
                                                            </tbody>
                                                            <tfoot>
                                                                <tr class="cart-subtotal">
                                                                    <th>Ara Toplam</th>
                                                                    <td><span class="woocommerce-Price-amount amount"><bdi><?php echo $sipariscek['siparis_aratoplam']; ?> TL</bdi>
                                                                        </span>
                                                                    </td>
                                                                </tr>
                                                                
                                                                <tr class="order-total">
                                                                    <th>Kargo Ücreti</th>
                                                                    <td><strong><span class="woocommerce-Price-amount amount"><bdi><?php echo $sipariscek['siparis_kargoucreti']; ?> TL</bdi></span></strong> </td>
                                                                </tr>

                                                                <tr class="order-total">
                                                                    <th>Taksit</th>
                                                                    <td><strong><span class="woocommerce-Price-amount amount"><bdi><?php if ($sipariscek['siparis_taksit']=='1') {

                                                                        echo "Tek Çekim";

                                                                    } else {

                                                                        echo $sipariscek['siparis_taksit']." Taksit";

                                                                    } ?></bdi></span></strong> </td>
                                                                </tr>

                                                                <tr class="order-total">
                                                                    <th>Vade Farkı</th>
                                                                    <td><strong><span class="woocommerce-Price-amount amount"><bdi><?php echo $sipariscek['siparis_vadefarki']; ?> TL</bdi></span></strong> </td>
                                                                </tr>

                                                                <tr class="order-total">
                                                                    <th>Toplam</th>
                                                                    <td><strong><span class="woocommerce-Price-amount amount"><bdi><?php echo $sipariscek['siparis_toplam'];?> TL</bdi></span></strong> </td>
                                                                </tr>
                                                            </tfoot>
                                                        </table>
                                                        
                                                    </div>
                                                </div>
                                            
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <!-- .entry-content -->
                        </article>
                        <!-- #post-## -->
                    </div>
                    <!-- .entry-content-wrapper -->
                </div>
                <!-- .row -->
            </div>
            <!-- .container -->
        </div>
        <!--==================== Checkout Section End ====================-->


        



        <?php require_once 'footer.php'; ?>

        