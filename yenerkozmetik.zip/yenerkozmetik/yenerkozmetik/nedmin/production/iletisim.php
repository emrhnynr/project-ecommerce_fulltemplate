<?php require_once 'header.php';

$genelayarsec=$db->prepare("SELECT * from genelayarlar");
$genelayarsec->execute();

 $genelayarcek=$genelayarsec->fetch(PDO::FETCH_ASSOC);

 $hakkimizda_baslik = $genelayarcek['hakkimizda_baslik'];
 $hakkimizda_text = $genelayarcek['hakkimizda_text']; 

 $ayar_iletisimbanner = $genelayarcek['ayar_iletisimbanner'];
 ?>



        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              

              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>İletişim Bilgileri</h2>

                    <ul class="nav navbar-right panel_toolbox">
                     
                      <a target="_blank" class="btn btn-success" href="../../iletisim">İletişim Sayfası </a>
                    </ul>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />

                    

                  <form id="iletisimbaslikform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

                      <h3 align="center">İletişim Başlık</h3> <hr>


                     
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Başlık

                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="ayar_iletisimbaslik" value="<?php echo $genelayarcek['ayar_iletisimbaslik']; ?>" name="ayar_iletisimbaslik" maxlength="150"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                    

                     

                      

                     

                

                      <input type="hidden" name="iletisimbaslikduzenle">


                      
                      
                      <div class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">

                         
                          
                          <button type="submit" class="btn btn-success iletisimbaslikbuton">Düzenle</button>
                        </div>
                      </div>

                    </form>

                    <form id="mailduzenleform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

                      <h3 align="center">Şirket Mail<hr></h3>


                     
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">E-Posta Adresi <span class="required">*</span>
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="ayar_mail" value="<?php echo $genelayarcek['ayar_mail']; ?>" name="ayar_mail" maxlength="100"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">E-Posta Şifre <span class="required">*</span>
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="password" id="ayar_mailsifre" name="ayar_mailsifre" maxlength="300"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Şifre Tekrar <span class="required">*</span>
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="password" id="ayar_mailsifretekrar" name="ayar_mailsifretekrar" maxlength="300"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      

                     

                

                      <input type="hidden" name="mailduzenleadmin">


                      
                      
                      <div class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">

                          <div style="display: none;" class="alert alert-warning uyarimail"></div>
                          
                          <button type="submit" class="btn btn-success mailduzenlebuton">Düzenle</button>
                        </div>
                      </div>

                    </form>

                    <form id="mailbaslikform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

                      <h3 align="center">Mail Başlık</h3> <p align="center"><i class="fa fa-info-circle"></i> Otomatik maillerde kullanılacak şirket ismi</p> <hr>


                     
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Başlık <span class="required">*</span>

                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" placeholder="Müşteriye atılacak maillerde gönderici ismi" id="ayar_mailbaslik" value="<?php echo $genelayarcek['ayar_mailbaslik']; ?>" name="ayar_mailbaslik" maxlength="300"  class="form-control col-md-10 col-xs-12">


                        </div>


                      </div>



                    

                     

                      

                     

                

                      <input type="hidden" name="mailbaslikduzenle">


                      
                      
                      <div class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">

                          <div class="alert alert-warning mailbaslikuyari" style="display: none;"></div>

                         
                          
                          <button type="submit" class="btn btn-success mailbaslikbuton">Düzenle</button>
                        </div>
                      </div>

                    </form>

                    <form id="telnoduzenleform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

                      <h3 align="center">Şirket Telefonu</h3>


                     
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Telefon Numarası
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="ayar_telno" value="<?php echo $genelayarcek['ayar_telno']; ?>" name="ayar_telno" maxlength="100"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                    

                     

                      

                     

                

                      <input type="hidden" name="telnoduzenleadmin">


                      
                      
                      <div class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">

                          <div style="display: none;" class="alert alert-warning uyaritelno"></div>
                          
                          <button type="submit" class="btn btn-success telnoduzenlebuton">Düzenle</button>
                        </div>
                      </div>

                    </form>

                    <form id="adresduzenleform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

                      <h3 align="center">Şirket Adresi<hr></h3>


                     
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Adres
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <textarea rows="8" class="form-control col-md-10 col-xs-12" id="ayar_adres" name="ayar_adres" maxlength="1500"><?php echo $genelayarcek['ayar_adres']; ?></textarea>
                          
                        </div>
                      </div>

                    

                     

                      

                     

                

                      <input type="hidden" name="adresduzenleadmin">


                      
                      
                      <div class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">

                          <div style="display: none;" class="alert alert-warning uyariadres"></div>
                          
                          <button type="submit" class="btn btn-success adresduzenlebuton">Düzenle</button>
                        </div>
                      </div>

                    </form>
                  </div>
                </div>
              </div>
            </div>

            <?php require_once 'footer.php'; ?>
            <script type="text/javascript">

              $('#iletisimbannerguncellebuton').click(function(){

var input = $('#ayar_iletisimbanner');
var foto = $('#ayar_iletisimbanner').val();
var filevalue = $('#ayar_iletisimbanner').get(0).files[0];
var fotouzanti = foto.split('.').pop();

var data = new FormData();
data.append('iletisimbannerguncelle',"ok");
data.append("file",filevalue);



if ($('#ayar_iletisimbanner').val().length==0){

 $('.uyaribanner').show();
$('.uyaribanner').html('<i class="fa fa-info-circle"></i> Lütfen banner yükleyin.');

  } else if (fotouzanti!='jpg' && fotouzanti!='jpeg' && fotouzanti!='png'){

$('.uyaribanner').show();
$('.uyaribanner').html('<i class="fa fa-info-circle"></i> Sadece <b>.jpg</b>, <b>.jpeg,</b> <b>.png</b>, uzantılı dosyaları yükleyebilirsiniz.');

} else {

  $('#iletisimbannerguncellebuton').prop('disabled',true);
  $('#iletisimbannerguncellebuton').html('Güncelleniyor...');

   $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            enctype : 'multipart/form-data',
            data : data,
            processData: false,
            contentType: false,
            cache: false,
            success : function(sonuc){

      sonuc=$.trim(sonuc);
      
      if (sonuc=="ok") {

        location.reload();
      }

 }

 });


}

});

              $('#iletisimbaslikform').submit(function(){

              var ayar_iletisimbaslik = $.trim($('#ayar_iletisimbaslik').val());
              


              $('.iletisimbaslikbuton').prop('disabled',true);

              

                

                $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : $('#iletisimbaslikform').serialize(),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

              if (sonuc=="ok") {

               
                $('.iletisimbaslikbuton').prop('disabled',false);


                swal({

  title: "Başarılı",
  text: "İletişim başlığı düzenlendi!",
  icon: "success",
  button: "OK",
});



              }
                

              }


            })
              

               });

              $('#mailbaslikform').submit(function(){

              var ayar_mailbaslik = $.trim($('#ayar_mailbaslik').val());
              


              if (ayar_mailbaslik.length<2) {

                $('.mailbaslikuyari').show();
                $('.mailbaslikuyari').html('<i class="fa fa-info-circle"></i> Lütfen bir mail başlığı girin.');


              } else {

                $('.mailbaslikbuton').prop('disabled',true);

              

                

                $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : $('#mailbaslikform').serialize(),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

              if (sonuc=="ok") {

               
                $('.mailbaslikbuton').prop('disabled',false);


                swal({

  title: "Başarılı",
  text: "Mail başlığı düzenlendi!",
  icon: "success",
  button: "OK",
});



              }
                

              }


            });

              }
               

               });

            $('#mailduzenleform').submit(function(){

              var ayar_mail = $.trim($('#ayar_mail').val());
              var ayar_mailsifre = $('#ayar_mailsifre').val();
              var ayar_mailsifretekrar = $('#ayar_mailsifretekrar').val();


              $('.mailduzenlebuton').prop('disabled',true);

              if (ayar_mail.length<6) {

    $('.uyarimail').show();
    $('.uyarimail').html('<i class="fa fa-info-circle"></i> Lütfen e-posta adresini doğru girin.');
    $('.mailduzenlebuton').prop('disabled',false);

              } else if (ayar_mailsifre.length<6) {

     $('.uyarimail').show();
    $('.uyarimail').html('<i class="fa fa-info-circle"></i> Lütfen şifreyi doğru girin.');
    $('.mailduzenlebuton').prop('disabled',false);

              } else if (ayar_mailsifre!=ayar_mailsifretekrar){

 $('.uyarimail').show();
    $('.uyarimail').html('<i class="fa fa-info-circle"></i> Şifreler uyuşmuyor.');
    $('.mailduzenlebuton').prop('disabled',false);

              } else {

                $('.uyarimail').hide();

                $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : $('#mailduzenleform').serialize(),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

              if (sonuc=="ok") {

                $('#ayar_mailsifre').val('');
                $('#ayar_mailsifretekrar').val('');
                $('.mailduzenlebuton').prop('disabled',false);


                swal({

  title: "Başarılı",
  text: "Şirket maili düzenlendi!",
  icon: "success",
  button: "OK",
});



              }
                

              }


            })

                 }

                 });


             $('#telnoduzenleform').submit(function(){

              var ayar_telno = $.trim($('#ayar_telno').val());
              


              $('.telnoduzenlebuton').prop('disabled',true);

              

                $('.uyaritelno').hide();

                $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : $('#telnoduzenleform').serialize(),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

              if (sonuc=="ok") {

               
                $('.telnoduzenlebuton').prop('disabled',false);


                swal({

  title: "Başarılı",
  text: "Şirket telefon numarası düzenlendi!",
  icon: "success",
  button: "OK",
});



              }
                

              }


            })
              

               });

             $('#adresduzenleform').submit(function(){

            
              


              $('.adresduzenlebuton').prop('disabled',true);

             

              


                $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : $('#adresduzenleform').serialize(),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

              if (sonuc=="ok") {

               
                $('.adresduzenlebuton').prop('disabled',false);


                swal({

  title: "Başarılı",
  text: "Şirket adresi düzenlendi!",
  icon: "success",
  button: "OK",
});



              }
                

              }


            })
              

               });



            </script>

              
             