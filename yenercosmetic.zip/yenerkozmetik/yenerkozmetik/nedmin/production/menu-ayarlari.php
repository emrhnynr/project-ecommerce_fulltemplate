<?php require_once 'header.php';

$seoayarsec=$db->prepare("SELECT * from seoayarlar");
$seoayarsec->execute();

 $seoayarcek=$seoayarsec->fetch(PDO::FETCH_ASSOC);

 $menu_anasayfa = $seoayarcek['menu_anasayfa'];
 $menu_hakkimizda = $seoayarcek['menu_hakkimizda'];
  $menu_iletisim = $seoayarcek['menu_iletisim'];
   $menu_blog = $seoayarcek['menu_blog'];
   $menu_ekip = $seoayarcek['menu_ekip'];
   $menu_sss = $seoayarcek['menu_sss'];



  ?>



        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              

              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                 
                  <div class="x_content">
                    <br />

                  

                    <form id="menuform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

                      <h3 align="center">Header Menü Ayarları</h3>
                      
                      
                      <hr>


                     
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Anasayfa 
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="menu_anasayfa" value="<?php echo $seoayarcek['menu_anasayfa']; ?>" name="menu_anasayfa" maxlength="50"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Hakkımızda 
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="menu_hakkimizda" value="<?php echo $seoayarcek['menu_hakkimizda']; ?>" name="menu_hakkimizda" maxlength="50"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">İletişim 
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="menu_iletisim" value="<?php echo $seoayarcek['menu_iletisim']; ?>" name="menu_iletisim" maxlength="50"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Blog 
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="menu_blog" value="<?php echo $seoayarcek['menu_blog']; ?>" name="menu_blog" maxlength="50"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Ekip 
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="menu_ekip" value="<?php echo $seoayarcek['menu_ekip']; ?>" name="menu_ekip" maxlength="50"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">SSS 
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="menu_sss" value="<?php echo $seoayarcek['menu_sss']; ?>" name="menu_sss" maxlength="50"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>


                      

                      

                     

                

                      <input type="hidden" name="menubaslikduzenle">


                      
                      
                      <div class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">

                       
                          
                          <button type="submit" class="btn btn-success menubuton">Düzenle</button>
                        </div>
                      </div>

                    </form>

                    

                   


                    
                  </div>
                </div>
              </div>
            </div>

            <?php require_once 'footer.php'; ?>



            <script type="text/javascript">

             

            $('#menuform').submit(function(){

             


              $('.menubuton').prop('disabled',true);

              

                $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : $('#menuform').serialize(),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

              if (sonuc=="ok") {

                
                $('.menubuton').prop('disabled',false);


                swal({

  title: "Başarılı",
  text: "Menü düzenlendi!",
  icon: "success",
  button: "OK",
});



              }
                

              }


            })

                 

                 });

            


            

            </script>

              
             