
<?php 	


try {


$db=new PDO("mysql:host=localhost;dbname=yenerkozmetik;charset=utf8",'root',""); //Bu Sayfa veritabanı bağlantısı yapılacak sayfalara copy-paste edilecek.Sadece veritabanı ismi fln değişebilir.

	
} catch (PDOException $e){


	echo $e->getMessage();

	
}



 ?>