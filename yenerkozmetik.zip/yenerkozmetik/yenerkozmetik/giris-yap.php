
<?php require_once 'header.php';

if (isset($_SESSION['kullanicioturum'])) {
    
    header("location:index");
}

 ?>

  <title>Giriş Yap | Yener Kozmetik</title>


        

        <!--==================== Registration Form Start ====================-->
        <div style="padding-top: 0px;" class="full-row">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="woocommerce">
                            <div class="row">
                                <div class="col-lg-6 col-md-8 col-12 mx-auto">
                                    <div class="registration-form">
                                        <h3 style="font-family: arial;font-weight: 200;">Giriş Yap</h3>

                                        <hr>
                                        <form onsubmit="return false;" id="loginform">
                                           

                                            <p>
                                                <label for="reg_email">E-Posta Adresiniz&nbsp;<span class="required">*</span></label>
                                                <input type="email" maxlength="100" class="form-control" name="kullanici_mail" id="kullanici_mail" />
                                            </p>

                                            <p>
                                                <label for="reg_email">Şifreniz&nbsp;<span class="required">*</span></label>
                                                <input type="password" maxlength="100" class="form-control" name="kullanici_password" id="kullanici_sifre" />
                                            </p>

                                            
                                        
                                            <input type="hidden" name="disableFill" value="">

                                            <div style="display: none;" class="alert alert-warning uyari"><i class="fa fa-info-circle"></i></div>

                                            
                                            <p>
                                                <button type="submit" class="btn btn-primary rounded-0 loginsubmitbuton" name="loginT">Giriş Yap</button>
                                            </p>

                                            <p>Henüz üye olmadınız mı? <a href="uye-ol"><u>Üyelik oluşturun</u></a></p>
                                        <p><a href="sifremi-unuttum"><u>Şifremi unuttum</u></a></p>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--==================== Registration Form Start ====================-->

       <?php require_once 'footer.php'; ?>

       <script type="text/javascript">
        
        


        $('#loginform').submit(function(){

        

var kullanici_mail = $('#kullanici_mail').val();
var kullanici_password = $('#kullanici_sifre').val();

$('.loginsubmitbuton').prop('disabled',true);


var data = $("#loginform").serializeArray();
data.push({name: "uyelogin",value: "ok"});

$.ajax({
            type : 'POST',
            url : 'musteriislem.php',
            data : $.param(data),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

              

              if (sonuc=='yanlisbilgiler') {
                
                $('.uyari').show();
                $('.uyari').html('<i class="fa fa-info-circle"></i> E-posta veya şifre yanlış.');
                $('.loginsubmitbuton').prop('disabled',false);
                $('.loginsubmitbuton').html('Giriş Yap');


               


              } else if (sonuc=="ok") {
                
                $('.loginsubmitbuton').html('Giriş Yapılıyor...');
                window.location = 'index';

              }
              }
        })

});
    </script>