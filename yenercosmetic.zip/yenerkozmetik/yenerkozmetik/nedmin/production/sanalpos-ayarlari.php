<?php require_once 'header.php';

$genelayarsec=$db->prepare("SELECT * from genelayarlar");
$genelayarsec->execute();

 $genelayarcek=$genelayarsec->fetch(PDO::FETCH_ASSOC);

 $ayar_iyziclientid= $genelayarcek['ayar_iyziclientid'];
 $ayar_iyzisecretkey = $genelayarcek['ayar_iyzisecretkey'];
  $ayar_3dodeme = $genelayarcek['ayar_3dodeme'];
   



  ?>



        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              

              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                 
                  <div class="x_content">
                    <br />

                  

                    <form id="sanalposduzenleform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

                      <h3 align="center">Sanal Pos Ayarları</h3>
                      
                      <hr>


                     
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Iyzico Client  Id <span class="required">*</span>
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="ayar_iyziclientid" value="<?php echo $genelayarcek['ayar_iyziclientid']; ?>" name="ayar_iyziclientid"  maxlength="100"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Iyzico Secret Key <span class="required">*</span>
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="ayar_iyzisecretkey" value="<?php echo $genelayarcek['ayar_iyzisecretkey']; ?>" name="ayar_iyzisecretkey" maxlength="100"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      

                      

                      

                      

                     

                

                      <input type="hidden" name="sanalposduzenleadmin">


                      
                      
                      <div class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">


                          <div class="alert alert-warning sanalposuyari" style="display: none;"></div>

                       
                          
                          <button type="submit" class="btn btn-success sanalposduzenlebuton">Düzenle</button>
                        </div>
                      </div>

                    </form>

                    

                   


                    
                  </div>
                </div>
              </div>
            </div>

            <?php require_once 'footer.php'; ?>



            <script type="text/javascript">

             

            $('#sanalposduzenleform').submit(function(){

         
         var ayar_iyziclientid = $.trim($('#ayar_iyziclientid').val()).length;
         var ayar_iyzisecretkey = $.trim($('#ayar_iyzisecretkey').val()).length;  

         if (ayar_iyziclientid==0 || ayar_iyzisecretkey==0) {

 $('.sanalposuyari').show();
 $('.sanalposuyari').html('<i class="fa fa-info-circle"></i> Tüm alanlar doldurulmalıdır.');
 

         }  else {

           $('.sanalposduzenlebuton').prop('disabled',true);

           $('.sanalposuyari').hide();

              

                $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : $('#sanalposduzenleform').serialize(),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

              if (sonuc=="ok") {

                
                $('.sanalposduzenlebuton').prop('disabled',false);


                swal({

  title: "Başarılı",
  text: "Sanal pos ayarları başarıyla güncellendi!",
  icon: "success",
  button: "OK",
});



              }
                

              }


            })


         }         
 

             

                 

                 });

            


            

            </script>

              
             