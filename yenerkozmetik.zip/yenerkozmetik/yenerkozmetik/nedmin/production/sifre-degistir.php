<?php require_once 'header.php'; ?>

        

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Panel Şifre Değiştir</h3>
              </div>

              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                 
                  <div class="x_content">
                    <br />
                    <form id="sifredegistirform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Mevcut Şifre <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="password" id="passwordpresent" name="mevcut_sifre"  placeholder="Mevcut şifrenizi girin" maxlength="100" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>
                       <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Yeni Şifre <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="password" id="passwordnew" name="yeni_sifre" placeholder="Yeni şifrenizi girin" maxlength="100" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>

                      <input type="hidden" name="adminsifredegistir">
                      <input type="hidden" value="<?php echo $adminsessioncek['kullanici_id']; ?>" name="admin_id">

                      
                     
                      
                      <div class="form-group">


                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">

                           <div style="display: none;" class="alert alert-danger uyari"></div>
                           <div style="display: none;" class="alert alert-success success"></div>
                          
                          <button type="submit" class="btn btn-success submitbuton">Değiştir</button>
                        </div>
                      </div>

                    </form>
                  </div>
                </div>
              </div>
            </div>

            <?php require_once 'footer.php'; ?>
            <script type="text/javascript">
              
              $('#sifredegistirform').submit(function(){

          var mevcutsifre = $('#passwordpresent').val();
          var yenisifre = $('#passwordnew').val();

          $('.submitbuton').prop('disabled',true);

        if (yenisifre.length<6) {

         $('.success').hide();
        $('.uyari').show();
        $('.uyari').html("Şifreniz 6 karakterden kısa olamaz.");
        $('.submitbuton').prop('disabled',false);

        } else {

          $('.submitbuton').html('Değiştiriliyor...');

          $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : $('#sifredegistirform').serialize(),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

              if (sonuc=="yanlissifre") {
           
           $('.submitbuton').prop('disabled',false);
           $('.success').hide();
           $('.uyari').show();
           $('.uyari').html('Girdiğiniz mevcut şifre doğru değil.');
           $('.submitbuton').html('Değiştir');

              } else if (sonuc=="ok") {

         $('.submitbuton').prop('disabled',false);
         $('.submitbuton').html('Değiştir');
         $('.uyari').hide();
        $('.success').show();
        $('.success').html('<i class="fa fa-check"></i> Şifre başarıyla değiştirildi!');
        $('#passwordnew').val('');
        $('#passwordpresent').val('');
               
            }
              }
        })
        }

              })

            </script>


            