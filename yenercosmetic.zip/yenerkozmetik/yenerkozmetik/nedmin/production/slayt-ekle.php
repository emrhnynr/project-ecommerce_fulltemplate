<?php require_once 'header.php'; ?>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              

              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Yeni Slayt Ekle</h2>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />
                    <form id="slaytekleform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Slayt Resim (1366 x 504px)<span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="file" id="slayt_foto" name="slayt_foto" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Slayt Sıra <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="number" id="slayt_sira" placeholder="Slaytın kaçıncı sırada listeleneceğini girin." name="slayt_sira"  class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Slayt Başlık
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" id="slayt_baslik" placeholder="Slayt resminin üzerindeki başlık" maxlength="300" name="slayt_baslik"  class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Slayt Metin
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <textarea rows="7" class="form-control" id="slayt_aciklama" name="slayt_aciklama" placeholder="Slayt resminin üzerindeki metin"></textarea>
                        </div>
                      </div>

                       <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Slayt Link
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" id="slayt_link" placeholder="Doldurmazsanız slayt tıklanamaz olur." maxlength="300" name="slayt_link"  class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>

                      <input type="hidden" name="slaytekleadmin">
                      
                      
                      <div class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                          <div style="display: none;" class="alert alert-warning uyari"></div>
                          
                          <button type="submit" class="btn btn-success slayteklebuton">Ekle</button>
                        </div>
                      </div>

                    </form>
                  </div>
                </div>
              </div>
            </div>

            <?php require_once 'footer.php'; ?>
            <script type="text/javascript">
              
              $('#slaytekleform').submit(function(){
          
          var slayt_sira = $('#slayt_sira').val();
         var slayt=$('#slayt_foto').val();
      var slaytuzanti=slayt.split('.').pop();
      var form = $('#slaytekleform')[0];
             var data = new FormData(form);

             if (slayt=="") {

   

$('.uyari').show();
$('.uyari').html('<i class="fa fa-info-circle"></i> Lütfen bir slayt resmi yükleyin.');


      } else if (slaytuzanti!='jpg' && slaytuzanti!='jpeg' && slaytuzanti!='png'){



$('.uyari').show();
$('.uyari').html('<i class="fa fa-info-circle"></i> Sadece <b>.jpg, .jpeg, .png</b> uzantılı dosyaları yükleyebilirsiniz.');

      } else if (slayt_sira.length==0){

$('.uyari').show();
$('.uyari').html('<i class="fa fa-info-circle"></i> Lütfen slaytın kaçıncı sırada listeleneceğini belirtin.');

      } else {

       
       $('.uyari').hide();
$('.slayteklebuton').prop('disabled',true);

$.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            enctype : 'multipart/form-data',
            data : data,
            processData: false,
            contentType: false,
            cache: false,
            success : function(sonuc){

                sonuc=$.trim(sonuc);

                if (sonuc=="ok") {

                  swal({

  title: "Başarılı",
  text: "Slayt ekleme başarılı!",
  icon: "success",
  button: "OK",
}).then((willDelete) => {
  if (willDelete) {

    window.location = 'slayt-ayarlari';

     }

   });
                }

                 }

               });


      }



              });

            </script>

            