<?php require_once 'header.php';


if (empty($_SESSION['kullanicioturum'])) {
    
    header("location:index");
    exit;
};


$siparislerimsec=$db->prepare("SELECT * from siparisler where kullanici_id=:id order by siparis_zaman DESC");
$siparislerimsec->execute(array(
"id" => $_SESSION['kullanici_id']
));

$siparislerimsay=$siparislerimsec->rowCount();

 ?>

 <title>Siparişlerim | Yener Kozmetik</title>

        <!-- breadcrumb -->
        <div class="full-row bg-light py-5">
            <div class="container">
                <div class="row text-secondary">
                    <div class="col-sm-6">
                        <h3 style="font-weight: 200;font-family: arial;" class="mb-2 text-secondary">Siparişlerim</h3>

                        <p class="form-row form-row-wide address-field update_totals_on_change validate-required" id="billing_country_field">
                                                               
                                                                <span class="woocommerce-input-wrapper">
                                                                    <select style="width: 100%;" id="siparisturu" class="country_to_state country_select select2-hidden-accessible">
                                                                        <option selected="" value="tumu">Tümü</option>

                                                                        <option value="teslimedildi">Teslim Edildi</option>

                                                                        <option value="kargoyaverildi">Kargoya Verildi</option>

                                                                        <option value="bekleniyor">Hazırlanıyor</option>

                                                                        
                                                                        
                                                                    </select>
                                                                </span>
                                                            </p>
                    </div>
                    <div class="col-sm-6">
                        <nav aria-label="breadcrumb" class="d-flex justify-content-sm-end align-items-center h-100">
                            <ol class="breadcrumb mb-0 d-inline-flex bg-transparent p-0">
                                <li class="breadcrumb-item"><a href="../"><i class="fas fa-home me-1"></i>Anasayfa</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Siparişlerim</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <!-- breadcrumb -->

        <!--==================== Wishlist Section Start ====================-->
        <div style="padding-top: 20px;" class="full-row">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <form id="yith-wcwl-form" class="table-responsive-lg">
                            

                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!--==================== Wishlist Section End ====================-->

       <?php require_once 'footer.php'; ?>

       <script type="text/javascript">
    
    $('#siparisturu').change(function(){


var siparis_turu = $(this).val();
$('.table-responsive-lg').html('<h4 style="font-family:Arial;" align="center">Yükleniyor...</h4>');

$.ajax({
            type : 'POST',
            url : 'musteriislem.php',
            data : {'siparis_turu':siparis_turu,'siparisturusecajax':'ok'},
            success : function(sonuc){

                sonuc=$.trim(sonuc);

                if (sonuc=='gecersizfiltre') {

                    location.reload();

                     } else {

                $('.table-responsive-lg').html(sonuc);

              }

                

                 }

                });

    }).change();

</script>