<?php require_once 'header.php'; 

if (empty($_GET['kategori_ust']) or $_GET['kategori_ust']=='0') {
  
  $kategori_ust = 0;

} else {

  $kategori_ust = $_GET['kategori_ust'];
}



$kategorisor=$db->prepare("SELECT * from kategoriler where kategori_ust='$kategori_ust' order by kategori_sira ASC");
$kategorisor->execute();

$kategorisay = $kategorisor->rowCount();



$kategorisor2=$db->prepare("SELECT * from kategoriler where kategori_id='$kategori_ust'");
$kategorisor2->execute();

$kategorisay2=$kategorisor2->rowCount();

$kategoricek2=$kategorisor2->fetch(PDO::FETCH_ASSOC);

$kategori_ust_ad=$kategoricek2['kategori_ad'];

if ($kategorisay2==0 and $kategori_ust!=0) {
  header("Location:kategori-ayarlari");
  exit;
}


$say=0;
                      $dizi = array();

                 while ($say<5) {
                    
                    $say++;

                    $kategorisec=$db->prepare("SELECT * from kategoriler where kategori_id='$kategori_ust'");
                    $kategorisec->execute();
                    $kategoricek=$kategorisec->fetch(PDO::FETCH_ASSOC);

                    $kategori_id = $kategoricek['kategori_id'];

                    if ($kategoricek['kategori_ust']==0) {
                      
                      array_push($dizi, $kategori_id);
                      break;

                    } else {

                      array_push($dizi, $kategori_id);

                    }

                    $kategori_ust = $kategoricek['kategori_ust'];

                  };

?>
        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
           

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2><?php if ($kategori_ust==0) {
                     echo "En Üst Kategoriler";
                    } else {

                      $dizibasla = count($dizi);

                      echo "<a href='kategori-ayarlari'>En Üst Kategoriler</a> > ";

                      while ($dizibasla>0) {
                        
                        $dizibasla--;

                        $kategori_id = $dizi[$dizibasla];

                        $kategorisec=$db->prepare("SELECT * from kategoriler where kategori_id='$kategori_id'");
                        $kategorisec->execute();

                        $kategoricek=$kategorisec->fetch(PDO::FETCH_ASSOC);

                        if ($kategori_id == $dizi[0]) {

                          echo $kategoricek['kategori_ad'];
                        } else {

                          echo "<a href='kategori-ayarlari?kategori_ust=$kategori_id'>".$kategoricek['kategori_ad']."</a> > ";


                        }
                      }

                      
                    } ?></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <a target="_blank" class="btn btn-success" data-toggle='modal' href="kategori-ekle?kategori_ust=<?php echo $_GET['kategori_ust']; ?>">Alt Kategori Ekle +</a>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">



                    


                   <?php if ($kategorisay==0 and $kategori_ust==0) {
                     
                     echo '<h4 align="center">Henüz kategori eklenmemiş.</h4>';

                   } else if ($kategorisay==0 and $kategori_ust!=0){

                    echo '<h4 align="center">Alt kategori bulunamadı.</h4>';


                   } else { ?>

                    <table id="datatable" class="table table-striped table-bordered">
                      <thead>
                        <tr>
                         
                          <th>Kategori Adı</th>
                          <th>Sıra</th>

                          

                          
                          
                         
                          <th></th>
                          
                          
                          
                         
                        </tr>
                      </thead>


                      <tbody>

        <?php 

        while ($kategoricek=$kategorisor->fetch(PDO::FETCH_ASSOC)) { 

          $kategori_id = $kategoricek['kategori_id'];
          $kategori_ad = $kategoricek['kategori_ad'];
          $kategori_sira = $kategoricek['kategori_sira'];
          $kategori_aktif = $kategoricek['kategori_aktif'];

          
          
           

          



         ?>

        <tr class="kategori_<?php echo $kategori_id; ?>">
                          
                          <td><?php echo $kategori_ad; ?></td>

                          
                        

                        <td><div class="col-md-8"><input id="kategori2_<?php echo $kategori_id; ?>" class="form-control" type="number" min="1" step='any' value="<?php echo $kategori_sira; ?>" name=""></div><div class="col-md-4"><a href="javascript:void(0);" class="btn btn-success btn-block siraguncelle" name="kategori_<?php echo $kategori_id; ?>">Güncelle</a></div></td>

                          




                      
                          
                          <td align="center">

                            <div class="row">

                              <div class="col-md-3">

                            <a class="btn btn-warning btn-block" href="kategori-duzenle?kategori_id=<?php echo $kategori_id; ?>">Düzenle</a>

                            </div>

                            <div class="col-md-3">

                            <a class="btn btn-warning btn-block" href="kategori-ayarlari?kategori_ust=<?php echo $kategori_id; ?>">Alt Kategoriler</a>

                            </div>

                            <div class="col-md-3">

                            <a class="btn btn-primary btn-block"  href="kategori-markalar?kategori_id=<?php echo $kategori_id; ?>">Markalar</a>

                          </div>

                            <div class="col-md-3">
                            
                            <?php if ($kategori_aktif==1) { ?>
                             
                             <a class="btn btn-danger btn-block kategoripasif" name="kategori_<?php echo $kategori_id; ?>" href="javascript:void(0);">Pasif Yap</a></td>

                            <?php } else { ?>

                              <a class="btn btn-success btn-block kategoriaktif" name="kategori_<?php echo $kategori_id; ?>" href="javascript:void(0);">Aktif Yap</a></td>


                           <?php } ?>



                         </div>



                            

                            

                         </div>


                        
                          
                          
                        </tr>
          
        <?php } ?>

                        
                        
                        
                      </tbody>
                    </table>



                   <?php } ?>
                    
                  </div>
                </div>
              </div>

              <!-- Bitiyor -->

              

            </div>
          </div>
        </div>
        <!-- /page content -->

       <?php require_once 'footer.php'; ?>
       <script type="text/javascript">
         
         $('.kategoripasif').click(function(){
            
            var buton = $(this);
            var id1=$(this).attr("name");
                var kategori_id=id1.substring(9);

               swal({
  title: "Emin misiniz?",
  text: "Bu kategori ve alt kategorileri websitesinde gözükmeyecek.",
  icon: "warning",
  buttons: ["Vazgeç", "Pasif Yap"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

    buton.html('Pasifleştiriliyor...');

    $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'kategoripasif':'ok','kategori_id':kategori_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              

              if (sonuc=="ok") {

                location.reload();
              }

               }

             });


     }

     })
         });


         $('.kategoriaktif').click(function(){
            
            var buton = $(this);
            var id1=$(this).attr("name");
                var kategori_id=id1.substring(9);

               swal({
  title: "Emin misiniz?",
  text: "Bu kategori websitesinde tekrar aktifleştirilecek.",
  icon: "warning",
  buttons: ["Vazgeç", "Aktif Yap"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

    buton.html('Aktifleştiriliyor...');

    $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'kategoriaktif':'ok','kategori_id':kategori_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              

              if (sonuc=="ok") {

                location.reload();
              }

               }

             });


     }

     })
         });


          

          $('.siraguncelle').click(function(){

                var buton = $(this);
                var id1=$(this).attr("name");
                var kategori_id=id1.substring(9);
                var sira = $.trim($('#kategori2_'+kategori_id).val());

                $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'kategorisiraguncelle':'ok','kategori_id':kategori_id,'sira':sira},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              if (sonuc=="ok") {

                swal({

  title: "Başarılı",
  text: "Kategori sırası güncellendi!",
  icon: "success",
  button: "OK",
});
              }

               }

             });
              });

       </script>