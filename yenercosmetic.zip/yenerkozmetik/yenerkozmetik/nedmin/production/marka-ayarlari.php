<?php require_once 'header.php'; ?>
        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
           

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Marka Ayarları</h2>


                    <ul class="nav navbar-right panel_toolbox">
                      <a class="btn btn-success" href="marka-ekle">Marka Ekle +</a>
                    </ul>


                    <div class="clearfix"></div>
                  </div>

                  
                  <div class="x_content">

                    <?php $markasec=$db->prepare("SELECT * from markalar");
        $markasec->execute();
        $markasay = $markasec->rowCount();

        if ($markasay==0) { ?>
           
           <h4 align="center">Henüz marka eklenmemiş.</h4>

        <?php } else { ?>


          <table id="datatable" class="table table-striped table-bordered">
                      <thead>
                        <tr>
                         
                          <th>Marka Logo</th>
                          <th>Marka İsmi</th>
                          <th></th>
                          
                        
                          
                          
                         
                        </tr>
                      </thead>


                      <tbody>

        <?php 

        while ($markacek=$markasec->fetch(PDO::FETCH_ASSOC)) { 

          $marka_id = $markacek['marka_id'];
          
          $marka_ad = $markacek['marka_ad'];
          $marka_logo = $markacek['marka_logo'];

         

           

          



         ?>

        <tr class="kategori_<?php echo $kategori_id; ?>">
                          
                          <td><img style="width: 120px;height: 120px;" class="img-responsive" src="../../<?php echo $marka_logo; ?>"></td>
                          <td><?php echo $marka_ad; ?></td>
                          <td align="right">
                            <a class="btn btn-warning btn-sm" href="marka-duzenle?marka_id=<?php echo $marka_id; ?>">Düzenle</a>
                            <a class="btn btn-danger btn-sm markasil" name="marka_<?php echo $marka_id; ?>" href="javascript:void(0);">Sil</a>
                          </td>
                         
                         
                        
                          
                          
                        </tr>
          
        <?php } ?>

                        
                        
                        
                      </tbody>
                    </table>


         <?php } ?>


                   
                    
                  </div>
                </div>
              </div>

              <!-- Bitiyor -->

              

            </div>
          </div>
        </div>
        <!-- /page content -->

       <?php require_once 'footer.php'; ?>
        <script type="text/javascript">
         
         $('.markasil').click(function(){

           var buton = $(this);
            var id1=$(this).attr("name");
                var marka_id=id1.substring(6);

               swal({
  title: "Bu markayı silmek istiyor musunuz?",
  text: "Bu markaya ait ürünler markayla birlikte kaldırılmayacak. Eğer ürünleri de kaldırmak istiyorsanız lütfen önce markaya ait tüm ürünleri kaldırın. Markaya ait ürün zaten yoksa bu uyarıyı görmezden gelin.",
  icon: "warning",
  buttons: ["Vazgeç", "Sil"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

    buton.html('Siliniyor...');

    $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'markasil':'ok','marka_id':marka_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              if (sonuc=="ok") {

                location.reload();
              }

               }

             });


     }

     })
         })

       </script>