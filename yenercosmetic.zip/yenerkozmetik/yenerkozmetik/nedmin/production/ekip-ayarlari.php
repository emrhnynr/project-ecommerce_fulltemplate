<?php require_once 'header.php';


$genelayarsec=$db->prepare("SELECT * from genelayarlar");
$genelayarsec->execute();

 $genelayarcek=$genelayarsec->fetch(PDO::FETCH_ASSOC);

 $ayar_ekipbaslik = $genelayarcek['ayar_ekipbaslik'];

  ?>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              
                <div class="row">
                      <div class="col-md-4 col-xs-12"><input maxlength="150" class="form-control" id="ayar_ekipbaslik" type="text" value="<?php echo $ayar_ekipbaslik; ?>" name="" ></div>
                      <div class="col-md-2 col-xs-12"><a class="btn btn-success btn-block baslikguncellebuton" href="javascript:void(0);">Güncelle</a></div>
                    </div>
              

             
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12">
                <div class="x_panel">
                  <div class="x_content">
                    <div class="row">
                      <div style="margin-bottom:50px;" align="right" class="col-md-12 col-sm-12 col-xs-12">
                        <a class="btn btn-success" data-toggle='modal' href="#yeniuye">+ Üye Ekle</a>
                      </div>

                      



                      <div class="clearfix"></div>



                      <?php $ekipuyelersec=$db->prepare("SELECT * from ekipuyeleri order by uye_sira ASC");
                      $ekipuyelersec->execute();
                      $ekipuyelersay = $ekipuyelersec->rowCount();

                      if ($ekipuyelersay==0) { ?>
                       
                       <h4 align="center">Henüz ekip üyesi eklenmemiş.</h4>

                     <?php } else { 


                      while ($ekipuyelercek=$ekipuyelersec->fetch(PDO::FETCH_ASSOC)) { ?>
                        
                        <div class="col-md-4 col-sm-4 col-xs-12 profile_details">
                        <div class="well profile_view">
                          <div class="col-sm-12">
                            <h4 class="brief"><i><?php echo $ekipuyelercek['uye_gorev']; ?></i></h4>
                            <div class="left col-xs-7">
                              <h2><?php echo $ekipuyelercek['uye_adsoyad']; ?></h2>
                              
                              
                            </div>
                            <div class="right col-xs-5 text-center">
                              <img src="../../<?php echo $ekipuyelercek['uye_foto']; ?>" alt="" class="img-circle img-responsive">
                            </div>
                          </div>
                          <div class="col-xs-12 bottom text-center">
                            
                            <div class="col-xs-12 col-sm-6 emphasis">
                              
                              <a data-toggle='modal' href="#uyeduzenle_<?php echo $ekipuyelercek['uye_id']; ?>"><button type="button" class="btn btn-warning btn-xs">
                                <i class="fa fa-user"> </i> Düzenle
                              </button></a>

                              <a class="ekipuyesil" name="uye_<?php echo $ekipuyelercek['uye_id']; ?>" href="javascript:void(0);"><button type="button" class="btn btn-danger btn-xs">
                                Sil
                              </button></a>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div class="modal fade" id="uyeduzenle_<?php echo $ekipuyelercek['uye_id']; ?>"> 
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

      

        <div style="padding: 50px;" class="modal-body">

          <h3>Ekip Üyesi Düzenle<hr></h3>

          <form action="../../adminislem.php" method="POST" id="ekipuyeduzenleform" enctype="multipart/form-data">
         <div class="row">

          <div class="col-md-12 col-xs-12 col-sm-12">
            <label>Profil Fotoğrafı (Seçmezseniz fotoğraf güncellenmez.)</label>
             <input class="form-control" type="file" name="uye_foto">
           </div>
           
           <div style="margin-top:20px;" class="col-md-12 col-xs-12 col-sm-12">
            <label>Ad & Soyad *</label>
             <input class="form-control" required="" type="text" maxlength="200" value="<?php echo $ekipuyelercek['uye_adsoyad']; ?>" name="uye_adsoyad">
           </div>



           <div style="margin-top:20px;" required="" class="col-md-12 col-xs-12 col-sm-12">
            <label>Görev *</label>
             <input class="form-control" required="" maxlength="200" value="<?php echo $ekipuyelercek['uye_gorev']; ?>" type="text" name="uye_gorev">
           </div>



           <div style="margin-top:20px;" required="" class="col-md-12 col-xs-12 col-sm-12">
            <label>Sıra *</label>
             <input class="form-control" required="" min="1" maxlength="200" value="<?php echo $ekipuyelercek['uye_sira']; ?>" type="number" name="uye_sira">
           </div>


           <input type="hidden" value="<?php echo $ekipuyelercek['uye_id']; ?>" name="uye_id">

          

         


        
           

         </div>

        </div>

     
       
    <div class="modal-footer">


  
    
    <button class="btn btn-success" name="ekipuyeduzenle" type="submit">Düzenle</button>

     </form>
    <button class="btn btn-danger" data-dismiss="modal">Kapat</button>

    
</div>





  

     
    </div>

  </div>

</div>



                    <?php } ?>

                      



                       <?php } ?>

                       <div class="modal fade" id="yeniuye"> 
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

      

        <div style="padding: 50px;" class="modal-body">

          <h3>Yeni Ekip Üyesi<hr></h3>

          <form action="../../adminislem.php" method="POST" id="ekipuyeekleform" enctype="multipart/form-data">
         <div class="row">



          <div class="col-md-12 col-xs-12 col-sm-12">
            <label>Profil Fotoğrafı*</label>
             <input class="form-control" required="" type="file" name="uye_foto">
           </div>
           
           <div style="margin-top:20px;" class="col-md-12 col-xs-12 col-sm-12">
            <label>Ad & Soyad*</label>
             <input class="form-control" required="" maxlength="200" type="text" name="uye_adsoyad">
           </div>



           <div style="margin-top:20px;" class="col-md-12 col-xs-12 col-sm-12">
            <label>Görev*</label>
             <input class="form-control" required="" maxlength="200" type="text" name="uye_gorev">
           </div>

          

           <div style="margin-top:20px;" class="col-md-12 col-xs-12 col-sm-12">
            <label>Sıra*</label>
             <input class="form-control" required="" min="1" maxlength="200" type="number" name="uye_sira">
           </div>


          

          

         


        
           

         </div>

        </div>

     
       
    <div class="modal-footer">


  
    
    <button class="btn btn-success" name="ekipuyeekle" type="submit">Ekle</button>

     </form>
    <button class="btn btn-danger" data-dismiss="modal">Kapat</button>

    
</div>





  

     
    </div>

  </div>

</div>

                      

                      
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <?php require_once 'footer.php'; ?>
        <script type="text/javascript">

          $('.baslikguncellebuton').click(function(){

var ayar_ekipbaslik = $.trim($('#ayar_ekipbaslik').val());

$('.baslikguncellebuton').prop('disabled',true);


$.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : {'ekipbaslikduzenle':'ok','ayar_ekipbaslik':ayar_ekipbaslik},
            success : function(sonuc){

              sonuc = $.trim(sonuc);

              if (sonuc=="ok") {

                


                swal({

  title: "Başarılı",
  text: "Ekip başlık güncellendi!",
  icon: "success",
  button: "OK",
});



              }
                

              }


            })



          });
          
 $('.ekipuyesil').click(function(){

var id1=$(this).attr("name");
                var uye_id=id1.substring(4);

                swal({
  title: "Bu üyeyi silmek istiyor musunuz?",
  icon: "warning",
  buttons: ["Vazgeç", "Sil"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

    $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'ekipuyesil':'ok','uye_id':uye_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              if (sonuc=="ok") {

                location.reload();
              }

               }

             });

     }

     })

 })



        </script>