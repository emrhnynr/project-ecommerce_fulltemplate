<?php require_once 'header.php'; 


// Tüm tekil ürün id lerinin toplam sepet miktarı hesaplanıyor, eğer stoktan fazla miktarda varsa o ürün kullanıcı sepetinden siliniyor. Eğer sonunda kullanıcı sepeti boşaldıysa sepetim sayfasına geri atıyor.

$urunidler = [];

$sepeturunsec0 = $db->prepare("SELECT * from sepetitem where kullanici_id=:id");
$sepeturunsec0->execute(array(
"id" => $_SESSION['kullanici_id']
));

while ($sepeturuncek0=$sepeturunsec0->fetch(PDO::FETCH_ASSOC)) {
    
    $urun_id = $sepeturuncek0['urun_id'];

    if (!in_array($urun_id, $urunidler)) {
        
        $urunidler[] = $urun_id;
    }

    

    }

    foreach ($urunidler as $urun_id) {
        
        $iddekisepeturunsayisi = 0;

        $sepetitemidler = [];


         $sepeturunicsec = $db->prepare("SELECT * from sepetitem where urun_id=:urunid and kullanici_id=:kulid");
         $sepeturunicsec->execute(array(

"urunid" => $urun_id,
"kulid" => $_SESSION['kullanici_id']

         ));

         while ($sepeturuniccek=$sepeturunicsec->fetch(PDO::FETCH_ASSOC)) {

            
               
               $sepetitemidler[] = $sepeturuniccek['sepetitem_id'];

            
        
        $iddekisepeturunsayisi = $iddekisepeturunsayisi + $sepeturuniccek['urun_miktar'];


    }

  $urunstoksec = $db->prepare("SELECT * from urunler where urun_id = '$urun_id' and urun_stok < $iddekisepeturunsayisi");
  $urunstoksec->execute();
  $urunstoksay = $urunstoksec->rowCount();

  if ($urunstoksay==1) {
      
    
    foreach ($sepetitemidler as $sepetitem_id) {

        $itemsepetsil = $db->prepare("DELETE from sepetitem where sepetitem_id='$sepetitem_id'");
        $itemsepetsil->execute();

        $itemsepetseceneklersil = $db->prepare("DELETE from sepetitemsecenekler where sepetitem_id='$sepetitem_id'");
        $itemsepetseceneklersil -> execute();

        
    }

    $sepetitemsilindi = '';
    

  }

    }


   
//------------------------------------------



$sepeturunsec=$db->prepare("SELECT * from sepetitem where kullanici_id=:id order by urun_id DESC");
                    $sepeturunsec->execute(array(

                        "id" => $_SESSION['kullanici_id']
                    ));

                    $sepeturunsay=$sepeturunsec->rowCount();


                    if (empty($_SESSION['kullanicioturum'])) {
                        
                        header("location:uye-ol");
                        exit;

                    } else if ($sepeturunsay==0){

                      header("location:sepetim");
                        exit;

                    };


                    $taksitaraliksec=$db->prepare("SELECT * from taksitler where taksit_altdeger<='$urun_toplam' and taksit_ustdeger>'$urun_toplam'");
                    $taksitaraliksec->execute();

                    $taksitaralikcek=$taksitaraliksec->fetch(PDO::FETCH_ASSOC);

                    $taksit_id = $taksitaralikcek['taksit_id'];


                    $taksitimkansec=$db->prepare("SELECT * from taksitaraliksecenekleri where taksit_id='$taksit_id' order by secenek_id ASC");

                    $taksitimkansec->execute();

                     ?>


                     <title>Siparişi Tamamlayın | Yener Kozmetik</title>




        

        <!--==================== Checkout Section Start ====================-->
        <div id="main-content" class="full-row site-content">
            <div class="container">
                <div class="row ">
                    <div id="primary" class="content-area col-md-12">
                        <article id="post-19" class="post-19 page type-page status-publish hentry">
                            <div class="entry-content">
                                <div class="woocommerce">
                                    
                                    

                    
                                   

                                    <form onsubmit="return false;" class="checkout woocommerce-checkout" id="checkoutform">
                                        <div class="row">

                                            <?php if (isset($sepetitemsilindi)) { ?>
                                                
                                                <div class="alert alert-info"><i class="fa fa-info-circle"></i> Stoğu yetersiz olan bazı ürünler sepetinizden kaldırıldı.</div>

                                           <?php } ?>

                                            <div class="col-lg-7">
                                                <div class="col2-set" id="customer_details">
                                                    <div class="woocommerce-billing-fields">
                                                        <h3 style="font-family: arial;font-weight: 200;">Teslimat Detayları</h3><hr>
                                                        <div class="woocommerce-billing-fields__field-wrapper">


                                                            <p class="form-row form-row-first validate-required" id="billing_first_name_field" data-priority="10">
                                                                <label for="billing_first_name" class="">Adınız&nbsp;<abbr class="required" title="required">*</abbr></label>
                                                                <span class="woocommerce-input-wrapper">
                                                                    <input type="text" class="input-text " name="siparis_ad" id="siparis_ad" maxlength="100">
                                                                </span>
                                                            </p>


                                                            <p class="form-row form-row-first validate-required" id="billing_first_name_field" data-priority="10">
                                                                <label for="billing_first_name" class="">Soyadınız&nbsp;<abbr class="required" title="required">*</abbr></label>
                                                                <span class="woocommerce-input-wrapper">
                                                                    <input type="text" class="input-text" name="siparis_soyad" id="siparis_soyad" maxlength="100">
                                                                </span>
                                                            </p>


                                                            <p class="form-row form-row-first validate-required" id="billing_first_name_field" data-priority="10">
                                                                <label for="billing_first_name" class="">Cep Telefonunuz&nbsp;<abbr class="required" title="required">*</abbr></label>
                                                                <span class="woocommerce-input-wrapper">
                                                                    <input type="text" class="input-text" name="siparis_telno" id="siparis_telno" maxlength="20" placeholder="Örn. (05xxxxxxxxx)">
                                                                </span>
                                                            </p>


                                                            


                                                            <p class="form-row form-row-wide address-field update_totals_on_change validate-required" id="billing_country_field">
                                                                <label for="billing_country" class="">Şehir&nbsp;<abbr class="required" title="required">*</abbr></label>
                                                                <span class="woocommerce-input-wrapper">
                                                                    <select name="siparis_sehir" id="siparis_sehir" class="country_to_state country_select select2-hidden-accessible">
                                                                        <option value="secilmedi">Seçiniz</option>

                                                                        <?php $sehirsec=$db->prepare("SELECT * from sehirler order by sehir_id ASC");
                                     $sehirsec->execute();

                                     while ($sehircek=$sehirsec->fetch(PDO::FETCH_ASSOC)) { ?>

                                                                        <option value="<?php echo  $sehircek['sehir_id']; ?>"><?php echo $sehircek['sehir_isim']; ?></option>

                                                                    <?php } ?>
                                                                        
                                                                    </select>
                                                                </span>
                                                            </p>

                                                            <p class="form-row form-row-wide address-field update_totals_on_change validate-required" id="billing_country_field">
                                                                <label for="billing_country" class="">İlçe&nbsp;<abbr class="required" title="required">*</abbr></label>
                                                                <span class="woocommerce-input-wrapper">
                                                                    <select name="siparis_ilce" id="siparis_ilce" class="country_to_state country_select select2-hidden-accessible">


                                                                        <option selected="">Önce Şehir Seçiniz</option>

                                                                        
                                                                    </select>
                                                                </span>
                                                            </p>

                                                            <p class="form-row notes" id="order_comments_field" data-priority=""><label for="order_comments" class="">Sipariş Adresi <span class="required">*</span></label><span class="woocommerce-input-wrapper"><textarea name="siparis_adres" class="input-text " id="siparis_adres" maxlength="1000" rows="3" cols="5"></textarea></span></p>


                                                            <p class="form-row notes" id="order_comments_field" data-priority=""><label for="order_comments" class="">Sipariş Notu <span class="optional">(Opsiyonel)</span></label><span class="woocommerce-input-wrapper"><textarea name="siparis_not" class="input-text " id="siparis_not" maxlength="500" rows="2" cols="5"></textarea></span></p>
                                                            
                                                        </div>
                                                    </div>

                                                    <div class="woocommerce-shipping-fields">
                                                        <h3 id="ship-to-different-address">
                                                            <label class="woocommerce-form__label woocommerce-form__label-for-checkbox checkbox">
                                                                <input id="sozlesme" class="woocommerce-form__input woocommerce-form__input-checkbox input-checkbox" type="checkbox" name="ship_to_different_address" value="0"> 
                                                                <span style="font-family: arial;font-size: 16px;"><a target="_blank" href="mesafeli-satis-sozlesmesi"><u>Mesafeli satış sözleşmesi'ni</u></a> okudum ve onaylıyorum.</span>
                                                            </label>
                                                        </h3>
                                                        
                                                    </div>
                                                    
                                                </div>
                                            </div>
                                            <div class="col-lg-5">
                                                <div class="order-review-inner">
                                                    <h3 style="font-family: arial;font-weight: 200;" id="order_review_heading">Ürünler</h3>
                                                    <div id="order_review" class="woocommerce-checkout-review-order">
                                                        <table style="width: 100%;" class="shop_table woocommerce-checkout-review-order-table">
                                                            <thead>
                                                                <tr>
                                                                    <th class="product-name">Ürün</th>
                                                                    <th class="product-total">Fiyat</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>

                                                                <?php 

              $sepeturunsec=$db->prepare("SELECT * from sepetitem where kullanici_id=:id order by urun_id DESC");
                    $sepeturunsec->execute(array(

                        "id" => $_SESSION['kullanici_id']
                    ));

                    $urun_toplam = 0;
                    $toplam_desi = 0;

                    $say=0;

                    

                    while ($sepeturuncek=$sepeturunsec->fetch(PDO::FETCH_ASSOC)) { 

                        $say++;

                        $sepetitem_id = $sepeturuncek['sepetitem_id'];
                        $urun_id = $sepeturuncek['urun_id'];  

                        $urunsec=$db->prepare("SELECT * from urunler where urun_id=:id");
                        $urunsec->execute(array(

                            "id" => $sepeturuncek['urun_id']
                        ));

                        $uruncek = $urunsec->fetch(PDO::FETCH_ASSOC);

                        

                            $sepetitemseceneksec = $db->prepare("SELECT * from sepetitemsecenekler where sepetitem_id='$sepetitem_id'");

                          $sepetitemseceneksec->execute();

                            

                              $urun_fiyat = $uruncek['urun_nihaifiyat'];

                              
                            

                        $urun_desi = $uruncek['urun_desi'];

                        $urun_toplamfiyat = $sepeturuncek['urun_miktar']*$urun_fiyat;
                        $urun_toplamdesi = $sepeturuncek['urun_miktar']*$urun_desi;

                        $urun_toplam+=$urun_toplamfiyat;
                        $toplam_desi+=$urun_toplamdesi;

                        $urun_ad=$uruncek['urun_ad'];

                
                     ?>

                                                                <tr class="cart_item">
                                                                    <td class="product-name">
                                                                        <a target="_blank" href='urun-<?php echo seo($urun_ad)."-".$uruncek['urun_id']; ?>'><?php if (strlen($urun_ad)>85) { ?>
                            <?php echo substr($urun_ad,0,85)."..."; ?>
                        <?php } else { 

                         echo $urun_ad; 
                         } ?></a> <strong class="product-quantity">×&nbsp;<?php echo $sepeturuncek['urun_miktar']; ?></strong><br>

                     <?php while ($sepetitemsecenekcek=$sepetitemseceneksec->fetch(PDO::FETCH_ASSOC)) { 
                $secenek_ad = $sepetitemsecenekcek['secenek_ad'];
                $altsecenek_ad = $sepetitemsecenekcek['altsecenek_ad']; ?> 


                <?php echo "<span style='font-weight:500;'>".$secenek_ad."</span> : ".$altsecenek_ad."<br>"; ?>
                            

              <?php } ?>
          </td>
                                                                    <td class="product-total">
                                                                        <span class="woocommerce-Price-amount amount"><bdi><?php echo $urun_toplamfiyat; ?> TL</bdi>
                                                                        </span>
                                                                    </td>
                                                                </tr>

                    <input type="hidden" value="<?php echo $sepeturuncek['sepetitem_id']; ?>" name="sepetitem_id[]">
                    <input type="hidden" value="<?php echo $sepeturuncek['urun_miktar']; ?>" name="urun_miktar[]">
                    <input type="hidden" value="<?php echo $urun_fiyat; ?>" name="urun_fiyat[]">

                    <?php

                    $sepetitemseceneksec2 = $db->prepare("SELECT * from sepetitemsecenekler where sepetitem_id='$sepetitem_id'");

                          $sepetitemseceneksec2->execute();

                           while ($sepetitemsecenekcek2=$sepetitemseceneksec2->fetch(PDO::FETCH_ASSOC)) { 
                $secenek_ad = $sepetitemsecenekcek2['secenek_ad'];
                $altsecenek_ad = $sepetitemsecenekcek2['altsecenek_ad']; ?> 


               <input type="hidden" value="<?php echo $secenek_ad; ?>" name="secenek_ad_<?php echo $say; ?>[]">
                <input type="hidden" value="<?php echo $altsecenek_ad; ?>" name="altsecenek_ad_<?php echo $say; ?>[]">

                                                            <?php  } }  ?>

                                                            
                                                                
                                                            </tbody>
                                                            <tfoot>

                                                                <?php if (!empty($genelayarcek['kargobedava_limit'])) {
                              
                              if ($urun_toplam>$genelayarcek['kargobedava_limit']) {

               $kargo_ucreti = 0.00;
                                

                              } else {


                   $kargoucretisec=$db->prepare("SELECT * from kargoucretleri where 
                                  min_desi<='$toplam_desi' and max_desi>'$toplam_desi'");
                                $kargoucretisec->execute();

                                $kargoucreticek=$kargoucretisec->fetch(PDO::FETCH_ASSOC);

                                


                   $kargo_ucreti = $kargoucreticek['kargo_ucreti'];

                              }

                            } else {

                               $kargoucretisec=$db->prepare("SELECT * from kargoucretleri where 
                                  min_desi<='$toplam_desi' and max_desi>'$toplam_desi'");
                                $kargoucretisec->execute();

                                $kargoucreticek=$kargoucretisec->fetch(PDO::FETCH_ASSOC);

                                


                   $kargo_ucreti = $kargoucreticek['kargo_ucreti'];


                            };





                             ?>

                                                                <tr class="cart-subtotal">
                                                                    <th>Ara Toplam</th>
                                                                    <td><span class="woocommerce-Price-amount amount"><bdi><?php echo $urun_toplam; ?> TL</bdi>
                                                                        </span>
                                                                    </td>
                                                                </tr>

                                                                <tr class="cart-subtotal">
                                                                    <th>Kargo Ücreti</th>
                                                                    <td><span class="woocommerce-Price-amount amount"><bdi><?php echo $kargo_ucreti; ?> TL</bdi>
                                                                        </span>
                                                                    </td>
                                                                </tr>
                                                                <tr class="woocommerce-shipping-totals shipping taksitsecenektr">
                                                                    <th>Taksit</th>
                                                                    <td data-title="Shipping">
                                                                        
                                                                        <div class="radio">
                          <label>
                            <input type="radio" name="taksitsecenegi" id="secenekid_0" value="1" checked="">
                            Tek Çekim
                          </label>
                        </div>


                        <?php while ($taksitimkancek=$taksitimkansec->fetch(PDO::FETCH_ASSOC)) {

                        $secenek_id = $taksitimkancek['secenek_id'];

                        $taksitseceneksec=$db->prepare("SELECT * from taksitsecenekleri where secenek_id='$secenek_id'");

                        $taksitseceneksec->execute();

                        $taksitsecenekcek=$taksitseceneksec->fetch(PDO::FETCH_ASSOC);

                        $secenek_ad = $taksitsecenekcek['secenek_ad'];
                        $secenek_vadefarki = $taksitsecenekcek['secenek_vadefarki'];


                            ?>
                            
                            <div class="radio">
                          <label>
                            <input type="radio" name="taksitsecenegi" id="secenekid_<?php echo $secenek_id; ?>" value="<?php echo $secenek_ad; ?>">
                            <?php echo $secenek_ad." Taksit"; ?>
                          </label>
                        </div>

                        <input type="hidden" value="<?php echo $secenek_vadefarki; ?>" class="secenekid_<?php echo $secenek_id; ?>">

                    <?php } ?>

                                                                    </td>
                                                                </tr>
                                                                <tr class="order-total">
                                                                    <th>Toplam</th>
                                                                    <td><strong><span class="woocommerce-Price-amount amount"><bdi><?php echo $urun_toplam + $kargo_ucreti; ?> TL</bdi></span></strong> </td>
                                                                </tr>
                                                            </tfoot>
                                                        </table>



            <input type="hidden" name="disableFill" value="">


                                                        <div style="margin-top:35px;" id="payment" class="woocommerce-checkout-payment">
                                                            
                                                            <h4 style="font-family: arial;font-weight: 200;">Ödeme Bilgileri <i class="far fa-credit-card"></i><hr></h4>

                                                            <p class="form-row form-row-first validate-required" id="billing_first_name_field" data-priority="10">
                                                                <label for="billing_first_name" class="">Kart Numarası&nbsp;<abbr class="required" title="required">*</abbr></label>
                                                                <span class="woocommerce-input-wrapper">
                                                                    <input type="text" placeholder="16 haneli kart numaranız" class="input-text " name="kartnumarasi" id="kartnumarasi" maxlength="22">
                                                                </span>
                                                            </p>


                                                            <p class="form-row form-row-first validate-required" id="billing_first_name_field" data-priority="10">
                                                                <label for="billing_first_name" class="">Kart Sahibi&nbsp;<abbr class="required" title="required">*</abbr></label>
                                                                <span class="woocommerce-input-wrapper">
                                                                    <input type="text" placeholder="Kartın üzerindeki ad & soyad" class="input-text " name="kartsahibi" id="kartsahibi" maxlength="100">
                                                                </span>
                                                            </p>


                                                            <div class="row">
                                                                
                                                                <div class="col-lg-4 col-md-6 col-xs-6">


                                                                    <p class="form-row form-row-wide address-field update_totals_on_change validate-required" id="billing_country_field">
                                                                
                                                                <span class="woocommerce-input-wrapper">
                                                                   <select style="background: white;" name="sonkullanimayi" class="country_to_state country_select select2-hidden-accessible">
                    <option value="aysecilmedi" selected="">Ay Seçiniz</option>
                    <option style='color: black;'>01</option>
                    <option style='color: black;'>02</option>
                    <option style='color: black;'>03</option>
                    <option style='color: black;'>04</option>
                    <option style='color: black;'>05</option>
                    <option style='color: black;'>06</option>
                    <option style='color: black;'>07</option>
                    <option style='color: black;'>08</option>
                    <option style='color: black;'>09</option>
                    <option style='color: black;'>10</option>
                    <option style='color: black;'>11</option>
                    <option style='color: black;'>12</option>
                  </select>
                                                                </span>
                                                            </p>
                                                                    

                                                                </div>

                                                                <div class="col-lg-4 col-md-6 col-xs-6">


                                                                    <p class="form-row form-row-wide address-field update_totals_on_change validate-required" id="billing_country_field">
                                                                
                                                                <span class="woocommerce-input-wrapper">
                                                                   <select style="background: white;" name="sonkullanimyili" class="country_to_state country_select select2-hidden-accessible">
                    <option value="yilsecilmedi" selected="">Yıl Seçiniz</option>
                    <option style='color: black;'>2020</option>
                    <option style='color: black;'>2021</option>
                    <option style='color: black;'>2022</option>
                    <option style='color: black;'>2023</option>
                    <option style='color: black;'>2024</option>
                    <option style='color: black;'>2025</option>
                    <option style='color: black;'>2026</option>
                    <option style='color: black;'>2027</option>
                    <option style='color: black;'>2028</option>
                    <option style='color: black;'>2029</option>
                    <option style='color: black;'>2030</option>
                    <option style='color: black;'>2031</option>
                    <option style='color: black;'>2032</option>
                  </select>
                                                                </span>
                                                            </p>
                                                                    

                                                                </div>


                                                                <div class="col-lg-4 col-md-6 col-xs-6">


                                                                    <p class="form-row form-row-wide address-field update_totals_on_change validate-required" id="billing_country_field">
                                                                
                                                                <span class="woocommerce-input-wrapper">
                                                                   
                                                                   <input type="text" placeholder="CVC" class="input-text " name="cvc" id="cvc" maxlength="3">

                                                                </span>
                                                            </p>
                                                                    

                                                                </div>

                                                            </div>

                                                            <div align="center" style="margin-top:25px;" class="form-row place-order">

                                                                <div style="display: none;" class="alert alert-warning uyari"></div>

                                                            <button type="submit" class="button alt checkoutbuton" name="woocommerce_checkout_place_order" id="place_order">Siparişi Tamamla</button>

                                                        </div>



                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <!-- .entry-content -->
                        </article>
                        <!-- #post-## -->
                    </div>
                    <!-- .entry-content-wrapper -->
                </div>
                <!-- .row -->
            </div>
            <!-- .container -->
        </div>
        <!--==================== Checkout Section End ====================-->


        <?php 

    $kullanici_id = $_SESSION['kullanici_id'];



    $hazirla = $db->prepare("UPDATE kullanici set

cart_taksitsecenegi=:cart_taksitsecenegi,
cart_vadefarki=:cart_vadefarki,
cart_kargoucreti=:cart_kargoucreti,
cart_aratoplam=:cart_aratoplam,
cart_toplam=:cart_toplam

where kullanici_id='$kullanici_id'

        ");

    $derle = $hazirla->execute(array(

"cart_taksitsecenegi" => 1,
"cart_vadefarki" => 0,
"cart_kargoucreti" => $kargo_ucreti,
"cart_aratoplam" => $urun_toplam,
"cart_toplam" => $urun_toplam+$kargo_ucreti

    ));

         ?>



        <?php require_once 'footer.php'; ?>

        <script type="text/javascript">
           
           $('#siparis_sehir').change(function(){

var sehir_id = $(this).val();

 $.ajax({

   type : 'POST',
            url : 'musteriislem.php',
            data : {'odemesehirsec':'ok','sehir_id':sehir_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);


              if (sonuc=='gecersizsehirid') {
         
location.reload();

              } else {

       $('#siparis_ilce').html(sonuc);

              }

            
               }

             });
        });


           jQuery.fn.ForceNumericOnly =
function()
{
    return this.each(function()
    {
        $(this).keydown(function(e)
        {
            var key = e.charCode || e.keyCode || 0;
            // allow backspace, tab, delete, enter, arrows, numbers and keypad numbers ONLY
            // home, end, period, and numpad decimal
            return (
                key == 8 || 
                key == 9 ||
                key == 13 ||
                key == 32 ||
                key == 46 ||
                (key >= 35 && key <= 40) ||
                (key >= 48 && key <= 57) ||
                (key >= 96 && key <= 105));
        });
    });
};

$("#siparis_telno,#cvc").ForceNumericOnly();


        $('#sozlesme').change(function(){


if ($('#sozlesme').prop('checked')) {

  
 $('#sozlesme').val('1');
  
} else {

  $('#sozlesme').val('0');
 
};

});


        $('input[type=radio][name=taksitsecenegi]').change(function() { 


            var id1=$(this).attr("id");
          var secenek_id=id1.substring(10);


          $('input[type=radio][name=taksitsecenegi]').attr('disabled',true);
          $('.checkoutbuton').attr('disabled',true);


          $.ajax({
            type : 'POST',
            url : 'musteriislem.php',
            data : {'taksitsecenekdegistir':'ok','secenek_id':secenek_id},
            success : function(sonuc){

              sonuc = $.trim(sonuc);
              

         if (sonuc=="gecersiztaksitid") {

           location.reload(); 

         } else {

            $('input[type=radio][name=taksitsecenegi]').attr('disabled',false);
          $('.checkoutbuton').attr('disabled',false);
          $('.vadefarkitr,.toplamtutartr').remove();
          $('.taksitsecenektr').after(sonuc);

         }
            
              
              }
        })

         

         


         });



        $('#checkoutform').submit(function(){

    var kartnumarasi=$.trim($('[name="kartnumarasi"]').val());
    var kartsahibi=$.trim($('[name="kartsahibi"]').val());
    var sonkullanimayi=$('[name="sonkullanimayi"]').val();
    var sonkullanimyili=$('[name="sonkullanimyili"]').val();
    var cvc=$.trim($('[name="cvc"]').val());



      var siparis_ad = $.trim($('#siparis_ad').val());
      var siparis_soyad = $.trim($('#siparis_soyad').val());
      var siparis_telno = $.trim($('#siparis_telno').val());
      var siparis_sehir = $('#siparis_sehir').val();
      var siparis_adres = $.trim($('#siparis_adres').val());
      var sozlesme = $('#sozlesme').val();

      if (siparis_ad.length<2) {

$('.uyari').show();
$('.uyari').html('<i class="fa fa-info-circle"></i> Lütfen adınızı doğru girin.');

      } else if (siparis_soyad.length<2){

$('.uyari').show();
$('.uyari').html('<i class="fa fa-info-circle"></i> Lütfen soyadınızı doğru girin.');

      } else if (siparis_telno.length<10){

$('.uyari').show();
$('.uyari').html('<i class="fa fa-info-circle"></i> Lütfen cep telefonunuzu doğru girin.');

      } else if (siparis_sehir=='secilmedi'){

$('.uyari').show();
$('.uyari').html('<i class="fa fa-info-circle"></i> Lütfen şehir ve ilçe seçin.');

      } else if (siparis_adres.length<15){

$('.uyari').show();
$('.uyari').html('<i class="fa fa-info-circle"></i> Lütfen adres kısmını biraz daha doldurun.');

      } else if (sozlesme=="0"){

$('.uyari').show();
$('.uyari').html('<i class="fa fa-info-circle"></i> Devam etmeden önce <b>mesafeli satış sözleşmesi</b>ni onaylamanız gerekir.');

      } else if (kartnumarasi.length<16) {

$('.uyari').show();
$('.uyari').html('<i class="fa fa-info-circle"></i> Kart numarası 16 haneden az olamaz.');


} else if(kartsahibi.length<4){

$('.uyari').show();
$('.uyari').html('<i class="fa fa-info-circle"></i> Lütfen kart sahibini doğru girin.');

} else if(sonkullanimayi=="aysecilmedi"){

$('.uyari').show();
$('.uyari').html('<i class="fa fa-info-circle"></i> Lütfen kartınızın son kullanım ayını girin.');

} else if(sonkullanimyili=='yilsecilmedi'){

$('.uyari').show();
$('.uyari').html('<i class="fa fa-info-circle"></i> Lütfen kartınızın son kullanım yılını girin.');

} else if (cvc.length!=3) {

$('.uyari').show();
$('.uyari').html('<i class="fa fa-info-circle"></i> CVC 3 karakterden oluşmalıdır.');

} else {

        $('.checkoutbuton').prop('disabled',true);
        $('.checkoutbuton').html('Lütfen Bekleyin...');
        $('.uyari').hide();
        var data = $("#checkoutform").serializeArray();
        data.push({name: "checkout",value: "ok"});

         $.ajax({
            type : 'POST',
            url : 'musteriislem.php',
            data : $.param(data),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

              

               if (sonuc!='bot' && sonuc!='gecersizistek' && sonuc!='sikintili') {


        if (sonuc=="odemehatasi") {

            $('.uyari').show();
            $('.uyari').html('Lütfen kredi kartı bilgilerinizi kontrol edip tekrar deneyin.');


             } else {

                location.href='siparislerim';
             }


              } else {

                location.reload();
    

              } 

              }
        })
      

      }




        })

        

       </script>