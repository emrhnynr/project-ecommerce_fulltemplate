<?php require_once 'header.php'; ?>
        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
           

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Ürün Seçenek Ayarları</h2>
                    <ul class="nav navbar-right panel_toolbox">
                     
                      <a data-toggle='modal' class="btn btn-success" href="#secenekekle">Seçenek Ekle +</a>
                    </ul>

                    <div class="modal fade" id="secenekekle"> 
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

      

        <div style="padding: 50px;" class="modal-body">

          <h3>Yeni Seçenek Ekle<hr></h3>

          <form action="../../adminislem.php" method="POST" id="secenekekleform" enctype="multipart/form-data">
         <div class="row">

          <div style="margin-top:20px;" class="col-md-12 col-xs-12 col-sm-12">
            <label>Seçenek Ad*</label>
             <input class="form-control" required="" maxlength="300" type="text" name="secenek_ad">
           </div>



          


         </div>

        </div>

     
       
    <div class="modal-footer">


  
    
    <button class="btn btn-success" name="secenekekle" type="submit">Ekle</button>

     </form>
    <button class="btn btn-danger" data-dismiss="modal">Kapat</button>

    
</div>





  

     
    </div>

  </div>

</div>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <?php $seceneksec=$db->prepare("SELECT * from secenekler order by secenek_id ASC");
        $seceneksec->execute();
        $seceneksay = $seceneksec->rowCount();

        if ($seceneksay==0) { ?>
           
     <h4 align="center">Henüz ürün seçeneği eklenmemiş.</h4>

        <?php } else { ?>


          <table id="datatable" class="table table-striped table-bordered">
                      <thead>
                        <tr>
                         
                          <th>Ürün Seçenekleri</th>

                         
                         
                          <th></th>
                          
                          
                          
                         
                        </tr>
                      </thead>


                      <tbody>

        <?php 

        while ($secenekcek=$seceneksec->fetch(PDO::FETCH_ASSOC)) { 

          $secenek_id = $secenekcek['secenek_id'];
          $secenek_ad = $secenekcek['secenek_ad'];

          
          



         ?>

        <tr class="secenek_<?php echo $secenek_id; ?>">
                          
                          <td><?php echo $secenek_ad; ?></td>

                          


                      
                          
                          <td align="right"><a class="btn btn-warning btn-sm" href="secenek-duzenle?secenek_id=<?php echo $secenek_id; ?>">Düzenle</a><a class="btn btn-danger btn-sm seceneksil" href="javascript:void(0);"  name="secenek_<?php echo $secenek_id; ?>">Sil</a></td>
                        
                          
                          
                        </tr>
          
        <?php } ?>

                        
                        
                        
                      </tbody>
                    </table>


       <?php } ?>
                   
                    
                  </div>
                </div>
              </div>

              <!-- Bitiyor -->

              

            </div>
          </div>
        </div>
        <!-- /page content -->

       <?php require_once 'footer.php'; ?>

       <script type="text/javascript">
         
         $('.seceneksil').click(function(){
            
            var buton = $(this);
            var id1=$(this).attr("name");
                var secenek_id=id1.substring(8);

               swal({
  title: "Bu seçeneği silmek istiyor musunuz?",
  text: "Seçenek ile beraber tüm alt seçenekleri de silinecek. Bu zamana kadar bu seçenek seçilerek sepete eklenmiş ürün ve siparişlere zarar gelmeyecek.",
  icon: "warning",
  buttons: ["Vazgeç", "Sil"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

    buton.html('Siliniyor...');

    $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'seceneksil':'ok','secenek_id':secenek_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              if (sonuc=="ok") {

                location.reload();
              }

               }

             });


     }

     })
         })


       </script>