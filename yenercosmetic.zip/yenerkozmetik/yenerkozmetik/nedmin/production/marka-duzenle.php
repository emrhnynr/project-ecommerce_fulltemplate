<?php require_once 'header.php';

 $marka_id=$_GET['marka_id'];
 $markasec=$db->prepare("SELECT * from markalar where marka_id=:id");
 $markasec->execute(array(
"id" => $marka_id
 ));

 $markasay=$markasec->rowCount();

 if ($markasay==0) {
   
   header("Location:index");
   exit;
 }

 $markacek=$markasec->fetch(PDO::FETCH_ASSOC);

 ?>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              

              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Marka Düzenle : <b><?php echo $markacek['marka_ad']; ?></b></h2>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />

                    <form id="markalogoduzenleform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

                   

                    

                    <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">
                        Logo (300 x 300px)</label>
                        <div align="center" class="col-md-6 col-sm-6 col-xs-12">
                          <img class="img-responsive" src="../../<?php echo $markacek['marka_logo']; ?>">
                        </div>
                      </div>



                      <div class="form-group">
                       
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="file" id="marka_logo" name="marka_logo"  class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>

                      <div align="left" class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                          <div style="display: none;" class="alert alert-warning uyarimarkalogo"></div>
                          
                          <button type="submit" class="btn btn-success markalogobuton">Güncelle</button>
                        </div>
                      </div>

                    </form>

                    <hr>

                    <form id="markaduzenleform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

                      
                      

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Marka İsmi <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" id="marka_ad" value="<?php echo $markacek['marka_ad']; ?>" maxlength="200" name="marka_ad"  class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>

                      

                     

                      <input type="hidden" name="markaduzenleadmin">
                      <input type="hidden" id="marka_id" value="<?php echo $markacek['marka_id'] ?>" name="marka_id">
                      
                      
                      <div class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                          <div style="display: none;" class="alert alert-warning uyari"></div>
                          
                          <button type="submit" class="btn btn-success markaduzenlebuton">Düzenle</button>
                        </div>
                      </div>

                    </form>
                  </div>
                </div>
              </div>
            </div>

            <?php require_once 'footer.php'; ?>
            <script type="text/javascript">

              $('.markalogobuton').click(function(){

               var input = $('#marka_logo');
var foto = $('#marka_logo').val();
var filevalue = $('#marka_logo').get(0).files[0];
var fotouzanti = foto.split('.').pop();
var marka_id = $('#marka_id').val();



var data = new FormData();
data.append('markalogoduzenle',"ok");
data.append('marka_id',marka_id);
data.append("file",filevalue);

if ($('#marka_logo').val().length==0){

 $('.uyarimarkalogo').show();
$('.uyarimarkalogo').html('<i class="fa fa-info-circle"></i> Lütfen bir logo yükleyin.');

  } else if (fotouzanti!='jpg' && fotouzanti!='jpeg' && fotouzanti!='png' && fotouzanti!='JPG' && fotouzanti!='PNG'){

$('.uyarimarkalogo').show();
$('.uyarimarkalogo').html('<i class="fa fa-info-circle"></i> Sadece <b>.jpg, .jpeg, .png</b> uzantılı dosyaları yükleyebilirsiniz.');

} else {

  $('.slaytfotobuton').prop('disabled',true);
  $('.slaytfotobuton').html('Güncelleniyor...');

  $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            enctype : 'multipart/form-data',
            data : data,
            processData: false,
            contentType: false,
            cache: false,
            success : function(sonuc){

      sonuc=$.trim(sonuc);
      
      if (sonuc=='ok') {

        location.reload();
      }

 }

 });


   }

              });
              
              $('#markaduzenleform').submit(function(){
          
          var marka_ad = $.trim($('#marka_ad').val());
        
    
      var form = $('#markaduzenleform')[0];
             var data = new FormData(form);

               if (marka_ad.length<2){

        $('.uyari').show();
        $('.uyari').html("Marka ismi 2 karakterden kısa olamaz.");

      } else {

       
       $('.uyari').hide();
$('.markaduzenlebuton').prop('disabled',true);
$('.markaduzenlebuton').html('Düzenleniyor...');

$.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : $('#markaduzenleform').serialize(),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

              if (sonuc=="ok") {

                swal({

  title: "Başarılı",
  text: "Marka ismi düzenlendi!",
  icon: "success",
  button: "OK",
}).then((willDelete) => {
  if (willDelete) {

    window.location = 'marka-ayarlari';

     }

   });
              }
              }
        })

      }



              });

            </script>

            