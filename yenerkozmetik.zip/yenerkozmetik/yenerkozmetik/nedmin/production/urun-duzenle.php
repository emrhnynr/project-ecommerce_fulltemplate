<?php require_once 'header.php'; 

$urun_id=$_GET['urun_id'];
$urunsec=$db->prepare("SELECT * from urunler where urun_id=:id and urun_kaldirildi=:kaldirildi");
$urunsec->execute(array(
"id" => $urun_id,
"kaldirildi" => 0
));

$urunsay=$urunsec->rowCount();

if ($urunsay==0) {
  
  header("Location:index");
  exit;
}

$uruncek=$urunsec->fetch(PDO::FETCH_ASSOC);

$urunkategorisec=$db->prepare("SELECT * from kategoriler where kategori_id=:id");
$urunkategorisec->execute(array(

"id" => $uruncek['kategori_id']
));

$urunkategoricek=$urunkategorisec->fetch(PDO::FETCH_ASSOC);

$urun_ustkategori = $urunkategoricek['kategori_ust'];



?>

<style type="text/css">
   /* Customize the label (the container) */
.checklabell {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 12px;
  cursor: pointer;
  font-size: 22px;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

/* Hide the browser's default checkbox */
.checklabell input {
  position: absolute;
  opacity: 0;
  cursor: pointer;
  height: 0;
  width: 0;
}

/* Create a custom checkbox */
.checkmark {
  position: absolute;
  top: 0;
  left: 0;
  height: 25px;
  width: 25px;
  background-color: #eee;
}

/* On mouse-over, add a grey background color */
.checklabell:hover input ~ .checkmark {
  background-color: #ccc;
}

/* When the checkbox is checked, add a blue background */
.checklabell input:checked ~ .checkmark {
  background-color: #43DE09;
}

/* Create the checkmark/indicator (hidden when not checked) */
.checkmark:after {
  content: "";
  position: absolute;
  display: none;
}

/* Show the checkmark when checked */
.checklabell input:checked ~ .checkmark:after {
  display: block;
}

/* Style the checkmark/indicator */
.checklabell .checkmark:after {
  left: 9px;
  top: 5px;
  width: 5px;
  height: 10px;
  border: solid white;
  border-width: 0 3px 3px 0;
  -webkit-transform: rotate(45deg);
  -ms-transform: rotate(45deg);
  transform: rotate(45deg);
}
}

</style>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              

              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Ürün Düzenle</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <a class="btn btn-success" target="_blank" href="ilgili-urunler?urun_id=<?php echo $urun_id; ?>"><i class="fa fa-refresh"></i> İlgili Ürünler</a>

                     <a class="btn btn-primary" target="_blank" href="urun-galeri?urun_id=<?php echo $urun_id; ?>"><i class="fa fa-picture-o"></i> Ürün Fotoğrafları</a>


                    </ul>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />
                    <form id="urunduzenleform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

<h3 align="center">Genel Bilgiler<hr></h3>
                     
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Ürün Ad <span class="required">*</span>
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="urun_ad" name="urun_ad" maxlength="200" value="<?php echo $uruncek['urun_ad']; ?>"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Ürün Fiyat <span class="required">*</span>
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="number" step="any" id="urun_indirimsizfiyat"
                           value="<?php echo $uruncek['urun_indirimsizfiyat']; ?>" min="0" name="urun_indirimsizfiyat" placeholder="TL cinsinden yazın."   class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                       <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">İndirimli Fiyat 
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="number" step="any" id="urun_fiyat" min="0" <?php if (!empty($uruncek['urun_fiyat'])) { ?>
                            value="<?php echo $uruncek['urun_fiyat']; ?>"
                          <?php } ?> name="urun_fiyat" placeholder="İndirim uygulamayacaksanız burayı boş bırakın."  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Ürün Stok <span class="required">*</span>
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="number" id="urun_stok" min="0" value="<?php echo $uruncek['urun_stok']; ?>" name="urun_stok" placeholder="Stok miktarını girin."  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Ürün Kategori <span class="required">*</span>
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                         
                         <select class="form-control" name="urun_kategori" id="urun_kategori">
                           <option value="secilmedi">Kategori Seçin</option>

                           <?php $kategorisec=$db->prepare("SELECT * from kategoriler where kategori_enalt=:enalt order by kategori_enust ASC");
                           $kategorisec->execute(array(
                            "enalt" => 1
                           ));

                           while ($kategoricek=$kategorisec->fetch(PDO::FETCH_ASSOC)) {

                           $kategori_enust = $kategoricek['kategori_enust'];

                            $enustkategorisec = $db->prepare("SELECT * from kategoriler where kategori_id='$kategori_enust'");
                            $enustkategorisec->execute();

                            $enustkategoricek=$enustkategorisec->fetch(PDO::FETCH_ASSOC);

                            $enust_ad = $enustkategoricek['kategori_ad'];
                             ?>
                              <option <?php if ($uruncek['kategori_id']==$kategoricek['kategori_id']) { ?>
                                selected=''
                             <?php } ?> value="<?php echo $kategoricek['kategori_id']; ?>"><?php if ($kategoricek['kategori_ust']==0) { 
                                
                                echo $kategoricek['kategori_ad'];

                               } else {


                                echo $kategoricek['kategori_ad']." (".$enust_ad.")";


                              } ?></option>
                            <?php } ?>
                         </select>

                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Ürün Marka <span class="required">*</span>
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                         
                         <select class="form-control" name="urun_marka" id="urun_marka">
                           <option value="secilmedi">Marka Seçin</option>

                           <?php $markasec=$db->prepare("SELECT * from markalar");
                           $markasec->execute();

                           while ($markacek=$markasec->fetch(PDO::FETCH_ASSOC)) { ?>
                              <option <?php if ($markacek['marka_id']==$uruncek['marka_id']) { ?>
                               selected=''
                              <?php } ?> value="<?php echo $markacek['marka_id']; ?>"><?php echo $markacek['marka_ad']; ?></option>
                            <?php } ?>
                         </select>

                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Ürün Cinsiyet <span class="required">*</span>
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                         
                         <select class="form-control" name="urun_cinsiyet" id="urun_cinsiyet">
                           
                            <option <?php if ($uruncek['urun_cinsiyet']=='k') { ?>
                              selected=''
                           <?php } ?> value="k">Kadın</option>

                              <option <?php if ($uruncek['urun_cinsiyet']=='e') { ?>
                              selected=''
                           <?php } ?> value="e">Erkek</option>

                              <option <?php if ($uruncek['urun_cinsiyet']=='u') { ?>
                              selected=''
                           <?php } ?> value="u">Unisex</option>

                              <option <?php if ($uruncek['urun_cinsiyet']=='c') { ?>
                              selected=''
                           <?php } ?> value="c">Çocuk</option>

                          
                            
                         </select>

                        </div>
                      </div>

                      

                       <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Ürün Video
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="urun_video" name="urun_video" placeholder="Youtube video url'sinde watch?v= den sonra gelen kısmı yapıştırın." maxlength="1000" <?php if (!empty($uruncek['urun_video'])) { ?>
                            value='<?php echo $uruncek['urun_video']; ?>'
                         <?php } ?>  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Ürün Desi <span class="required">*</span>
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="number" value="<?php echo $uruncek['urun_desi']; ?>" step="any" min="0" id="urun_desi" name="urun_desi" placeholder="Sabit kargo uyguluyorsanız temsili bir sayı yazabilirsiniz."  class="form-control col-md-10 col-xs-12">

                          <hr>



                          <h4 style="margin-top:15px;" align="center"><a target="_blank" href="https://desi.hesaplama.net/" style="text-decoration: underline;">Desi Hesaplama Aracı</a></h4>
                        </div>
                      </div>

                    

                      

                      
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Ürün Açıklaması <span class="required">*</span>
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <textarea id="inputt" name="urun_aciklama" class="form-control col-md-10 col-xs-12 ckeditor"><?php echo $uruncek['urun_aciklama']; ?></textarea>
                        </div>
                      </div>

                      <script type="text/javascript">
                        
                        CKEDİTOR.replace('inputt');

                      </script>

                      

<br>

<div class="urunsecenekler">
  


</div>




<br>

<h3 class="urunozelliklerititle" align="center">Ürün Özellikleri<hr></h3>

<?php $urunozelliksec=$db->prepare("SELECT * from urunozellik where urun_id=:id");
$urunozelliksec->execute(array(
"id" => $_GET['urun_id']
));
 


$ozelliksay=0;

while ($urunozellikcek=$urunozelliksec->fetch(PDO::FETCH_ASSOC)) { 

  $ozelliksay++; ?>

   <div style="margin-bottom:40px;position: relative;" class="ozellik ozellik_<?php echo $urunozellikcek['urunozellik_id']; ?>">
   
  <h4 align="center"><b>Özellik <?php echo $ozelliksay; ?></b> <a class="btn btn-xs btn-danger urunozelliksil" name="urunozellik_<?php echo $urunozellikcek['urunozellik_id']; ?>" href="javascript:void(0);"><i class="fa fa-trash"></i> Kaldır</a></h4>



<div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Özellik Başlık
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="ozellik_baslik" value="<?php echo $urunozellikcek['ozellik_baslik']; ?>" placeholder="örn. Ağırlık, Kumaş Türü, İşlemci vs." name="ozellik_baslik[]" maxlength="200"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Özellik İçerik 
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="ozellik_icerik" value="<?php echo $urunozellikcek['ozellik_icerik']; ?>" placeholder="örn. 1.7 Kg, Likra, i7 vs." name="ozellik_icerik[]" maxlength="200"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>
</div>

 <?php } ?>

 <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name"></span>
                        </label>
                        <a href="javascript:void(0);" class="ozellikekle"><div align="center" class="form-group">
                        <div style="margin-bottom: 80px;border:1px solid #d7d7d7;" class="col-md-7 col-sm-7 col-xs-12">
                          <h3>Özellik Ekle +</h3>
                        </div></a>
                      </div>






               <input type="hidden" value="<?php echo $uruncek['urun_id'] ?>" id='urun_id' name="urun_id">

                      <input type="hidden" name="urunduzenleadmin">
                      
                      
                      <div class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                          <div style="display: none;" class="alert alert-warning uyari"></div>
                          
                          <button type="submit" class="btn btn-success urunduzenlebuton">Düzenle</button>
                        </div>
                      </div>

                    </form>
                  </div>
                </div>
              </div>
            </div>

            <?php require_once 'footer.php'; ?>
            <script src="../vendors/dropzone/dist/min/dropzone.min.js"></script>
            <script type="text/javascript">

              

               $('.urunozelliksil').click(function(){

           var buton = $(this);
            var id1=$(this).attr("name");
                var urunozellik_id=id1.substring(12);

               buton.prop('disabled',true);
               buton.html('Kaldırılıyor...');

               $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'urunozelliksil':'ok','urunozellik_id':urunozellik_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              if (sonuc=="ok") {

                $('.ozellik_'+urunozellik_id).remove();
              }

               }

             });

               });

               $('#urun_kategori').change(function(){

                var urun_kategori = $(this).val();
                var urun_id = $('#urun_id').val();

                $.ajax({

type: 'POST',
url: '../../adminislem.php',
data: {'kategoriseceneksecduzenle':'ok','kategori_id':urun_kategori,'urun_id':urun_id},
success : function(sonuc){

  sonuc=$.trim(sonuc);

  $('.urunsecenekler').html(sonuc);

}

                })

              }).change();


               $('.ozellikekle').click(function(){

       var ozelliksayisi = $('.ozellik').length;
       var yeniozelliksayisi = ozelliksayisi+1;

       

       if (ozelliksayisi==0) {

        $('.urunozelliklerititle').after('<div style="margin-bottom:40px;position: relative;" class="ozellik ozellikekle_1"><h4 align="center"><b>Özellik 1</b> <a class="btn btn-xs btn-danger eklenenozelliksil" name="eklenenozellik_1" href="javascript:void(0);"><i class="fa fa-trash"></i> Kaldır</a></h4><div class="form-group"><label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Özellik Başlık </label><div class="col-md-7 col-sm-7 col-xs-12"><input type="text" id="ozellik_baslik" placeholder="örn. Ağırlık, Kumaş Türü, İşlemci vs." name="ozellik_baslik[]" maxlength="200"  class="form-control col-md-10 col-xs-12"></div></div><div class="form-group"><label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Özellik İçerik </label><div class="col-md-7 col-sm-7 col-xs-12"><input type="text" id="ozellik_icerik" placeholder="örn. 1.7 Kg, Likra, i7 vs." name="ozellik_icerik[]" maxlength="200"  class="form-control col-md-10 col-xs-12"></div></div></div>');


       } else {

        $('.ozellik').last().after('<div style="margin-bottom:40px;position: relative;" class="ozellik ozellikekle_'+yeniozelliksayisi+'"><h4 align="center"><b>Özellik '+yeniozelliksayisi+'</b> <a class="btn btn-xs btn-danger eklenenozelliksil" name="eklenenozellik_'+yeniozelliksayisi+'" href="javascript:void(0);"><i class="fa fa-trash"></i> Kaldır</a></h4><div class="form-group"><label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Özellik Başlık </label><div class="col-md-7 col-sm-7 col-xs-12"><input type="text" id="ozellik_baslik" placeholder="örn. Ağırlık, Kumaş Türü, İşlemci vs." name="ozellik_baslik[]" maxlength="200"  class="form-control col-md-10 col-xs-12"></div></div><div class="form-group"><label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Özellik İçerik </label><div class="col-md-7 col-sm-7 col-xs-12"><input type="text" id="ozellik_icerik" placeholder="örn. 1.7 Kg, Likra, i7 vs." name="ozellik_icerik[]" maxlength="200"  class="form-control col-md-10 col-xs-12"></div></div></div>');

       }

       $('.eklenenozelliksil').click(function(){

var id1=$(this).attr("name");
      var eklenenozellik_id=id1.substring(15);

      $('.ozellikekle_'+eklenenozellik_id).remove();

       })

               })

              
              
              $('#urunduzenleform').submit(function(){

 for (instance in CKEDITOR.instances) {
            CKEDITOR.instances[instance].updateElement();
    }


                
          var urun_ad = $.trim($('#urun_ad').val());
          var urun_model = $.trim($('#urun_model').val());
          var urun_indirimsizfiyat = $('#urun_indirimsizfiyat').val();
         var urun_fiyat = $('#urun_fiyat').val();
        var urun_aciklama = $('#inputt').val();
        var urun_stok = $('#urun_stok').val();
        var urun_desi = $('#urun_desi').val();
        var urun_kategori = $('#urun_kategori').val();
        var urun_marka = $('#urun_marka').val();
      var form = $('#urunduzenleform')[0];
             var data = new FormData(form);

            if (urun_ad.length<2){

$('.uyari').show();
$('.uyari').html("<i class='fa fa-info-circle'></i> Ürün adı 2 karakterden kısa olamaz.");

      }  else if (urun_indirimsizfiyat.length==0){

$('.uyari').show();
$('.uyari').html("<i class='fa fa-info-circle'></i> Lütfen ürününüz için bir fiyat belirtin.");

      } else if (urun_stok.length==0){

$('.uyari').show();
$('.uyari').html('<i class="fa fa-info-circle"></i> Lütfen ürününüz için stok miktarı belirtin.');

      }  else if (urun_kategori=='secilmedi'){

$('.uyari').show();
$('.uyari').html('<i class="fa fa-info-circle"></i> Lütfen ürününüz için bir kategori seçin.');

      } else if (urun_marka=='secilmedi'){

$('.uyari').show();
$('.uyari').html("<i class='fa fa-info-circle'></i> Lütfen ürününüzün markasını seçin.");

      } else if (urun_desi.length==0){

$('.uyari').show();
$('.uyari').html("<i class='fa fa-info-circle'></i> Ürününüz için desi miktarını girin.");

      }  else {

       
       $('.uyari').hide();
$('.urunduzenlebuton').prop('disabled',true);
$('.urunduzenlebuton').html('Lütfen Bekleyin...');

  $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
             enctype : 'multipart/form-data',
            data : data,
            processData: false,
            contentType: false,
            cache: false,
            success : function(sonuc){

              sonuc = $.trim(sonuc);


              ;

            

             if (sonuc=="ok") {

swal({

  title: "Başarılı",
  text: "Ürün düzenlendi!",
  icon: "success",
  button: "OK",
}).then((willDelete) => {
  if (willDelete) {

    location.reload();

     }

   });



             }

             
              }
        })

      }

              });

            </script>

            