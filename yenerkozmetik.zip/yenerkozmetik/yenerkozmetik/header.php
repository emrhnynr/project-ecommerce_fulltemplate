<?php 
require_once 'db.php'; 
include 'fonksiyon.php';


$ip_adresi=$_SERVER['REMOTE_ADDR'];
date_default_timezone_set('Europe/Istanbul');

ob_start();
session_start();

$kullanicioturumsec=$db->prepare("SELECT * from kullanici where kullanici_yetki=:yetki and kullanici_mail=:mail");
$kullanicioturumsec->execute(array(
  "yetki" => 1,
  "mail" => $_SESSION['kullanicioturum']
));
$kullanicioturumcek=$kullanicioturumsec->fetch(PDO::FETCH_ASSOC);

if ($kullanicioturumcek['kullanici_ban']==1) { 
    
    header("Location:logout?url=index");
    exit;

 }

$_SESSION['kullanici_id']=$kullanicioturumcek['kullanici_id'];

$genelayarsec=$db->prepare("SELECT * from genelayarlar");
$genelayarsec->execute();

 $genelayarcek=$genelayarsec->fetch(PDO::FETCH_ASSOC);

 $seoayarsec=$db->prepare("SELECT * from seoayarlar");
$seoayarsec->execute();

 $seoayarcek=$seoayarsec->fetch(PDO::FETCH_ASSOC);

 $ayar_logo=$genelayarcek['ayar_logo'];
 $ayar_beyazlogo = $genelayarcek['ayar_beyazlogo'];

 if (isset($_SESSION['kullanicioturum'])) {
    
    $sepeturunsecheader = $db->prepare("SELECT * from sepetitem where kullanici_id=:id order by urun_id DESC");
 $sepeturunsecheader->execute(array(

"id" => $_SESSION['kullanici_id']

 ));

 $sepeturunsecheader2 = $db->prepare("SELECT * from sepetitem where kullanici_id=:id order by urun_id DESC");
 $sepeturunsecheader2->execute(array(

"id" => $_SESSION['kullanici_id']

 ));

 } else {

    $sepeturunsecheader = $db->prepare("SELECT * from sepetitem where kullanici_ip=:ip order by urun_id DESC");
 $sepeturunsecheader->execute(array(

"ip" => $ip_adresi

 ));


 $sepeturunsecheader2 = $db->prepare("SELECT * from sepetitem where kullanici_ip=:ip order by urun_id DESC");
 $sepeturunsecheader2->execute(array(

"ip" => $ip_adresi

 ));

 }

 $sepeturunsayheader=$sepeturunsecheader->rowCount();

 $favorilersec=$db->prepare("SELECT * from favoriler where kullanici_id=:id");
 $favorilersec->execute(array(
    "id" => $_SESSION['kullanici_id']
));

 $favorilersay=$favorilersec->rowCount();

 ?>

<!DOCTYPE html>
<html lang="tr">


<head>
    <!-- Meta Tag -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Yener Kozmetik">

    <meta name="author" content="root">

    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo $genelayarcek['ayar_favicon']; ?>">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Josefin+Slab:wght@100;200;300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <!--  CSS Style -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/all.min.css">
    <link rel="stylesheet" href="assets/css/animate.min.css">
    <link rel="stylesheet" href="assets/webfonts/flaticon/flaticon.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/jquery.fancybox.min.css">
    <link rel="stylesheet" href="assets/css/layerslider.css">
    <link rel="stylesheet" href="assets/css/template.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/category/cosmetic-store.css">

    <?php echo $genelayarcek['googleanalytics_api']; ?>


    


</head>


<body>

    <div id="page_wrapper" class="bg-white">
        <!--==================== Header Section Start ====================-->
        <header class="ecommerce-header">
            <div class="top-header d-none d-lg-block py-2 bg-light border-0 font-normal">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-4 sm-mx-none">
                            <div class="d-flex align-items-center">
                                <a href="tel:<?php echo $genelayarcek['ayar_telno']; ?>" class="text-general"><span style="font-size: 14px;"><?php echo $genelayarcek['ayar_telno']; ?></span></a>
                            </div>
                        </div>
                        <div class="col-lg-8 d-flex">
                         


                            <ul class="top-links d-flex ms-auto align-items-center">

                                <?php if (empty($_SESSION['kullanicioturum'])) { ?>


                                     <li class="my-account-dropdown">
                                    <a href="" class="has-dropdown"><i class="flaticon-user-3 flat-mini text-primary me-1"></i>Üye Ol / Giriş Yap</a>
                                    <ul class="my-account-popup">
                                        <li><a href="uye-ol"><span class="menu-item-text">Üye Ol</span></a></li>
                                        <li><a href="giris-yap"><span class="menu-item-text">Giriş Yap</span></a></li>
                                        
                                    </ul>
                                </li>
                            </ul>


                        <?php  } else { ?>


                       <li><a href="favoriler"><i class="flaticon-like flat-mini me-1 text-primary"></i> Favoriler</a></li>

                       <li class="my-account-dropdown">
                                    <a href="" class="has-dropdown"><i class="flaticon-user-3 flat-mini text-primary me-1"></i><?php echo $kullanicioturumcek['kullanici_ad']." ".$kullanicioturumcek['kullanici_soyad']; ?></a>
                                    <ul class="my-account-popup">
                                        <li><a href="kullanici-bilgilerim"><span class="menu-item-text">Kullanıcı Bilgilerim</span></a></li>
                                        <li><a href="siparislerim"><span class="menu-item-text">Siparişlerim</span></a></li>
                                        <li><a href="sepetim"><span class="menu-item-text">Sepetim</span></a></li>
                                         <li><a href="favoriler"><span class="menu-item-text">Favoriler</span></a></li>

                                          <?php if ($sepeturunsayheader!=0) { ?>


                                            <li><a href="odeme"><span class="menu-item-text">Ödemeyi Tamamla</span></a></li>

                                        <?php  } ?>

                                         <li><a href="sifre-guncelle"><span class="menu-item-text">Şifre Güncelle</span></a></li>


                                         <li><a href="logout?url=<?php echo 'http://'.$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI']; ?>"><span class="menu-item-text">Çıkış Yap</span></a></li>

                                    </ul>
                                </li>


                   <?php  } ?>
                                
                                
                                
                                
                               
                        </div>
                    </div>
                </div>
            </div>
            <div class="main-nav py-4 bg-white d-none d-lg-block">
                <div style="padding-left: 25px;padding-right: 25px;" class="container-fluid">
                    <div class="row align-items-center">
                        <div class="col-xl-8 col-md-9">
                            <nav class="navbar navbar-expand-lg nav-general nav-primary-hover">
                                <a class="navbar-brand" href="../"><img  class="nav-logo" src="<?php echo $ayar_logo; ?>" alt="Yener Kozmetik Logo"></a>
                                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                <i class="flaticon-menu-2 flat-small text-primary"></i>
                                </button>
                                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                    <ul class="navbar-nav mx-auto">
                                        
                                        <li class="nav-item dropdown mega-dropdown">
                                            <a style="color: black;font-size: 14px;" class="nav-link dropdown-toggle" href="javascript:void(0);">Kategoriler</a>
                                            <ul class="dropdown-menu mega-dropdown-menu">
                                                <li class="mega-container">

                                                    

                                                    <div class="row row-cols-lg-4 row-cols-sm-2 row-cols-1">

                                                         <?php $kategorimenusec=$db->prepare("SELECT * from kategoriler where kategori_ust='0' and kategori_aktif='1' order by kategori_sira ASC");

                                      $kategorimenusec->execute();

                                      while ($kategorimenucek=$kategorimenusec->fetch(PDO::FETCH_ASSOC)) {



                                        $kategori_id = $kategorimenucek['kategori_id'];
                                        $kategori_ad = $kategorimenucek['kategori_ad'];

                                        $altsecc=$db->prepare("SELECT * from kategoriler where kategori_ust='$kategori_id' and kategori_aktif='1'");
                                        $altsecc->execute();
                                        $altsayy=$altsecc->rowCount();

                                        $kategori_enalt = $kategorimenucek['kategori_enalt']; ?>
                                                        
                                                        <div class="col">
                                                            <a  href="c-<?php echo seo($kategori_ad)."-".$kategori_id; ?>"><span class="d-inline-block px-3 font-600 text-uppercase text-secondary pb-2"><?php echo $kategori_ad; ?></span></a>

                                                            <?php $altkategorisecmenu = $db->prepare("SELECT * from kategoriler where kategori_ust='$kategori_id' and kategori_aktif='1' order by kategori_sira ASC");

                                                 $altkategorisecmenu->execute();

                                                 $altkategorisaymenu = $altkategorisecmenu->rowCount();

                                                
                                          if ($altkategorisaymenu>0) { ?>
                                              
                                              <ul>
                                                         
                                                         <?php while($altkategoricekmenu = $altkategorisecmenu->fetch(PDO::FETCH_ASSOC)){ 

                                       $altkategori_ad = $altkategoricekmenu['kategori_ad'];
                                       $altkategori_id = $altkategoricekmenu['kategori_id']; ?>

                                                                <li><a class="dropdown-item" href="c-<?php echo seo($altkategori_ad)."-".$altkategori_id; ?>"><?php echo $altkategori_ad; ?></a></li>

                                                            <?php  } ?>
                                                               
                                                            </ul>


                                         <?php  } ?>

                                                    



                                                     

                                                        </div>

                                                    <?php  } ?>

                                                    </div>
                                                

                                                </li>
                                            </ul>
                                        </li>


                                        <li class="nav-item dropdown mega-dropdown">
                                            <a style="color: black;font-size: 14px;" class="nav-link dropdown-toggle" href="markalar">Markalar</a>
                                            <ul class="dropdown-menu mega-dropdown-menu">
                                                <li class="mega-container">
                                                    <div class="row">
                                                        
                                                        <?php $markasec=$db->prepare("SELECT * from markalar order by marka_ad ASC");

                                                $markasec->execute();

                                                while ($markacek=$markasec->fetch(PDO::FETCH_ASSOC)) { 

                                                    $marka_ad = $markacek['marka_ad'];
                                                    $marka_id = $markacek['marka_id']; ?>


                                                    <div class="col-md-4 col-sm-6 col-xs-12">
                                                        
                                                         <a class="dropdown-item" href="markalar-<?php echo seo($marka_ad); ?>"><?php echo $marka_ad; ?></a> 

                                                    </div>


                                                <?php } ?>



                                                    </div>
                                                </li>
                                            </ul>
                                        </li>

                                         <?php $kampanyasec=$db->prepare("SELECT * from kampanyalar where kampanya_menu='1' order by kampanya_sira ASC");
                                $kampanyasec->execute();

                                while($kampanyacek=$kampanyasec->fetch(PDO::FETCH_ASSOC)){

                                $kampanya_baslik = $kampanyacek['kampanya_baslik']; ?>


                                        <li class="nav-item"><a style="color: black;font-size: 14px;" class="nav-link" href="kampanya-<?php echo seo($kampanya_baslik); ?>"><?php echo $kampanya_baslik; ?></a></li>

                                    <?php } ?>


                                        
                                        
                                    </ul>
                                </div>
                            </nav>
                        </div>
                        <div class="col-xl-4 col-md-3">
                            <div class="margin-right-3 d-flex align-items-center justify-content-end h-100">
                                <div class="product-search-one flex-grow-1 global-search touch-screen-view">
                                    <form class="form-inline search-pill-shape" id="searchform" onsubmit="return false;">
                                        <input type="text" maxlength="100" class="form-control search-field" name="search" placeholder="Ürün adı / Ürün No. / Marka" id="searchquery">
                                        
                                        <button type="submit" name="submit" class="search-submit"><i class="flaticon-search flat-mini text-white"></i></button>
                                    </form>
                                </div>
                                <div class="search-view d-xl-none">
                                    <a href="#" class="search-pop top-quantity d-flex align-items-center text-decoration-none">
                                        <i class="flaticon-search flat-small text-dark"></i>
                                    </a>
                                </div>
                               
                                <div class="header-cart-4">
                                    <a href="sepetim" class="cart has-cart-data" title="Sepetim">
                                        <div class="cart-icon"><i class="flaticon-shopping-cart flat-small"></i> <span class="header-cart-count sepetitemsayisi"><?php echo $sepeturunsayheader; ?></span></div>
                                        
                                    </a>
                                    <div class="cart-popup">

                                        <?php if ($sepeturunsayheader==0) { ?>

                                            <span style="color:#707070;">Sepetiniz henüz boş.</span>
                                            

                                       <?php } else { ?>

                                        <ul class="cart_list product_list_widget ">

                                            <?php

                                                        $urun_toplam=0;

                                                        while ($sepeturuncekheader=$sepeturunsecheader->fetch(PDO::FETCH_ASSOC)) { 

                $urunsec=$db->prepare("SELECT * from urunler where urun_id=:id");
                        $urunsec->execute(array(

                            "id" => $sepeturuncekheader['urun_id']
                        ));

                        $uruncek = $urunsec->fetch(PDO::FETCH_ASSOC);

                        $urun_marka = $uruncek['marka_id'];

                        if ($uruncek['urun_indirim']==1) {
                            
                            $urun_fiyat = $uruncek['urun_fiyat'];

                        } else {

                            $urun_fiyat = $uruncek['urun_indirimsizfiyat'];
                        };

                        $urun_toplamfiyat = $sepeturuncekheader['urun_miktar']*$urun_fiyat;
                        $sepetitem_id = $sepeturuncekheader['sepetitem_id'];

                        $sepetitemseceneksec = $db->prepare("SELECT * from sepetitemsecenekler where sepetitem_id='$sepetitem_id'");

                          $sepetitemseceneksec->execute();

                        $urun_toplam+=$urun_toplamfiyat;

                        $urun_ad=$uruncek['urun_ad'];

                         $urunfotosec=$db->prepare("SELECT * from urunfoto where urun_id=:id and urunfoto_kapak=:kapak");
                $urunfotosec->execute(array(
                    "id" => $sepeturuncekheader['urun_id'],
                    "kapak" => 1

                ));

                $urunfotocek=$urunfotosec->fetch(PDO::FETCH_ASSOC);

                $markasec=$db->prepare("SELECT * from markalar where marka_id='$urun_marka'");
                        $markasec->execute();
                        $markacek=$markasec->fetch(PDO::FETCH_ASSOC);
                        $marka_ad=$markacek['marka_ad'];

                ?>
                                            
                                            <li class="mini-cart-item">
                                                
                                                <a href="urun-<?php echo seo($urun_ad)."-".$uruncek['urun_id']; ?>" class="product-image bg-light"><img src="<?php echo $urunfotocek['urunfoto_yol']; ?>" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt=""></a>
                                                <span style="font-weight: 500;"><?php echo $marka_ad; ?></span>
                                                <a href="urun-<?php echo seo($urun_ad)."-".$uruncek['urun_id']; ?>" class="product-name"><?php if (strlen($urun_ad)>50) { ?>
                            <?php echo substr($urun_ad,0,50)."..."; ?>
                        <?php } else { 

                         echo $urun_ad; 
                         } ?></a>
                                                <?php while ($sepetitemsecenekcek=$sepetitemseceneksec->fetch(PDO::FETCH_ASSOC)) { 
                $secenek_ad = $sepetitemsecenekcek['secenek_ad'];
                $altsecenek_ad = $sepetitemsecenekcek['altsecenek_ad']; ?>


                                                <div class="variation">
                                                    <span><?php echo $secenek_ad; ?>:</span>
                                                    <span><?php echo $altsecenek_ad; ?></span>
                                                </div>

                                            <?php } ?>

                                                <div class="cart-item-quantity"><?php echo $sepeturuncekheader['urun_miktar']; ?> ×
                                                    <span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">₺</span><?php echo $urun_fiyat; ?></bdi>
                                                    </span>
                                                </div>
                                            </li>

                                        <?php } ?>
                                        </ul>
                                        <div class="total-cart">
                                            <div class="title">Toplam: </div>
                                            <div class="price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol"></span><?php echo $urun_toplam; ?> TL</span>
                                            </div>
                                        </div>
                                        <div class="buttons">
                                            <a href="sepetim" class="btn btn-primary rounded-0 view-cart">Sepete Git</a>
                                            <a href="odeme" class="btn btn-secondary rounded-0 checkout">Ödeme Yap</a>
                                        </div>

                                       <?php } ?>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="header-sticky bg-white py-10">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-xxl-2 col-xl-2 col-lg-3 col-6 order-lg-1">
                            <div class="d-flex align-items-center h-100 md-py-10">
                                <div class="nav-leftpush-overlay">
                                    <nav class="navbar navbar-expand-lg nav-general nav-primary-hover">
                                        <button type="button" class="push-nav-toggle d-lg-none border-0">
                                            <i class="flaticon-menu-2 flat-small text-primary"></i>
                                        </button>
                                        <div class="navbar-slide-push transation-this">
                                            <div class="login-signup bg-secondary d-flex justify-content-between py-10 px-20 align-items-center">
                                                <a href="registration.html" class="d-flex align-items-center text-white">
                                                    <i class="flaticon-user flat-small me-1"></i>
                                                    <span>Login/Signup</span>
                                                </a>
                                                <span class="slide-nav-close"><i class="flaticon-cancel flat-mini text-white"></i></span>
                                            </div>
                                            <div class="menu-and-category">
                                                <ul class="nav nav-pills wc-tabs" id="menu-and-category" role="tablist">
                                                    <li class="nav-item" role="presentation">
                                                        <a class="nav-link active" id="pills-push-menu-tab" data-bs-toggle="pill" href="#pills-push-menu" role="tab" aria-controls="pills-push-menu" aria-selected="true">Menu</a>
                                                    </li>
                                                    <li class="nav-item" role="presentation">
                                                        <a class="nav-link" id="pills-push-categories-tab" data-bs-toggle="pill" href="#pills-push-categories" role="tab" aria-controls="pills-push-categories" aria-selected="true">Categories</a>
                                                    </li>
                                                </ul>
                                                <div class="tab-content" id="menu-and-categoryContent">
                                                    <div class="tab-pane fade show active woocommerce-Tabs-panel woocommerce-Tabs-panel--description" id="pills-push-menu" role="tabpanel" aria-labelledby="pills-push-menu-tab">
                                                        <div class="push-navbar">
                                                            <ul class="navbar-nav">
                                                                <li class="nav-item dropdown">
                                                                    <a class="nav-link dropdown-toggle" href="index.html">Home</a>
                                                                    <ul class="dropdown-menu">
                                                                        <li><a class="dropdown-item" href="index.html">All Demos</a></li>
                                                                        <li><a class="dropdown-item" href="index-minimal.html">Minimal</a></li>
                                                                        <li><a class="dropdown-item" href="index-watches.html">Watches</a></li>
                                                                        <li><a class="dropdown-item" href="index-fatloss.html">Fatloss</a></li>
                                                                        <li><a class="dropdown-item" href="index-handicruft.html">Handicruft</a></li>
                                                                        <li><a class="dropdown-item" href="index-food-corner.html">Food Corner</a></li>
                                                                        <li><a class="dropdown-item" href="index-classic.html">Classic</a></li>
                                                                        <li><a class="dropdown-item" href="index-optical-shop.html">Optical</a></li>
                                                                        <li><a class="dropdown-item" href="index-furniture-store.html">Furniture</a></li>
                                                                        <li><a class="dropdown-item" href="index-grocery-store.html">Grocery</a></li>
                                                                        <li><a class="dropdown-item" href="index-cosmetic-store.html">Cosmetic</a></li>
                                                                        <li><a class="dropdown-item" href="index-women-fashion.html">Women Fashion</a></li>
                                                                        <li><a class="dropdown-item" href="index-pet-shop.html">Pet Shop</a></li>
                                                                        <li><a class="dropdown-item" href="index-man-fashion.html">Man Fashion</a></li>
                                                                        <li><a class="dropdown-item" href="index-electronic.html">Electronic</a></li>
                                                                        <li><a class="dropdown-item" href="index-standard.html">Standard</a></li>
                                                                    </ul>
                                                                </li>
                                                                <li class="nav-item dropdown mega-dropdown">
                                                                    <a class="nav-link dropdown-toggle" href="#">Shop</a>
                                                                    <ul class="dropdown-menu mega-dropdown-menu">
                                                                        <li class="mega-container">
                                                                            <div class="row row-cols-lg-4 row-cols-sm-2 row-cols-1">
                                                                                <div class="col">
                                                                                    <span class="d-inline-block px-3 font-600 text-uppercase text-secondary pb-2">Product Grid View</span>
                                                                                    <ul>
                                                                                        <li><a class="dropdown-item" href="shop-grid-full.html">Shop Grid Full</a></li>
                                                                                        <li><a class="dropdown-item" href="shop-grid-left-sidebar.html">Shop Grid Modern</a></li>
                                                                                        <li><a class="dropdown-item" href="shop-grid-left-sidebar-1.html">Shop Grid Left Sidebar 1</a></li>
                                                                                        <li><a class="dropdown-item" href="shop-grid-left-sidebar-2.html">Shop Grid Left Sidebar 2</a></li>
                                                                                        <li><a class="dropdown-item" href="shop-grid-left-sidebar-3.html">Shop Grid Left Sidebar 3</a></li>
                                                                                        <li><a class="dropdown-item" href="shop-grid-right-sidebar-1.html">Shop Grid Right Sidebar 1</a></li>
                                                                                        <li><a class="dropdown-item" href="shop-grid-right-sidebar-2.html">Shop Grid Right Sidebar 2</a></li>
                                                                                        <li><a class="dropdown-item" href="shop-grid-right-sidebar-3.html">Shop Grid Right Sidebar 3</a></li>
                                                                                    </ul>
                                                                                </div>
                                                                                <div class="col">
                                                                                    <span class="d-inline-block px-3 font-600 text-uppercase text-secondary pb-2">Product List View</span>
                                                                                    <ul>
                                                                                        <li><a class="dropdown-item" href="shop-list-full.html">Shop List Full</a></li>
                                                                                        <li><a class="dropdown-item" href="shop-list-left-sidebar.html">Shop List Modern</a></li>
                                                                                        <li><a class="dropdown-item" href="shop-list-left-sidebar-1.html">Shop List Left Sidebar 1</a></li>
                                                                                        <li><a class="dropdown-item" href="shop-list-left-sidebar-2.html">Shop List Left Sidebar 2</a></li>
                                                                                        <li><a class="dropdown-item" href="shop-list-left-sidebar-3.html">Shop List Left Sidebar 3</a></li>
                                                                                        <li><a class="dropdown-item" href="shop-list-right-sidebar-1.html">Shop List Right Sidebar 1</a></li>
                                                                                        <li><a class="dropdown-item" href="shop-list-right-sidebar-2.html">Shop List Right Sidebar 2</a></li>
                                                                                        <li><a class="dropdown-item" href="shop-list-right-sidebar-3.html">Shop List Right Sidebar 3</a></li>
                                                                                    </ul>
                                                                                </div>
                                                                                <div class="col">
                                                                                    <span class="d-inline-block px-3 font-600 text-uppercase text-secondary pb-2">Woocommerce Pages</span>
                                                                                    <ul>
                                                                                        <li><a class="dropdown-item" href="cart.html">Cart</a></li>
                                                                                        <li><a class="dropdown-item" href="checkout.html">Checkout</a></li>
                                                                                        <li><a class="dropdown-item" href="my-account.html">My Account</a></li>
                                                                                        <li><a class="dropdown-item" href="registration.html">Registration</a></li>
                                                                                        <li><a class="dropdown-item" href="wishlist.html">Wishlist</a></li>
                                                                                        <li><a class="dropdown-item" href="single-shop.html">Single Shop 1</a></li>
                                                                                        <li><a class="dropdown-item" href="single-shop-2.html">Single Shop 2</a></li>
                                                                                        <li><a class="dropdown-item" href="single-shop-3.html">Single Shop 3</a></li>
                                                                                    </ul>
                                                                                </div>
                                                                                <div class="col">
                                                                                    <span class="d-inline-block px-3 font-600 text-uppercase text-secondary pb-2">Product Thumbs</span>
                                                                                    <ul>
                                                                                        <li><a class="dropdown-item" href="hover-bg-light.html">Hover Background Light</a></li>
                                                                                        <li><a class="dropdown-item" href="hover-shadow-active.html">Hover Shadow Active</a></li>
                                                                                        <li><a class="dropdown-item" href="hover-image-zoom.html">Hover Image Zoom</a></li>
                                                                                        <li><a class="dropdown-item" href="hover-btn-slide-1.html">Hover Btn Slide 1</a></li>
                                                                                        <li><a class="dropdown-item" href="hover-btn-slide-2.html">Hover Btn Slide 2</a></li>
                                                                                        <li><a class="dropdown-item" href="hover-btn-slide-3.html">Hover Btn Slide 3</a></li>
                                                                                    </ul>
                                                                                </div>
                                                                            </div>
                                                                        </li>
                                                                    </ul>
                                                                </li>
                                                                <li class="nav-item dropdown">
                                                                    <a class="nav-link dropdown-toggle" href="#">Pages</a>
                                                                    <ul class="dropdown-menu">
                                                                        <li class="dropdown">
                                                                            <a class="dropdown-toggle dropdown-item" href="portfolio-filter-column-four.html">Portfolio</a>
                                                                            <ul class="dropdown-menu">
                                                                                <li><a class="dropdown-item" href="portfolio-column-three.html">Portfolio Column Three</a></li>
                                                                                <li><a class="dropdown-item" href="portfolio-column-four.html">Portfolio Column Four</a></li>
                                                                                <li><a class="dropdown-item" href="portfolio-full-width.html">Portfolio Full Width</a></li>
                                                                                <li><a class="dropdown-item" href="portfolio-filter-column-three.html">Portfolio Filter Column Three</a></li>
                                                                                <li><a class="dropdown-item" href="portfolio-filter-column-four.html">Portfolio Filter Column Four</a></li>
                                                                                <li><a class="dropdown-item" href="portfolio-single-slider-layout.html">Portfolio Single Slider Layout</a></li>
                                                                            </ul>
                                                                        </li>
                                                                        <li class="dropdown"> <a class="dropdown-toggle dropdown-item" href="general-support.html">Help and Support</a>
                                                                            <ul class="dropdown-menu">
                                                                                <li><a class="dropdown-item" href="how-it-work.html">How It Work</a></li>
                                                                                <li><a class="dropdown-item" href="general-support.html">General Support</a></li>
                                                                                <li><a class="dropdown-item" href="help-center.html">Help Center</a></li>
                                                                                <li><a class="dropdown-item" href="support-article-details.html">Support Article</a></li>
                                                                                <li><a class="dropdown-item" href="terms-and-condition.html">Terms & Condition</a></li>
                                                                            </ul>
                                                                        </li>
                                                                        <li><a class="dropdown-item" href="about-owner.html">About Owner</a></li>
                                                                        <li><a class="dropdown-item" href="about.html">About Us 1</a></li>
                                                                        <li><a class="dropdown-item" href="about-2.html">About Us 2</a></li>
                                                                        <li><a class="dropdown-item" href="service.html">Services</a></li>
                                                                        <li><a class="dropdown-item" href="gallery.html">Gallery</a></li>
                                                                        <li><a class="dropdown-item" href="404.html">404 Page</a></li>
                                                                    </ul>
                                                                </li>
                                                                <li class="nav-item dropdown">
                                                                    <a class="nav-link dropdown-toggle" href="blog-grid-left-sidebar.html">Blog</a>
                                                                    <ul class="dropdown-menu">
                                                                        <li class="dropdown"> <a class="dropdown-toggle dropdown-item" href="blog-grid-modern.html">Blog Grid</a>
                                                                            <ul class="dropdown-menu">
                                                                                <li><a class="dropdown-item" href="blog-grid-modern.html">Grid Modern</a></li>
                                                                                <li><a class="dropdown-item" href="blog-grid-left-sidebar.html">Left Sidebar Grid</a></li>
                                                                                <li><a class="dropdown-item" href="blog-grid-right-sidebar.html">Right Sidebar Grid</a></li>
                                                                            </ul>
                                                                        </li>
                                                                        <li class="dropdown"> <a class="dropdown-toggle dropdown-item" href="blog-list-modern.html">Blog List</a>
                                                                            <ul class="dropdown-menu">
                                                                                <li><a class="dropdown-item" href="blog-list-modern.html">List Modern</a></li>
                                                                                <li><a class="dropdown-item" href="blog-list-left-sidebar.html">Left Sidebar List</a></li>
                                                                                <li><a class="dropdown-item" href="blog-list-right-sidebar.html">Right Sidebar List</a></li>
                                                                            </ul>
                                                                        </li>
                                                                        <li class="dropdown"> <a class="dropdown-toggle dropdown-item" href="blog-single-modern.html">Blog Single</a>
                                                                            <ul class="dropdown-menu">
                                                                                <li><a class="dropdown-item" href="blog-single-modern.html">Blog Single Modern</a></li>
                                                                                <li><a class="dropdown-item" href="blog-single-left-sidebar.html">Blog Single Left Sidebar</a></li>
                                                                                <li><a class="dropdown-item" href="blog-single-right-sidebar.html">Blog Single Right Sidebar</a></li>
                                                                            </ul>
                                                                        </li>
                                                                        <li><a class="dropdown-item" href="blog-missionary-grid.html">Missionary Grid</a></li>
                                                                        <li><a class="dropdown-item" href="blog-video-grid.html">Video Grid</a></li>
                                                                    </ul>
                                                                </li>
                                                                <li class="nav-item dropdown">
                                                                    <a class="nav-link dropdown-toggle" href="#">Elements</a>
                                                                    <ul class="dropdown-menu">
                                                                        <li class="dropdown">
                                                                            <a class="dropdown-toggle dropdown-item" href="#">Product Thumbnails</a>
                                                                            <ul class="dropdown-menu">
                                                                                <li><a class="dropdown-item" href="element-product-grid-view.html">Grid View Style</a></li>
                                                                                <li><a class="dropdown-item" href="element-product-list-view.html">List View Style</a></li>
                                                                            </ul>
                                                                        </li>
                                                                        <li><a class="dropdown-item" href="element-carousel.html">Product Carousel</a></li>
                                                                        <li><a class="dropdown-item" href="element-tab.html">Product Tab</a></li>
                                                                        <li><a class="dropdown-item" href="element-typography.html">Typography</a></li>
                                                                        <li><a class="dropdown-item" href="element-banner.html">Banner Style</a></li>
                                                                        <li><a class="dropdown-item" href="element-accordions.html">Accordion</a></li>
                                                                        <li><a class="dropdown-item" href="element-flash-deal.html">Flash Deal</a></li>
                                                                        <li><a class="dropdown-item" href="element-product-category.html">Product Category</a></li>
                                                                        <li><a class="dropdown-item" href="element-countdown.html">Fact Counter</a></li>
                                                                    </ul>
                                                                </li>
                                                                <li class="nav-item"><a class="nav-link" href="contact.html">Contact</a></li>
                                                            </ul>
                                                            <a href="#" class="p-20 d-block bg-secondary text-primary text-uppercase font-600 hover-text-primary">Buy now!</a>
                                                        </div>
                                                    </div>
                                                    <div class="tab-pane fade" id="pills-push-categories" role="tabpanel" aria-labelledby="pills-push-categories-tab">
                                                        <div class="categories-menu">
                                                            <ul class="menu">
                                                                <li class="menu-item-has-children unicode-megamenu-dropdown unicode-megamenu-item-full-width">
                                                                    <a href="#">Women's Fashion</a>
                                                                    <div class="unicode-megamenu-wrapper" style="background-image: url(assets/images/banner/49.png); background-size: cover;
																		background-position:0px;">
                                                                        <div class="unicode-megamenu-holder">
                                                                            <div class="row row-cols-3">
                                                                                <div class="col">
                                                                                    <ul class="unicode-menu-element unicode-megamenu-list">
                                                                                        <li class="menu-item">
                                                                                            <a class="nav-link" href="#" title="Top wear"> <span>Top Clothing</span></a>
                                                                                            <ul class="unicode-sub-megamenu">
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="Tops"> <span>Tops</span> </a>
                                                                                                </li>
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="T-Shirts"> <span>T-Shirts</span> </a>
                                                                                                </li>
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="Shirts"> <span>Shirts</span></a>
                                                                                                </li>
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="Jeans & Jeggings"> <span>Jeans & Jeggings</span> </a>
                                                                                                </li>
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="Trousers & Capris"> <span>Trousers & Capris</span> </a>
                                                                                                </li>
                                                                                            </ul>
                                                                                        </li>
                                                                                    </ul>
                                                                                    <ul class="unicode-menu-element unicode-megamenu-list">
                                                                                        <li class="menu-item"> <a class="nav-link" href="#" title="Fusion Wear"><span>Fusion Wear</span></a>
                                                                                            <ul class="unicode-sub-megamenu">
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="Sweaters & Sweatshirts"> <span>Sweaters & Sweatshirts</span> </a>
                                                                                                </li>
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="Coats & Blazers"> <span>Coats & Blazers</span> </a>
                                                                                                </li>
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="Jackets & Waistcoats"> <span>Jackets & Waistcoats</span> </a>
                                                                                                </li>
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="Shorts & Skirts"> <span>Shorts & Skirts</span> </a>
                                                                                                </li>
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="Camisoles & Slips"> <span>Camisoles & Slips</span> </a>
                                                                                                </li>
                                                                                            </ul>
                                                                                        </li>
                                                                                    </ul>
                                                                                </div>
                                                                                <div class="col">
                                                                                    <ul class="unicode-menu-element unicode-megamenu-list">
                                                                                        <li class="menu-item">
                                                                                            <a class="nav-link" href="#" title="Sports & Active Wear"> <span>Sports & Active Wear</span> </a>
                                                                                            <ul class="unicode-sub-megamenu">
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="Clothing"> <span>Clothing</span> </a>
                                                                                                </li>
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="Footwear"> <span>Footwear</span> </a>
                                                                                                </li>
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="T-Shirts"> <span>T-Shirts</span> </a>
                                                                                                </li>
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="Sports Accessories"> <span>Sports Accessories</span> </a>
                                                                                                </li>
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="Sports Equipment"> <span>Sports Equipment</span> </a>
                                                                                                </li>
                                                                                            </ul>
                                                                                        </li>
                                                                                    </ul>
                                                                                    <ul class="unicode-menu-element unicode-megamenu-list">
                                                                                        <li class="menu-item">
                                                                                            <a class="nav-link" href="#" title="Lingerie & Sleepwear"> <span>Lingerie & Sleepwear</span> </a>
                                                                                            <ul class="unicode-sub-megamenu">
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="Bras & Lingerie Sets"> <span>Bras & Lingerie Sets</span> </a>
                                                                                                </li>
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="Briefs"> <span>Briefs</span> </a>
                                                                                                </li>
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="Shapewear"> <span>Shapewear</span> </a>
                                                                                                </li>
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="Sleepwear & Loungewear"> <span>Sleepwear & Loungewear</span> </a>
                                                                                                </li>
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="Camisoles & Thermals"> <span>Camisoles & Thermals</span> </a>
                                                                                                </li>
                                                                                            </ul>
                                                                                        </li>
                                                                                    </ul>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </li>
                                                                <li class="menu-item-has-children unicode-megamenu-dropdown unicode-megamenu-item-full-width">
                                                                    <a href="#">Men's Fashion</a>
                                                                    <div class="unicode-megamenu-wrapper">
                                                                        <div class="unicode-megamenu-holder">
                                                                            <div class="row row-cols-3">
                                                                                <div class="col">
                                                                                    <ul class="unicode-menu-element unicode-megamenu-list">
                                                                                        <li class="menu-item">
                                                                                            <a class="nav-link" href="#" title="Top wear"> <span>Top Clothing</span></a>
                                                                                            <ul class="unicode-sub-megamenu">
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="Tops"> <span>Tops</span> </a>
                                                                                                </li>
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="T-Shirts"> <span>T-Shirts</span> </a>
                                                                                                </li>
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="Shirts"> <span>Shirts</span></a>
                                                                                                </li>
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="Jeans & Jeggings"> <span>Jeans & Jeggings</span> </a>
                                                                                                </li>
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="Trousers & Capris"> <span>Trousers & Capris</span> </a>
                                                                                                </li>
                                                                                            </ul>
                                                                                        </li>
                                                                                    </ul>
                                                                                    <ul class="unicode-menu-element unicode-megamenu-list">
                                                                                        <li class="menu-item"> <a class="nav-link" href="#" title="Fusion Wear"><span>Fusion Wear</span></a>
                                                                                            <ul class="unicode-sub-megamenu">
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="Sweaters & Sweatshirts"> <span>Sweaters & Sweatshirts</span> </a>
                                                                                                </li>
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="Coats & Blazers"> <span>Coats & Blazers</span> </a>
                                                                                                </li>
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="Jackets & Waistcoats"> <span>Jackets & Waistcoats</span> </a>
                                                                                                </li>
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="Shorts & Skirts"> <span>Shorts & Skirts</span> </a>
                                                                                                </li>
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="Camisoles & Slips"> <span>Camisoles & Slips</span> </a>
                                                                                                </li>
                                                                                            </ul>
                                                                                        </li>
                                                                                    </ul>
                                                                                </div>
                                                                                <div class="col">
                                                                                    <ul class="unicode-menu-element unicode-megamenu-list">
                                                                                        <li class="menu-item">
                                                                                            <a class="nav-link" href="#" title="Sports & Active Wear"> <span>Sports & Active Wear</span> </a>
                                                                                            <ul class="unicode-sub-megamenu">
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="Clothing"> <span>Clothing</span> </a>
                                                                                                </li>
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="Footwear"> <span>Footwear</span> </a>
                                                                                                </li>
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="T-Shirts"> <span>T-Shirts</span> </a>
                                                                                                </li>
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="Sports Accessories"> <span>Sports Accessories</span> </a>
                                                                                                </li>
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="Sports Equipment"> <span>Sports Equipment</span> </a>
                                                                                                </li>
                                                                                            </ul>
                                                                                        </li>
                                                                                    </ul>
                                                                                    <ul class="unicode-menu-element unicode-megamenu-list">
                                                                                        <li class="menu-item">
                                                                                            <a class="nav-link" href="#" title="Lingerie & Sleepwear"> <span>Lingerie & Sleepwear</span> </a>
                                                                                            <ul class="unicode-sub-megamenu">
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="Bras & Lingerie Sets"> <span>Bras & Lingerie Sets</span> </a>
                                                                                                </li>
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="Briefs"> <span>Briefs</span> </a>
                                                                                                </li>
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="Shapewear"> <span>Shapewear</span> </a>
                                                                                                </li>
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="Sleepwear & Loungewear"> <span>Sleepwear & Loungewear</span> </a>
                                                                                                </li>
                                                                                                <li class="menu-item">
                                                                                                    <a class="nav-link" href="#" title="Camisoles & Thermals"> <span>Camisoles & Thermals</span> </a>
                                                                                                </li>
                                                                                            </ul>
                                                                                        </li>
                                                                                    </ul>
                                                                                </div>
                                                                                <div class="col">
                                                                                    <img src="assets/images/banner/13.png" alt="">
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </li>
                                                                <li class="menu-item-has-children"><a href="#">Phones & Telecommunications</a></li>
                                                                <li class="menu-item-has-children"><a href="#">Computer, Office & Security</a></li>
                                                                <li class="menu-item-has-children"><a href="#">Consumer Electronics</a></li>
                                                                <li class="menu-item-has-children"><a href="#">Jewelry & Watches</a></li>
                                                                <li class="menu-item-has-children"><a href="#">Home, Pet & Appliances</a></li>
                                                                <li class="menu-item-has-children"><a href="#">Bags & Shoes</a></li>
                                                                <li class="menu-item-has-children"><a href="#">Toys , Kids & Babies</a></li>
                                                                <li class="menu-item-has-children"><a href="#">Outdoor Fun & Sports</a></li>
                                                                <li class="menu-item-has-children"><a href="#">Beauty, Health & Hair</a></li>
                                                                <li class="menu-item-has-children"><a href="#">Home Improvement & Tools</a></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </nav>
                                </div>
                                <a class="navbar-brand" href="../"><img class="nav-logo" src="<?php echo $ayar_logo; ?>" alt="Yener Kozmetik"></a>
                            </div>
                        </div>
                        <div class="col-xxl-3 col-xl-4 col-lg-3 col-6 order-lg-3">
                            <div class="margin-right-1 d-flex align-items-center justify-content-end h-100 md-py-10">
                                <div class="sign-in position-relative font-general my-account-dropdown">
                                    <a href="my-account.html" class="has-dropdown d-flex align-items-center text-dark text-decoration-none" title="My Account">
                                        <i class="flaticon-user-3 flat-small me-1"></i>
                                    </a>
                                    <ul class="my-account-popup">

                                        <?php if (empty($_SESSION['kullanicioturum'])) { ?>

                             <li><a href="uye-ol"><span style="color: black;" class="menu-item-text">Üye Ol</span></a></li>
                             <li><a href="giris-yap"><span style="color: black;" class="menu-item-text">Giriş Yap</span></a></li>

                                        <?php } else { ?>

                                       
                                       <li><a href="kullanici-bilgilerim"><span style="color: black;" class="menu-item-text">Kullanıcı Bilgilerim</span></a></li>
                                        
                                         <li><a href="siparislerim"><span style="color: black;" class="menu-item-text">Siparişlerim</span></a></li>
                                        <li><a href="sepetim"><span style="color: black;" class="menu-item-text">Sepetim</span></a></li>
                                        <li><a href="favoriler"><span style="color: black;" class="menu-item-text">Favoriler</span></a></li>

                                        <li><a href="odeme"><span style="color: black;" class="menu-item-text">Ödemeyi Tamamla</span></a></li>

                                        <li><a href="sifre-guncelle"><span style="color: black;" class="menu-item-text">Şifre Güncelle</span></a></li>

                                        <li><a href="logout?url=<?php echo 'http://'.$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI']; ?>"><span style="color: black;" class="menu-item-text">Çıkış Yap</span></a></li>

                                      <?php  } ?>
                                        
                                    </ul>
                                </div>
                                <div class="wishlist-view">
                                    <a href="favoriler" class="position-relative top-quantity d-flex align-items-center text-white text-decoration-none" title="Favoriler">
                                        <i class="flaticon-like flat-small text-dark"></i>
                                    </a>
                                </div>
                                
                                <div class="header-cart-4">
                                    <a href="cart.html" class="cart has-cart-data" title="Sepetim">
                                        <div class="cart-icon"><i class="flaticon-shopping-cart flat-small"></i> <span class="header-cart-count sepetitemsayisi"><?php echo $sepeturunsayheader; ?></span></div>
                                        
                                    </a>
                                    <div class="cart-popup">

                                        <?php if ($sepeturunsayheader==0) { ?>

                                            <span style="color:#707070;">Sepetiniz henüz boş.</span>
                                            

                                       <?php } else { ?>

                                        <ul class="cart_list product_list_widget ">

                                            <?php

                                                        $urun_toplam=0;

                                                        while ($sepeturuncekheader2=$sepeturunsecheader2->fetch(PDO::FETCH_ASSOC)) { 

                $urunsec=$db->prepare("SELECT * from urunler where urun_id=:id");
                        $urunsec->execute(array(

                            "id" => $sepeturuncekheader2['urun_id']
                        ));

                        $uruncek = $urunsec->fetch(PDO::FETCH_ASSOC);

                        $urun_marka = $uruncek['marka_id'];

                        if ($uruncek['urun_indirim']==1) {
                            
                            $urun_fiyat = $uruncek['urun_fiyat'];

                        } else {

                            $urun_fiyat = $uruncek['urun_indirimsizfiyat'];
                        };

                        $urun_toplamfiyat = $sepeturuncekheader2['urun_miktar']*$urun_fiyat;
                        $sepetitem_id = $sepeturuncekheader2['sepetitem_id'];

                        $sepetitemseceneksec = $db->prepare("SELECT * from sepetitemsecenekler where sepetitem_id='$sepetitem_id'");

                          $sepetitemseceneksec->execute();

                        $urun_toplam+=$urun_toplamfiyat;

                        $urun_ad=$uruncek['urun_ad'];

                         $urunfotosec=$db->prepare("SELECT * from urunfoto where urun_id=:id and urunfoto_kapak=:kapak");
                $urunfotosec->execute(array(
                    "id" => $sepeturuncekheader2['urun_id'],
                    "kapak" => 1

                ));

                $urunfotocek=$urunfotosec->fetch(PDO::FETCH_ASSOC);

                $markasec=$db->prepare("SELECT * from markalar where marka_id='$urun_marka'");
                        $markasec->execute();
                        $markacek=$markasec->fetch(PDO::FETCH_ASSOC);
                        $marka_ad=$markacek['marka_ad'];

                ?>
                                            
                                            <li class="mini-cart-item">
                                                
                                                <a href="urun-<?php echo seo($urun_ad)."-".$uruncek['urun_id']; ?>" class="product-image bg-light"><img src="<?php echo $urunfotocek['urunfoto_yol']; ?>" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt=""></a>
                                                <span style="font-weight: 500;"><?php echo $marka_ad; ?></span>
                                                <a href="urun-<?php echo seo($urun_ad)."-".$uruncek['urun_id']; ?>" class="product-name"><?php if (strlen($urun_ad)>50) { ?>
                            <?php echo substr($urun_ad,0,50)."..."; ?>
                        <?php } else { 

                         echo $urun_ad; 
                         } ?></a>
                                                <?php while ($sepetitemsecenekcek=$sepetitemseceneksec->fetch(PDO::FETCH_ASSOC)) { 
                $secenek_ad = $sepetitemsecenekcek['secenek_ad'];
                $altsecenek_ad = $sepetitemsecenekcek['altsecenek_ad']; ?>


                                                <div class="variation">
                                                    <span><?php echo $secenek_ad; ?>:</span>
                                                    <span><?php echo $altsecenek_ad; ?></span>
                                                </div>

                                            <?php } ?>

                                                <div class="cart-item-quantity"><?php echo $sepeturuncekheader2['urun_miktar']; ?> ×
                                                    <span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">₺</span><?php echo $urun_fiyat; ?></bdi>
                                                    </span>
                                                </div>
                                            </li>

                                        <?php } ?>
                                        </ul>
                                        <div class="total-cart">
                                            <div class="title">Toplam: </div>
                                            <div class="price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol"></span><?php echo $urun_toplam; ?> TL</span>
                                            </div>
                                        </div>
                                        <div class="buttons">
                                            <a href="sepetim" class="btn btn-primary rounded-0 view-cart">Sepete Git</a>
                                            <a href="odeme" class="btn btn-secondary rounded-0 checkout">Ödeme Yap</a>
                                        </div>

                                       <?php } ?>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xxl-7 col-xl-6 col-lg-6 col-12 order-lg-2">
                            <div class="product-search-one">
                                <form class="form-inline search-pill-shape" id="searchform2" onsubmit="return false;">
                                    <input type="text" class="form-control search-field" name="search" placeholder="Ürün Adı / Ürün No. / Marka" id="searchquery2">
                                    
                                    <button type="submit" name="submit" class="search-submit searchbutonn2"><i class="flaticon-search flat-mini text-white"></i></button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!--==================== Header Section End ====================-->