<?php require_once 'header.php';

$ayar_hakkimizdabanner = $genelayarcek['ayar_hakkimizdabanner'];
 $hakkimizda_text = $genelayarcek['hakkimizda_text'];

  ?>


   <head>

<meta name="description" content="<?php echo $seoayarcek['hakkimizda_description']; ?>">

<title><?php echo $seoayarcek['hakkimizda_title']; ?></title>

</head>

        

        <!--==================== About Owner Section Start ====================-->
        <div style="padding-top: 20px;" class="full-row">
            <div class="container">
                
                  <div align="center" class="col-md-12 col-xs-12 col-lg-12">
                
                <div class="col-lg-10 col-md-12 col-xs-12">
                    
                   <img style="width: 100%;" class="img-responsive" src="<?php echo $ayar_hakkimizdabanner; ?>">

                </div>

                </div>

                <div style="margin-top:50px;" class="col-md-12 col-xs-12 col-lg-12">
                
                
                    
                   <?php echo $hakkimizda_text; ?>

                

                </div>

            </div>
        </div>

     

        <!--==================== About Owner Section End ====================-->

        

        <?php require_once 'footer.php'; ?>