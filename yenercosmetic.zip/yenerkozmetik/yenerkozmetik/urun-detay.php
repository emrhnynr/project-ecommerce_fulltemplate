<?php require_once 'header.php';

$urun_id = $_GET['urun_id'];

 $urunsec = $db->prepare("SELECT * from urunler where urun_id=:id");
 $urunsec->execute(array(
"id" => $urun_id
 ));

$urunsay=$urunsec->rowCount();

if ($urunsay==0) {
    
    header("location:index");
    exit;
}

 $uruncek = $urunsec->fetch(PDO::FETCH_ASSOC);

 $urun_video = $uruncek['urun_video'];
 $urun_stok = $uruncek['urun_stok'];

 $urunfotokapaksec=$db->prepare("SELECT * from urunfoto where urun_id=:id and urunfoto_kapak=:kapak");
 $urunfotokapaksec->execute(array(
"id" => $urun_id,
"kapak" => 1
 ));

 $urunfotokapakcek=$urunfotokapaksec->fetch(PDO::FETCH_ASSOC);

 $urunfotosec=$db->prepare("SELECT * from urunfoto where urun_id=:id and urunfoto_kapak=:kapak order by foto_sira ASC");
 $urunfotosec->execute(array(
"id" => $urun_id,
"kapak" => 0
 ));

 $urunkategorisec=$db->prepare("SELECT * from kategoriler where kategori_id=:id");
 $urunkategorisec->execute(array(
"id" => $uruncek['kategori_id']
 ));

 $urunkategoricek=$urunkategorisec->fetch(PDO::FETCH_ASSOC);

 $urun_kategori = $urunkategoricek['kategori_ad'];
 $urun_ustkategori = $uruncek['kategori_ust'];

 $urunmarkasec=$db->prepare("SELECT * from markalar where marka_id=:id");
 $urunmarkasec->execute(array(
"id" => $uruncek['marka_id']
 ));

 $urunmarkacek=$urunmarkasec->fetch(PDO::FETCH_ASSOC);

 $urun_marka = $urunmarkacek['marka_ad'];
 $kategori_ust = $uruncek['kategori_id'];

 $say=0;
                      $dizi = array();

                 while ($say<5) {
                    
                    $say++;

                    $kategorisec=$db->prepare("SELECT * from kategoriler where kategori_id='$kategori_ust'");
                    $kategorisec->execute();
                    $kategoricek=$kategorisec->fetch(PDO::FETCH_ASSOC);

                    $kategori_id = $kategoricek['kategori_id'];

                    if ($kategoricek['kategori_ust']==0) {
                      
                      array_push($dizi, $kategori_id);
                      break;

                    } else {

                      array_push($dizi, $kategori_id);

                    }

                    $kategori_ust = $kategoricek['kategori_ust'];

                  };


 

 $favorikontrolsec=$db->prepare("SELECT * from favoriler where kullanici_id=:kulid and urun_id=:urunid");
 $favorikontrolsec->execute(array(
  "kulid" => $_SESSION['kullanici_id'],
  "urunid" => $uruncek['urun_id']
));

 $favorikontrolsay=$favorikontrolsec->rowCount();

 if ($uruncek['urun_indirim']==1) {
  
  $indirim_miktari = $uruncek['urun_indirimsizfiyat']-$uruncek['urun_fiyat'];
  $indirim_yuzdesi = round(($indirim_miktari*100)/$uruncek['urun_indirimsizfiyat']);
 }

 $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

  ?>

   <title><?php echo $urun_marka." ".$uruncek['urun_ad']; ?> | Yener Kozmetik</title>
        
        
    <?php if ($uruncek['urun_kaldirildi']==1) { ?>

        <div class="full-row">
                    <div class="container">

                    <h3 style="font-family: Arial;" align="center">Bu ürün kaldırılmış.</h3>

                   </div>
                   </div>
            
      <?php  } else { ?>

<div class="full-row">
            <div class="container">
                <div class="row single-product-wrapper">
                    <div class="col-12 col-md-6 col-lg-5">
                        <div class="product-images">
                            <div class="images-inner">
                                <div class="woocommerce-product-gallery woocommerce-product-gallery--with-images woocommerce-product-gallery--columns-4 images" data-columns="4" style="opacity: 1; transition: opacity 0.25s ease-in-out 0s;">
                                    <figure class="woocommerce-product-gallery__wrapper">
                                        <img id="single-image-zoom" src="<?php echo $urunfotokapakcek['urunfoto_yol']; ?>" alt="Ürün Fotoğrafı" data-zoom-image="<?php echo $urunfotokapakcek['urunfoto_yol']; ?>" />

                                        <div id="gallery_09" class="product-slide-thumb">
                                            <div class="owl-carousel four-carousel dot-disable nav-arrow-middle owl-mx-5">
                                               
                                               <?php while ($urunfotocek=$urunfotosec->fetch(PDO::FETCH_ASSOC)) { ?>

                                                <div class="item">
                                                    <a href="#" data-image="<?php echo $urunfotocek['urunfoto_yol'] ?>" data-zoom-image="<?php echo $urunfotocek['urunfoto_yol'] ?>">
                                                        <img src="<?php echo $urunfotocek['urunfoto_yol'] ?>" alt="Ürün Fotoğrafı" />
                                                    </a>
                                                </div>

                                            <?php } ?>

                                            </div>
                                        </div>
                                    </figure>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-7">
                        <div class="summary entry-summary">
                            <div class="summary-inner">
                                <div style="margin-top: 43px;" class="product-navigation-share">
                                    <div class="product-share bigbazar-arrow">
                                        <div class="bigbazar-social">
                                            <a target="_blank" href="http://www.facebook.com/sharer.php?u=<?php echo $actual_link; ?>&title=<?php echo $urun_marka." ".$uruncek['urun_ad']; ?>" title="Facebook'ta paylaş" class="social-facebook"><i class="fab fa-facebook-f"></i></a>
                                            <a target="_blank" href="whatsapp://send?<?php echo $actual_link; ?>" data-action="share/whatsapp/share" title="Whatsapp'ta paylaş"><i class="fab fa-whatsapp"></i></a>
                                            
                                        </div>
                                    </div>
                                </div>
                                <div class="entry-breadcrumbs">
                                    <nav class="breadcrumb-divider-slash" aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="../">Anasayfa</a></li>


                                    <?php 

                                    $dizibasla = count($dizi);

                      

                      while ($dizibasla>0) {
                        
                        $dizibasla--;

                        $kategori_id = $dizi[$dizibasla];

                        $kategorisec=$db->prepare("SELECT * from kategoriler where kategori_id='$kategori_id'");
                        $kategorisec->execute();

                        $kategoricek=$kategorisec->fetch(PDO::FETCH_ASSOC); ?>

                        <li class="breadcrumb-item"><a href="c-<?php echo seo($kategoricek['kategori_ad'])."-".$kategoricek['kategori_id']; ?> "><?php echo $kategoricek['kategori_ad']; ?></a></li>

                    <?php } ?>
                                            
                                            <li class="breadcrumb-item active" aria-current="page"><?php echo $urun_marka." ".$uruncek['urun_ad']; ?></li>
                                        </ol>
                                    </nav>
                                </div>
                                <h1 style="font-weight: 200;font-family: arial;" class="product_title entry-title"><?php echo $urun_marka." ".$uruncek['urun_ad']; ?></h1>

                                <?php 

                                if ($uruncek['urun_indirim']==1) { ?>

                                    <p class="price">
                                    <span class="woocommerce-Price-amount amount">
                                        <bdi 

                                        <?php if ($indirim_yuzdesi<40) { ?> style="color:#F3612E;" 
                                            <?php } else { ?>

                                             style="color:#D4102E;"

                                            <?php } ?>><?php echo $uruncek['urun_fiyat']; ?> TL</bdi>
                                            <br>
                                            <del style="color:#707070;font-size: 17px;"><?php echo $uruncek['urun_indirimsizfiyat']; ?> TL</del>
                                    </span>
                                    
                                </p>


                                <?php } else { ?>

                                    <p class="price">
                                    <span class="woocommerce-Price-amount amount">
                                        <bdi><?php echo $uruncek['urun_indirimsizfiyat']; ?> TL</bdi>
                                    </span>
                                    
                                </p>


                               <?php  } ?>

                               <?php if ($uruncek['urun_indirim']==1) { ?>
                                
                                
                                <div <?php if ($indirim_yuzdesi<40) { ?> style="background-color:#F3612E;" 
                                            <?php } else { ?>

                                             style="background-color:#D4102E;"

                                            <?php } ?> class="product-price-discount"><span style="color: #fff;" class="on-sale"><span><?php echo $indirim_yuzdesi ?></span>% İndirim</span>
                                </div>

                            <?php } ?>

                            <?php if ($uruncek['urun_stok']>0) { ?>
                                
                                <div style="font-size: 15px;" class="stock-availability in-stock">Stokta</div>

                            <?php } else { ?>


                                <div style="color:#D4102E;font-size: 18px;" class="stock-availability in-stock"><i class="fas fa-ban"></i> Stokta Yok</div>


                            <?php } ?>
                                <div class="product-offers">
                                    <ul class="product-offers-list">

                                        <?php if ($genelayarcek['kargobedava_limit']<$uruncek['urun_nihaifiyat']) {  ?>
                                        
                                        <li class="product-offer-item"><span class="h6"><b style="font-weight: 200;font-family: arial;">Kargo Bedava</b></span> - <?php echo intval($genelayarcek['kargobedava_limit'])." TL üzeri kargo bedava!";
                                           
                                            }  ?>
                                        </li>
                                    </ul>
                                </div>
                                <div class="product-brands">
                                    <a class="brand-image" target="_blank" href="markalar-<?php echo seo($urun_marka); ?>"> <img src="<?php echo $urunmarkacek['marka_logo']; ?>" class="attachment-full size-full" alt="" width="120" height="120"> </a>
                                </div>
                                
                                <form class="variations_form cart kapee-swatches-wrap sepeteekleform" onsubmit="return false;" >

                                     <input type="hidden" value="<?php echo $_GET['urun_id']; ?>" id='urun_id' name="urun_id">

                                    

                                    <table class="variations">

                                       

                                        <tbody>

                                            <?php $urunseceneklersec=$db->prepare("SELECT * from urunsecenekler where urun_id=:id");
                                           $urunseceneklersec->execute(array(
                                            "id" => $_GET['urun_id']
                                          ));

                                          while ($urunseceneklercek=$urunseceneklersec->fetch(PDO::FETCH_ASSOC)) { 

                                            $secenek_id = $urunseceneklercek['secenek_id'];
                                            $seceneksec=$db->prepare("SELECT * from secenekler where secenek_id=:id");
                                            $seceneksec->execute(array(
                                              "id" => $secenek_id
                                            ));

                                             $secenekcek=$seceneksec->fetch(PDO::FETCH_ASSOC);

                                             $secenek_ad = $secenekcek['secenek_ad'];

                                              ?>
                                            
                                            <tr>
                                                <td class="label"><label><?php echo $secenek_ad; ?></label></td>
                                                <td class="value with-swatches">
                                                    <select name="altsecenek_id_<?php echo $secenek_id; ?>" class="form-control" id="<?php echo $secenekcek['secenek_name']; ?>">
                                            <option class="secenekoption" value="secilmedi" selected="" hidden="">Seç</option>
                                            <?php $urunaltseceneksec=$db->prepare("SELECT * from urunaltsecenekler where secenek_id=:secenekid and urun_id=:urunid");
                                       $urunaltseceneksec->execute(array(
                                        "secenekid" => $secenek_id,
                                        "urunid" => $_GET['urun_id']
                                      ));

                                      while ($urunaltsecenekcek=$urunaltseceneksec->fetch(PDO::FETCH_ASSOC)) { ?>
                                         <option><?php echo $urunaltsecenekcek['altsecenek_ad']; ?></option>
                                       <?php } ?>
                                        </select>
                                                </td>
                                            </tr>

                                        <?php } ?>
                                            
                                        </tbody>
                                    </table>
                                    <div class="single_variation_wrap">
                                        <select class="form-control" name="urun_miktar">
                                                <?php $adetsay=0;

                                                while ($adetsay<10) {
                                                     
                                                     $adetsay++; ?>

                                                      <option value="<?php echo $adetsay; ?>"><?php echo $adetsay; ?></option>

                                                <?php } ?>
                                               
                                            </select>
                                        <div class="woocommerce-variation-add-to-cart variations_button woocommerce-variation-add-to-cart-enabled">

                                             <?php if ($uruncek['urun_stok']==0) { ?>

                                                <button class="single_add_to_cart_button button alt single_add_to_cart_ajax_button"><i class="fas fa-ban"></i> Stokta Yok</button>

                                             <?php } else { ?>


                                                <button type="submit" class="single_add_to_cart_button button alt single_add_to_cart_ajax_button sepeteeklebuton"><i class="fa fa-shopping-cart"></i> Sepete Ekle</button>


                                            <?php } ?>
                                            
                                            
                                        </div>
                                    </div>
                                </form>

                                <span class="sepeteekleuyari" style="color:#EA350E;display: none;"></span>

                                <br>

                                


                                <?php if (empty($_SESSION['kullanicioturum'])) { ?>

                                    <div class="yith-wcwl-add-to-wishlist wishlist-fragment">
                                    <div class="wishlist-button">
                                        <a style="font-size: 17px;" id="favorinosession" class="add_to_wishlist" href="favoriler"  title="Favorilere Ekle"  aria-label="Add to Wishlist">Favorilere Ekle </a>
                                    </div>
                                    
                                </div>

                                <?php } else { ?>

                                <?php if ($favorikontrolsay==0) { ?>

                                <div class="yith-wcwl-add-to-wishlist wishlist-fragment">
                                    <div class="wishlist-button">
                                        <a style="font-size: 17px;" id="favourites-button" class="add_to_wishlist" href="javascript:void(0);"  title="Favorilere Ekle"  aria-label="Add to Wishlist">Favorilere Ekle </a>
                                    </div>
                                    
                                </div>

                            <?php } else { ?>

                                <div class="yith-wcwl-add-to-wishlist wishlist-fragment">
                                    <div class="wishlist-button">
                                        <a style="font-size: 17px;" id="favoricikar" class="add_to_wishlist" href="javascript:void(0);"  title="Favorilerden Çıkar"  aria-label="Add to Wishlist">Favorilerden Çıkar </a>
                                    </div>
                                    
                                </div>


                           <?php } } ?>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--==================== Product Description Section Start ====================-->
        <div class="full-row pt-0">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="border-bottom border-top border-gray border-2">
                            <div class="woocommerce-tabs wc-tabs-wrapper ps-0 py-30 mt-0">
                                <ul class="nav nav-pills wc-tabs justify-content-center" id="pills-tab-one" role="tablist">
                                    <li class="nav-item" role="presentation">
                                        <a class="nav-link active" id="pills-description-one-tab" data-bs-toggle="pill" href="#pills-description-one" role="tab" aria-controls="pills-description-one" aria-selected="true">Ürün Açıklaması</a>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <a class="nav-link" id="pills-additional-info-one-tab" data-bs-toggle="pill" href="#pills-additional-info-one" role="tab" aria-controls="pills-additional-info-one" aria-selected="true">Özellikler</a>
                                    </li>

                                    <?php if (!empty($urun_video)) { ?>


                                        <li class="nav-item" role="presentation">
                                        <a class="nav-link" id="pills-video-one-tab" data-bs-toggle="pill" href="#pills-video-one" role="tab" aria-controls="pills-video-one" aria-selected="true">Ürün Videosu</a>
                                    </li>


                                    <?php } ?>

                                    <?php $yorumlarsec=$db->prepare("SELECT * from yorumlar where urun_id=:id and yorum_onay='1' order by yorum_zaman DESC");
                            $yorumlarsec->execute(array(

"id" => $_GET['urun_id']
                            ));

                            $yorumlarsay=$yorumlarsec->rowCount(); ?>


                                    <li class="nav-item" role="presentation">
                                        <a class="nav-link" id="pills-reviews-one-tab" data-bs-toggle="pill" href="#pills-reviews-one" role="tab" aria-controls="pills-reviews-one" aria-selected="true">Yorumlar (<?php echo $yorumlarsay; ?>)</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="woocommerce-tabs wc-tabs-wrapper ps-0 mt-0">
                            <div class="tab-content" id="pills-tabContent-one">
                                <div class="tab-pane fade show active woocommerce-Tabs-panel woocommerce-Tabs-panel--description" id="pills-description-one" role="tabpanel" aria-labelledby="pills-description-one-tab">
                                    <div class="pt-30">

                                        <?php echo $uruncek['urun_aciklama']; ?>
                                        
                                        

                                    </div>
                                </div>
                                <div class="tab-pane fade" id="pills-additional-info-one" role="tabpanel" aria-labelledby="pills-additional-info-one-tab">
                                    <div class="pt-30">
                                        <h2 style="font-weight: 200;font-family: arial;">Özellikler</h2>
                                        <table class="woocommerce-product-attributes shop_attributes">

                                            <?php $urunozelliksec=$db->prepare("SELECT * from urunozellik where urun_id=:id");
                                $urunozelliksec->execute(array(
                                  "id" => $_GET['urun_id']
                                ));

                                $urunozelliksay=$urunozelliksec->rowCount();

                               

                                    while ($urunozellikcek=$urunozelliksec->fetch(PDO::FETCH_ASSOC)) {

                                        ?>
                                                
                                                <tr class="woocommerce-product-attributes-item woocommerce-product-attributes-item--attribute_pa_size">
                                                    <th class="woocommerce-product-attributes-item__label"><?php  echo $urunozellikcek['ozellik_baslik']; ?> :</th>
                                                    <td class="woocommerce-product-attributes-item__value">
                                                        <p><?php  echo $urunozellikcek['ozellik_icerik']; ?></p>
                                                    </td>
                                                </tr>

                                            <?php } ?>

                                            </table>
                                    </div>
                                </div>

                                <?php if (!empty($urun_video)) { ?>

                                <div class="tab-pane fade" id="pills-video-one" role="tabpanel" aria-labelledby="pills-video-one-tab">
                                    <div class="pt-30">
                                        
                             <div align="center" class="col-md-12 col-xs-12 col-sm-12">
                                        <div class="col-lg-8 col-md-12 col-xs-12">

                                             <br>
                                            
                                            <iframe width="100%" height="315" src="https://www.youtube.com/embed/<?php echo $urun_video; ?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

                                        </div>
                                    </div>

                                    </div>
                                </div>

                            <?php } ?>

                                <div class="tab-pane fade" id="pills-reviews-one" role="tabpanel" aria-labelledby="pills-reviews-one-tab">
                                    

                                    <div class="row">
                                        <div class="col-8">
                                            <div id="comments">
                                                
                                                <ol class="commentlist">

                           <?php while($yorumlarcek=$yorumlarsec->fetch(PDO::FETCH_ASSOC)){

                 $yorum_zaman = $yorumlarcek['yorum_zaman'];
                 $d = new DateTime($yorum_zaman);
                 $zamanson =  $d->format('d/m/Y');
                 $kullanici_id = $yorumlarcek['kullanici_id'];

                 $kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_id=:id");
                 $kullanicisec->execute(array(

                    "id" => $kullanici_id
                 ));

                 $kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

                 $kullanici_ad = $kullanicicek['kullanici_ad']." ".substr($kullanicicek['kullanici_soyad'], 0,1).".";

                             ?>

                                                    <li>
                                                        <div class="comment_container">
                                                            <img src="assets/images/avatar.png" class="avatar" alt="Image not found!">
                                                            <div class="comment-text">
                                                                
                                                                <p class="meta">
                                                                    <strong class="woocommerce-review__author"><?php echo $kullanici_ad; ?> </strong>
                                                                    <span class="woocommerce-review__dash">–</span>
                                                                    <span class="woocommerce-review__published-date"><?php echo $zamanson; ?></span>
                                                                </p>
                                                                <div class="description">
                                                                    <span style="color:#C7071E;"><?php echo $yorumlarcek['yorum_konu']; ?></span>
                                                                    <p><?php echo $yorumlarcek['yorum_icerik']; ?></p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>

                <?php } ?>

                                                </ol>
                                            </div>
                                            <div id="review_form_wrapper">
                                                <div id="review_form">
                                                    <div id="respond" class="comment-respond">
                                                        <br>
                                                        <h5 style="font-weight: 200;font-family: arial;" id="reply-title" class="comment-reply-title my-20">Ürünü Yorumlayın<hr></h5>

                                                        <?php if (isset($_SESSION['kullanicioturum'])) { ?>

                                                             <form id="yorumyapform" onsubmit="return false;" class="comment-form">
                                                                 <input type="hidden" value="<?php echo $_GET['urun_id']; ?>" id='urun_id' name="urun_id">
                                                            <div class="row g-3">
                                                                <div class="col-12">
                                                                    <label for="comment">Konu<span class="required">*</span></label>
                                                                    <input type="text" maxlength="100" name="yorum_konu" id="yorum_konu" class="form-control">
                                                                </div>
                                                                
                                                                <div class="col-12">
                                                                    <div class="comment-form-comment">
                                                                        <label for="comment">Yorumunuz<span class="required">*</span></label>
                                                                        <textarea id="yorum_icerik" maxlength="1000" name="yorum_icerik" cols="45" rows="8"></textarea>
                                                                    </div>
                                                                </div>

                                                                <div style="display: none;" class="alert alert-warning yorumuyari"></div>

                                                                <input type="hidden" name="disableFill" value="">

                                                                


                                                                <div class="col-12">
                                                                    <div class="form-submit">
                                                                        <button name="submit" type="submit" id="submit" class="btn btn-primary yorumyapbuton">Gönder</button>
                                                                    </div>
                                                                </div>

                                                            </div>
                                                            
                                                        </form>

                                                        <?php } else { ?>

                                                            <h5 style="font-weight: 200;font-family: arial;" align="center">Yorum yapabilmek için <a href="uye-ol"><u>üye olmanız</u></a> gerekmektedir.</h5>


                                                        <?php } ?>
                                                       
                                                    </div>
                                                    <!-- #respond -->
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--==================== Product Description Section End ====================-->

        
        
        <!--==================== Related Products Section Start ====================-->
        <div class="full-row pt-0">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="section-head border-bottom d-flex justify-content-between align-items-center mb-2">
                            <div class="d-flex section-head-side-title">
                                <h4 style="font-weight: 200;font-family: arial;" class="text-dark mb-0">İlgili Ürünler</h4>
                            </div>
                        </div>
                    </div>

                    <div style="margin-top: 20px;" class="col-12">
                        <div class="products product-style-2 owl-mx-5">
                            <div class="product-carousel five-carousel owl-carousel owl-item-mb-50 owl-nav-hover-primary nav-top-right dot-disable e-bg-light e-hover-wrapper-absolute e-hover-image-zoom">


                                <?php $ilgiliurunsec=$db->prepare("SELECT * from ilgiliurunler where urun_id='$urun_id' and urun_kaldirildi='0' order by urun_sira ASC");
                    $ilgiliurunsec->execute();

                    while ($ilgiliuruncek=$ilgiliurunsec->fetch(PDO::FETCH_ASSOC)) { 

                        $ilgiliurun_id = $ilgiliuruncek['ilgiliurun_id'];

                  $urunsec = $db->prepare("SELECT * from urunler where urun_id='$ilgiliurun_id'");
                  $urunsec->execute();

                  $uruncek=$urunsec->fetch(PDO::FETCH_ASSOC);

                  $urun_id = $uruncek['urun_id'];

                  $urun_marka = $uruncek['marka_id'];



                  $urunfotosec=$db->prepare("SELECT * from urunfoto where urun_id=:id and urunfoto_kapak=:kapak");
                        $urunfotosec->execute(array(

                          "kapak" => 1,
                           "id" => $urun_id

                         ));

                        $urunfotocek=$urunfotosec->fetch(PDO::FETCH_ASSOC);

                        $urunkapakfoto = $urunfotocek['urunfoto_yol'];

                        $markasec=$db->prepare("SELECT * from markalar where marka_id='$urun_marka'");
                        $markasec->execute();
                        $markacek=$markasec->fetch(PDO::FETCH_ASSOC);
                        $marka_ad=$markacek['marka_ad'];

                        ?>
                                
                               
                                <div class="item">
                                    <div class="product type-product">
                                        <div class="product-wrapper">
                                            <div class="product-image">
                                                <a href="urun-<?php echo seo($uruncek['urun_ad'])."-".$urun_id; ?>" class="woocommerce-LoopProduct-link"><img src="<?php echo $urunkapakfoto; ?>" alt=""></a>
                                                
                                            </div>
                                            <div class="product-info">
                                                <div class="product-cats"><a><b><?php echo $marka_ad; ?></b></a></div>
                                                <h3 class="product-title"><a  style="font-weight: 200;font-family: arial;font-size: 15.5px;" href="urun-<?php echo seo($uruncek['urun_ad'])."-".$urun_id; ?>"><?php echo $uruncek['urun_ad']; ?></a></h3>
                                                <div class="product-price">
                                                    <div class="price">

                                                        <?php if ($uruncek['urun_indirim']==1) { ?>
                                                           
                                                          
                                                        <ins <?php if ($indirim_yuzdesi<40) { ?>

                                                        style='color:#F3612E;'

                                                    <?php } else { ?>

                                                        style='color:#D4102E;'


                                                    <?php } ?>><b><?php echo $uruncek['urun_fiyat']; ?> TL</b></ins>
                                                        <del><?php echo $uruncek['urun_indirimsizfiyat']; ?> TL</del>
                                                    

                                                       <?php } else { ?>

                                                        <ins><b style="color: black;"><?php echo $uruncek['urun_indirimsizfiyat']; ?> TL</b></ins>


                                                       <?php } ?>

                                                        
                                                    </div>

                                                    <?php if ($uruncek['urun_indirim']==1) {

                                                $indirim_miktari = $uruncek['urun_indirimsizfiyat']-$uruncek['urun_fiyat'];
                                                $indirim_yuzdesi = round(($indirim_miktari*100)/$uruncek['urun_indirimsizfiyat']);

                                                    ?>


                                                    <div <?php if ($indirim_yuzdesi<40) { ?>

                                                        style='background-color:#F3612E;color: white;'

                                                    <?php } else { ?>

                                                        style='background-color:#D4102E;color: white;'


                                                    <?php } ?> class="on-sale">- <?php echo $indirim_yuzdesi; ?>%</div>

                                                    <?php } ?>
                                                </div>
                                                
                                               
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                

                         <?php } ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

      <?php } ?>

      <input id="sepeturunsayhidden" value="<?php echo $sepeturunsayheader; ?>" type="hidden" name="">

       <?php require_once 'footer.php'; ?>

       <script type="text/javascript">
           
           $('#favourites-button').click(function(){

            var urun_id = $('#urun_id').val();

           
              

                    $('#favourites-button').prop('disabled',true);

$.ajax({
            type : 'POST',
            url : 'musteriislem.php',
            data : {'favorilereekle':'ok','urun_id':urun_id},
            success : function(sonuc){

              sonuc = $.trim(sonuc);
              $('#favourites-button').html('Ekleniyor...');



          

         if (sonuc=="ok") {

          

          $('.wishlist-button').replaceWith('<span style="color:green;font-size:17px;"><i class="far fa-heart"></i> Favorilere Eklendi</span>');



         



         }

                

                  
     
              
              }
        })


                




        });

           $('#favoricikar').click(function(){

                


var urun_id = $('#urun_id').val();
              

                    $('#favoricikar').prop('disabled',true);

$.ajax({
            type : 'POST',
            url : 'musteriislem.php',
            data : {'favorilerdencikar':'ok','urun_id':urun_id},
            success : function(sonuc){

              sonuc = $.trim(sonuc);
              $('#favoricikar').html('Çıkarılıyor...');


          

         if (sonuc=="ok") {

          

          $('.wishlist-button').replaceWith('<span style="color:green;font-size:17px;"><i class="fas fa-ban"></i> Favorilerden Çıkarıldı</span>');



         }

                

                  

               

                

                



                


            
              
              }
        })


                



        });

          

           $('#yorumyapform').submit(function(){

            var yorumsayisi = $('.commentlist li').length;
            var yorumsayisiyeni = yorumsayisi+1;
            

           $('.yorumyapbuton').prop('disabled',true);

 var yorum_icerik = $.trim($('#yorum_icerik').val());
 var yorum_konu = $.trim($('#yorum_konu').val());

 if (yorum_konu.length<3) {

    $('.yorumyapbuton').prop('disabled',false);

$('.yorumuyari').show();
$('.yorumuyari').html('<i class="fa fa-info-circle"></i> Lütfen yorum konusu girin.');

 } else if (yorum_icerik.length<3) {

    $('.yorumyapbuton').prop('disabled',false);

$('.yorumuyari').show();
$('.yorumuyari').html('<i class="fa fa-info-circle"></i> Lütfen yorum kısmını doldurun.');

 } else {

$('.yorumuyari').hide();
var data = $("#yorumyapform").serializeArray();
data.push({name: "yorumyap",value: "ok"});

$.ajax({
            type : 'POST',
            url : 'musteriislem.php',
            data : $.param(data),
            success : function(sonuc){

              sonuc = $.trim(sonuc);





       

         if (sonuc!='bot') {
 

    $('#yorumyapform').html('<h4 style="font-family:Arial;" align="center"><i style="color:green;" class="fa fa-check"></i> Yorumunuz için teşekkür ederiz. Onay aşamasından sonra yayınlanacaktır.</h4>');


    } 

 



            
              }
        })

 }

        });



            $('.sepeteeklebuton').click(function(){

             var bossecenekler =  $('option[value="secilmedi"]:selected').length;

             

              

                if (bossecenekler>0) {

        $('.sepeteekleuyari').show();
        $('.sepeteekleuyari').html('<i class="fas fa-info"></i> Sepete eklemeden önce ürün seçeneklerini seçmeniz gerekiyor.');

                } else {

                    $('.sepeteeklebuton').prop('disabled',true);
                    var data = $(".sepeteekleform").serializeArray();
                   data.push({name: "sepeteurunekle",value: "ok"});

$.ajax({
            type : 'POST',
            url : 'musteriislem.php',
            data : $.param(data),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

             
        
         
          
           if (sonuc!='bot') {
          

            if (sonuc=="gecersizistek"){


                location.reload();


                } else if (sonuc=="stokyok") {

         $('.sepeteekleuyari').show();
        $('.sepeteekleuyari').html('<i class="fas fa-info"></i> Eklemek istediğiniz ürün adeti kadar stok mevcut değil.');

         $('.sepeteeklebuton').prop('disabled',false);

                } else {

                    

                  $('.sepeteekleuyari').hide();
                  $('.sepeteeklebuton').prop('disabled',true);
                  $('.sepeteeklebuton').html('<i class="fas fa-check"></i> Sepete Eklendi');
                  $('.sepeteeklebuton').css('background-color','green');

                    

  

                $('.cart-popup').html(sonuc);               
                var sepeturunsayheader = $('#sepeturunsayhidden').val();
                $('.sepetitemsayisi').html(parseInt(sepeturunsayheader)+1);

               

                

                }



                
              }

            
              
              }
        })



                }


        });

       </script>

