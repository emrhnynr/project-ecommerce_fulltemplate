
<?php require_once 'header.php'; ?>

<head>

<meta name="description" content="<?php echo $seoayarcek['anasayfa_description']; ?>">

</head>

<title><?php echo $seoayarcek['anasayfa_title']; ?></title>

        <!--==================== Slider Section End ====================-->
        <div class="full-row p-0 bg-light">

        	
      
      <?php if (!empty($genelayarcek['ayar_girisfoto'])) { 

                    if(empty($genelayarcek['ayar_girisfotolink'])){ ?>

               <img width="100%" style="margin-bottom: 15px;" class="img-responsive" src="<?php echo $genelayarcek['ayar_girisfoto']; ?>">

                   <?php } else { ?>

                    <a href="<?php echo $genelayarcek['ayar_girisfotolink']; ?>">
                         <img style="margin-bottom: 15px;" width="100%" class="img-responsive" src="<?php echo $genelayarcek['ayar_girisfoto']; ?>">
                    </a>
                       
                  <?php } } ?>

            <div style="width: 100%;" id="slider">


            	<?php $slaytsec=$db->prepare("SELECT * from slaytlar order by slayt_sira ASC");
         $slaytsec->execute();
         while ($slaytcek=$slaytsec->fetch(PDO::FETCH_ASSOC)) { 
          $slayt_foto = $slaytcek['slayt_foto'];
          $slayt_baslik = $slaytcek['slayt_baslik'];
          $slayt_aciklama = $slaytcek['slayt_aciklama'];
          $slayt_link = $slaytcek['slayt_link'];

          if (empty($slayt_link)) { ?>
                

                <!-- Slide 2-->
                <div class="ls-slide" data-ls="duration:8000; transition2d:4; ">
                    <img src="<?php echo $slayt_foto; ?>" class="ls-bg img-responsive" alt="" style="width:100%;" data-ls="  ">

                    
                </div>

           <?php } else { ?>


           	 <!-- Slide 2-->
                <div class="ls-slide" data-ls="duration:8000; transition2d:4; ">
                    <img src="<?php echo $slayt_foto; ?>" class="ls-bg img-responsive" alt="" style="width:100%;" data-ls="  ">

                    
                </div>


          <?php } } ?>

            </div>
         
        </div>
        <!--==================== Slider Section End ====================-->

        <!--==================== Shop By Categories Section Start ====================-->
        <div class="full-row pb-0">
          


            <div class="container">

            <?php $anasayfaurunlistesec = $db->prepare("SELECT * from anasayfaurunliste order by liste_sira ASC");

            $anasayfaurunlistesec->execute();


            while ($anasayfaurunlistecek=$anasayfaurunlistesec->fetch(PDO::FETCH_ASSOC)) { 

                $liste_baslik=$anasayfaurunlistecek['liste_baslik'];
                $liste_turu = $anasayfaurunlistecek['liste_turu'];
                $anasayfaurunliste_id=$anasayfaurunlistecek['anasayfaurunliste_id']; ?>

                <div class="row justify-content-center wow fadeInUp animated" data-wow-delay="200ms" data-wow-duration="1000ms">
                    <div class="col-xxl-4 col-xl-6 col-lg-7 col-md-8">
                        <div class="text-center mb-5">
                            <h3 style="font-family: Arial;" class="text-center font-400 mb-4"><?php echo $liste_baslik; ?></h3>
                            
                        </div>
                    </div>
                </div>

                <?php if ($liste_turu=='slayt') { ?>
                     
                     
                <div class="row">
                    <div class="col-12">
                        <div class="products product-style-1 owl-mx-15">
                            <div class="four-carousel owl-carousel dot-disable nav-arrow-middle-show e-title-hover-primary e-hover-image-zoom e-info-center">

                                <?php $anasayfalisteurunsec=$db->prepare("SELECT * from anasayfalisteurun where urun_kaldirildi=:kaldirildi and anasayfaurunliste_id=:id order by urun_sira ASC");
                  $anasayfalisteurunsec->execute(array(

                    
                    "kaldirildi" => 0,
                    "id" => $anasayfaurunliste_id
                  ));

                  while ($anasayfalisteuruncek=$anasayfalisteurunsec->fetch(PDO::FETCH_ASSOC)) {

                 
                  $urun_id = $anasayfalisteuruncek['urun_id'];

                  $urunsec = $db->prepare("SELECT * from urunler where urun_id='$urun_id'");
                  $urunsec->execute();

                  $uruncek=$urunsec->fetch(PDO::FETCH_ASSOC);

                  $urun_id = $uruncek['urun_id'];

                  $urunseceneklersec=$db->prepare("SELECT * from urunsecenekler where urun_id=:id");
                                           $urunseceneklersec->execute(array(
                                            "id" => $urun_id
                                          ));

                                           $urunseceneklersay=$urunseceneklersec->rowCount();



                  $urunfotosec=$db->prepare("SELECT * from urunfoto where urun_id=:id and urunfoto_kapak=:kapak");
                        $urunfotosec->execute(array(

                          "kapak" => 1,
                           "id" => $urun_id

                         ));

                        $urunfotocek=$urunfotosec->fetch(PDO::FETCH_ASSOC);

                        $urunkapakfoto = $urunfotocek['urunfoto_yol'];

                       
                         ?>


                            <div class="item">
                                <div  class="product type-product">
                                    <div  class="product-wrapper">
                                        <div class="product-image">
                                            <a href="urun-<?php echo seo($uruncek['urun_ad'])."-".$urun_id; ?>" class="woocommerce-LoopProduct-link"><img src="<?php echo $urunkapakfoto; ?>" alt="Product Image"></a>
                                            <?php if ($uruncek['urun_indirim']==1) {

                                                $indirim_miktari = $uruncek['urun_indirimsizfiyat']-$uruncek['urun_fiyat'];
                                                $indirim_yuzdesi = round(($indirim_miktari*100)/$uruncek['urun_indirimsizfiyat']);

                                                    ?>
                                                    
                                                    <div style="background: #D4102E;" class="product-labels">
                                                    <div <?php if ($indirim_yuzdesi<40) { ?>

                                                        style='background-color:#F3612E;'

                                                    <?php } else { ?>

                                                        style='background-color:#D4102E;'


                                                    <?php } ?> class="badge1"><span> - %<?php echo $indirim_yuzdesi; ?></span></div>
                                                </div>

                                                <?php } ?>
                                            <div class="hover-area">

                                               

                                                        <?php if ($urunseceneklersay==0 and $uruncek['urun_stok']>0) { ?>

                                                <div class="cart-button">
                                                    <a href="javascript:void(0);" class="button add_to_cart_button sepeteeklebuton"  data-bs-placement="right" title="Hemen Al" name="urun_<?php echo $urun_id;?>"></a>
                                                </div>

                                                    <?php } ?>

                                                <div class="wishlist-button wishlist_<?php echo $urun_id; ?>">

                                                    <?php if (isset($_SESSION['kullanicioturum'])) { 

                                                             $favorikontrolsec=$db->prepare("SELECT * from favoriler where kullanici_id=:kulid and urun_id=:urunid");
                                                    $favorikontrolsec->execute(array(
                                                        "kulid" => $_SESSION['kullanici_id'],
                                                       "urunid" => $urun_id
                                                           ));

                                                    $favorikontrolsay=$favorikontrolsec->rowCount(); ?>

                                                    <?php if ($favorikontrolsay>0) { ?>

                                                        <a style="background-color: green;color:white;border-color:green;" class="favoricikarbuton favoridencikar" title="Favorilerden Çıkar" name="urun_<?php echo $urun_id; ?>" href="javascript:void(0);">Favoriler</a>
                                                        

                                                    <?php } else { ?>

                                                        <a class="add_to_wishlist favorieklebuton" title="Favorilere Ekle" name="urun_<?php echo $urun_id; ?>" href="javascript:void(0);">Favoriler</a>

                                                        


                                                    <?php } ?>

                                                            

                                                       <?php } else { ?>

                                                        <a class="add_to_wishlist" target="_blank" href="giris-yap" title="Favorilere Ekle">Favoriler</a>

                                                        


                                                       <?php } ?>
                                                    
                                                </div>
                                               
                                            </div>
                                        </div>
                                        <div class="product-info">
                                            <div><a style="font-weight: 600;"><?php echo $uruncek['marka_ad']; ?></a></div>
                                            <h3 class="product-title"><a href="urun-<?php echo seo($uruncek['urun_ad'])."-".$urun_id; ?>"><h3 class="product-title"><a href="urun-<?php echo seo($uruncek['urun_ad'])."-".$urun_id; ?>"><?php echo $uruncek['urun_ad']; ?></a></h3></a></h3>
                                            <div class="product-price">
                                                <div class="price">
                                                    
                                                       
                                                       <?php if ($uruncek['urun_indirim']==1) { ?>
                                                           
                                                           <div class="price">
                                                        <ins <?php if ($indirim_yuzdesi<40) { ?>

                                                        style='color:#F3612E;'

                                                    <?php } else { ?>

                                                        style='color:#D4102E;'


                                                    <?php } ?>><b><?php echo $uruncek['urun_fiyat']; ?> TL</b></ins>
                                                        <del><?php echo $uruncek['urun_indirimsizfiyat']; ?> TL</del>
                                                    </div>

                                                       <?php } else { ?>

                                                        <div class="price">
                                                        <ins style="color:#707070;"><b><?php echo $uruncek['urun_indirimsizfiyat']; ?> TL</b></ins>
                                                    </div>


                                                       <?php } ?>

                                                        
                                                    
                                                </div>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php } ?>
                        </div>
                        </div>
                    </div>
                </div>

                 <?php } else if ($liste_turu=='liste'){ ?>


           <div class="row">
                    
                    <div class="col-xl-12 col-lg-12">
                        <div class="products product-style-1">
                            <div class="row gy-4 row-cols-xl-4 row-cols-lg-4 row-cols-md-3 row-cols-sm-12 
                            row-cols-2 e-title-hover-primary e-hover-image-zoom e-info-center">

                            <?php $anasayfalisteurunsec=$db->prepare("SELECT * from anasayfalisteurun where urun_kaldirildi=:kaldirildi and anasayfaurunliste_id=:id order by urun_sira ASC");
                  $anasayfalisteurunsec->execute(array(

                    
                    "kaldirildi" => 0,
                    "id" => $anasayfaurunliste_id
                  ));

                  while ($anasayfalisteuruncek=$anasayfalisteurunsec->fetch(PDO::FETCH_ASSOC)) {

                 
                  $urun_id = $anasayfalisteuruncek['urun_id'];

                  $urunsec = $db->prepare("SELECT * from urunler where urun_id='$urun_id'");
                  $urunsec->execute();

                  $uruncek=$urunsec->fetch(PDO::FETCH_ASSOC);

                  $urun_id = $uruncek['urun_id'];

                  $urunseceneklersec=$db->prepare("SELECT * from urunsecenekler where urun_id=:id");
                                           $urunseceneklersec->execute(array(
                                            "id" => $urun_id
                                          ));

                                           $urunseceneklersay=$urunseceneklersec->rowCount();



                  $urunfotosec=$db->prepare("SELECT * from urunfoto where urun_id=:id and urunfoto_kapak=:kapak");
                        $urunfotosec->execute(array(

                          "kapak" => 1,
                           "id" => $urun_id

                         ));

                        $urunfotocek=$urunfotosec->fetch(PDO::FETCH_ASSOC);

                        $urunkapakfoto = $urunfotocek['urunfoto_yol'];

                       
                         ?>


                                 <div class="col">
                                <div class="product type-product">
                                    <div class="product-wrapper">
                                        <div class="product-image">
                                            <a href="urun-<?php echo seo($uruncek['urun_ad'])."-".$urun_id; ?>" class="woocommerce-LoopProduct-link"><img src="<?php echo $urunkapakfoto; ?>" alt="Product Image"></a>
                                            
                                            <?php if ($uruncek['urun_indirim']==1) {

                                                $indirim_miktari = $uruncek['urun_indirimsizfiyat']-$uruncek['urun_fiyat'];
                                                $indirim_yuzdesi = round(($indirim_miktari*100)/$uruncek['urun_indirimsizfiyat']);

                                                    ?>
                                                    
                                                    <div class="product-labels">
                                                    <div <?php if ($indirim_yuzdesi<40) { ?>

                                                        style='background-color:#F3612E;'

                                                    <?php } else { ?>

                                                        style='background-color:#D4102E;'


                                                    <?php } ?> class="badge1"><span> - %<?php echo $indirim_yuzdesi; ?></span></div>
                                                </div>

                                                <?php } ?>
                                            <div class="hover-area">

                                               

                                                        <?php if ($urunseceneklersay==0 and $uruncek['urun_stok']>0) { ?>

                                                <div class="cart-button">
                                                    <a href="javascript:void(0);" class="button add_to_cart_button sepeteeklebuton"  data-bs-placement="right" title="Hemen Al" name="urun_<?php echo $urun_id;?>"></a>
                                                </div>

                                                    <?php } ?>

                                                <div class="wishlist-button wishlist_<?php echo $urun_id; ?>">

                                                    <?php if (isset($_SESSION['kullanicioturum'])) { 

                                                             $favorikontrolsec=$db->prepare("SELECT * from favoriler where kullanici_id=:kulid and urun_id=:urunid");
                                                    $favorikontrolsec->execute(array(
                                                        "kulid" => $_SESSION['kullanici_id'],
                                                       "urunid" => $urun_id
                                                           ));

                                                    $favorikontrolsay=$favorikontrolsec->rowCount(); ?>

                                                    <?php if ($favorikontrolsay>0) { ?>

                                                        <a style="background-color: green;color:white;border-color:green;" class="favoricikarbuton favoridencikar" title="Favorilerden Çıkar" name="urun_<?php echo $urun_id; ?>" href="javascript:void(0);">Favoriler</a>
                                                        

                                                    <?php } else { ?>

                                                        <a class="add_to_wishlist favorieklebuton" title="Favorilere Ekle" name="urun_<?php echo $urun_id; ?>" href="javascript:void(0);">Favoriler</a>

                                                        


                                                    <?php } ?>

                                                            

                                                       <?php } else { ?>

                                                        <a class="add_to_wishlist" target="_blank" href="giris-yap" title="Favorilere Ekle">Favoriler</a>

                                                        


                                                       <?php } ?>
                                                    
                                                </div>
                                               
                                            </div>
                                        </div>
                                        <div class="product-info">
                                            <div><a style="font-weight: 600;"><?php echo $uruncek['marka_ad']; ?></a></div>
                                            <h3 class="product-title"><a href="urun-<?php echo seo($uruncek['urun_ad'])."-".$urun_id; ?>"><h3 class="product-title"><a href="urun-<?php echo seo($uruncek['urun_ad'])."-".$urun_id; ?>"><?php echo $uruncek['urun_ad']; ?></a></h3></a></h3>
                                            <div class="product-price">
                                                <div class="price">
                                                    
                                                       
                                                       <?php if ($uruncek['urun_indirim']==1) { ?>
                                                           
                                                           <div class="price">
                                                        <ins <?php if ($indirim_yuzdesi<40) { ?>

                                                        style='color:#F3612E;'

                                                    <?php } else { ?>

                                                        style='color:#D4102E;'


                                                    <?php } ?>><b><?php echo $uruncek['urun_fiyat']; ?> TL</b></ins>
                                                        <del><?php echo $uruncek['urun_indirimsizfiyat']; ?> TL</del>
                                                    </div>

                                                       <?php } else { ?>

                                                        <div class="price">
                                                        <ins style="color:#707070;"><b><?php echo $uruncek['urun_indirimsizfiyat']; ?> TL</b></ins>
                                                    </div>


                                                       <?php } ?>

                                                        
                                                    
                                                </div>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>


                             <?php } ?>
                            
                            
                        </div>
                        </div>
                    </div>
                </div>


                <?php } ?>

            
                
            

            <br><br>

        <?php } ?>

    </div>



        
        
        </div>
        <!--==================== Shop By Categories Section End ====================-->

       

       
        

       

        <div class="full-row pb-0">
            <div class="container-fluid">
                <div class="row g-0">
                    <div class="col-md-12">
                        <div class="owl-carousel dot-disable nav-disable six-carousel">

                        	<?php $anasayfamarkasec=$db->prepare("SELECT * from anasayfamarkalar order by marka_ad ASC");
                            $anasayfamarkasec->execute();

                            while ($anasayfamarkacek=$anasayfamarkasec->fetch(PDO::FETCH_ASSOC)) { 

                                $marka_ad = $anasayfamarkacek['marka_ad'];
                                $marka_id = $anasayfamarkacek['marka_id'];
                                $markasec = $db->prepare("SELECT * from markalar where marka_id='$marka_id'");
                                $markasec->execute();
                                $markacek=$markasec->fetch(PDO::FETCH_ASSOC);
                                $marka_logo=$markacek['marka_logo']; ?>
                            
                            <div style="border:1px solid rgba(112,112,112,0.3);padding: 10px;" class="item">
                                <div class="hover-img-zoom overflow-hidden transation">
                                    <a href="<?php echo $marka_logo; ?>" data-fancybox="gallery" data-caption="<?php echo $marka_ad; ?>">
                                        <img class="transation" src="<?php echo $marka_logo; ?>" alt="Image not found!">
                                    </a>
                                </div>
                            </div>

                        <?php } ?>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <br>

        

        <?php require_once 'footer.php'; ?>

        <script type="text/javascript">
           
           $('.sepeteeklebuton').click(function(){

            
var id1=$(this).attr("name");
         var urun_id=id1.substring(5);
             

              

               

                    $('.sepeteeklebuton').prop('disabled',true);

$.ajax({
            type : 'POST',
            url : 'musteriislem.php',
            data : {'hemensepeteekle':'ok','urun_id':urun_id},
            success : function(sonuc){

              sonuc = $.trim(sonuc);


        

     
            window.location = 'sepetim';
                


            
              
              }
        })



                


        });

           $('.favorieklebuton').click(function(){

                

var buton = $(this);


var id1=$(this).attr("name");
var urun_id=id1.substring(5);


              

                    buton.prop('disabled',true);

$.ajax({
            type : 'POST',
            url : 'musteriislem.php',
            data : {'favorilereekle':'ok','urun_id':urun_id},
            success : function(sonuc){

              sonuc = $.trim(sonuc);

           
              


          

         if (sonuc=="ok") {

          

          $('.wishlist_'+urun_id).replaceWith('<i style="color:green;font-size:17px;margin-left:10px;margin-top:7px;" class="fas fa-check"></i>');



        



         }

                

                  

               

                

                



                


            
              
              }
        })


                



        });

           $('.favoricikarbuton').click(function(){

                

var buton = $(this);


var id1=$(this).attr("name");
var urun_id=id1.substring(5);


              

                    buton.prop('disabled',true);

$.ajax({
            type : 'POST',
            url : 'musteriislem.php',
            data : {'favorilerdencikar':'ok','urun_id':urun_id},
            success : function(sonuc){

              sonuc = $.trim(sonuc);

           
              


          

         if (sonuc=="ok") {

          

          $('.wishlist_'+urun_id).replaceWith('<i style="color:green;font-size:17px;margin-left:10px;margin-top:7px;" class="fas fa-ban"></i>');



        



         }

                

                  

               

                

                



                


            
              
              }
        })


                



        });

       </script>

        