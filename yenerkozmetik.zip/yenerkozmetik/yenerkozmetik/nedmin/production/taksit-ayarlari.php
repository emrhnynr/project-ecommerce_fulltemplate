<?php require_once 'header.php';

$genelayarsec=$db->prepare("SELECT * from genelayarlar");
$genelayarsec->execute();

 $genelayarcek=$genelayarsec->fetch(PDO::FETCH_ASSOC);
  ?>


  <style type="text/css">
   /* Customize the label (the container) */
.checklabell {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 12px;
  cursor: pointer;
  font-size: 22px;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

/* Hide the browser's default checkbox */
.checklabell input {
  position: absolute;
  opacity: 0;
  cursor: pointer;
  height: 0;
  width: 0;
}

/* Create a custom checkbox */
.checkmark {
  position: absolute;
  top: 0;
  left: 0;
  height: 25px;
  width: 25px;
  background-color: #eee;
}

/* On mouse-over, add a grey background color */
.checklabell:hover input ~ .checkmark {
  background-color: #ccc;
}

/* When the checkbox is checked, add a blue background */
.checklabell input:checked ~ .checkmark {
  background-color: #43DE09;
}

/* Create the checkmark/indicator (hidden when not checked) */
.checkmark:after {
  content: "";
  position: absolute;
  display: none;
}

/* Show the checkmark when checked */
.checklabell input:checked ~ .checkmark:after {
  display: block;
}

/* Style the checkmark/indicator */
.checklabell .checkmark:after {
  left: 9px;
  top: 5px;
  width: 5px;
  height: 10px;
  border: solid white;
  border-width: 0 3px 3px 0;
  -webkit-transform: rotate(45deg);
  -ms-transform: rotate(45deg);
  transform: rotate(45deg);
}
}



</style>



        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              

              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Taksit Ayarları</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      
                    </ul>

                    
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <h3 align="center">Vade Farkı Oranları</h3>
                      <hr>

                    <form id="vadefarkiduzenleform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

                      
                    <?php $taksitseceneksec=$db->prepare("SELECT * from taksitsecenekleri where secenek_ad!='1' order by secenek_ad ASC");
                    $taksitseceneksec->execute();

                    while ($taksitsecenekcek=$taksitseceneksec->fetch(PDO::FETCH_ASSOC)) { 

                      $secenek_ad=$taksitsecenekcek['secenek_ad'];
                      $secenek_id=$taksitsecenekcek['secenek_id'];
                      $secenek_vadefarki=$taksitsecenekcek['secenek_vadefarki']; ?>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name"><?php echo $secenek_ad." Taksit"; ?>
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input placeholder="Vade farkı oranı girin (%)"  type="number" name="secenek_id_<?php echo $secenek_id; ?>" step="any" value="<?php echo $taksitsecenekcek['secenek_vadefarki']; ?>"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>
                       


                    <?php  } ?>

                     
                     

                      

                     

                      

                     

                

                      <input type="hidden" name="vadefarkiduzenle">


                      
                      
                      <div class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">

                          <div style="display: none;" class="alert alert-warning uyari"></div>
                          
                          <button type="submit" class="btn btn-success vadefarkiduzenlebuton">Düzenle</button>
                        </div>
                      </div>

                    </form>

                    <br /><br>
                    

                    <h3 align="center">Taksit Aralıkları <a class="btn btn-success" data-toggle='modal' href="#taksitaralikekle">Ekle +</a>
                      <hr>

                    </h3>

                    <h4 align="center">Bu alanda sepet tutar aralıklarında taksit seçeneği açmanız gerekiyor. Tek Çekim otomatik olarak açılır.<br><br> (Sabit taksit seçenekleri açmak için tek bir alanda 0 alt değer, 999999 üst değer olarak girip taksit seçenek/seçenekleri belirtebilirsiniz.)</h4><hr>

                    <?php $taksitsec=$db->prepare("SELECT * from taksitler order by taksit_altdeger ASC");
                      $taksitsec->execute();
                      $taksitsay = $taksitsec->rowCount();

                      if ($taksitsay==0) { ?>
                         
                         <h4 align="center">Taksit aralığı belirlenmemiş.</h4>

                      <?php } else { ?>

                         <form style="margin-top:40px;" id="taksitaralikduzenleform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">


                      <?php 

                      $say=0;

                      while ($taksitcek=$taksitsec->fetch(PDO::FETCH_ASSOC)) {

                      $say++;
                      $taksit_id = $taksitcek['taksit_id']; ?>
                         
                         <div style="border:1px solid rgba(112,112,112,0.6);padding: 20px;margin-top:15px;" class="taksitid_<?php echo $taksit_id; ?> taksitaralikk">

                      
                   
                       <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Sepet Alt Değer
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input placeholder="Örn. 0-100 TL arası sepet için taksit seçenekleri belirleyecekseniz 0'ı buraya yazın."  type="number" min="0" id="taksit_altdeger" name="taksit_altdeger_<?php echo $taksit_id; ?>" step="any" value="<?php echo $taksitcek['taksit_altdeger']; ?>"  class="form-control col-md-10 col-xs-12 inputs">
                        </div>
                      </div>


                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Sepet Üst Değer
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input placeholder="Örn. 0-100 TL arası sepet için taksit seçenekleri belirleyecekseniz 100'ü buraya yazın."  type="number" min="0" id="taksit_ustdeger" name="taksit_ustdeger_<?php echo $taksit_id; ?>" step="any" value="<?php echo $taksitcek['taksit_ustdeger']; ?>"  class="form-control col-md-10 col-xs-12 inputs">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">
                        </label>
                        <div align="center" class="col-md-7 col-sm-7 col-xs-12">

                          <h3 align="center">Taksit Seçenekleri<hr></h3>

                          <?php $taksitseceneksec=$db->prepare("SELECT * from taksitsecenekleri where secenek_ad!='1' order by secenek_ad ASC");
                          $taksitseceneksec->execute();

                          while ($taksitsecenekcek=$taksitseceneksec->fetch(PDO::FETCH_ASSOC)) { 

                            $secenek_id = $taksitsecenekcek['secenek_id'];
                            $secenek_ad = $taksitsecenekcek['secenek_ad'];


                            $sor=$db->prepare("SELECT * from taksitaraliksecenekleri where secenek_id='$secenek_id' and taksit_id='$taksit_id'");
                            $sor->execute();

                            $varmi = $sor->rowCount(); ?>

                            <div align="left" class="col-lg-4 col-md-4 col-sm-4 col-xs-6" > 

     <label class="checklabell"><?php echo $secenek_ad; ?>
  <input <?php if ($varmi==1) { ?>
    checked=''
  <?php } ?> name="secenek_id_<?php echo $taksit_id; ?>[]" value="<?php  echo $secenek_id; ?>"  type="checkbox">
  <span class="checkmark"></span>
</label>

<br>




</div>
                             


                           <?php } ?>

                        </div>
                      </div>
                     
                     

                      

                      <div class="form-group"><label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name"></label><div align="center" class="col-md-7 col-sm-7 col-xs-12"><a class="btn btn-danger taksitkaldir" name="taksitid_<?php echo $taksit_id; ?>" href="javascript:void(0);"><i class="fa fa-trash-o"></i> Kaldır</a></div></div>

                    </div>

                    <br>
                    

                       <?php } ?>

                       



                        




                      

                     

                      

                     

                

                      <input type="hidden" name="taksitaralikduzenleadmin">


                      
                      
                      <div  class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">

                          <div style="display: none;" class="alert alert-warning uyariucret"></div>
                          
                          <button type="submit" class="btn btn-success taksitaralikduzenlebuton">Düzenle</button>
                        </div>
                      </div>

                    </form>


                      <?php } ?>

                   


                    <div class="modal fade" id="taksitaralikekle"> 
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

      

        <div style="padding: 50px;" class="modal-body">

          <h3>Taksit Aralığı Ekle<hr></h3>

          <form action="../../adminislem.php" method="POST" id="taksitaralikekleform" enctype="multipart/form-data">
         <div class="row">



          
           
           <div style="margin-top:20px;" class="col-md-12 col-xs-12 col-sm-12">
            <label>Sepet Alt Değeri*</label>
             <input class="form-control" required="" placeholder="Örn. 0-100 TL arası sepet için taksit seçenekleri belirleyecekseniz 0'ı buraya yazın." type="number" min="0" step="any" name="taksit_altdeger">
           </div>



           <div style="margin-top:20px;margin-bottom: 30px;" class="col-md-12 col-xs-12 col-sm-12">
            <label>Sepet Üst Değeri*</label>
             <input class="form-control" required="" placeholder="Örn. 0-100 TL arası sepet için taksit seçenekleri belirleyecekseniz 100'ü buraya yazın." type="number" step="any" min="0" name="taksit_ustdeger">
           </div>



           <h3 align="center">Taksit Seçenekleri<hr></h3>

           <?php $taksitseceneksec=$db->prepare("SELECT * from taksitsecenekleri where secenek_ad!='1' order by secenek_ad ASC");
           $taksitseceneksec->execute();

           while ($taksitsecenekcek=$taksitseceneksec->fetch(PDO::FETCH_ASSOC)) { 

            $secenek_id = $taksitsecenekcek['secenek_id'];
            $secenek_ad = $taksitsecenekcek['secenek_ad']; ?>
             
             <div align="center" class="col-lg-3 col-md-3 col-sm-4 col-xs-6" > 

     <label style="text-align: left;" class="checklabell"><?php  echo $secenek_ad; ?>
  <input name="secenek_id[]" value="<?php  echo $secenek_id; ?>"  type="checkbox">
  <span class="checkmark"></span>
</label>

<br>




</div>

            <?php } ?>

          

          


          

          

         


        
           

         </div>

        </div>

     
       
    <div class="modal-footer">


  
    
    <button class="btn btn-success" name="taksitaralikekle" type="submit">Ekle</button>

     </form>
    <button class="btn btn-danger" data-dismiss="modal">Kapat</button>

    
</div>





  

     
    </div>

  </div>

</div>

                    

                   
                  </div>
                </div>
              </div>
            </div>

            <?php require_once 'footer.php'; ?>
            <script type="text/javascript">

              $('.taksitkaldir').click(function(){

           var buton = $(this);
            var id1=$(this).attr("name");
                var taksit_id=id1.substring(9);



               swal({
  title: "Emin misiniz?",
  text: "Bu taksit aralığı kaldırılsın mı?",
  icon: "warning",
  buttons: ["Vazgeç", "Sil"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

    buton.html('Siliniyor...');

    $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'taksitaraliksil':'ok','taksit_id':taksit_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              if (sonuc=="ok") {

                $('.taksitid_'+taksit_id).remove();
                swal({

  title: "Başarılı",
  text: "Taksit Aralığı Kaldırıldı!",
  icon: "success",
  button: "OK",
});


                var taksitaraliksay = $('.taksitaralikk').length;

                if (taksitaraliksay==0) {

          $('.taksitaralikduzenlebuton').remove();

                }
              }



               }

             });


     }

     })
         })

            $('#vadefarkiduzenleform').submit(function(){

             
             
              $('.vadefarkiduzenlebuton').prop('disabled',true);

              

                $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : $('#vadefarkiduzenleform').serialize(),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

             

              if (sonuc=="ok") {

                
                $('.vadefarkiduzenlebuton').prop('disabled',false);


                swal({

  title: "Başarılı",
  text: "Vade farkları düzenlendi!",
  icon: "success",
  button: "OK",
});



              }            

              }


            })

              

                 });


            $('#taksitaralikduzenleform').submit(function(){



             
              var bosinputsayisi = $('.inputs').filter(function(){
    return !$.trim($(this).val());
}).length;



              $('.taksitaralikduzenlebuton').prop('disabled',true);
                
                if (bosinputsayisi>0) {

           $('.uyariucret').show();
           $('.uyariucret').html('<i class="fa fa-info-circle"></i> Taksit alt ve üst değerlerinin tamamını doldurmalısınız.');
           $('.taksitaralikduzenlebuton').prop('disabled',false);

                } else {


             


              

              $('.uyariucret').hide();

                $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : $('#taksitaralikduzenleform').serialize(),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

              

             

               if (sonuc=="ok") {

                
                $('.taksitaralikduzenlebuton').prop('disabled',false);


                swal({

  title: "Başarılı",
  text: "Taksit aralıkları güncellendi!",
  icon: "success",
  button: "OK",
});



              }            

              }


            })

                 }

              

                 });


             

            </script>

              
             