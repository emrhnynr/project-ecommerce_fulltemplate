<?php require_once 'header.php';

$seoayarsec=$db->prepare("SELECT * from seoayarlar");
$seoayarsec->execute();

 $seoayarcek=$seoayarsec->fetch(PDO::FETCH_ASSOC);

 $anasayfa_description = $seoayarcek['anasayfa_description'];
 $hakkimizda_description = $seoayarcek['hakkimizda_description'];
  $iletisim_description = $seoayarcek['iletisim_description'];
   $blog_description = $seoayarcek['blog_description'];
   $ekip_description = $seoayarcek['ekip_description'];
   $sss_description = $seoayarcek['sss_description'];



  ?>



        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              

              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                 
                  <div class="x_content">
                    <br />

                  

                    <form id="descriptionform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

                      <h3 align="center">SEO Sayfa Açıklamaları</h3>
                      <h5 align="center">Sayfalarınızın Google sonuçlarında başlığın altındaki açıklama yazıları.</h5>
                      
                      <hr>


                     
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Anasayfa 
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="anasayfa_description" value="<?php echo $anasayfa_description; ?>" name="anasayfa_description" maxlength="400"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Hakkımızda 
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="hakkimizda_description" value="<?php echo $hakkimizda_description; ?>" name="hakkimizda_description" maxlength="400"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">İletişim
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="iletisim_description" value="<?php echo $iletisim_description; ?>" name="iletisim_description" maxlength="400"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Blog 
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="blog_description" value="<?php echo $blog_description; ?>" name="blog_description" maxlength="400"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Ekip 
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="ekip_description" value="<?php echo $ekip_description; ?>" name="ekip_description" maxlength="400"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>


                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">SSS
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="sss_description" value="<?php echo $sss_description; ?>" name="sss_description" maxlength="400"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>


                      

                      

                     

                

                      <input type="hidden" name="descriptionduzenle">


                      
                      
                      <div class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">

                       
                          
                          <button style="margin-bottom: 25px;" type="submit" class="btn btn-success descriptionbuton">Düzenle</button>



                          
                        </div>
                      </div>

                    </form>



                    

                   


                    
                  </div>
                </div>
              </div>
            </div>

            <?php require_once 'footer.php'; ?>



            <script type="text/javascript">

             

            $('#descriptionform').submit(function(){

             


              $('.descriptionbuton').prop('disabled',true);

              

                $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : $('#descriptionform').serialize(),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

              if (sonuc=="ok") {

                
                $('.descriptionbuton').prop('disabled',false);


                swal({

  title: "Başarılı",
  text: "Sayfa açıklamaları düzenlendi!",
  icon: "success",
  button: "OK",
});



              }
                

              }


            })

                 

                 });

            


            

            </script>

              
             