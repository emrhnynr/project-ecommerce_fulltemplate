<?php require_once 'header.php';

$genelayarsec=$db->prepare("SELECT * from genelayarlar");
$genelayarsec->execute();

 $genelayarcek=$genelayarsec->fetch(PDO::FETCH_ASSOC);

 $ayar_kargosirketi = $genelayarcek['ayar_kargosirketi'];  ?>



        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              

              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2><i class="fa fa-truck"></i> Kargo Ayarları</h2>
                    <ul class="nav navbar-right panel_toolbox">
                                         </ul>

                    
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />
                    <form id="kargoduzenleform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

                      
                    <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Kargo Şirketi
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">

                          <select class="form-control" name="ayar_kargosirketi" id="kargo_sirketi">
                            
                            <option <?php if ($ayar_kargosirketi=='MNG Kargo') { ?>
                              selected=''
                            <?php } ?> >MNG Kargo</option>

                            <option <?php if ($ayar_kargosirketi=='Aras Kargo') { ?>
                              selected=''
                            <?php } ?>>Aras Kargo</option>

                            <option <?php if ($ayar_kargosirketi=='Yurtiçi Kargo') { ?>
                              selected=''
                            <?php } ?>>Yurtiçi Kargo</option>

                            <option <?php if ($ayar_kargosirketi=='Sürat Kargo') { ?>
                              selected=''
                            <?php } ?>>Sürat Kargo</option>

                            <option <?php if ($ayar_kargosirketi=='UPS Kargo') { ?>
                              selected=''
                            <?php } ?>>UPS Kargo</option>

                            <option <?php if ($ayar_kargosirketi=='Ptt Kargo') { ?>
                              selected=''
                            <?php } ?>>Ptt Kargo</option>

                            <option <?php if ($ayar_kargosirketi=='vatan Kargo') { ?>
                              selected=''
                            <?php } ?>>Vatan Kargo</option>

                            <option <?php if ($ayar_kargosirketi=='İyi Kargo') { ?>
                              selected=''
                            <?php } ?>>İyi Kargo</option>

                            <option <?php if ($ayar_kargosirketi=='KargoTürk') { ?>
                              selected=''
                            <?php } ?>>KargoTürk</option>

                            <option <?php if ($ayar_kargosirketi=='Ay Kargo') { ?>
                              selected=''
                            <?php } ?>>Ay Kargo</option>

                            <option <?php if ($ayar_kargosirketi=='Git Kargo') { ?>
                              selected=''
                            <?php } ?>>Git Kargo</option>

                            <option <?php if ($ayar_kargosirketi=='Filo Kargo') { ?>
                              selected=''
                            <?php } ?>>Filo Kargo</option>

                            <option <?php if ($ayar_kargosirketi=='TNT Kargo') { ?>
                              selected=''
                            <?php } ?>>TNT Kargo</option>

                            <option <?php if ($ayar_kargosirketi=='Agt Kurye') { ?>
                              selected=''
                            <?php } ?>>Agt Kurye</option>

                            <option <?php if ($ayar_kargosirketi=='Horoz Lojistik') { ?>
                              selected=''
                            <?php } ?>>Horoz Lojistik</option>

                          </select>
                          
                        </div>
                      </div>

                     
                     

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Kaç TL Üzeri Kargo Bedava?
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input placeholder="Kampanya uygulamıyorsanız burayı boş bırakın."  type="number" id="kargobedava_limit" name="kargobedava_limit" step="any" value="<?php echo $genelayarcek['kargobedava_limit']; ?>"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>


                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Kargo İade Kodu
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input placeholder="İade aşamasında müşteriye verilecek iade kodu." maxlength="50"  type="text" id="kargo_iadekodu" name="kargo_iadekodu" value="<?php echo $genelayarcek['kargo_iadekodu']; ?>"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">İade Ad Soyad
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input placeholder="İade için yazılacak ad soyad" maxlength="150"  type="text" id="iade_adsoyad" name="iade_adsoyad" value="<?php echo $genelayarcek['iade_adsoyad']; ?>"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>


                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">İade Adresi
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <textarea rows="5" class="form-control" placeholder="İade için yazılacak ad soyad" maxlength="1000" id="iade_adres" name="iade_adres"><?php echo $genelayarcek['iade_adres']; ?></textarea>
                          
                        </div>
                      </div>

                     

                      

                     

                

                      <input type="hidden" name="kargoduzenleadmin">


                      
                      
                      <div class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">

                          <div style="display: none;" class="alert alert-warning uyari"></div>
                          
                          <button type="submit" class="btn btn-success kargoduzenlebuton">Düzenle</button>
                        </div>
                      </div>

                    </form>

                    <br>

                    <h3 align="center">Kargo Ücretleri  <a class="btn btn-success" data-toggle='modal' href="#kargoucretiekle">Ekle +</a>

                      <h4 align="center">Sabit kargo ücreti uygulamak istiyorsanız tek bir alan açıp 0-99999 desi değerlerini girerek ücreti yazabilirsiniz.</h4>

                      <hr>

                    </h3>

                    

                    <?php 
                    $kargoucretisec=$db->prepare("SELECT * from kargoucretleri order by min_desi ASC");
                      $kargoucretisec->execute();
                      $kargoucretisay=$kargoucretisec->rowCount();

                      if ($kargoucretisay==0) { ?>
                        
      <h4 align="center">Kargo ücret aralığı eklenmemiş.</h4>

                      <?php } else { ?>

               <form style="margin-top:40px;" id="kargoucretduzenleform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">


                      <?php 

                      $say=0;

                      while ($kargoucreticek=$kargoucretisec->fetch(PDO::FETCH_ASSOC)) {

                      $say++;
                      $kargoucret_id = $kargoucreticek['kargoucret_id']; ?>
                         
                         <div class="kargoucreti_<?php echo $kargoucret_id; ?> kargoucretlerr">

                      
                   
                       <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Desi Alt Değer
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input placeholder="Örn. 0-5 desi arası ücret belirleyecekseniz 0'ı buraya yazın."  type="number" min="0" id="min_desi" name="min_desi_<?php echo $kargoucret_id; ?>" step="any" value="<?php echo $kargoucreticek['min_desi']; ?>"  class="form-control col-md-10 col-xs-12 inputs">
                        </div>
                      </div>


                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Desi Üst Değer
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input placeholder="Örn. 0-5 desi arası ücret belirleyecekseniz 5'i buraya yazın."  type="number" min="0" id="max_desi" name="max_desi_<?php echo $kargoucret_id; ?>" step="any" value="<?php echo $kargoucreticek['max_desi']; ?>"  class="form-control col-md-10 col-xs-12 inputs">
                        </div>
                      </div>
                     
                     

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Bu Desiler Arası Kargo Ücreti
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input placeholder="Kargo ücreti girin." min="0" type="number" id="kargo_ucreti" name="kargo_ucreti_<?php echo $kargoucret_id; ?>" step="any" value="<?php echo $kargoucreticek['kargo_ucreti']; ?>"  class="form-control col-md-10 col-xs-12 inputs">
                        </div>
                      </div>

                      <div class="form-group"><label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name"></label><div align="center" class="col-md-7 col-sm-7 col-xs-12"><a class="btn btn-danger kargokaldir" name="kargoucret_<?php echo $kargoucret_id; ?>" href="javascript:void(0);"><i class="fa fa-trash-o"></i> Kaldır</a></div></div>

                    </div>

                    <br>
                    

                       <?php } ?>

                      



                        




                      

                     

                      

                     

                

                      <input type="hidden" name="kargoucretduzenleadmin">


                      
                      
                      <div  class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">

                          <div style="display: none;" class="alert alert-warning uyariucret"></div>
                          
                          <button type="submit" class="btn btn-success kargoucretduzenlebuton">Düzenle</button>
                        </div>
                      </div>

                    </form>

                     <?php } ?>
                       

                    


                    <div class="modal fade" id="kargoucretiekle"> 
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

      

        <div style="padding: 50px;" class="modal-body">

          <h3>Kargo Ücreti Ekle<hr></h3>

          <form action="../../adminislem.php" method="POST" id="kargoucretiekleform" enctype="multipart/form-data">
         <div class="row">



          
           
           <div style="margin-top:20px;" class="col-md-12 col-xs-12 col-sm-12">
            <label>Desi Alt Değeri*</label>
             <input class="form-control" required="" placeholder="Örn. 0-5 desi arası ücret belirleyecekseniz 0'ı buraya yazın." type="number" min="0" step="any" name="min_desi">
           </div>



           <div style="margin-top:20px;" class="col-md-12 col-xs-12 col-sm-12">
            <label>Desi Üst Değeri*</label>
             <input class="form-control" required="" placeholder="Örn. 0-5 desi arası ücret belirleyecekseniz 5'i buraya yazın." type="number" step="any" min="0" name="max_desi">
           </div>

          

           <div style="margin-top:20px;" class="col-md-12 col-xs-12 col-sm-12">
            <label>Bu Desiler Arası Kargo Ücreti*</label>
             <input class="form-control" required="" step="any" min="0" placeholder="Kargo ücreti girin." type="number" name="kargo_ucreti">
           </div>


          

          

         


        
           

         </div>

        </div>

     
       
    <div class="modal-footer">


  
    
    <button class="btn btn-success" name="kargoucretiekle" type="submit">Ekle</button>

     </form>
    <button class="btn btn-danger" data-dismiss="modal">Kapat</button>

    
</div>





  

     
    </div>

  </div>

</div>

                    

                   
                  </div>
                </div>
              </div>
            </div>

            <?php require_once 'footer.php'; ?>
            <script type="text/javascript">

              $('.kargokaldir').click(function(){

           var buton = $(this);
            var id1=$(this).attr("name");
                var kargoucret_id=id1.substring(11);



               swal({
  title: "Emin misiniz?",
  text: "Bu kargo ücret tarifesi kaldırılsın mı?",
  icon: "warning",
  buttons: ["Vazgeç", "Sil"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

    buton.html('Siliniyor...');

    $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'kargoucretsil':'ok','kargoucret_id':kargoucret_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              if (sonuc=="ok") {

                $('.kargoucreti_'+kargoucret_id).remove();
              }

              var kargoucretsay = $('.kargoucretlerr').length;

              if (kargoucretsay==0) {

         $('.kargoucretduzenlebuton').remove();

              }

               }

             });


     }

     })
         })

            $('#kargoduzenleform').submit(function(){

             
              var kargobedava_limit = $.trim($('#kargobedava_limit').val());


              


              $('.kargoduzenlebuton').prop('disabled',true);

              $('.uyarimail').hide();

                $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : $('#kargoduzenleform').serialize(),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

             

              if (sonuc=="ok") {

                
                $('.kargoduzenlebuton').prop('disabled',false);


                swal({

  title: "Başarılı",
  text: "Kargo ayarları güncellendi!",
  icon: "success",
  button: "OK",
});



              }            

              }


            })

              

                 });


            $('#kargoucretduzenleform').submit(function(){

             
              var bosinputsayisi = $('.inputs').filter(function(){
    return !$.trim($(this).val());
}).length;

              $('.kargoucretduzenlebuton').prop('disabled',true);
                
                if (bosinputsayisi>0) {

           $('.uyariucret').show();
           $('.uyariucret').html('<i class="fa fa-info-circle"></i> Tüm alanları doldurmanız gerekmektedir.');
           $('.kargoucretduzenlebuton').prop('disabled',false);

                } else {


              


              $('.kargoucretduzenlebuton').prop('disabled',false);

              $('.uyariucret').hide();

                $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : $('#kargoucretduzenleform').serialize(),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

              

             

               if (sonuc=="ok") {

                
                $('.kargoucretduzenlebuton').prop('disabled',false);


                swal({

  title: "Başarılı",
  text: "Kargo ücretleri güncellendi!",
  icon: "success",
  button: "OK",
});



              }            

              }


            })

                 }

              

                 });


             

            </script>

              
             