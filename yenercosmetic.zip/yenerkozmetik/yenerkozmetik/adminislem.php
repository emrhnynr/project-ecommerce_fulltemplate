<?php 

ob_start();
session_start();

if (empty($_POST) and empty($_GET)) {
	
	header("Location:/");
	exit;
}





require_once 'db.php';
include 'fonksiyon.php';
include('SimpleImage.php');

 $ip_adresi=$_SERVER['REMOTE_ADDR'];
 date_default_timezone_set('Europe/Istanbul');

 


 if (isset($_POST['admingiris'])) {
	
	$admin_mail=trim($_POST['admin_mail']);
    $admin_sifre=trim($_POST['admin_sifre']);



 	$adminsec=$db->prepare("SELECT * from kullanici where kullanici_mail=:mail and kullanici_password=:password and kullanici_yetki=:yetki");
 	$adminsec->execute(array(


"mail" => $admin_mail,
"password" => md5($admin_sifre),
"yetki" => 5

 	));

 	$kayitsay=$adminsec->rowCount();

 	if ($kayitsay==1) {
 		
$_SESSION['admin_oturum']=$admin_mail;
Header("Location:nedmin/production");
exit;

 	} else {


Header("Location:nedmin/production/login?loginstatus=no");
exit;


}

} else if(isset($_POST['adminsifredegistir'])){

$mevcut_sifre=$_POST['mevcut_sifre'];
$yeni_sifre=$_POST['yeni_sifre'];
$admin_id=trim($_POST['admin_id']);

$adminsec=$db->prepare("SELECT * from kullanici where kullanici_id=:id");
$adminsec->execute(array(
"id" => $admin_id
));

$admincek=$adminsec->fetch(PDO::FETCH_ASSOC);

$admin_sifre = $admincek['kullanici_password'];



if ($admin_sifre!=md5($mevcut_sifre)) {
	
	echo "yanlissifre";

} else {

 $hazirla=$db->prepare("UPDATE kullanici set

kullanici_password=:kullanici_password

where kullanici_id='$admin_id'

 	");

 $derle=$hazirla->execute(array(

"kullanici_password" => htmlspecialchars(md5($yeni_sifre))

 ));

 echo "ok";

}

} else if (isset($_POST['slaytfotoduzenle'])){


$slayt_id = $_POST['slayt_id'];

$slaytsec = $db->prepare("SELECT * from slaytlar where slayt_id=:id");
$slaytsec->execute(array(

"id" => $slayt_id

));

$slaytcek = $slaytsec->fetch(PDO::FETCH_ASSOC);




$name=$_FILES['file']['name'];
$uzanti=ext($_FILES['file']['name']);



$uniq = uniqid();
$tmpname=$_FILES['file']['tmp_name'];
$depodosya = 'dimg/slaytfoto';
/*$image = new SimpleImage();
	$image->load($tmpname);
	$image->resize(1366,504);
	$image->save($tmpname);*/

	$refimgyol=$depodosya."/".$uniq.".".$uzanti;
	@move_uploaded_file($tmpname, "$depodosya/$uniq.$uzanti");

	$hazirla=$db->prepare("UPDATE slaytlar set

slayt_foto=:slayt_foto

where slayt_id='$slayt_id'
		");

	$derle=$hazirla->execute(array(

		"slayt_foto" => $refimgyol

	));

	if ($derle) {
		
		echo "ok";
	} 




 } else if (isset($_POST['kutufotoduzenle'])){


$kutu_id = $_POST['kutu_id'];

$kutusec = $db->prepare("SELECT * from anasayfakutular where kutu_id=:id");
$kutusec->execute(array(

"id" => $kutu_id

));

$kutucek = $kutusec->fetch(PDO::FETCH_ASSOC);




$name=$_FILES['file']['name'];
$uzanti=ext($_FILES['file']['name']);



$uniq = uniqid();
$tmpname=$_FILES['file']['tmp_name'];
$depodosya = 'dimg/anasayfakutufoto';
/*$image = new SimpleImage();
	$image->load($tmpname);
	$image->resize(800,560);
	$image->save($tmpname);*/

	$refimgyol=$depodosya."/".$uniq.".".$uzanti;
	@move_uploaded_file($tmpname, "$depodosya/$uniq.$uzanti");

	$hazirla=$db->prepare("UPDATE anasayfakutular set

kutu_foto=:kutu_foto

where kutu_id='$kutu_id'
		");

	$derle=$hazirla->execute(array(

		"kutu_foto" => $refimgyol

	));

	if ($derle) {
		
		echo "ok";
	} 




 } else if (isset($_POST['markalogoduzenle'])){


$marka_id = $_POST['marka_id'];

$markasec = $db->prepare("SELECT * from markalar where marka_id=:id");
$markasec->execute(array(

"id" => $marka_id

));

$markacek = $markasec->fetch(PDO::FETCH_ASSOC);




$name=$_FILES['file']['name'];
$uzanti=ext($_FILES['file']['name']);



$uniq = uniqid();
$tmpname=$_FILES['file']['tmp_name'];
$depodosya = 'dimg/markalogo';

	$refimgyol=$depodosya."/".$uniq.".".$uzanti;
	@move_uploaded_file($tmpname, "$depodosya/$uniq.$uzanti");

	$hazirla=$db->prepare("UPDATE markalar set

marka_logo=:marka_logo

where marka_id='$marka_id'
		");

	$derle=$hazirla->execute(array(

		"marka_logo" => $refimgyol

	));

	if ($derle) {
		
		echo "ok";
	} 




 } else if(isset($_POST['slaytekleadmin'])){



$slayt_sira=$_POST['slayt_sira'];
$slayt_link=trim($_POST['slayt_link']);
$slayt_baslik = trim($_POST['slayt_baslik']);
$slayt_aciklama = trim($_POST['slayt_aciklama']);
$uzanti=ext($_FILES['slayt_foto']['name']);

$depodosya = 'dimg/slaytfoto';

$tmp_name = $_FILES['slayt_foto']["tmp_name"];
$name = $_FILES['slayt_foto']["name"];
/*$image = new SimpleImage();
	$image->load($tmp_name);
	$image->resize(1366,504);
	$image->save($tmp_name);*/
$uniq=uniqid();
	$refimgyol=$depodosya."/".$uniq.".".$uzanti;
	@move_uploaded_file($tmp_name, "$depodosya/$uniq.$uzanti");

	$hazirla=$db->prepare("INSERT into slaytlar set

slayt_sira=:slayt_sira,
slayt_foto=:slayt_foto,
slayt_link=:slayt_link,
slayt_baslik=:slayt_baslik,
slayt_aciklama=:slayt_aciklama
		");

	$derle=$hazirla->execute(array(

"slayt_sira" => $slayt_sira,
"slayt_foto" => $refimgyol,
"slayt_link" => htmlspecialchars($slayt_link),
"slayt_baslik" => htmlspecialchars($slayt_baslik),
"slayt_aciklama" => htmlspecialchars($slayt_aciklama)
	));

	if ($derle) {
		
		echo "ok";
	}




} else if(isset($_POST['kutuekleadmin'])){



$kutu_sira=$_POST['kutu_sira'];
$kutu_link=trim($_POST['kutu_link']);
$uzanti=ext($_FILES['kutu_foto']['name']);

$depodosya = 'dimg/anasayfakutufoto';

$tmp_name = $_FILES['kutu_foto']["tmp_name"];
$name = $_FILES['kutu_foto']["name"];
/*$image = new SimpleImage();
	$image->load($tmp_name);
	$image->resize(800,560);
	$image->save($tmp_name);*/
$uniq=uniqid();
	$refimgyol=$depodosya."/".$uniq.".".$uzanti;
	@move_uploaded_file($tmp_name, "$depodosya/$uniq.$uzanti");

	$hazirla=$db->prepare("INSERT into anasayfakutular set

kutu_sira=:kutu_sira,
kutu_foto=:kutu_foto,
kutu_link=:kutu_link
		");

	$derle=$hazirla->execute(array(

"kutu_sira" => $kutu_sira,
"kutu_foto" => $refimgyol,
"kutu_link" => htmlspecialchars($kutu_link)

));

	if ($derle) {
		
		echo "ok";
	}




} else if (isset($_POST['kutuogesil'])){

$kutu_id = $_POST['kutu_id'];

$kutusec=$db->prepare("SELECT * from anasayfakutular where kutu_id=:id");
$kutusec->execute(array(
"id" => $kutu_id
));

$kutucek=$kutusec->fetch(PDO::FETCH_ASSOC);

$kutu_foto = $kutucek['kutu_foto'];

unlink($kutu_foto);

$kutusil=$db->prepare("DELETE from anasayfakutular where kutu_id=:id");
$silkutu=$kutusil->execute(array(
"id" => $kutu_id
));

if ($silkutu) {
	
	echo "ok";
}

} else if (isset($_POST['slaytogesil'])){

$slayt_id = $_POST['slayt_id'];

$slaytsec=$db->prepare("SELECT * from slaytlar where slayt_id=:id");
$slaytsec->execute(array(
"id" => $slayt_id
));

$slaytcek=$slaytsec->fetch(PDO::FETCH_ASSOC);

$slayt_foto = $slaytcek['slayt_foto'];

unlink($slayt_foto);

$slaytsil=$db->prepare("DELETE from slaytlar where slayt_id=:id");
$silslayt=$slaytsil->execute(array(
"id" => $slayt_id
));

if ($silslayt) {
	
	echo "ok";
}

} else if (isset($_POST['girisbaslikduzenleadmin'])){

$ayar_hometext = trim($_POST['ayar_hometext']);

$hazirla=$db->prepare("UPDATE genelayarlar set

ayar_hometext=:ayar_hometext

	");

$derle=$hazirla->execute(array(

"ayar_hometext" => htmlspecialchars($ayar_hometext)

));

if ($derle) {
	
	echo "ok";
}

} else if (isset($_POST['reelkodduzenleadmin'])){

$ayar_reelkod = trim($_POST['ayar_reelkod']);

$hazirla=$db->prepare("UPDATE genelayarlar set

ayar_reelkod=:ayar_reelkod

	");

$derle=$hazirla->execute(array(

"ayar_reelkod" => htmlspecialchars($ayar_reelkod),

));

if ($derle) {
	
	echo "ok";
}

} else if (isset($_POST['footerdescduzenleadmin'])){

$ayar_footerdesc = trim($_POST['ayar_footerdesc']);

$hazirla=$db->prepare("UPDATE genelayarlar set

ayar_footerdesc=:ayar_footerdesc
	");

$derle=$hazirla->execute(array(
"ayar_footerdesc" => htmlspecialchars($ayar_footerdesc)
));

if ($derle) {
	
	echo "ok";
}

} else if (isset($_POST['footertextduzenleadmin'])){

$ayar_footertext = trim($_POST['ayar_footertext']);

$hazirla=$db->prepare("UPDATE genelayarlar set

ayar_footertext=:ayar_footertext

	");

$derle=$hazirla->execute(array(

"ayar_footertext" => htmlspecialchars($ayar_footertext)

));

if ($derle) {
	
	echo "ok";
}

} else if (isset($_POST['hakkimizdabannerguncelle'])){


$name=$_FILES['file']['name'];
$uzanti=ext($_FILES['file']['name']);
$tmp_name=$_FILES['file']['tmp_name'];
$depodosya = 'dimg/girisfoto';





$uniq=uniqid();
$refimgyol=$depodosya."/".$uniq.".".$uzanti;

@move_uploaded_file($tmp_name, "$depodosya/$uniq.$uzanti");

$hazirla=$db->prepare("UPDATE genelayarlar set

ayar_hakkimizdabanner=:ayar_hakkimizdabanner
	");

$derle=$hazirla->execute(array(
"ayar_hakkimizdabanner" => $refimgyol
));

echo "ok";

 } else if (isset($_POST['iletisimbannerguncelle'])){


$name=$_FILES['file']['name'];
$uzanti=ext($_FILES['file']['name']);
$tmp_name=$_FILES['file']['tmp_name'];
$depodosya = 'dimg/girisfoto';





$uniq=uniqid();
$refimgyol=$depodosya."/".$uniq.".".$uzanti;

@move_uploaded_file($tmp_name, "$depodosya/$uniq.$uzanti");

$hazirla=$db->prepare("UPDATE genelayarlar set

ayar_iletisimbanner=:ayar_iletisimbanner
	");

$derle=$hazirla->execute(array(
"ayar_iletisimbanner" => $refimgyol
));

echo "ok";

 } else if (isset($_POST['hakkimizda1fotoguncelle'])){


$name=$_FILES['file']['name'];
$uzanti=ext($_FILES['file']['name']);
$tmp_name=$_FILES['file']['tmp_name'];
$depodosya = 'dimg/hakkimizdafoto';



$image = new SimpleImage();
	$image->load($tmp_name);
	$image->resize(651,553);
	$image->save($tmp_name);

$uniq=uniqid();
$refimgyol=$depodosya."/".$uniq.".".$uzanti;

@move_uploaded_file($tmp_name, "$depodosya/$uniq.$uzanti");

$hazirla=$db->prepare("UPDATE genelayarlar set

hakkimizda1_foto=:hakkimizda1_foto
	");

$derle=$hazirla->execute(array(
"hakkimizda1_foto" => $refimgyol
));

echo "ok";

 } else if (isset($_POST['faviconguncelleadmin'])){

$name=$_FILES['file']['name'];
$uzanti=ext($_FILES['file']['name']);
$tmp_name=$_FILES['file']['tmp_name'];
$depodosya = 'dimg/logo';



$uniq=uniqid();
$refimgyol=$depodosya."/".$uniq.".".$uzanti;

@move_uploaded_file($tmp_name, "$depodosya/$uniq.$uzanti");

$hazirla=$db->prepare("UPDATE genelayarlar set

ayar_favicon=:ayar_favicon
	");

$derle=$hazirla->execute(array(
"ayar_favicon" => $refimgyol
));

echo "ok";

} else if (isset($_POST['anasayfakeywordsduzenle'])){

$anasayfa_keywords= trim($_POST['anasayfa_keywords']);

$hazirla=$db->prepare("UPDATE genelayarlar set

anasayfa_keywords=:anasayfa_keywords
	");


$derle=$hazirla->execute(array(
"anasayfa_keywords" => $anasayfa_keywords
));

if ($derle) {
	
	echo "ok";
}

 } else if (isset($_POST['keywordsduzenle'])){


$hazirla=$db->prepare("UPDATE seoayarlar set

anasayfa_keywords=:anasayfa_keywords,
hakkimizda_keywords=:hakkimizda_keywords,
iletisim_keywords=:iletisim_keywords,
blog_keywords=:blog_keywords,
ekip_keywords=:ekip_keywords,
sss_keywords=:sss_keywords


  ");

$derle=$hazirla->execute(array(

"anasayfa_keywords" => htmlspecialchars(trim($_POST['anasayfa_keywords'])),
"iletisim_keywords" => htmlspecialchars(trim($_POST['iletisim_keywords'])),
"hakkimizda_keywords" => htmlspecialchars(trim($_POST['hakkimizda_keywords'])),
"blog_keywords" => htmlspecialchars(trim($_POST['blog_keywords'])),
"ekip_keywords" => htmlspecialchars(trim($_POST['ekip_keywords'])),
"sss_keywords" => htmlspecialchars(trim($_POST['sss_keywords']))

));

if ($derle) {
  
  echo "ok";
}


 } else if (isset($_POST['anasayfadescriptionduzenle'])){

$anasayfa_description= trim($_POST['anasayfa_description']);

$hazirla=$db->prepare("UPDATE genelayarlar set

anasayfa_description=:anasayfa_description
	");


$derle=$hazirla->execute(array(
"anasayfa_description" => $anasayfa_description
));

if ($derle) {
	
	echo "ok";
}

 }  else if (isset($_POST['hakkimizdadescriptionduzenle'])){

$hakkimizda_description = trim($_POST['hakkimizda_description']);

$hazirla=$db->prepare("UPDATE genelayarlar set

hakkimizda_description=:hakkimizda_description
	");


$derle=$hazirla->execute(array(
"hakkimizda_description" => $hakkimizda_description
));

if ($derle) {
	
	echo "ok";
}

 } else if (isset($_POST['iletisimdescriptionduzenle'])){

$iletisim_description = trim($_POST['iletisim_description']);

$hazirla=$db->prepare("UPDATE genelayarlar set

iletisim_description=:iletisim_description
	");


$derle=$hazirla->execute(array(
"iletisim_description" => $iletisim_description
));

if ($derle) {
	
	echo "ok";
}

 } else if (isset($_POST['descriptionduzenle'])){


$hazirla=$db->prepare("UPDATE seoayarlar set

anasayfa_description=:anasayfa_description,
hakkimizda_description=:hakkimizda_description,
iletisim_description=:iletisim_description,
blog_description=:blog_description,
ekip_description=:ekip_description,
sss_description=:sss_description


  ");

$derle=$hazirla->execute(array(

"anasayfa_description" => htmlspecialchars(trim($_POST['anasayfa_description'])),
"hakkimizda_description" => htmlspecialchars(trim($_POST['hakkimizda_description'])),
"iletisim_description" => htmlspecialchars(trim($_POST['iletisim_description'])),
"blog_description" => htmlspecialchars(trim($_POST['blog_description'])),
"ekip_description" => htmlspecialchars(trim($_POST['ekip_description'])),
"sss_description" => htmlspecialchars(trim($_POST['sss_description']))

));

if ($derle) {
  
  echo "ok";
}


 } else if (isset($_POST['kategoriekle'])){

$kategori_ust = $_POST['kategori_ust'];
$kategori_ust2 = $kategori_ust;

if ($kategori_ust2==0) {
	
	$kategori_ust2 = NULL;

} else {

$say=0;

while ($say<5) {
	
	$say++;

	$ustkategorisec=$db->prepare("SELECT * from kategoriler where kategori_id='$kategori_ust2'");
	$ustkategorisec->execute();
	$ustkategoricek=$ustkategorisec->fetch(PDO::FETCH_ASSOC);

	if ($ustkategoricek['kategori_ust']==0) {
		
		break;

	} else {

		$kategori_ust2=$ustkategoricek['kategori_ust'];
	}
}
	
}






$kategori_adlar = $_POST['kategori_ad'];


$sayy = 0;

foreach ($kategori_adlar as $kategori_ad) {

	

	$kategorisec=$db->prepare("SELECT * from kategoriler where kategori_ust='$kategori_ust'");
	$kategorisec->execute();
	$kategorisay = $kategorisec->rowCount();
	$kategori_sira = $kategorisay+1;

$kategori_ad=trim($kategori_ad);

$hazirla=$db->prepare("INSERT into kategoriler set

kategori_ad=:kategori_ad,
kategori_ust=:kategori_ust,
kategori_sira=:kategori_sira,
kategori_enust=:kategori_enust

	");

$derle=$hazirla->execute(array(
"kategori_ad" => htmlspecialchars($kategori_ad),
"kategori_ust" => $kategori_ust,
"kategori_sira" => $kategori_sira,
"kategori_enust" => $kategori_ust2
));


$sayy++;



}

$hazirla=$db->prepare("UPDATE kategoriler set

kategori_enalt=:kategori_enalt

where kategori_id='$kategori_ust'
	");

$derle=$hazirla->execute(array(
"kategori_enalt" => 0
));

echo "ok";

 } else if (isset($_POST['kategoripasif'])){

$kategori_id=$_POST['kategori_id'];

$hazirla=$db->prepare("UPDATE kategoriler set

kategori_aktif=:kategori_aktif

where kategori_id='$kategori_id'
	");

$derle=$hazirla->execute(array(

"kategori_aktif" => 0

));

$kategorisec = $db->prepare("SELECT * from kategoriler where kategori_id='$kategori_id'");
$kategorisec->execute();
$kategoricek=$kategorisec->fetch(PDO::FETCH_ASSOC);
$kategori_ust=$kategoricek['kategori_ust'];

if ($kategori_ust!=0) {
	
	$kategorisor=$db->prepare("SELECT * from kategoriler where kategori_ust='$kategori_ust' and kategori_aktif='1'");
	$kategorisor->execute();
	$aktifkategorisay=$kategorisor->rowCount();

	if ($aktifkategorisay==0) {
		
		$hazirla=$db->prepare("UPDATE kategoriler set


kategori_enalt=:kategori_enalt

where kategori_id='$kategori_ust
'
			");

		$derle=$hazirla->execute(array(

"kategori_enalt" => 1

		));
	}
}

if ($derle) {
	
	echo "ok";
}





	
	


} else if (isset($_POST['kategoriaktif'])){

$kategori_id=$_POST['kategori_id'];

$kategorisec = $db->prepare("SELECT * from kategoriler where kategori_id='$kategori_id'");
$kategorisec->execute();
$kategoricek=$kategorisec->fetch(PDO::FETCH_ASSOC);
$kategori_ust=$kategoricek['kategori_ust'];

$hazirla=$db->prepare("UPDATE kategoriler set

kategori_aktif=:kategori_aktif

where kategori_id='$kategori_id'
	");

$derle=$hazirla->execute(array(

"kategori_aktif" => 1

));

if ($derle) {

	$hazirla=$db->prepare("UPDATE kategoriler set

kategori_enalt=:kategori_enalt

where kategori_id='$kategori_ust'

		");

	$derle=$hazirla->execute(array(
"kategori_enalt" => 0
	));
	
	echo "ok";
}





	
	


} else if (isset($_POST['urunekleadmin'])){

$urun_ad = trim($_POST['urun_ad']);
if (empty($_POST['urun_fiyat'])) { 

	$urun_fiyat = NULL;
	$urun_indirim = 0;
	$urun_nihaifiyat = $_POST['urun_indirimsizfiyat'];

 } else {

 	$urun_fiyat = $_POST['urun_fiyat'];
 	$urun_indirim = 1;
 	$urun_nihaifiyat = $_POST['urun_fiyat'];

 }
$urun_indirimsizfiyat = $_POST['urun_indirimsizfiyat'];
$urun_stok = $_POST['urun_stok'];
$urun_marka = $_POST['urun_marka'];
$markasec = $db->prepare("SELECT * from markalar where marka_id='$urun_marka'");
$markasec->execute();
$markacek = $markasec->fetch(PDO::FETCH_ASSOC);
$marka_ad = $markacek['marka_ad'];
$urun_desi = $_POST['urun_desi'];



if (empty(trim($_POST['urun_video']))) {
	
	$urun_video = NULL;

} else {

	$urun_video = trim($_POST['urun_video']);
};
$urun_kategori = $_POST['urun_kategori'];
$urun_cinsiyet = $_POST['urun_cinsiyet'];
$urun_ustkategori = $_POST['urun_ustkategori'];
$kategorisec=$db->prepare("SELECT * from kategoriler where kategori_id=:id");
$kategorisec->execute(array(
"id" => $urun_ustkategori
));
$kategoricek=$kategorisec->fetch(PDO::FETCH_ASSOC);
$ustkategori_ad = $kategoricek['kategori_ad'];
$urun_aciklama = $_POST['urun_aciklama'];
$urun_seourl = seo($urun_ad);
$urun_ozellikler = $_POST['ozellik_baslik'];
$ozellik_icerikler = $_POST['ozellik_icerik'];
$urun_zaman = date('Y-m-d H:i:s');


$hazirla=$db->prepare("INSERT into urunler set

urun_ad=:urun_ad,
urun_fiyat=:urun_fiyat,
urun_indirim=:urun_indirim,
urun_indirimsizfiyat=:urun_indirimsizfiyat,
urun_nihaifiyat=:urun_nihaifiyat,
urun_stok=:urun_stok,
marka_id=:marka_id,
marka_ad=:marka_ad,
urun_desi=:urun_desi,
urun_video=:urun_video,
urun_cinsiyet=:urun_cinsiyet,
kategori_id=:kategori_id,
kategori_ust=:kategori_ust,
urun_aciklama=:urun_aciklama,
urun_zaman=:urun_zaman,
urun_seourl=:urun_seourl

	");

$derle=$hazirla->execute(array(

"urun_ad" => htmlspecialchars($urun_ad),
"urun_fiyat" => $urun_fiyat,
"urun_indirim" => $urun_indirim,
"urun_indirimsizfiyat" => $urun_indirimsizfiyat,
"urun_nihaifiyat" => $urun_nihaifiyat,
"urun_stok" => $urun_stok,
"kategori_id" => $urun_kategori,
"kategori_ust" => $ustkategori_ad,
"marka_id" => $urun_marka,
"urun_cinsiyet" => $urun_cinsiyet,
"marka_ad" => $marka_ad,
"urun_desi" => $urun_desi,
"urun_video" => $urun_video,
"urun_aciklama" => $urun_aciklama,
"urun_zaman" => $urun_zaman,
"urun_seourl" => $urun_seourl

));

$urun_id = $db->lastInsertId();



if ($derle) {


$sayy=0;

while ($sayy<10) {
	
	$sayy++;

	$hazirla=$db->prepare("INSERT into urunkategori set

urun_zaman=:urun_zaman,
urun_id=:urun_id,
kategori_id=:kategori_id,
marka_id=:marka_id,
urun_nihaifiyat=:urun_nihaifiyat,
urun_indirim=:urun_indirim,
urun_cinsiyet=:urun_cinsiyet,
urun_ad=:urun_ad

		");

	$derle=$hazirla->execute(array(

"urun_zaman" => $urun_zaman,
"urun_id" => $urun_id,
"kategori_id" => $urun_kategori,
"marka_id" => $urun_marka,
"urun_nihaifiyat" => $urun_nihaifiyat,
"urun_indirim" => $urun_indirim,
"urun_cinsiyet" => $urun_cinsiyet,
"urun_ad" => $urun_ad

	));

	$kategorisec=$db->prepare("SELECT * from kategoriler where kategori_id='$urun_kategori'");
	$kategorisec->execute();

	$kategoricek=$kategorisec->fetch(PDO::FETCH_ASSOC);

	$urun_kategori=$kategoricek['kategori_ust'];

	if ($urun_kategori==0) {
	
	break;
	
	}


}



$ozelliksay = 0;

foreach ($urun_ozellikler as $ozellik) {

	if (!empty(trim($ozellik))) {
		
		$ozellik_icerik = $ozellik_icerikler[$ozelliksay];

	$hazirla=$db->prepare("INSERT into urunozellik set

urun_id=:urun_id,
ozellik_baslik=:ozellik_baslik,
ozellik_icerik=:ozellik_icerik
		");

	$derle=$hazirla->execute(array(
		"urun_id" => $urun_id,
	    "ozellik_baslik" => htmlspecialchars(trim($ozellik)),
         "ozellik_icerik" => htmlspecialchars(trim($ozellik_icerik))

	));

	}
	
	$ozelliksay++;
}


$tumseceneklersec=$db->prepare("SELECT * from secenekler");
$tumseceneklersec->execute();

while ($tumseceneklercek=$tumseceneklersec->fetch(PDO::FETCH_ASSOC)) {
	
	$secenek_id = $tumseceneklercek['secenek_id'];

	$seceneksayisi = count($_POST['secenek_id_'.$secenek_id]);

	if ($seceneksayisi!=0) {
		
		$hazirla=$db->prepare("INSERT into urunsecenekler set

urun_id=:urun_id,
secenek_id=:secenek_id
			");

		$derle=$hazirla->execute(array(
"urun_id" => $urun_id,
"secenek_id" => $secenek_id

		));

		$seceneksecim = $_POST['secenek_id_'.$secenek_id];

		foreach ($seceneksecim as $altsecenek_id) {
			
			$altseceneksec=$db->prepare("SELECT * from altsecenekler where altsecenek_id='$altsecenek_id'");
			$altseceneksec->execute();
			$altsecenekcek=$altseceneksec->fetch(PDO::FETCH_ASSOC);

			$altsecenek_ad = $altsecenekcek['altsecenek_ad'];

			$hazirla=$db->prepare("INSERT into urunaltsecenekler set

secenek_id=:secenek_id,
altsecenek_ad=:altsecenek_ad,
urun_id=:urun_id
				");

			$derle=$hazirla->execute(array(
"secenek_id" => $secenek_id,
"altsecenek_ad" => $altsecenek_ad,
"urun_id" => $urun_id
			));

		}
	}


}





$depodosya = 'dimg/urunfoto';


 $name=$_FILES['urun_kapakfoto']['name'];
$uzanti=ext($_FILES['urun_kapakfoto']['name']);
$tmp_name=$_FILES['urun_kapakfoto']['tmp_name'];


$image = new SimpleImage();
	$image->load($tmp_name);
	$image->resize(800,800);
	$image->save($tmp_name);

$uniq=uniqid();
$refimgyol=$depodosya."/".$uniq.".".$uzanti;

@move_uploaded_file($tmp_name, "$depodosya/$uniq.$uzanti");

	
	
$hazirla=$db->prepare("INSERT into urunfoto set

urunfoto_yol=:urunfoto_yol,
urun_id=:urun_id,
urunfoto_kapak=:urunfoto_kapak
		");

	$derle=$hazirla->execute(array(
"urunfoto_yol" => $refimgyol,
"urun_id" => $urun_id,
"urunfoto_kapak" => 1
	));

	
	
	
	
if (count(array_filter($_FILES['urun_fotolar']['name']))!=0) {




$foto_sira = 0;



	foreach($_FILES['urun_fotolar']['tmp_name'] as $key => $tmp_name){

		


   $name = $key.$_FILES['urun_fotolar']['name'][$key];
   $uzanti = ext($name);
   $tmpname = $_FILES['urun_fotolar']['tmp_name'][$key];
   $image = new SimpleImage();
	$image->load($tmpname);
	$image->resize(800,800);
	$image->save($tmpname);
	$uniq=uniqid();
	$refimgyol=$depodosya."/".$uniq.".".$uzanti;
	@move_uploaded_file($tmpname, "$depodosya/$uniq.$uzanti");

	

		$foto_sira++;

		$hazirla=$db->prepare("INSERT into urunfoto set

urunfoto_yol=:urunfoto_yol,
urun_id=:urun_id,
urunfoto_kapak=:urunfoto_kapak,
foto_sira=:foto_sira
		");

	$derle=$hazirla->execute(array(
"urunfoto_yol" => $refimgyol,
"urun_id" => $urun_id,
"urunfoto_kapak" => 0,
"foto_sira" => $foto_sira
	));
	


	}

    }

	echo "ok";
}

} else if (isset($_POST['markaekleadmin'])){


$marka_ad = trim($_POST['marka_ad']);
$marka_seourl = seo($marka_ad);
$marka_keywords = trim($_POST['marka_keywords']);


$name=$_FILES['file']['name'];
$uzanti=ext($_FILES['file']['name']);



$uniq = uniqid();
$tmpname=$_FILES['file']['tmp_name'];
$depodosya = 'dimg/markalogo';


	$refimgyol=$depodosya."/".$uniq.".".$uzanti;
	@move_uploaded_file($tmpname, "$depodosya/$uniq.$uzanti");

$hazirla=$db->prepare("INSERT into markalar set

marka_ad=:marka_ad,
marka_seourl=:marka_seourl,
marka_logo=:marka_logo,
marka_keywords=:marka_keywords
	");

$derle=$hazirla->execute(array(
"marka_ad" => htmlspecialchars($marka_ad),
"marka_seourl" => htmlspecialchars($marka_seourl),
"marka_logo" => $refimgyol,
"marka_keywords" => htmlspecialchars($marka_keywords)
));

if ($derle) {
	
	echo "ok";
}

} else if (isset($_POST['logoguncelleadmin'])){

$name=$_FILES['file']['name'];
$uzanti=ext($_FILES['file']['name']);
$tmp_name=$_FILES['file']['tmp_name'];
$depodosya = 'dimg/logo';



$uniq=uniqid();
$refimgyol=$depodosya."/".$uniq.".".$uzanti;

@move_uploaded_file($tmp_name, "$depodosya/$uniq.$uzanti");

$hazirla=$db->prepare("UPDATE genelayarlar set

ayar_logo=:ayar_logo
	");

$derle=$hazirla->execute(array(
"ayar_logo" => $refimgyol
));

echo "ok";

} else if (isset($_POST['mobillogoguncelleadmin'])){

$name=$_FILES['file']['name'];
$uzanti=ext($_FILES['file']['name']);
$tmp_name=$_FILES['file']['tmp_name'];
$depodosya = 'dimg/logo';



$uniq=uniqid();
$refimgyol=$depodosya."/".$uniq.".".$uzanti;

@move_uploaded_file($tmp_name, "$depodosya/$uniq.$uzanti");

$hazirla=$db->prepare("UPDATE genelayarlar set

ayar_mobillogo=:ayar_mobillogo
	");

$derle=$hazirla->execute(array(
"ayar_mobillogo" => $refimgyol
));

echo "ok";

} else if (isset($_POST['beyazlogoguncelleadmin'])){

$name=$_FILES['file']['name'];
$uzanti=ext($_FILES['file']['name']);
$tmp_name=$_FILES['file']['tmp_name'];
$depodosya = 'dimg/logo';



$uniq=uniqid();
$refimgyol=$depodosya."/".$uniq.".".$uzanti;

@move_uploaded_file($tmp_name, "$depodosya/$uniq.$uzanti");

$hazirla=$db->prepare("UPDATE genelayarlar set

ayar_beyazlogo=:ayar_beyazlogo
  ");

$derle=$hazirla->execute(array(
"ayar_beyazlogo" => $refimgyol
));

echo "ok";

} else if (isset($_POST['slaytduzenleadmin'])){

$slayt_sira = $_POST['slayt_sira'];
$slayt_link = trim($_POST['slayt_link']);
$slayt_baslik = trim($_POST['slayt_baslik']);
$slayt_aciklama = trim($_POST['slayt_aciklama']);
$slayt_id = $_POST['slayt_id'];

$hazirla=$db->prepare("UPDATE slaytlar set

slayt_sira=:slayt_sira,
slayt_link=:slayt_link,
slayt_baslik=:slayt_baslik,
slayt_aciklama=:slayt_aciklama

where slayt_id='$slayt_id'
	");

$derle=$hazirla->execute(array(

"slayt_sira" => $slayt_sira,
"slayt_link" => htmlspecialchars($slayt_link),
"slayt_baslik" => htmlspecialchars($slayt_baslik),
"slayt_aciklama" => htmlspecialchars($slayt_aciklama)

));

if ($derle) {
	
	echo "ok";
}


} else if (isset($_POST['kategoriduzenleadmin'])){

$kategori_ad = trim($_POST['kategori_ad']);
$kategori_keywords = trim($_POST['kategori_keywords']);
$kategori_id = $_POST['kategori_id'];

$hazirla=$db->prepare("UPDATE kategoriler set

kategori_ad=:kategori_ad,
kategori_keywords=:kategori_keywords

where kategori_id='$kategori_id'
	");

$derle=$hazirla->execute(array(

"kategori_ad" => htmlspecialchars($kategori_ad),
"kategori_keywords" => htmlspecialchars($kategori_keywords)

));

if ($derle) {
	
	echo "ok";
}


} else if (isset($_POST['kutuduzenleadmin'])){

$kutu_sira = $_POST['kutu_sira'];
$kutu_link = trim($_POST['kutu_link']);
$kutu_id = $_POST['kutu_id'];

$hazirla=$db->prepare("UPDATE anasayfakutular set

kutu_sira=:kutu_sira,
kutu_link=:kutu_link

where kutu_id='$kutu_id'
	");

$derle=$hazirla->execute(array(

"kutu_sira" => $kutu_sira,
"kutu_link" => htmlspecialchars($kutu_link)

));

if ($derle) {
	
	echo "ok";
}


} else if (isset($_POST['markaduzenleadmin'])){


$marka_ad = trim($_POST['marka_ad']);
$marka_seourl = seo($marka_ad);
$marka_id = $_POST['marka_id'];
$marka_keywords = trim($_POST['marka_keywords']);

$hazirla=$db->prepare("UPDATE markalar set


marka_ad=:marka_ad,
marka_seourl=:marka_seourl,
marka_keywords=:marka_keywords

where marka_id='$marka_id'
	");

$derle=$hazirla->execute(array(

"marka_ad" => htmlspecialchars($marka_ad),
"marka_seourl" => $marka_seourl,
"marka_keywords" => htmlspecialchars($marka_keywords)

));

if ($derle) {

	$hazirla=$db->prepare("UPDATE urunler set


marka_ad=:marka_ad

where marka_id='$marka_id'
	");

$derle=$hazirla->execute(array(

"marka_ad" => htmlspecialchars($marka_ad)

));
	
	echo "ok";
}


} else if (isset($_POST['markasil'])){

$marka_id=$_POST['marka_id'];

$markasil=$db->prepare("DELETE from markalar where marka_id=:id");
$silmarka=$markasil->execute(array(
"id" => $marka_id
));






if ($silmarka) {

	$anasayfamarkasil = $db->prepare("DELETE from anasayfamarkalar where marka_id=:id");
	$silanasayfamarka = $anasayfamarkasil->execute(array(
"id" => $marka_id
	));
	
	echo "ok";
}

} else if (isset($_POST['yorumsil'])){

$yorum_id=$_POST['yorum_id'];

$yorumsil=$db->prepare("DELETE from yorumlar where yorum_id=:id");
$silyorum=$yorumsil->execute(array(
"id" => $yorum_id
));






if ($silyorum) {
	
	echo "ok";
}

} else if (isset($_POST['yorumonayla'])){

$yorum_id=$_POST['yorum_id'];

$hazirla=$db->prepare("UPDATE yorumlar set
yorum_onay=:yorum_onay

where yorum_id='$yorum_id'
	");

$derle=$hazirla->execute(array(
"yorum_onay" => '1'

));






if ($derle) {
	
	echo "ok";
}

}  else if (isset($_POST['urunsil'])){

 $urun_id=$_POST['urun_id'];
 $hazirla=$db->prepare("UPDATE urunler set

urun_kaldirildi=:urun_kaldirildi

where urun_id='$urun_id'

 	");
 $derle=$hazirla->execute(array(
"urun_kaldirildi" => 1
 ));


 $hazirla2=$db->prepare("UPDATE anasayfalisteurun set

urun_kaldirildi=:urun_kaldirildi

where urun_id='$urun_id'

 	");
 $derle2=$hazirla2->execute(array(
"urun_kaldirildi" => 1
 ));

 $hazirla3=$db->prepare("UPDATE kampanyaurun set

urun_kaldirildi=:urun_kaldirildi

where urun_id='$urun_id'

 	");
 $derle3=$hazirla3->execute(array(
"urun_kaldirildi" => 1
 ));

 $hazirla4=$db->prepare("UPDATE urunkategori set

urun_kaldirildi=:urun_kaldirildi

where urun_id='$urun_id'

 	");
 $derle4=$hazirla4->execute(array(
"urun_kaldirildi" => 1
 ));

 $hazirla5=$db->prepare("UPDATE ilgiliurunler set

urun_kaldirildi=:urun_kaldirildi

where urun_id='$urun_id'

 	");

 $derle5=$hazirla5->execute(array(
"urun_kaldirildi" => 1
 ));

 

 $sepetitemsec=$db->prepare("SELECT * from sepetitem where urun_id='$urun_id'");
 $sepetitemsec->execute();
 while ($sepetitemcek=$sepetitemsec->fetch(PDO::FETCH_ASSOC)) {

 	$sepetitem_id=$sepetitemcek['sepetitem_id'];

    $sepetitemsil=$db->prepare("DELETE from sepetitem where sepetitem_id='$sepetitem_id'");
 $sepetitemsil->execute();

 $sepetitemseceneksil=$db->prepare("DELETE from sepetitemsecenekler where sepetitem_id='$sepetitem_id'");
 $sepetitemseceneksil->execute();

 }


 $urunseceneksil=$db->prepare("DELETE from urunsecenekler where urun_id=:id");
 $urunseceneksil->execute(array(
 	"id" => $urun_id
 ));

 $urunaltseceneksil=$db->prepare("DELETE from urunaltsecenekler where urun_id=:id");
 $urunaltseceneksil->execute(array(
 	"id" => $urun_id
 ));

 



 if ($derle) {

 	echo "ok";
 	
 }





} else if (isset($_POST['uyelersiralamaolcutudegistir'])){ 

$siralamaolcutu = $_POST['siralamaolcutu'];
 $kullanicitestsec=$db->prepare("SELECT * from kullanici where kullanici_yetki=:yetki and kullanici_ban=:ban");
   $kullanicitestsec->execute(array(

                            "yetki" => 1,
                            "ban" => 0

       ));

  $kullanicitestsay=$kullanicitestsec->rowCount();

  if ($kullanicitestsay==0) { ?>
  	
  	<h4 align="center">Henüz üye kaydı yok. Olduğunda burada gözükecek.</h4>

 <?php } else { 

 	$sayfa=1;
$kacar=30;
$sayfasayisi=ceil($kullanicitestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;


switch ($siralamaolcutu) {
	case 'kayitsondanbasa':

	
		
		  $kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_yetki=:yetki and kullanici_ban=:ban order by kullanici_kayitzaman DESC limit $baslangic,$kacar");
                          $kullanicisec->execute(array(

                            "yetki" => 1,
                            "ban" => 0

                          ));

		break;
	
	case 'kayitbastansona' :
		

  $kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_yetki=:yetki and kullanici_ban=:ban order by kullanici_kayitzaman ASC limit $baslangic,$kacar");
                          $kullanicisec->execute(array(

                            "yetki" => 1,
                            "ban" => 0

                          ));

		break;
}
	?>

	<div class="table-responsive">

 <table class="table table-striped jambo_table bulk_action">
                        <thead>
                          <tr class="headings">
                           
                            <th class="column-title">Kayıt Tarihi </th>
                            <th class="column-title">Ad & Soyad </th>
                            <th class="column-title">Sipariş Sayısı</th>
                            <th class="column-title"></th>
                            <th></th>
                            </th>
                            
                          </tr>
                        </thead>

                        <tbody>
                          
                          <?php 
                        

                          while ($kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC)) { 
                            
                            $kullanici_id=$kullanicicek['kullanici_id'];
                            $kullanici_zaman = $kullanicicek['kullanici_kayitzaman'];
                 $d = new DateTime($kullanici_zaman);
                 $zamanson =  $d->format('d/m/Y H:i');
                 $kullanici_id = $kullanicicek['kullanici_id'];

                 

                

                

                 

                 $kullanici_ad = $kullanicicek['kullanici_ad']." ".$kullanicicek['kullanici_soyad'];

                 ?>
                            
                          <tr class="even pointer kullanici_<?php echo $kullanici_id; ?>">
                           
                            <td><?php echo $zamanson; ?></td>
                            <td><?php echo $kullanici_ad; ?></td>
                            <td><?php echo $kullanicicek['kullanici_siparissayisi']; ?></td>
                           <td align="left"><a target="_blank" class="btn btn-success btn-sm btn-block" href="uye-detay?uye_id=<?php echo $kullanici_id; ?>">Detaylar</a></td>

                            
 
                            
                            <td align="right"><a class="btn btn-danger btn-sm kullanicisil" name="kullanici_<?php echo $kullanici_id; ?>" href="javascript:void(0);">Sil</a></td>
                            
                           
                          </tr>

                         <?php } ?>
                                 
                        
                        </tbody>
                      </table>

                  </div>

                  <?php if ($kullanicitestsay>$kacar) { ?>

                  	<div  class="pagination-wrapper">
						
							<div  class="GridLex-grid-middle GridLex-grid-noGutter">
								
								<div class="GridLex-col-12_sm-12_xs-12">
									<nav>
										<ul class="pagination pagination-text-center-sm mb-5-xs">
											<?php $p=0; if ($sayfa!=1) { ?>
												<li>
												<a href="javascript:void(0);" name='page_<?php echo $sayfa-1; ?>' aria-label="Previous">
													<span aria-hidden="true">&laquo;</span>
												</a>
											</li>
											<?php } ?>
											
											<?php while ($p<$sayfasayisi) { $p++;

											if ($p<=$sayfa+3 and $p>=$sayfa-3) {

											 ?>
												
												<li <?php if ($p==$sayfa) { ?>
													class="active"
												<?php } ?>><a href="javascript:void(0);" name="page_<?php echo $p; ?>"><?php echo $p; ?></a></li>

											<?php } } ?>

											<?php if ($sayfa!=$sayfasayisi) { ?>

												<li>
												<a href="javascript:void(0);" name="page_<?php echo $sayfa+1; ?>" aria-label="Next">
													<span aria-hidden="true">&raquo;</span>
												</a>
											</li>
												
											<?php } ?>
											
											
										</ul>
									</nav>

								</div>
							</div>

						</div>
                  	
                  <?php } ?>

                  <script type="text/javascript">


$('.kullanicisil').click(function(){

var buton = $(this);
var id1=$(this).attr("name");
     var kullanici_id=id1.substring(10);

              swal({
  title: "Bu üyeyi silmek istediğinize emin misiniz?",
  text: "Bu üyenin giriş yapması engellenecek ve yaptığı yorumlar silinecek.",
  icon: "warning",
  buttons: ["Vazgeç", "Sil"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

  	buton.html('Siliniyor...');

    $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'kullanicisiladmin':'ok','kullanici_id':kullanici_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

             if (sonuc=="ok") {


             	$('.kullanici_'+kullanici_id).remove();

             }

               }

             });


     }

     })

})

							$('.pagination li a').click(function(){


var id1=$(this).attr("name");
 var page=id1.substring(5);
var siralamaolcutu=$('#siralamaolcutu').val();
 $('.x_content').html('<h3 align="center">Yükleniyor...</h3>');

 $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : {'kullanicisiralamapaginationdegistir':'ok',"siralamaolcutu":siralamaolcutu,"page":page},
            success : function(sonuc){

            	sonuc=$.trim(sonuc);
            	 $('.x_content').html(sonuc);

            	 }

            	});
							})
						</script>


 <?php } ?>





<?php } else if (isset($_POST['kullanicisiralamapaginationdegistir'])){

	$siralamaolcutu = $_POST['siralamaolcutu'];
 $kullanicitestsec=$db->prepare("SELECT * from kullanici where kullanici_yetki=:yetki and kullanici_ban=:ban");
   $kullanicitestsec->execute(array(

                            "yetki" => 1,
                            "ban" => 0

       ));

  $kullanicitestsay=$kullanicitestsec->rowCount();

  if ($kullanicitestsay==0) { ?>
  	
  	<h4 align="center">Henüz üye kaydı yok. Olduğunda burada gözükecek.</h4>

 <?php } else { 

 	$sayfa=$_POST['page'];
$kacar=30;
$sayfasayisi=ceil($kullanicitestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;


switch ($siralamaolcutu) {
	case 'kayitsondanbasa':

	
		
		  $kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_yetki=:yetki and kullanici_ban=:ban order by kullanici_kayitzaman DESC limit $baslangic,$kacar");
                          $kullanicisec->execute(array(

                            "yetki" => 1,
                            "ban" => 0

                          ));

		break;
	
	case 'kayitbastansona' :
		

  $kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_yetki=:yetki and kullanici_ban=:ban order by kullanici_kayitzaman ASC limit $baslangic,$kacar");
                          $kullanicisec->execute(array(

                            "yetki" => 1,
                            "ban" => 0

                          ));

		break;
}
	?>

	<div class="table-responsive">

 <table class="table table-striped jambo_table bulk_action">
                        <thead>
                          <tr class="headings">
                           
                            <th class="column-title">Kayıt Tarihi </th>
                            <th class="column-title">Ad & Soyad </th>
                            <th class="column-title">Sipariş Sayısı</th>
                            <th class="column-title"></th>
                            <th></th>
                            </th>
                            
                          </tr>
                        </thead>

                        <tbody>
                          
                          <?php 
                        

                          while ($kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC)) { 
                            
                            $kullanici_id=$kullanicicek['kullanici_id'];
                            $kullanici_zaman = $kullanicicek['kullanici_kayitzaman'];
                 $d = new DateTime($kullanici_zaman);
                 $zamanson =  $d->format('d/m/Y H:i');
                 $kullanici_id = $kullanicicek['kullanici_id'];

                 

                

                

                 

                 $kullanici_ad = $kullanicicek['kullanici_ad']." ".$kullanicicek['kullanici_soyad'];

                 ?>
                            
                          <tr class="even pointer kullanici_<?php echo $kullanici_id; ?>">
                           
                            <td><?php echo $zamanson; ?></td>
                            <td><?php echo $kullanici_ad; ?></td>
                            <td><?php echo $kullanicicek['kullanici_siparissayisi']; ?></td>
                           <td align="left"><a target="_blank" class="btn btn-success btn-sm btn-block" href="uye-detay?uye_id=<?php echo $kullanici_id; ?>">Detaylar</a></td>

                            
 
                            
                            <td align="right"><a class="btn btn-danger btn-sm kullanicisil" name="kullanici_<?php echo $kullanici_id; ?>" href="javascript:void(0);">Sil</a></td>
                            
                           
                          </tr>

                         <?php } ?>
                                 
                        
                        </tbody>
                      </table>

                  </div>

                  <?php if ($kullanicitestsay>$kacar) { ?>

                  	<div  class="pagination-wrapper">
						
							<div  class="GridLex-grid-middle GridLex-grid-noGutter">
								
								<div class="GridLex-col-12_sm-12_xs-12">
									<nav>
										<ul class="pagination pagination-text-center-sm mb-5-xs">
											<?php $p=0; if ($sayfa!=1) { ?>
												<li>
												<a href="javascript:void(0);" name='page_<?php echo $sayfa-1; ?>' aria-label="Previous">
													<span aria-hidden="true">&laquo;</span>
												</a>
											</li>
											<?php } ?>
											
											<?php while ($p<$sayfasayisi) { $p++;

											if ($p<=$sayfa+3 and $p>=$sayfa-3) {

											 ?>
												
												<li <?php if ($p==$sayfa) { ?>
													class="active"
												<?php } ?>><a href="javascript:void(0);" name="page_<?php echo $p; ?>"><?php echo $p; ?></a></li>

											<?php } } ?>

											<?php if ($sayfa!=$sayfasayisi) { ?>

												<li>
												<a href="javascript:void(0);" name="page_<?php echo $sayfa+1; ?>" aria-label="Next">
													<span aria-hidden="true">&raquo;</span>
												</a>
											</li>
												
											<?php } ?>
											
											
										</ul>
									</nav>

								</div>
							</div>

						</div>
                  	
                  <?php } ?>

                  <script type="text/javascript">


$('.kullanicisil').click(function(){

var buton = $(this);
var id1=$(this).attr("name");
     var kullanici_id=id1.substring(10);

              swal({
  title: "Bu üyeyi silmek istiyor musunuz?",
  text: "Bu üyenin giriş yapması engellenecek ve yaptığı yorumlar silinecek.",
  icon: "warning",
  buttons: ["Vazgeç", "Sil"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

  	buton.html('Siliniyor...');

    $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'kullanicisiladmin':'ok','kullanici_id':kullanici_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

             if (sonuc=="ok") {


             	$('.kullanici_'+kullanici_id).remove();

             }

               }

             });


     }

     })

})

							$('.pagination li a').click(function(){


var id1=$(this).attr("name");
 var page=id1.substring(5);
var siralamaolcutu=$('#siralamaolcutu').val();
 $('.x_content').html('<h3 align="center">Yükleniyor...</h3>');

 $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : {'kullanicisiralamapaginationdegistir':'ok',"siralamaolcutu":siralamaolcutu,"page":page},
            success : function(sonuc){

            	sonuc=$.trim(sonuc);
            	 $('.x_content').html(sonuc);

            	 }

            	});
							})
						</script>







<?php } } else if (isset($_POST['titleduzenleadmin'])){

$ayar_title = trim($_POST['ayar_title']);

$hazirla=$db->prepare("UPDATE genelayarlar set

ayar_title=:ayar_title

	");

$derle=$hazirla->execute(array(

"ayar_title" => htmlspecialchars($ayar_title),

));

if ($derle) {
	
	echo "ok";
}

} else if (isset($_POST['yorumlarsiralamaolcutudegistir'])){ 


if ($_POST['yorumturu']=='tumu') {
	
	$query = "SELECT * from yorumlar";

} else {

	$yorumturu = $_POST['yorumturu'];
	$query = "SELECT * from yorumlar where yorum_onay='$yorumturu'";
}

$siralamaolcutu = $_POST['siralamaolcutu'];

if ($siralamaolcutu=='kayitsondanbasa') {
	
$query .= " order by yorum_zaman DESC ";

} else if ($siralamaolcutu=='kayitbastansona') {

	$query .= " order by yorum_zaman ASC ";
}







 $yorumtestsec=$db->prepare($query);
   $yorumtestsec->execute();

  $yorumtestsay=$yorumtestsec->rowCount();

  if ($yorumtestsay==0) { ?>
  	
  	<?php 

  	switch ($_POST['yorumturu']) {

  	 	case 'tumu': ?>

  	 	<h4 align="center">Henüz herhangi bir ürüne yorum yapılmamış.</h4>
  	 		
  	 		<?php break;

  	 		case '0': ?>

  	 	<h4 align="center">Onaylanmayan yorum bulunamadı.</h4>
  	 		
  	 		<?php break;

  	 		case '1': ?>

  	 	<h4 align="center">Onaylı yorum bulunamadı.</h4>
  	 		
  	 		<?php break;
  	 	
  	 	
  	 } ?>

 <?php } else { 

$sayfa=1;
$kacar=20;
$sayfasayisi=ceil($yorumtestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;

 $query .= " limit $baslangic,$kacar ";


$yorumsec=$db->prepare($query);
$yorumsec->execute();

 	?>

 	<div class="table-responsive">
                      <table class="table table-striped jambo_table bulk_action">
                        <thead>
                          <tr class="headings">
                           
                            <th class="column-title">Yorum Tarihi </th>
                            <th class="column-title">Üye </th>
                            <th class="column-title">Ürün </th>
                            <th style="text-align: center;" class="column-title">Yorum İçeriği</th>
                            <th></th>
                            </th>
                            
                          </tr>
                        </thead>

                        <tbody>
                          
                          <?php 
                         

                          while ($yorumcek=$yorumsec->fetch(PDO::FETCH_ASSOC)) { 
                            
                            $yorum_id=$yorumcek['yorum_id'];
                            $yorum_zaman = $yorumcek['yorum_zaman'];
                 $d = new DateTime($yorum_zaman);
                 $zamanson =  $d->format('d/m/Y H:i');
                 $kullanici_id = $yorumcek['kullanici_id'];

                 $kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_id=:id");
                 $kullanicisec->execute(array(

                  "id" => $kullanici_id
                 ));

                 $kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

                 $urunsec=$db->prepare("SELECT * from urunler where urun_id=:id");
                 $urunsec->execute(array(

                  "id" => $yorumcek['urun_id']
                ));

                 $uruncek=$urunsec->fetch(PDO::FETCH_ASSOC);

                 $urun_ad=$uruncek['urun_ad'];

                 $kullanici_ad = $kullanicicek['kullanici_ad']." ".substr($kullanicicek['kullanici_soyad'], 0,1).".";

                 ?>
                            
                          <tr class="even pointer">
                           
                            <td><?php echo $zamanson; ?></td>
                            <td><a target="_blank" href='uye-detay?uye_id=<?php echo $kullanici_id; ?>'><?php echo $kullanici_ad; ?></a></td>
                            <td><a target="_blank" href="../../urun-<?php echo seo($urun_ad)."-".$uruncek['urun_id']; ?>"><?php echo $urun_ad; ?></a></td>
                           <td align="left"><a data-toggle='modal' class="btn btn-primary btn-sm btn-block" href="#<?php echo $yorum_id; ?>">İncele</a></td>

                            <div class="modal fade" id="<?php   echo $yorum_id;  ?>"> 
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

      

        <div style="padding: 50px;" class="modal-body">

         <div class="row">
           
           <div class="col-md-12 col-xs-12 col-sm-12">
            <label>Üye</label>
             <input class="form-control" value="<?php echo $kullanicicek['kullanici_ad']." ".$kullanicicek['kullanici_soyad']; ?>" readonly="" type="text" name="">
           </div>

          

           <div  style="margin-top:20px;" class="col-md-12 col-xs-12 col-sm-12">
            <label>Ürün</label>
             <input class="form-control" value="<?php echo $urun_ad; ?>" readonly="" type="text" name="">
           </div>


           <div  style="margin-top:20px;" class="col-md-12 col-xs-12 col-sm-12">
            <label>Konu</label>
             <input class="form-control" value="<?php echo $yorumcek['yorum_konu']; ?>" readonly="" type="text" name="">
           </div>

          

           <div style="margin-top:20px;" class="col-md-12 col-xs-12 col-sm-12">
            <label>Yorum İçerik</label>
             <textarea readonly="" rows="10" class="form-control"><?php echo $yorumcek['yorum_icerik']; ?></textarea>
           </div>

         </div>

        </div>

     
       
    <div class="modal-footer">


  
    <a target="_blank" href="../../urun-<?php echo seo($urun_ad)."-".$uruncek['urun_id']; ?>" ><button class="btn btn-success">Ürün Sayfası</button></a>
    <button class="btn btn-success" data-dismiss="modal">OK</button>

    
</div>



  

     
    </div>

  </div>

</div>
 
                            
                            <td align="right">
                            	<?php if ($yorumcek['yorum_onay']=='1') { ?>

                            		<span style="color: green;margin-right: 5px;"><i class="fa fa-check"></i> Onaylı </span>

                            	<?php } else { ?>


                            		<a class="btn btn-success btn-sm yorumonayla" name="yorum_<?php echo $yorum_id; ?>" href="javascript:void(0);">Onayla</a>


                            	<?php } ?>
                            	<a class="btn btn-danger btn-sm yorumsil" name="yorum_<?php echo $yorum_id; ?>" href="javascript:void(0);">Sil</a>
                            </td>
                            
                           
                          </tr>

                         <?php } ?>
                                 
                        
                        </tbody>
                      </table>
                    </div>

                    <?php if ($yorumtestsay>$kacar) { ?>

                  	<div  class="pagination-wrapper">
						
							<div  class="GridLex-grid-middle GridLex-grid-noGutter">
								
								<div class="GridLex-col-12_sm-12_xs-12">
									<nav>
										<ul class="pagination pagination-text-center-sm mb-5-xs">
											<?php $p=0; if ($sayfa!=1) { ?>
												<li>
												<a href="javascript:void(0);" name='page_<?php echo $sayfa-1; ?>' aria-label="Previous">
													<span aria-hidden="true">&laquo;</span>
												</a>
											</li>
											<?php } ?>
											
											<?php while ($p<$sayfasayisi) { $p++;

											if ($p<=$sayfa+3 and $p>=$sayfa-3) {

											 ?>
												
												<li <?php if ($p==$sayfa) { ?>
													class="active"
												<?php } ?>><a href="javascript:void(0);" name="page_<?php echo $p; ?>"><?php echo $p; ?></a></li>

											<?php } } ?>

											<?php if ($sayfa!=$sayfasayisi) { ?>

												<li>
												<a href="javascript:void(0);" name="page_<?php echo $sayfa+1; ?>" aria-label="Next">
													<span aria-hidden="true">&raquo;</span>
												</a>
											</li>
												
											<?php } ?>
											
											
										</ul>
									</nav>

								</div>
							</div>

						</div>
                  	
                  <?php } ?>



<script type="text/javascript">

	$('.pagination li a').click(function(){


var id1=$(this).attr("name");
 var page=id1.substring(5);
var siralamaolcutu=$('#siralamaolcutu').val();
var yorumturu=$('#yorumturu').val();
 $('.x_content').html('<h3 align="center">Yükleniyor...</h3>');

 $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : {'yorumsiralamapaginationdegistir':'ok',"siralamaolcutu":siralamaolcutu,'yorumturu':yorumturu,"page":page},
            success : function(sonuc){

            	sonuc=$.trim(sonuc);
            	 $('.x_content').html(sonuc);

            	 }

            	});
							});


	$('.yorumsil').click(function(){
               
               var buton = $(this);
             var id1=$(this).attr("name");
                var yorum_id=id1.substring(6);

              swal({
  title: "Bu yorumu silmek istiyor musunuz?",
  icon: "warning",
  buttons: ["Vazgeç", "Sil"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

  	buton.html('Siliniyor...');

    $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'yorumsil':'ok','yorum_id':yorum_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              if (sonuc=="ok") {

                location.reload();
              }

               }

             });


     }

     })
         });


	$('.yorumonayla').click(function(){
               
               var buton = $(this);
             var id1=$(this).attr("name");
                var yorum_id=id1.substring(6);

              swal({
  title: "Bu yorumu onaylamak istiyor musunuz?",
  icon: "info",
  buttons: ["Vazgeç", "Onayla"]
})
.then((willDelete) => {
  if (willDelete) {

  	buton.html('Onaylanıyor...');

    $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'yorumonayla':'ok','yorum_id':yorum_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              if (sonuc=="ok") {

                location.reload();
              }

               }

             });


     }

     })
         }) 
	
	
</script>


	





<?php }  } else if (isset($_POST['yorumsiralamapaginationdegistir'])){

	if ($_POST['yorumturu']=='tumu') {
	
	$query = "SELECT * from yorumlar";

} else {

	$yorumturu = $_POST['yorumturu'];
	$query = "SELECT * from yorumlar where yorum_onay='$yorumturu'";
}

$siralamaolcutu = $_POST['siralamaolcutu'];

if ($siralamaolcutu=='kayitsondanbasa') {
	
$query .= " order by yorum_zaman DESC ";

} else if ($siralamaolcutu=='kayitbastansona') {

	$query .= " order by yorum_zaman ASC ";
}







 $yorumtestsec=$db->prepare($query);
   $yorumtestsec->execute();

  $yorumtestsay=$yorumtestsec->rowCount();

  if ($yorumtestsay==0) { ?>
  	
  	<?php 

  	switch ($_POST['yorumturu']) {

  	 	case 'tumu': ?>

  	 	<h4 align="center">Henüz herhangi bir ürüne yorum yapılmamış.</h4>
  	 		
  	 		<?php break;

  	 		case '0': ?>

  	 	<h4 align="center">Onaylanmayan yorum bulunamadı.</h4>
  	 		
  	 		<?php break;

  	 		case '1': ?>

  	 	<h4 align="center">Onaylı yorum bulunamadı.</h4>
  	 		
  	 		<?php break;
  	 	
  	 	
  	 } ?>

 <?php } else { 

$sayfa=$_POST['page'];
$kacar=20;
$sayfasayisi=ceil($yorumtestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;

 $query .= " limit $baslangic,$kacar ";


$yorumsec=$db->prepare($query);
$yorumsec->execute();

 	?>

 	<div class="table-responsive">
                      <table class="table table-striped jambo_table bulk_action">
                        <thead>
                          <tr class="headings">
                           
                            <th class="column-title">Yorum Tarihi </th>
                            <th class="column-title">Üye </th>
                            <th class="column-title">Ürün </th>
                            <th style="text-align: center;" class="column-title">Yorum İçeriği</th>
                            <th></th>
                            </th>
                            
                          </tr>
                        </thead>

                        <tbody>
                          
                          <?php 
                         

                          while ($yorumcek=$yorumsec->fetch(PDO::FETCH_ASSOC)) { 
                            
                            $yorum_id=$yorumcek['yorum_id'];
                            $yorum_zaman = $yorumcek['yorum_zaman'];
                 $d = new DateTime($yorum_zaman);
                 $zamanson =  $d->format('d/m/Y H:i');
                 $kullanici_id = $yorumcek['kullanici_id'];

                 $kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_id=:id");
                 $kullanicisec->execute(array(

                  "id" => $kullanici_id
                 ));

                 $kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

                 $urunsec=$db->prepare("SELECT * from urunler where urun_id=:id");
                 $urunsec->execute(array(

                  "id" => $yorumcek['urun_id']
                ));

                 $uruncek=$urunsec->fetch(PDO::FETCH_ASSOC);

                 $urun_ad=$uruncek['urun_ad'];

                 $kullanici_ad = $kullanicicek['kullanici_ad']." ".substr($kullanicicek['kullanici_soyad'], 0,1).".";

                 ?>
                            
                          <tr class="even pointer">
                           
                            <td><?php echo $zamanson; ?></td>
                            <td><a target="_blank" href='uye-detay?uye_id=<?php echo $kullanici_id; ?>'><?php echo $kullanici_ad; ?></a></td>
                            <td><a target="_blank" href="../../urun-<?php echo seo($urun_ad)."-".$uruncek['urun_id']; ?>"><?php echo $urun_ad; ?></a></td>
                           <td align="left"><a data-toggle='modal' class="btn btn-primary btn-sm btn-block" href="#<?php echo $yorum_id; ?>">İncele</a></td>

                            <div class="modal fade" id="<?php   echo $yorum_id;  ?>"> 
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

      

        <div style="padding: 50px;" class="modal-body">

         <div class="row">
           
           <div class="col-md-12 col-xs-12 col-sm-12">
            <label>Üye</label>
             <input class="form-control" value="<?php echo $kullanicicek['kullanici_ad']." ".$kullanicicek['kullanici_soyad']; ?>" readonly="" type="text" name="">
           </div>

          

           <div  style="margin-top:20px;" class="col-md-12 col-xs-12 col-sm-12">
            <label>Ürün</label>
             <input class="form-control" value="<?php echo $urun_ad; ?>" readonly="" type="text" name="">
           </div>


           <div  style="margin-top:20px;" class="col-md-12 col-xs-12 col-sm-12">
            <label>Konu</label>
             <input class="form-control" value="<?php echo $yorumcek['yorum_konu']; ?>" readonly="" type="text" name="">
           </div>

          

           <div style="margin-top:20px;" class="col-md-12 col-xs-12 col-sm-12">
            <label>Yorum İçerik</label>
             <textarea readonly="" rows="10" class="form-control"><?php echo $yorumcek['yorum_icerik']; ?></textarea>
           </div>

         </div>

        </div>

     
       
    <div class="modal-footer">


  
    <a target="_blank" href="../../urun-<?php echo seo($urun_ad)."-".$uruncek['urun_id']; ?>" ><button class="btn btn-success">Ürün Sayfası</button></a>
    <button class="btn btn-success" data-dismiss="modal">OK</button>

    
</div>



  

     
    </div>

  </div>

</div>
 
                            
                            <td align="right">
                            	<?php if ($yorumcek['yorum_onay']=='1') { ?>

                            		<span style="color: green;margin-right: 5px;"><i class="fa fa-check"></i> Onaylı </span>

                            	<?php } else { ?>


                            		<a class="btn btn-success btn-sm yorumonayla" name="yorum_<?php echo $yorum_id; ?>" href="javascript:void(0);">Onayla</a>


                            	<?php } ?>
                            	<a class="btn btn-danger btn-sm yorumsil" name="yorum_<?php echo $yorum_id; ?>" href="javascript:void(0);">Sil</a>
                            </td>
                            
                           
                          </tr>

                         <?php } ?>
                                 
                        
                        </tbody>
                      </table>
                    </div>

                    <?php if ($yorumtestsay>$kacar) { ?>

                  	<div  class="pagination-wrapper">
						
							<div  class="GridLex-grid-middle GridLex-grid-noGutter">
								
								<div class="GridLex-col-12_sm-12_xs-12">
									<nav>
										<ul class="pagination pagination-text-center-sm mb-5-xs">
											<?php $p=0; if ($sayfa!=1) { ?>
												<li>
												<a href="javascript:void(0);" name='page_<?php echo $sayfa-1; ?>' aria-label="Previous">
													<span aria-hidden="true">&laquo;</span>
												</a>
											</li>
											<?php } ?>
											
											<?php while ($p<$sayfasayisi) { $p++;

											if ($p<=$sayfa+3 and $p>=$sayfa-3) {

											 ?>
												
												<li <?php if ($p==$sayfa) { ?>
													class="active"
												<?php } ?>><a href="javascript:void(0);" name="page_<?php echo $p; ?>"><?php echo $p; ?></a></li>

											<?php } } ?>

											<?php if ($sayfa!=$sayfasayisi) { ?>

												<li>
												<a href="javascript:void(0);" name="page_<?php echo $sayfa+1; ?>" aria-label="Next">
													<span aria-hidden="true">&raquo;</span>
												</a>
											</li>
												
											<?php } ?>
											
											
										</ul>
									</nav>

								</div>
							</div>

						</div>
                  	
                  <?php } ?>



<script type="text/javascript">

	$('.pagination li a').click(function(){


var id1=$(this).attr("name");
 var page=id1.substring(5);
var siralamaolcutu=$('#siralamaolcutu').val();
var yorumturu=$('#yorumturu').val();
 $('.x_content').html('<h3 align="center">Yükleniyor...</h3>');

 $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : {'yorumsiralamapaginationdegistir':'ok',"siralamaolcutu":siralamaolcutu,'yorumturu':yorumturu,"page":page},
            success : function(sonuc){

            	sonuc=$.trim(sonuc);
            	 $('.x_content').html(sonuc);

            	 }

            	});
							});


	$('.yorumsil').click(function(){
               
               var buton = $(this);
             var id1=$(this).attr("name");
                var yorum_id=id1.substring(6);

              swal({
  title: "Bu yorumu silmek istiyor musunuz?",
  icon: "warning",
  buttons: ["Vazgeç", "Sil"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

  	buton.html('Siliniyor...');

    $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'yorumsil':'ok','yorum_id':yorum_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              if (sonuc=="ok") {

                location.reload();
              }

               }

             });


     }

     })
         });


	$('.yorumonayla').click(function(){
               
               var buton = $(this);
             var id1=$(this).attr("name");
                var yorum_id=id1.substring(6);

              swal({
  title: "Bu yorumu onaylamak istiyor musunuz?",
  icon: "info",
  buttons: ["Vazgeç", "Onayla"]
})
.then((willDelete) => {
  if (willDelete) {

  	buton.html('Onaylanıyor...');

    $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'yorumonayla':'ok','yorum_id':yorum_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              if (sonuc=="ok") {

                location.reload();
              }

               }

             });


     }

     })
         }) 
	
	
</script>


	





<?php }  } else if (isset($_POST['urunduzenleadmin'])){

$urun_id = $_POST['urun_id'];
$urun_ad = htmlspecialchars(trim($_POST['urun_ad']));
if (empty($_POST['urun_fiyat'])) { 

	$urun_fiyat = NULL;
	$urun_indirim = 0;
	$urun_nihaifiyat = $_POST['urun_indirimsizfiyat'];

 } else {

 	$urun_fiyat = $_POST['urun_fiyat'];
 	$urun_indirim = 1;
 	$urun_nihaifiyat = $_POST['urun_fiyat'];
 }

 $urunsec=$db->prepare("SELECT * from urunler where urun_id='$urun_id'");
   $urunsec->execute();

   $uruncek=$urunsec->fetch(PDO::FETCH_ASSOC);

   $urun_oncekikategori = $uruncek['kategori_id'];
   $urun_zaman = $uruncek['urun_zaman'];

   
$urun_indirimsizfiyat = $_POST['urun_indirimsizfiyat'];
$urun_stok = $_POST['urun_stok'];
$urun_marka = $_POST['urun_marka'];
$markasec = $db->prepare("SELECT * from markalar where marka_id='$urun_marka'");
$markasec->execute();
$markacek = $markasec->fetch(PDO::FETCH_ASSOC);
$marka_ad = $markacek['marka_ad'];
$urun_desi = $_POST['urun_desi'];
$urun_cinsiyet = $_POST['urun_cinsiyet'];
if (empty(trim($_POST['urun_video']))) {
	
	$urun_video = NULL;

} else {

	$urun_video = trim($_POST['urun_video']);
};
$urun_kategori = $_POST['urun_kategori'];
$kategorisec=$db->prepare("SELECT * from kategoriler where kategori_id=:id");
$kategorisec->execute(array(
"id" => $urun_ustkategori
));
$kategoricek=$kategorisec->fetch(PDO::FETCH_ASSOC);
$urun_aciklama = $_POST['urun_aciklama'];
$urun_seourl = seo($urun_ad);
$urun_ozellikler = $_POST['ozellik_baslik'];
$ozellik_icerikler = $_POST['ozellik_icerik'];

$hazirla=$db->prepare("UPDATE urunler set

urun_ad=:urun_ad,
urun_fiyat=:urun_fiyat,
urun_indirim=:urun_indirim,
urun_indirimsizfiyat=:urun_indirimsizfiyat,
urun_stok=:urun_stok,
marka_id=:marka_id,
marka_ad=:marka_ad,
urun_desi=:urun_desi,
urun_video=:urun_video,
urun_nihaifiyat=:urun_nihaifiyat,
urun_cinsiyet=:urun_cinsiyet,
kategori_id=:kategori_id,
urun_aciklama=:urun_aciklama,
urun_seourl=:urun_seourl

where urun_id='$urun_id'

	");

$derle=$hazirla->execute(array(

"urun_ad" => htmlspecialchars($urun_ad),
"urun_fiyat" => $urun_fiyat,
"urun_indirim" => $urun_indirim,
"urun_indirimsizfiyat" => $urun_indirimsizfiyat,
"urun_nihaifiyat" => $urun_nihaifiyat,
"urun_stok" => $urun_stok,
"kategori_id" => $urun_kategori,
"urun_cinsiyet" => $urun_cinsiyet,
"marka_id" => $urun_marka,
"marka_ad" => $marka_ad,
"urun_desi" => $urun_desi,
"urun_video" => $urun_video,
"urun_aciklama" => $urun_aciklama,
"urun_seourl" => $urun_seourl

));



if ($derle) {


	
		
		
	

   

   if ($urun_kategori!=$urun_oncekikategori) {
   	
   	$urunkategorisil=$db->prepare("DELETE from urunkategori where urun_id=:id");
	$urunkategorisil->execute(array(
		"id" => $urun_id
	));


	$sayy=0;

while ($sayy<10) {
	
	$sayy++;

	$hazirla=$db->prepare("INSERT into urunkategori set

urun_id=:urun_id,
kategori_id=:kategori_id,
marka_id=:marka_id,
urun_indirim=:urun_indirim,
urun_cinsiyet=:urun_cinsiyet,
urun_nihaifiyat=:urun_nihaifiyat,
urun_ad=:urun_ad,
urun_zaman=:urun_zaman

		");

	$derle=$hazirla->execute(array(

"urun_id" => $urun_id,
"kategori_id" => $urun_kategori,
"marka_id" => $urun_marka,
"urun_indirim" => $urun_indirim,
"urun_cinsiyet" => $urun_cinsiyet,
"urun_nihaifiyat" => $urun_nihaifiyat,
"urun_ad" => $urun_ad,
"urun_zaman" => $urun_zaman

	));

	$kategorisec=$db->prepare("SELECT * from kategoriler where kategori_id='$urun_kategori'");
	$kategorisec->execute();

	$kategoricek=$kategorisec->fetch(PDO::FETCH_ASSOC);

	$urun_kategori=$kategoricek['kategori_ust'];

	if ($urun_kategori==0) {
	
	break;
	
	}


}



   } else {


$hazirla=$db->prepare("UPDATE urunkategori set

marka_id=:marka_id,
urun_indirim=:urun_indirim,
urun_cinsiyet=:urun_cinsiyet,
urun_nihaifiyat=:urun_nihaifiyat,
urun_ad=:urun_ad

where urun_id='$urun_id'

			");

		$derle=$hazirla->execute(array(

"marka_id" => $urun_marka,
"urun_indirim" => $urun_indirim,
"urun_cinsiyet" => $urun_cinsiyet,
"urun_nihaifiyat" => $urun_nihaifiyat,
"urun_ad" => $urun_ad

		));

   }


	$urunozelliksil=$db->prepare("DELETE from urunozellik where urun_id=:id");
	$urunozelliksil->execute(array(
		"id" => $urun_id
	));

	
	if (count($urun_ozellikler)!=0) { 
		
		$ozelliksay = 0;

foreach ($urun_ozellikler as $ozellik) {

	if (!empty(trim($ozellik))) {
		
		$ozellik_icerik = $ozellik_icerikler[$ozelliksay];

	$hazirla=$db->prepare("INSERT into urunozellik set

urun_id=:urun_id,
ozellik_baslik=:ozellik_baslik,
ozellik_icerik=:ozellik_icerik
		");

	$derle=$hazirla->execute(array(
		"urun_id" => $urun_id,
	    "ozellik_baslik" => htmlspecialchars(trim($ozellik)),
         "ozellik_icerik" => htmlspecialchars(trim($ozellik_icerik))

	));

	}
	
	$ozelliksay++;
}
	}


    

	
	$urunseceneklersil=$db->prepare("DELETE from urunsecenekler where urun_id=:id");
	$urunseceneklersil->execute(array(
		"id" => $urun_id
	));

	$urunaltseceneklersil=$db->prepare("DELETE from urunaltsecenekler where urun_id=:id");
	$urunaltseceneklersil->execute(array(
		"id" => $urun_id
	));


	$tumseceneklersec=$db->prepare("SELECT * from secenekler");
$tumseceneklersec->execute();

while ($tumseceneklercek=$tumseceneklersec->fetch(PDO::FETCH_ASSOC)) {
	
	$secenek_id = $tumseceneklercek['secenek_id'];

	$seceneksayisi = count($_POST['secenek_id_'.$secenek_id]);

	if ($seceneksayisi!=0) {
		
		$hazirla=$db->prepare("INSERT into urunsecenekler set

urun_id=:urun_id,
secenek_id=:secenek_id
			");

		$derle=$hazirla->execute(array(
"urun_id" => $urun_id,
"secenek_id" => $secenek_id

		));

		$seceneksecim = $_POST['secenek_id_'.$secenek_id];

		foreach ($seceneksecim as $altsecenek_id) {
			
			$altseceneksec=$db->prepare("SELECT * from altsecenekler where altsecenek_id='$altsecenek_id'");
			$altseceneksec->execute();
			$altsecenekcek=$altseceneksec->fetch(PDO::FETCH_ASSOC);

			$altsecenek_ad = $altsecenekcek['altsecenek_ad'];

			$hazirla=$db->prepare("INSERT into urunaltsecenekler set

secenek_id=:secenek_id,
altsecenek_ad=:altsecenek_ad,
urun_id=:urun_id
				");

			$derle=$hazirla->execute(array(
"secenek_id" => $secenek_id,
"altsecenek_ad" => $altsecenek_ad,
"urun_id" => $urun_id
			));

		}
	}


}






	echo "ok";


}



} else if (isset($_POST['sosyalmedyaduzenle'])){

$ayar_facebook = trim($_POST['ayar_facebook']);
$ayar_youtube = trim($_POST['ayar_youtube']);
$ayar_instagram = trim($_POST['ayar_instagram']);
$ayar_twitter = trim($_POST['ayar_twitter']);
$ayar_ios = trim($_POST['ayar_ios']);
$ayar_googleplay = trim($_POST['ayar_googleplay']);

$hazirla=$db->prepare("UPDATE genelayarlar set

ayar_facebook=:ayar_facebook,
ayar_instagram=:ayar_instagram,
ayar_twitter=:ayar_twitter,
ayar_youtube=:ayar_youtube,
ayar_ios=:ayar_ios,
ayar_googleplay=:ayar_googleplay

	");

$derle=$hazirla->execute(array(
"ayar_facebook" => htmlspecialchars($ayar_facebook),
"ayar_youtube" => htmlspecialchars($ayar_youtube),
"ayar_instagram" => htmlspecialchars($ayar_instagram),
"ayar_twitter" => htmlspecialchars($ayar_twitter),
"ayar_ios" => htmlspecialchars($ayar_ios),
"ayar_googleplay" => htmlspecialchars($ayar_googleplay)
));

if ($derle) {
	
	echo "ok";
}

 } else if (isset($_POST['sanalposduzenleadmin'])){

$ayar_iyziclientid = trim($_POST['ayar_iyziclientid']);
$ayar_iyzisecretkey = trim($_POST['ayar_iyzisecretkey']);

$hazirla=$db->prepare("UPDATE genelayarlar set

ayar_iyziclientid=:ayar_iyziclientid,
ayar_iyzisecretkey=:ayar_iyzisecretkey

	");

$derle=$hazirla->execute(array(
"ayar_iyziclientid" => htmlspecialchars($ayar_iyziclientid),
"ayar_iyzisecretkey" => htmlspecialchars($ayar_iyzisecretkey)
));

if ($derle) {
	
	echo "ok";
}

 } else if (isset($_POST['referansgalerireload'])){



$referanssec=$db->prepare("SELECT * from referanslar");
$referanssec->execute();


 ?>

<div class="row">

	
 <input type="hidden" value="<?php echo $calisma_id; ?>" id="calisma_id" name="">


<?php 

          while ($referanscek=$referanssec->fetch(PDO::FETCH_ASSOC)) { 
            
            $referans_logo = $referanscek['referans_logo'];
            $referans_id = $referanscek['referans_id'];

           
             ?>

            <div style="margin-bottom:50px;" class="col-md-3 col-sm-3 col-xs-12">
              
               <div style="position: relative;" class="col-md-12 col-sm-12 col-xs-12 image">
                <a class="referanslogosil" name="referans_<?php echo $referans_id; ?>" href="javascript:void(0);"><i class="fa fa-times-circle" style="position: absolute;top:-5px;right: 5px;font-size:20px;color:red;"></i></a>
                 <img style="height: 120px;width: 150px;" class="img-responsive" src="../../<?php echo $referans_logo; ?>">
               </div>
              
             </div>

            <?php } ?>

            <div style="margin-bottom:50px;" class="col-md-3 col-sm-3 col-xs-12">
              
               <div style="position: relative;border:1px dashed;height: 200px;" class="col-md-12 col-sm-12 col-xs-12 imageadd">

                <div class="col-md-12 col-xs-12 col-sm-12" style="height: 130px;">
                  <h3 align="center">Yükle <i class="fa fa-upload"></i></h3>
                  <p style="font-size:14px;" align="center">Yeni referans logosu yüklemek için aşağıdan resmi seçin veya sürükleyip bırakın.</p>
                </div>
                
                 <input style="height: 55px;" class="form-control referanslogoekle" type="file"   name="">
               </div>
              
             </div>


</div>

<script type="text/javascript">

	$('.referanslogosil').click(function(){

          var id1=$(this).attr("name");
                var referans_id=id1.substring(9);
                

                swal({
  title: "Emin misiniz?",
  text: "Bu referans logosunu silmek istiyor musunuz?",
  icon: "warning",
  buttons: ["Vazgeç", "Sil"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

    $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'referanslogosil':'ok','referans_id':referans_id},
            success : function(sonuc){

              $('.x_content').html('<h3 align="center">Yükleniyor...</h3>');

               $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'referansgalerireload':'ok'},
            success : function(sonuc){

             var sonuc = $.trim(sonuc);
              
              $('.x_content').html(sonuc);

              

               }

             });
              


               }

             });


     }

     });
         });
	

$('.referanslogoekle').change(function(){

          var input = $(this);
            
           
       
      var foto = $(this).val();
      var filevalue = $(this).get(0).files[0];

      if (foto.length!=0) {

        swal({
  title: "Emin misiniz?",
  text: "Bu logo referans galerisine eklenecek.",
  icon: "info",
  buttons: ["Vazgeç", "Ekle"]
})
.then((willDelete) => {
  if (willDelete) {


    var fotouzanti=foto.split('.').pop();

      

      var data = new FormData();
      data.append('referanslogoekle',"ok");
      data.append("file",filevalue);
    

      if (fotouzanti!='jpg' && fotouzanti!='jpeg' && fotouzanti!='png'){


           swal({

  title: "Bilgi",
  text: "Sadece .jpg, .jpeg, .png uzantılı dosyaları yükleyebilirsiniz.",
  icon: "info",
  button: "OK",
});


               } else {

                $('.imageadd').html('<h3 style="margin-top:80px;" align="center">Ekleniyor...</h3>');

               $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            enctype : 'multipart/form-data',
            data : data,
            processData: false,
            contentType: false,
            cache: false,
            success : function(sonuc){

            sonuc=$.trim(sonuc);

           if (sonuc=="ok") {

 $('.x_content').html('<h3 align="center">Yükleniyor...</h3>');

              

               $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'referansgalerireload':'ok'},
            success : function(sonuc){

             var sonuc = $.trim(sonuc);
              
              $('.x_content').html(sonuc);

              

               }

             });

 
           } else {

            location.reload();
           }

             }

          })

                 }



     }

     })

        
      
        }

         })

</script>

 

<?php } else if (isset($_POST['referanslogoekle'])){

$name=$_FILES['file']['name'];
$uzanti=ext($_FILES['file']['name']);
$tmpname=$_FILES['file']['tmp_name'];
$depodosya = 'dimg/referanslogo';




	$uniq=uniqid();
	$refimgyol=$depodosya."/".$uniq.".".$uzanti;
	@move_uploaded_file($tmpname, "$depodosya/$uniq.$uzanti");

	$hazirla=$db->prepare("INSERT into referanslar set

referans_logo=:referans_logo


		");

	$derle=$hazirla->execute(array(

"referans_logo" => $refimgyol

));

	if ($derle) {
		
		echo "ok";
	}




} else if (isset($_POST['iadelersiralamaolcutudegistir'])){

$siralamaolcutu = $_POST['siralamaolcutu'];
$sort = $_POST['sort'];
$sayfa=1;
$kacar=30;

if ($sort=='yenideneskiye') {
	
	$orderby = 'order by iade_tarihi DESC';

} else {

	$orderby = 'order by iade_tarihi ASC';
}

switch ($siralamaolcutu) {

	 case 'cevapbekleyen':
		
   $iadetestsec=$db->prepare("SELECT * from siparisitem where urun_iade='1'");
   $iadetestsec->execute();
   $iadetestsay=$iadetestsec->rowCount();
   $sayfasayisi=ceil($iadetestsay/$kacar);
   $baslangic=($kacar*$sayfa)-$kacar;
   $iadesec=$db->prepare("SELECT * from siparisitem where urun_iade='1' $orderby limit $baslangic,$kacar");
   $iadesec->execute();

   if ($iadetestsay==0) {
   	echo '<h4 align="center">Cevap bekleyen iade talebi yok. Olduğunda burada gözükecek.</h4>';
   	exit;
   }

     break;

     case 'iadekabul':
		
		 $iadetestsec=$db->prepare("SELECT * from siparisitem where urun_iade='2'");
   $iadetestsec->execute();
   $iadetestsay=$iadetestsec->rowCount();
   $sayfasayisi=ceil($iadetestsay/$kacar);
   $baslangic=($kacar*$sayfa)-$kacar;
   $iadesec=$db->prepare("SELECT * from siparisitem where urun_iade='2' $orderby limit $baslangic,$kacar");
   $iadesec->execute();
   if ($iadetestsay==0) {
   	echo '<h4 align="center">Kabul edilen iade talebi yok. Olduğunda burada gözükecek.</h4>';
   	exit;
   }

     break;

     case 'iadered':
		
		 $iadetestsec=$db->prepare("SELECT * from siparisitem where urun_iade='3'");
   $iadetestsec->execute();
   $iadetestsay=$iadetestsec->rowCount();
   $sayfasayisi=ceil($iadetestsay/$kacar);
   $baslangic=($kacar*$sayfa)-$kacar;
   $iadesec=$db->prepare("SELECT * from siparisitem where urun_iade='3' $orderby limit $baslangic,$kacar");
   $iadesec->execute();
   if ($iadetestsay==0) {
   	echo '<h4 align="center">Reddedilen iade talebi yok. Olduğunda burada gözükecek.</h4>';
   	exit;
   }

     break;
	
	
} ?>


<div class="table-responsive">
                      <table class="table table-striped jambo_table bulk_action">
                        <thead>
                          <tr class="headings">
                            
                            <th class="column-title">İade Tarihi</th>
                            <th class="column-title">Müşteri</th>
                            <th class="column-title">Ürün </th>
                            <th class="column-title">İade Adedi </th>
                            <th class="column-title">Birim Fiyat</th>
                            <th class="column-title">İade Tutarı</th>
                            <th class="column-title">Sipariş</th>
                            <th></th>

                            
                            
                            
                            
                            
                          </tr>
                        </thead>

                        <tbody>
                          
                          <?php 
                         
                        


                          while ($iadecek=$iadesec->fetch(PDO::FETCH_ASSOC)) { 

                            $siparisitem_id=$iadecek['siparisitem_id'];
                       $iade_zaman = $iadecek['iade_tarihi'];
                       $d = new DateTime($iade_zaman);
                        $zamanson =  $d->format('d/m/Y H:i');
                        $urun_id = $iadecek['urun_id'];
                        $kullanici_id = $iadecek['kullanici_id'];

                        $urunsec=$db->prepare("SELECT * from urunler where urun_id='$urun_id'");
                        $urunsec->execute();
                        $uruncek=$urunsec->fetch(PDO::FETCH_ASSOC);

                        $iade_miktar = $iadecek['iade_miktar'];
                        $iade_tutar = $iadecek['iade_tutar'];

                        $siparisitemseceneksec = $db->prepare("SELECT * from siparisitemsecenekler where siparisitem_id='$siparisitem_id'");

                          $siparisitemseceneksec->execute();

                        $urun_ad = $uruncek['urun_ad'];
                      
                      $siparis_id = $iadecek['siparis_id'];

                      $urun_fiyat=$iadecek['urun_fiyat'];
                      $urun_miktar=$iadecek['urun_miktar'];
                      $urun_toplam=$iadecek['urun_toplam'];
                      $kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_yetki=:yetki and kullanici_id=:id");
                      $kullanicisec->execute(array(
                        "yetki" => 1,
                        "id" => $kullanici_id
                      ));

                      $kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

                      $kullanici_ad = $kullanicicek['kullanici_ad']." ".substr($kullanicicek['kullanici_soyad'], 0,1).".";

                
                            ?>
                            
                          <tr class="even pointer">
                          	
                          	<td><?php echo $zamanson ?></td>
                          	<td><a target="_blank" href="uye-detay?uye_id=<?php echo $kullanici_id; ?>"><?php echo $kullanici_ad; ?></a></td>
                          	<td><a target="_blank" href='../../urun-<?php echo seo($urun_ad)."-".$uruncek['urun_id']; ?>'><?php if (strlen($urun_ad)>85) { ?>
              <?php echo substr($urun_ad,0,85)."..."; ?>
            <?php } else { 

                         echo $urun_ad; 
             } ?></a><br>

           <?php while ($siparisitemsecenekcek=$siparisitemseceneksec->fetch(PDO::FETCH_ASSOC)) { 
                $secenek_ad = $siparisitemsecenekcek['secenek_ad'];
                $altsecenek_ad = $siparisitemsecenekcek['altsecenek_ad']; ?> 


                <?php echo $secenek_ad." : ".$altsecenek_ad."<br>"; ?>
                            

              <?php } ?></td>
                          	<td><?php echo $iade_miktar; ?></td>
                          	<td>₺ <?php echo $urun_fiyat; ?></td>
                          	<td>₺ <?php echo $iade_tutar; ?></td>
                          	<td><a target="_blank" class="btn btn-xs btn-success" href="siparis-detay?siparis_id=<?php echo $siparis_id; ?>">Siparişi Gör</a></td>
                          	<td><a target="_blank" class="btn btn-xs btn-primary" href="iade-detay?siparisurun=<?php echo $siparisitem_id; ?>">İade Detayları</a></td>
                          

                          </tr>

                         <?php } ?>
                                 
                        
                        </tbody>
                      </table>
                    </div>

                    <?php if ($iadetestsay>$kacar) { ?>

                  	<div  class="pagination-wrapper">
						
							<div  class="GridLex-grid-middle GridLex-grid-noGutter">
								
								<div class="GridLex-col-12_sm-12_xs-12">
									<nav>
										<ul class="pagination pagination-text-center-sm mb-5-xs">
											<?php $p=0; if ($sayfa!=1) { ?>
												<li>
												<a href="javascript:void(0);" name='page_<?php echo $sayfa-1; ?>' aria-label="Previous">
													<span aria-hidden="true">&laquo;</span>
												</a>
											</li>
											<?php } ?>
											
											<?php while ($p<$sayfasayisi) { $p++;

											if ($p<=$sayfa+3 and $p>=$sayfa-3) {

											 ?>
												
												<li <?php if ($p==$sayfa) { ?>
													class="active"
												<?php } ?>><a href="javascript:void(0);" name="page_<?php echo $p; ?>"><?php echo $p; ?></a></li>

											<?php } } ?>

											<?php if ($sayfa!=$sayfasayisi) { ?>

												<li>
												<a href="javascript:void(0);" name="page_<?php echo $sayfa+1; ?>" aria-label="Next">
													<span aria-hidden="true">&raquo;</span>
												</a>
											</li>
												
											<?php } ?>
											
											
										</ul>
									</nav>

								</div>
							</div>

						</div>
                  	
                  <?php } ?>

                  <script type="text/javascript">
                  	
                  	$('.pagination li a').click(function(){


var id1=$(this).attr("name");
 var page=id1.substring(5);
var siralamaolcutu=$('#siralamaolcutu').val();
var sort = $('#sort').val();
 $('.x_content').html('<h3 align="center">Yükleniyor...</h3>');

 $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : {'iadelersiralamapaginationdegistir':'ok',"siralamaolcutu":siralamaolcutu,'sort':sort,"page":page},
            success : function(sonuc){

            	sonuc=$.trim(sonuc);
            	 $('.x_content').html(sonuc);

            	 }

            	});
							});

                  </script>


<?php } else if (isset($_POST['iadelersiralamapaginationdegistir'])){

$siralamaolcutu = $_POST['siralamaolcutu'];
$sort = $_POST['sort'];
$sayfa=$_POST['page'];
$kacar=30;

if ($sort=='yenideneskiye') {
	
	$orderby = 'order by iade_tarihi DESC';

} else {

	$orderby = 'order by iade_tarihi ASC';
}

switch ($siralamaolcutu) {

	 case 'cevapbekleyen':
		
   $iadetestsec=$db->prepare("SELECT * from siparisitem where urun_iade='1'");
   $iadetestsec->execute();
   $iadetestsay=$iadetestsec->rowCount();
   $sayfasayisi=ceil($iadetestsay/$kacar);
   $baslangic=($kacar*$sayfa)-$kacar;
   $iadesec=$db->prepare("SELECT * from siparisitem where urun_iade='1' $orderby limit $baslangic,$kacar");
   $iadesec->execute();

   if ($iadetestsay==0) {
   	echo '<h4 align="center">Cevap bekleyen iade talebi yok. Olduğunda burada gözükecek.</h4>';
   	exit;
   }

     break;

     case 'iadekabul':
		
		 $iadetestsec=$db->prepare("SELECT * from siparisitem where urun_iade='2'");
   $iadetestsec->execute();
   $iadetestsay=$iadetestsec->rowCount();
   $sayfasayisi=ceil($iadetestsay/$kacar);
   $baslangic=($kacar*$sayfa)-$kacar;
   $iadesec=$db->prepare("SELECT * from siparisitem where urun_iade='2' $orderby limit $baslangic,$kacar");
   $iadesec->execute();
   if ($iadetestsay==0) {
   	echo '<h4 align="center">Kabul edilen iade talebi yok. Olduğunda burada gözükecek.</h4>';
   	exit;
   }

     break;

     case 'iadered':
		
		 $iadetestsec=$db->prepare("SELECT * from siparisitem where urun_iade='3'");
   $iadetestsec->execute();
   $iadetestsay=$iadetestsec->rowCount();
   $sayfasayisi=ceil($iadetestsay/$kacar);
   $baslangic=($kacar*$sayfa)-$kacar;
   $iadesec=$db->prepare("SELECT * from siparisitem where urun_iade='3' $orderby limit $baslangic,$kacar");
   $iadesec->execute();
   if ($iadetestsay==0) {
   	echo '<h4 align="center">Reddedilen iade talebi yok. Olduğunda burada gözükecek.</h4>';
   	exit;
   }

     break;
	
	
} ?>


<div class="table-responsive">
                      <table class="table table-striped jambo_table bulk_action">
                        <thead>
                          <tr class="headings">
                            
                            <th class="column-title">İade Tarihi</th>
                            <th class="column-title">Müşteri</th>
                            <th class="column-title">Ürün </th>
                            <th class="column-title">İade Adedi </th>
                            <th class="column-title">Birim Fiyat</th>
                            <th class="column-title">İade Tutarı</th>
                            <th class="column-title">Sipariş</th>
                            <th></th>

                            
                            
                            
                            
                            
                          </tr>
                        </thead>

                        <tbody>
                          
                          <?php 
                         
                        


                          while ($iadecek=$iadesec->fetch(PDO::FETCH_ASSOC)) { 

                            $siparisitem_id=$iadecek['siparisitem_id'];
                       $iade_zaman = $iadecek['iade_tarihi'];
                       $d = new DateTime($iade_zaman);
                        $zamanson =  $d->format('d/m/Y H:i');
                        $urun_id = $iadecek['urun_id'];
                        $kullanici_id = $iadecek['kullanici_id'];

                        $urunsec=$db->prepare("SELECT * from urunler where urun_id='$urun_id'");
                        $urunsec->execute();
                        $uruncek=$urunsec->fetch(PDO::FETCH_ASSOC);

                        $iade_miktar = $iadecek['iade_miktar'];
                        $iade_tutar = $iadecek['iade_tutar'];

                        $siparisitemseceneksec = $db->prepare("SELECT * from siparisitemsecenekler where siparisitem_id='$siparisitem_id'");

                          $siparisitemseceneksec->execute();

                        $urun_ad = $uruncek['urun_ad'];
                      
                      $siparis_id = $iadecek['siparis_id'];

                      $urun_fiyat=$iadecek['urun_fiyat'];
                      $urun_miktar=$iadecek['urun_miktar'];
                      $urun_toplam=$iadecek['urun_toplam'];
                      $kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_yetki=:yetki and kullanici_id=:id");
                      $kullanicisec->execute(array(
                        "yetki" => 1,
                        "id" => $kullanici_id
                      ));

                      $kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

                      $kullanici_ad = $kullanicicek['kullanici_ad']." ".substr($kullanicicek['kullanici_soyad'], 0,1).".";

                
                            ?>
                            
                          <tr class="even pointer">
                          	
                          	<td><?php echo $zamanson ?></td>
                          	<td><a target="_blank" href="uye-detay?uye_id=<?php echo $kullanici_id; ?>"><?php echo $kullanici_ad; ?></a></td>
                          	<td><a target="_blank" href='../../urun-<?php echo seo($urun_ad)."-".$uruncek['urun_id']; ?>'><?php if (strlen($urun_ad)>85) { ?>
              <?php echo substr($urun_ad,0,85)."..."; ?>
            <?php } else { 

                         echo $urun_ad; 
             } ?></a><br>

           <?php while ($siparisitemsecenekcek=$siparisitemseceneksec->fetch(PDO::FETCH_ASSOC)) { 
                $secenek_ad = $siparisitemsecenekcek['secenek_ad'];
                $altsecenek_ad = $siparisitemsecenekcek['altsecenek_ad']; ?> 


                <?php echo $secenek_ad." : ".$altsecenek_ad."<br>"; ?>
                            

              <?php } ?></td>
                          	<td><?php echo $iade_miktar; ?></td>
                          	<td>₺ <?php echo $urun_fiyat; ?></td>
                          	<td>₺ <?php echo $iade_tutar; ?></td>
                          	<td><a target="_blank" class="btn btn-xs btn-success" href="siparis-detay?siparis_id=<?php echo $siparis_id; ?>">Siparişi Gör</a></td>
                          	<td><a target="_blank" class="btn btn-xs btn-primary" href="iade-detay?siparisurun=<?php echo $siparisitem_id; ?>">İade Detayları</a></td>
                          

                          </tr>

                         <?php } ?>
                                 
                        
                        </tbody>
                      </table>
                    </div>

                    <?php if ($iadetestsay>$kacar) { ?>

                  	<div  class="pagination-wrapper">
						
							<div  class="GridLex-grid-middle GridLex-grid-noGutter">
								
								<div class="GridLex-col-12_sm-12_xs-12">
									<nav>
										<ul class="pagination pagination-text-center-sm mb-5-xs">
											<?php $p=0; if ($sayfa!=1) { ?>
												<li>
												<a href="javascript:void(0);" name='page_<?php echo $sayfa-1; ?>' aria-label="Previous">
													<span aria-hidden="true">&laquo;</span>
												</a>
											</li>
											<?php } ?>
											
											<?php while ($p<$sayfasayisi) { $p++;

											if ($p<=$sayfa+3 and $p>=$sayfa-3) {
											 ?>
												
												<li <?php if ($p==$sayfa) { ?>
													class="active"
												<?php } ?>><a href="javascript:void(0);" name="page_<?php echo $p; ?>"><?php echo $p; ?></a></li>

											<?php } } ?>

											<?php if ($sayfa!=$sayfasayisi) { ?>

												<li>
												<a href="javascript:void(0);" name="page_<?php echo $sayfa+1; ?>" aria-label="Next">
													<span aria-hidden="true">&raquo;</span>
												</a>
											</li>
												
											<?php } ?>
											
											
										</ul>
									</nav>

								</div>
							</div>

						</div>
                  	
                  <?php } ?>

                  <script type="text/javascript">
                  	
                  	$('.pagination li a').click(function(){


var id1=$(this).attr("name");
 var page=id1.substring(5);
var siralamaolcutu=$('#siralamaolcutu').val();
var sort = $('#sort').val();
 $('.x_content').html('<h3 align="center">Yükleniyor...</h3>');

 $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : {'iadelersiralamapaginationdegistir':'ok',"siralamaolcutu":siralamaolcutu,'sort':sort,"page":page},
            success : function(sonuc){

            	sonuc=$.trim(sonuc);
            	 $('.x_content').html(sonuc);

            	 }

            	});
							});

                  </script>


<?php } else if (isset($_POST['siparislersiralamaolcutudegistir'])){

$siralamaolcutu = $_POST['siralamaolcutu'];
$zamanfiltresi = $_POST['zamanfiltresi'];

$sayfa=1;
$kacar=30;


switch ($siralamaolcutu) {
	case 'kayitsondanbasa':
	
	switch ($zamanfiltresi) {

		case 'tumzamanlar':
			$siparistestsec=$db->prepare("SELECT * from siparisler");
   $siparistestsec->execute();
   $siparistestsay=$siparistestsec->rowCount();
   $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
   $siparissec=$db->prepare("SELECT * from siparisler order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute();
   if ($siparistestsay==0) {
   	echo '<h4 align="center">Henüz sipariş yok. Olduğunda burada gözükecek.</h4>';
   	exit;
   }
			break;


			case 'bugun':
			$buguntarih = date("Y-m-d");
			$siparistestsec=$db->prepare("SELECT * from siparisler where DATE(siparis_zaman) = '$buguntarih'");
   $siparistestsec->execute();
   $siparistestsay=$siparistestsec->rowCount();
   $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
   $siparissec=$db->prepare("SELECT * from siparisler where DATE(siparis_zaman) = '$buguntarih' order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute();
   if ($siparistestsay==0) {
   	echo '<h4 align="center">Henüz sipariş yok. Olduğunda burada gözükecek.</h4>';
   	exit;
   }
			break;

			case 'buhafta':
			$gun7once = date("Y-m-d",strtotime("-7 days"));
     		$buguntarih = date("Y-m-d,",strtotime("+1 day"));
			$siparistestsec=$db->prepare("SELECT * from siparisler where siparis_zaman BETWEEN '$gun7once' and '$buguntarih'");
   $siparistestsec->execute();
   $siparistestsay=$siparistestsec->rowCount();
   $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
   $siparissec=$db->prepare("SELECT * from siparisler where siparis_zaman BETWEEN '$gun7once' and '$buguntarih' order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute();
   if ($siparistestsay==0) {
   	echo '<h4 align="center">Henüz sipariş yok. Olduğunda burada gözükecek.</h4>';
   	exit;
   }
			break;

			case 'buay':
			$buguntarihay = date("Y-m-01");
     		$ay1sonra = date("Y-m-01",strtotime("+1 months"));
			$siparistestsec=$db->prepare("SELECT * from siparisler where siparis_zaman BETWEEN '$buguntarihay' AND '$ay1sonra'");
   $siparistestsec->execute();
   $siparistestsay=$siparistestsec->rowCount();
   $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
   $siparissec=$db->prepare("SELECT * from siparisler where siparis_zaman BETWEEN '$buguntarihay' AND '$ay1sonra' order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute();
   if ($siparistestsay==0) {
   	echo '<h4 align="center">Henüz sipariş yok. Olduğunda burada gözükecek.</h4>';
   	exit;
   }
			break;


			case 'gecenay':
			$buguntarihay = date("Y-m-01");
     		 $ay1once = date("Y-m-01",strtotime("-1 months"));
			$siparistestsec=$db->prepare("SELECT * from siparisler where siparis_zaman BETWEEN '$ay1once' and '$buguntarihay'");
   $siparistestsec->execute();
   $siparistestsay=$siparistestsec->rowCount();
   $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
   $siparissec=$db->prepare("SELECT * from siparisler where siparis_zaman BETWEEN '$ay1once' and '$buguntarihay' order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute();
   if ($siparistestsay==0) {
   	echo '<h4 align="center">Henüz sipariş yok. Olduğunda burada gözükecek.</h4>';
   	exit;
   }
			break;
		
		
	}
  
		
		break;
	
	

		case 'bekleniyor':
		
		switch ($zamanfiltresi) {

			case 'tumzamanlar':
				
				$siparistestsec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis");
   $siparistestsec->execute(array(
   	"ulasmis" => 0
   ));
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
 $siparissec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute(array(
   	"ulasmis" => 0
   ));
   if ($siparistestsay==0) {
   	echo '<h4 align="center">Hazırlanan sipariş bulunamadı.</h4>';
   	exit;
   }

				break;

				case 'bugun':

				$buguntarih = date("Y-m-d");
				
				$siparistestsec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and DATE(siparis_zaman) = '$buguntarih'");
   $siparistestsec->execute(array(
   	"ulasmis" => 0
   ));
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
 $siparissec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and DATE(siparis_zaman) = '$buguntarih' order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute(array(
   	"ulasmis" => 0
   ));
   if ($siparistestsay==0) {
   	echo '<h4 align="center">Hazırlanan sipariş bulunamadı.</h4>';
   	exit;
   }
   
				break;


				case 'buhafta':

				$gun7once = date("Y-m-d",strtotime("-7 days"));
     		   $buguntarih = date("Y-m-d,",strtotime("+1 day"));
				
				$siparistestsec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and siparis_zaman BETWEEN '$gun7once' and '$buguntarih'");
   $siparistestsec->execute(array(
   	"ulasmis" => 0
   ));
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
 $siparissec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and siparis_zaman BETWEEN '$gun7once' and '$buguntarih' order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute(array(
   	"ulasmis" => 0
   ));
   if ($siparistestsay==0) {
   	echo '<h4 align="center">Hazırlanan sipariş bulunamadı.</h4>';
   	exit;
   }
   
				break;


				case 'buay':

				$buguntarihay = date("Y-m-01");
     		    $ay1sonra = date("Y-m-01",strtotime("+1 months"));
				
				$siparistestsec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and siparis_zaman BETWEEN '$buguntarihay' AND '$ay1sonra'");
   $siparistestsec->execute(array(
   	"ulasmis" => 0
   ));
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
 $siparissec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and siparis_zaman BETWEEN '$buguntarihay' AND '$ay1sonra' order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute(array(
   	"ulasmis" => 0
   ));
   if ($siparistestsay==0) {
   	echo '<h4 align="center">Hazırlanan sipariş bulunamadı.</h4>';
   	exit;
   }
   
				break;

				case 'gecenay':

				$buguntarihay = date("Y-m-01");
     		   $ay1once = date("Y-m-01",strtotime("-1 months"));
				
				$siparistestsec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and siparis_zaman BETWEEN '$ay1once' and '$buguntarihay'");
   $siparistestsec->execute(array(
   	"ulasmis" => 0
   ));
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
 $siparissec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and siparis_zaman BETWEEN '$ay1once' and '$buguntarihay' order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute(array(
   	"ulasmis" => 0
   ));
   if ($siparistestsay==0) {
   	echo '<h4 align="center">Hazırlanan sipariş bulunamadı.</h4>';
   	exit;
   }
   
				break;
			
			
		}
  
		
		break;

		case 'teslimedildi':
		
		switch ($zamanfiltresi) {

			case 'tumzamanlar':
				$siparistestsec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis");
   $siparistestsec->execute(array(
   	"ulasmis" => 1
   ));
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
 $siparissec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute(array(
   	"ulasmis" => 1
   ));

   if ($siparistestsay==0) {
   	echo '<h4 align="center">Teslim edilmiş sipariş bulunamadı.</h4>';
   	exit;
   }
				break;

				case 'bugun':
				$buguntarih = date("Y-m-d");
				$siparistestsec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and DATE(siparis_zaman) = '$buguntarih'");
   $siparistestsec->execute(array(
   	"ulasmis" => 1
   ));
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
 $siparissec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and DATE(siparis_zaman) = '$buguntarih' order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute(array(
   	"ulasmis" => 1
   ));

   if ($siparistestsay==0) {
   	echo '<h4 align="center">Teslim edilmiş sipariş bulunamadı.</h4>';
   	exit;
   }
				break;

				case 'buhafta':

				$gun7once = date("Y-m-d",strtotime("-7 days"));
     		 $buguntarih = date("Y-m-d,",strtotime("+1 day"));

				$siparistestsec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and siparis_zaman BETWEEN '$gun7once' and '$buguntarih'");
   $siparistestsec->execute(array(
   	"ulasmis" => 1
   ));
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
 $siparissec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and siparis_zaman BETWEEN '$gun7once' and '$buguntarih' order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute(array(
   	"ulasmis" => 1
   ));

   if ($siparistestsay==0) {
   	echo '<h4 align="center">Teslim edilmiş sipariş bulunamadı.</h4>';
   	exit;
   }
				break;

				case 'buay':

				$buguntarihay = date("Y-m-01");
     		   $ay1sonra = date("Y-m-01",strtotime("+1 months"));
     		 
				$siparistestsec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and siparis_zaman BETWEEN '$buguntarihay' AND '$ay1sonra'");
   $siparistestsec->execute(array(
   	"ulasmis" => 1
   ));
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
 $siparissec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and siparis_zaman BETWEEN '$buguntarihay' AND '$ay1sonra' order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute(array(
   	"ulasmis" => 1
   ));

   if ($siparistestsay==0) {
   	echo '<h4 align="center">Teslim edilmiş sipariş bulunamadı.</h4>';
   	exit;
   }
				break;

				case 'gecenay':

				$buguntarihay = date("Y-m-01");
     		   $ay1once = date("Y-m-01",strtotime("-1 months"));
     		 
				$siparistestsec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and siparis_zaman BETWEEN '$ay1once' and '$buguntarihay'");
   $siparistestsec->execute(array(
   	"ulasmis" => 1
   ));
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
 $siparissec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and siparis_zaman BETWEEN '$ay1once' and '$buguntarihay' order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute(array(
   	"ulasmis" => 1
   ));

   if ($siparistestsay==0) {
   	echo '<h4 align="center">Teslim edilmiş sipariş bulunamadı.</h4>';
   	exit;
   }
				break;
			
			
		}

   
		
		break;

		case 'kargoyaverildi':
		
		switch ($zamanfiltresi) {

			case 'tumzamanlar':
				$siparistestsec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis");
   $siparistestsec->execute(array(
   	"ulasmis" => 2
   ));
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
 $siparissec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute(array(
   	"ulasmis" => 2
   ));

   if ($siparistestsay==0) {
   	echo '<h4 align="center">Kargoda sipariş bulunamadı.</h4>';
   	exit;
   }
				break;

				case 'bugun':
				$buguntarih = date("Y-m-d");
				$siparistestsec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and DATE(siparis_zaman) = '$buguntarih'");
   $siparistestsec->execute(array(
   	"ulasmis" => 2
   ));
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
 $siparissec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and DATE(siparis_zaman) = '$buguntarih' order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute(array(
   	"ulasmis" => 2
   ));

   if ($siparistestsay==0) {
   	echo '<h4 align="center">Kargoda sipariş bulunamadı.</h4>';
   	exit;
   }
				break;

				case 'buhafta':
				$gun7once = date("Y-m-d",strtotime("-7 days"));
     		 $buguntarih = date("Y-m-d,",strtotime("+1 day"));
				$siparistestsec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and siparis_zaman BETWEEN '$gun7once' and '$buguntarih'");
   $siparistestsec->execute(array(
   	"ulasmis" => 2
   ));
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
 $siparissec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and siparis_zaman BETWEEN '$gun7once' and '$buguntarih' order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute(array(
   	"ulasmis" => 2
   ));

   if ($siparistestsay==0) {
   	echo '<h4 align="center">Kargoda sipariş bulunamadı.</h4>';
   	exit;
   }
				break;

				case 'buay':
				$buguntarihay = date("Y-m-01");
     		 $ay1sonra = date("Y-m-01",strtotime("+1 months"));
				$siparistestsec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and siparis_zaman BETWEEN '$buguntarihay' AND '$ay1sonra'");
   $siparistestsec->execute(array(
   	"ulasmis" => 2
   ));
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
 $siparissec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and siparis_zaman BETWEEN '$buguntarihay' AND '$ay1sonra' order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute(array(
   	"ulasmis" => 2
   ));

   if ($siparistestsay==0) {
   	echo '<h4 align="center">Kargoda sipariş bulunamadı.</h4>';
   	exit;
   }
				break;


				case 'gecenay':
				
				 $buguntarihay = date("Y-m-01");
     		 $ay1once = date("Y-m-01",strtotime("-1 months"));

				$siparistestsec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and siparis_zaman BETWEEN '$ay1once' and '$buguntarihay'");
   $siparistestsec->execute(array(
   	"ulasmis" => 2
   ));
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
 $siparissec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and siparis_zaman BETWEEN '$ay1once' and '$buguntarihay' order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute(array(
   	"ulasmis" => 2
   ));

   if ($siparistestsay==0) {
   	echo '<h4 align="center">Kargoda sipariş bulunamadı.</h4>';
   	exit;
   }
				break;
			
			
		}

   
		
		break;






		
} ?>

<div class="table-responsive">
                      <table class="table table-striped jambo_table bulk_action">
                        <thead>
                          <tr class="headings">
                            
                            <th class="column-title">Sipariş No.</th>
                            <th class="column-title">Sipariş Tarihi </th>
                            <th class="column-title">Ad & Soyad </th>
                            <th class="column-title">Ürün Sayısı</th>
                            <th class="column-title">Ara Toplam</th>
                            <th class="column-title">Kargo Ücreti</th>
                            <th class="column-title">Taksit</th>
                            <th class="column-title">Vade Farkı</th>
                            <th class="column-title">Toplam</th>
                            <th class="column-title">Teslimat</th>
                            <th class="column-title">#</th>
                            <th></th>
                            </th>
                            
                          </tr>
                        </thead>

                        <tbody>
                          
                          <?php 
                         
                        


                          while ($sipariscek=$siparissec->fetch(PDO::FETCH_ASSOC)) {

                          $siparis_kargoucreti = $sipariscek['siparis_kargoucreti'];
                      $siparis_taksit = $sipariscek['siparis_taksit'];
                      $siparis_vadefarki = $sipariscek['siparis_vadefarki']; 

                            $siparis_id=$sipariscek['siparis_id'];
                       $siparis_zaman = $sipariscek['siparis_zaman'];
                       $d = new DateTime($siparis_zaman);
                        $zamanson =  $d->format('d/m/Y H:i');
                      
                      $siparisitemsec=$db->prepare("SELECT * from siparisitem where siparis_id=:id");
                      $siparisitemsec->execute(array(

                        "id" => $siparis_id

                      ));

                      

                      $siparisitemsay=$siparisitemsec->rowCount();

                      $siparis_aratoplam=$sipariscek['siparis_aratoplam'];
                      $siparis_toplam=$sipariscek['siparis_toplam'];
                      $siparis_teslimat=$sipariscek['siparis_ulasmis'];
                      $kullanici_id=$sipariscek['kullanici_id'];
                      $kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_yetki=:yetki");
                      $kullanicisec->execute(array(
                        "yetki" => 1
                      ));

                      $kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

                      $kullanici_ad = $kullanicicek['kullanici_ad']." ".substr($kullanicicek['kullanici_soyad'], 0,1).".";

                
                            ?>
                            
                          <tr class="even pointer">
                           
                            <td><?php echo $siparis_id; ?></td>
                            <td><?php echo $zamanson; ?></td>
                            <td><a target="_blank" href="uye-detay?uye_id=<?php echo $kullanici_id; ?>"><?php echo $kullanici_ad; ?></a></td>
                            <td><?php echo $siparisitemsay; ?></td>
                            <td>₺ <?php echo $siparis_aratoplam; ?></td>
                            <td>₺ <?php echo $siparis_kargoucreti; ?></td>
                            <td><?php if ($siparis_taksit=='1') {

                            	echo "Tek Ç.";

                            } else {

                            	echo $siparis_taksit;

                            } ?></td>
                            <td>₺ <?php echo $siparis_vadefarki; ?></td>
                            <td>₺ <?php echo $siparis_toplam; ?></td>
                            <?php if ($siparis_teslimat==0) { ?>

              <td><div style="background: orange;" class="badge badge-warning">Hazırlanıyor</div></td>
              
            <?php } else if ($siparis_teslimat==1) { ?>
                           
                           <td><div style="background: green;" class="badge badge-success">Teslim Edildi</div></td>

            <?php } else if ($siparis_teslimat==2) { ?>
                           
                           <td><div style="background: #225E88;" class="badge badge-info">Kargoda</div></td>

            <?php }  ?>
                           <td><a target="_blank" style="color: white;" href="siparis-detay?siparis_id=<?php echo $siparis_id; ?>" class="btn btn-info btn-xs">Detaylar</a></td>
                            <td></td>
                            <td></td>
                            
                           
                          </tr>

                         <?php } ?>
                                 
                        
                        </tbody>
                      </table>
                    </div>

                    <?php if ($siparistestsay>$kacar) { ?>

                  	<div  class="pagination-wrapper">
						
							<div  class="GridLex-grid-middle GridLex-grid-noGutter">
								
								<div class="GridLex-col-12_sm-12_xs-12">
									<nav>
										<ul class="pagination pagination-text-center-sm mb-5-xs">
											<?php $p=0; if ($sayfa!=1) { ?>
												<li>
												<a href="javascript:void(0);" name='page_<?php echo $sayfa-1; ?>' aria-label="Previous">
													<span aria-hidden="true">&laquo;</span>
												</a>
											</li>
											<?php } ?>
											
											<?php while ($p<$sayfasayisi) { $p++;

											if ($p<=$sayfa+3 and $p>=$sayfa-3) {

											 ?>
												
												<li <?php if ($p==$sayfa) { ?>
													class="active"
												<?php } ?>><a href="javascript:void(0);" name="page_<?php echo $p; ?>"><?php echo $p; ?></a></li>

											<?php } } ?>

											<?php if ($sayfa!=$sayfasayisi) { ?>

												<li>
												<a href="javascript:void(0);" name="page_<?php echo $sayfa+1; ?>" aria-label="Next">
													<span aria-hidden="true">&raquo;</span>
												</a>
											</li>
												
											<?php } ?>
											
											
										</ul>
									</nav>

								</div>
							</div>

						</div>
                  	
                  <?php } ?>

                  <script type="text/javascript">
                  	
                  	$('.pagination li a').click(function(){


var id1=$(this).attr("name");
 var page=id1.substring(5);
var siralamaolcutu=$('#siralamaolcutu').val();
var zamanfiltresi = $('#zamanfiltresi').val();
 $('.x_content').html('<h3 align="center">Yükleniyor...</h3>');

 $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : {'siparislersiralamapaginationdegistir':'ok',"siralamaolcutu":siralamaolcutu,'zamanfiltresi':zamanfiltresi,"page":page},
            success : function(sonuc){

            	sonuc=$.trim(sonuc);
            	 $('.x_content').html(sonuc);

            	 }

            	});
							});

                  </script>



<?php } else if (isset($_POST['siparislersiralamapaginationdegistir'])){

$siralamaolcutu = $_POST['siralamaolcutu'];
$zamanfiltresi = $_POST['zamanfiltresi'];

$sayfa=$_POST['page'];
$kacar=30;


switch ($siralamaolcutu) {
	case 'kayitsondanbasa':
	
	switch ($zamanfiltresi) {

		case 'tumzamanlar':
			$siparistestsec=$db->prepare("SELECT * from siparisler");
   $siparistestsec->execute();
   $siparistestsay=$siparistestsec->rowCount();
   $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
   $siparissec=$db->prepare("SELECT * from siparisler order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute();
   if ($siparistestsay==0) {
   	echo '<h4 align="center">Henüz sipariş yok. Olduğunda burada gözükecek.</h4>';
   	exit;
   }
			break;


			case 'bugun':
			$buguntarih = date("Y-m-d");
			$siparistestsec=$db->prepare("SELECT * from siparisler where DATE(siparis_zaman) = '$buguntarih'");
   $siparistestsec->execute();
   $siparistestsay=$siparistestsec->rowCount();
   $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
   $siparissec=$db->prepare("SELECT * from siparisler where DATE(siparis_zaman) = '$buguntarih' order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute();
   if ($siparistestsay==0) {
   	echo '<h4 align="center">Henüz sipariş yok. Olduğunda burada gözükecek.</h4>';
   	exit;
   }
			break;

			case 'buhafta':
			$gun7once = date("Y-m-d",strtotime("-7 days"));
     		$buguntarih = date("Y-m-d,",strtotime("+1 day"));
			$siparistestsec=$db->prepare("SELECT * from siparisler where siparis_zaman BETWEEN '$gun7once' and '$buguntarih'");
   $siparistestsec->execute();
   $siparistestsay=$siparistestsec->rowCount();
   $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
   $siparissec=$db->prepare("SELECT * from siparisler where siparis_zaman BETWEEN '$gun7once' and '$buguntarih' order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute();
   if ($siparistestsay==0) {
   	echo '<h4 align="center">Henüz sipariş yok. Olduğunda burada gözükecek.</h4>';
   	exit;
   }
			break;

			case 'buay':
			$buguntarihay = date("Y-m-01");
     		$ay1sonra = date("Y-m-01",strtotime("+1 months"));
			$siparistestsec=$db->prepare("SELECT * from siparisler where siparis_zaman BETWEEN '$buguntarihay' AND '$ay1sonra'");
   $siparistestsec->execute();
   $siparistestsay=$siparistestsec->rowCount();
   $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
   $siparissec=$db->prepare("SELECT * from siparisler where siparis_zaman BETWEEN '$buguntarihay' AND '$ay1sonra' order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute();
   if ($siparistestsay==0) {
   	echo '<h4 align="center">Henüz sipariş yok. Olduğunda burada gözükecek.</h4>';
   	exit;
   }
			break;


			case 'gecenay':
			$buguntarihay = date("Y-m-01");
     		 $ay1once = date("Y-m-01",strtotime("-1 months"));
			$siparistestsec=$db->prepare("SELECT * from siparisler where siparis_zaman BETWEEN '$ay1once' and '$buguntarihay'");
   $siparistestsec->execute();
   $siparistestsay=$siparistestsec->rowCount();
   $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
   $siparissec=$db->prepare("SELECT * from siparisler where siparis_zaman BETWEEN '$ay1once' and '$buguntarihay' order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute();
   if ($siparistestsay==0) {
   	echo '<h4 align="center">Henüz sipariş yok. Olduğunda burada gözükecek.</h4>';
   	exit;
   }
			break;
		
		
	}
  
		
		break;
	
	

		case 'bekleniyor':
		
		switch ($zamanfiltresi) {

			case 'tumzamanlar':
				
				$siparistestsec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis");
   $siparistestsec->execute(array(
   	"ulasmis" => 0
   ));
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
 $siparissec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute(array(
   	"ulasmis" => 0
   ));
   if ($siparistestsay==0) {
   	echo '<h4 align="center">Hazırlanan sipariş bulunamadı.</h4>';
   	exit;
   }

				break;

				case 'bugun':

				$buguntarih = date("Y-m-d");
				
				$siparistestsec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and DATE(siparis_zaman) = '$buguntarih'");
   $siparistestsec->execute(array(
   	"ulasmis" => 0
   ));
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
 $siparissec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and DATE(siparis_zaman) = '$buguntarih' order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute(array(
   	"ulasmis" => 0
   ));
   if ($siparistestsay==0) {
   	echo '<h4 align="center">Hazırlanan sipariş bulunamadı.</h4>';
   	exit;
   }
   
				break;


				case 'buhafta':

				$gun7once = date("Y-m-d",strtotime("-7 days"));
     		   $buguntarih = date("Y-m-d,",strtotime("+1 day"));
				
				$siparistestsec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and siparis_zaman BETWEEN '$gun7once' and '$buguntarih'");
   $siparistestsec->execute(array(
   	"ulasmis" => 0
   ));
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
 $siparissec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and siparis_zaman BETWEEN '$gun7once' and '$buguntarih' order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute(array(
   	"ulasmis" => 0
   ));
   if ($siparistestsay==0) {
   	echo '<h4 align="center">Hazırlanan sipariş bulunamadı.</h4>';
   	exit;
   }
   
				break;


				case 'buay':

				$buguntarihay = date("Y-m-01");
     		    $ay1sonra = date("Y-m-01",strtotime("+1 months"));
				
				$siparistestsec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and siparis_zaman BETWEEN '$buguntarihay' AND '$ay1sonra'");
   $siparistestsec->execute(array(
   	"ulasmis" => 0
   ));
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
 $siparissec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and siparis_zaman BETWEEN '$buguntarihay' AND '$ay1sonra' order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute(array(
   	"ulasmis" => 0
   ));
   if ($siparistestsay==0) {
   	echo '<h4 align="center">Hazırlanan sipariş bulunamadı.</h4>';
   	exit;
   }
   
				break;

				case 'gecenay':

				$buguntarihay = date("Y-m-01");
     		   $ay1once = date("Y-m-01",strtotime("-1 months"));
				
				$siparistestsec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and siparis_zaman BETWEEN '$ay1once' and '$buguntarihay'");
   $siparistestsec->execute(array(
   	"ulasmis" => 0
   ));
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
 $siparissec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and siparis_zaman BETWEEN '$ay1once' and '$buguntarihay' order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute(array(
   	"ulasmis" => 0
   ));
   if ($siparistestsay==0) {
   	echo '<h4 align="center">Hazırlanan sipariş bulunamadı.</h4>';
   	exit;
   }
   
				break;
			
			
		}
  
		
		break;

		case 'teslimedildi':
		
		switch ($zamanfiltresi) {

			case 'tumzamanlar':
				$siparistestsec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis");
   $siparistestsec->execute(array(
   	"ulasmis" => 1
   ));
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
 $siparissec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute(array(
   	"ulasmis" => 1
   ));

   if ($siparistestsay==0) {
   	echo '<h4 align="center">Teslim edilmiş sipariş bulunamadı.</h4>';
   	exit;
   }
				break;

				case 'bugun':
				$buguntarih = date("Y-m-d");
				$siparistestsec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and DATE(siparis_zaman) = '$buguntarih'");
   $siparistestsec->execute(array(
   	"ulasmis" => 1
   ));
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
 $siparissec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and DATE(siparis_zaman) = '$buguntarih' order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute(array(
   	"ulasmis" => 1
   ));

   if ($siparistestsay==0) {
   	echo '<h4 align="center">Teslim edilmiş sipariş bulunamadı.</h4>';
   	exit;
   }
				break;

				case 'buhafta':

				$gun7once = date("Y-m-d",strtotime("-7 days"));
     		 $buguntarih = date("Y-m-d,",strtotime("+1 day"));

				$siparistestsec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and siparis_zaman BETWEEN '$gun7once' and '$buguntarih'");
   $siparistestsec->execute(array(
   	"ulasmis" => 1
   ));
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
 $siparissec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and siparis_zaman BETWEEN '$gun7once' and '$buguntarih' order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute(array(
   	"ulasmis" => 1
   ));

   if ($siparistestsay==0) {
   	echo '<h4 align="center">Teslim edilmiş sipariş bulunamadı.</h4>';
   	exit;
   }
				break;

				case 'buay':

				$buguntarihay = date("Y-m-01");
     		   $ay1sonra = date("Y-m-01",strtotime("+1 months"));
     		 
				$siparistestsec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and siparis_zaman BETWEEN '$buguntarihay' AND '$ay1sonra'");
   $siparistestsec->execute(array(
   	"ulasmis" => 1
   ));
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
 $siparissec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and siparis_zaman BETWEEN '$buguntarihay' AND '$ay1sonra' order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute(array(
   	"ulasmis" => 1
   ));

   if ($siparistestsay==0) {
   	echo '<h4 align="center">Teslim edilmiş sipariş bulunamadı.</h4>';
   	exit;
   }
				break;

				case 'gecenay':

				$buguntarihay = date("Y-m-01");
     		   $ay1once = date("Y-m-01",strtotime("-1 months"));
     		 
				$siparistestsec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and siparis_zaman BETWEEN '$ay1once' and '$buguntarihay'");
   $siparistestsec->execute(array(
   	"ulasmis" => 1
   ));
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
 $siparissec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and siparis_zaman BETWEEN '$ay1once' and '$buguntarihay' order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute(array(
   	"ulasmis" => 1
   ));

   if ($siparistestsay==0) {
   	echo '<h4 align="center">Teslim edilmiş sipariş bulunamadı.</h4>';
   	exit;
   }
				break;
			
			
		}

   
		
		break;

		case 'kargoyaverildi':
		
		switch ($zamanfiltresi) {

			case 'tumzamanlar':
				$siparistestsec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis");
   $siparistestsec->execute(array(
   	"ulasmis" => 2
   ));
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
 $siparissec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute(array(
   	"ulasmis" => 2
   ));

   if ($siparistestsay==0) {
   	echo '<h4 align="center">Kargoda sipariş bulunamadı.</h4>';
   	exit;
   }
				break;

				case 'bugun':
				$buguntarih = date("Y-m-d");
				$siparistestsec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and DATE(siparis_zaman) = '$buguntarih'");
   $siparistestsec->execute(array(
   	"ulasmis" => 2
   ));
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
 $siparissec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and DATE(siparis_zaman) = '$buguntarih' order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute(array(
   	"ulasmis" => 2
   ));

   if ($siparistestsay==0) {
   	echo '<h4 align="center">Kargoda sipariş bulunamadı.</h4>';
   	exit;
   }
				break;

				case 'buhafta':
				$gun7once = date("Y-m-d",strtotime("-7 days"));
     		 $buguntarih = date("Y-m-d,",strtotime("+1 day"));
				$siparistestsec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and siparis_zaman BETWEEN '$gun7once' and '$buguntarih'");
   $siparistestsec->execute(array(
   	"ulasmis" => 2
   ));
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
 $siparissec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and siparis_zaman BETWEEN '$gun7once' and '$buguntarih' order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute(array(
   	"ulasmis" => 2
   ));

   if ($siparistestsay==0) {
   	echo '<h4 align="center">Kargoda sipariş bulunamadı.</h4>';
   	exit;
   }
				break;

				case 'buay':
				$buguntarihay = date("Y-m-01");
     		 $ay1sonra = date("Y-m-01",strtotime("+1 months"));
				$siparistestsec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and siparis_zaman BETWEEN '$buguntarihay' AND '$ay1sonra'");
   $siparistestsec->execute(array(
   	"ulasmis" => 2
   ));
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
 $siparissec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and siparis_zaman BETWEEN '$buguntarihay' AND '$ay1sonra' order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute(array(
   	"ulasmis" => 2
   ));

   if ($siparistestsay==0) {
   	echo '<h4 align="center">Kargoda sipariş bulunamadı.</h4>';
   	exit;
   }
				break;


				case 'gecenay':
				
				 $buguntarihay = date("Y-m-01");
     		 $ay1once = date("Y-m-01",strtotime("-1 months"));

				$siparistestsec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and siparis_zaman BETWEEN '$ay1once' and '$buguntarihay'");
   $siparistestsec->execute(array(
   	"ulasmis" => 2
   ));
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
 $siparissec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis and siparis_zaman BETWEEN '$ay1once' and '$buguntarihay' order by siparis_zaman DESC limit $baslangic,$kacar");
   $siparissec->execute(array(
   	"ulasmis" => 2
   ));

   if ($siparistestsay==0) {
   	echo '<h4 align="center">Kargoda sipariş bulunamadı.</h4>';
   	exit;
   }
				break;
			
			
		}

   
		
		break;






		
} ?>

<div class="table-responsive">
                      <table class="table table-striped jambo_table bulk_action">
                        <thead>
                          <tr class="headings">
                            
                            <th class="column-title">Sipariş No.</th>
                            <th class="column-title">Sipariş Tarihi </th>
                            <th class="column-title">Ad & Soyad </th>
                            <th class="column-title">Ürün Sayısı</th>
                            <th class="column-title">Ara Toplam</th>
                            <th class="column-title">Kargo Ücreti</th>
                            <th class="column-title">Taksit</th>
                            <th class="column-title">Vade Farkı</th>
                            <th class="column-title">Toplam</th>
                            <th class="column-title">Teslimat</th>
                            <th class="column-title">#</th>
                            <th></th>
                            </th>
                            
                          </tr>
                        </thead>

                        <tbody>
                          
                          <?php 
                         
                        


                          while ($sipariscek=$siparissec->fetch(PDO::FETCH_ASSOC)) { 

                          	$siparis_kargoucreti = $sipariscek['siparis_kargoucreti'];
                      $siparis_taksit = $sipariscek['siparis_taksit'];
                      $siparis_vadefarki = $sipariscek['siparis_vadefarki'];

                            $siparis_id=$sipariscek['siparis_id'];
                       $siparis_zaman = $sipariscek['siparis_zaman'];
                       $d = new DateTime($siparis_zaman);
                        $zamanson =  $d->format('d/m/Y H:i');
                      
                      $siparisitemsec=$db->prepare("SELECT * from siparisitem where siparis_id=:id");
                      $siparisitemsec->execute(array(

                        "id" => $siparis_id

                      ));

                      $siparisitemsay=$siparisitemsec->rowCount();

                      $siparis_aratoplam=$sipariscek['siparis_aratoplam'];
                      $siparis_toplam=$sipariscek['siparis_toplam'];
                      $siparis_teslimat=$sipariscek['siparis_ulasmis'];
                      $kullanici_id=$sipariscek['kullanici_id'];
                      $kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_yetki=:yetki");
                      $kullanicisec->execute(array(
                        "yetki" => 1
                      ));

                      $kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

                      $kullanici_ad = $kullanicicek['kullanici_ad']." ".substr($kullanicicek['kullanici_soyad'], 0,1).".";

                
                            ?>
                            
                          <tr class="even pointer">
                           
                            <td><?php echo $siparis_id; ?></td>
                            <td><?php echo $zamanson; ?></td>
                            <td><a target="_blank" href="uye-detay?uye_id=<?php echo $kullanici_id; ?>"><?php echo $kullanici_ad; ?></a></td>
                            <td><?php echo $siparisitemsay; ?></td>
                            <td>₺ <?php echo $siparis_aratoplam; ?></td>
                            <td>₺ <?php echo $siparis_kargoucreti; ?></td>
                            <td><?php if ($siparis_taksit=='1') {

                            	echo "Tek Ç.";

                            } else {

                            	echo $siparis_taksit;

                            } ?></td>
                            <td>₺ <?php echo $siparis_vadefarki; ?></td>
                            <td>₺ <?php echo $siparis_toplam; ?></td>
                            <?php if ($siparis_teslimat==0) { ?>

              <td><div style="background: orange;" class="badge badge-warning">Hazırlanıyor</div></td>
              
            <?php } else if ($siparis_teslimat==1) { ?>
                           
                           <td><div style="background: green;" class="badge badge-success">Teslim Edildi</div></td>

            <?php } else if ($siparis_teslimat==2) { ?>
                           
                           <td><div style="background: #225E88;" class="badge badge-info">Kargoda</div></td>

            <?php }  ?>
                           <td><a target="_blank" style="color: white;" href="siparis-detay?siparis_id=<?php echo $siparis_id; ?>" class="btn btn-info btn-xs">Detaylar</a></td>
                            <td></td>
                            <td></td>
                            
                           
                          </tr>

                         <?php } ?>
                                 
                        
                        </tbody>
                      </table>
                    </div>

                    <?php if ($siparistestsay>$kacar) { ?>

                  	<div  class="pagination-wrapper">
						
							<div  class="GridLex-grid-middle GridLex-grid-noGutter">
								
								<div class="GridLex-col-12_sm-12_xs-12">
									<nav>
										<ul class="pagination pagination-text-center-sm mb-5-xs">
											<?php $p=0; if ($sayfa!=1) { ?>
												<li>
												<a href="javascript:void(0);" name='page_<?php echo $sayfa-1; ?>' aria-label="Previous">
													<span aria-hidden="true">&laquo;</span>
												</a>
											</li>
											<?php } ?>
											
											<?php while ($p<$sayfasayisi) { $p++;

											if ($p<=$sayfa+3 and $p>=$sayfa-3) { ?>
												
												<li <?php if ($p==$sayfa) { ?>
													class="active"
												<?php } ?>><a href="javascript:void(0);" name="page_<?php echo $p; ?>"><?php echo $p; ?></a></li>

											<?php } } ?>

											<?php if ($sayfa!=$sayfasayisi) { ?>

												<li>
												<a href="javascript:void(0);" name="page_<?php echo $sayfa+1; ?>" aria-label="Next">
													<span aria-hidden="true">&raquo;</span>
												</a>
											</li>
												
											<?php } ?>
											
											
										</ul>
									</nav>

								</div>
							</div>

						</div>
                  	
                  <?php } ?>

                  <script type="text/javascript">
                  	
                  	$('.pagination li a').click(function(){


var id1=$(this).attr("name");
 var page=id1.substring(5);
var siralamaolcutu=$('#siralamaolcutu').val();
var zamanfiltresi = $('#zamanfiltresi').val();
 $('.x_content').html('<h3 align="center">Yükleniyor...</h3>');

 $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : {'siparislersiralamapaginationdegistir':'ok',"siralamaolcutu":siralamaolcutu,'zamanfiltresi':zamanfiltresi,"page":page},
            success : function(sonuc){

            	sonuc=$.trim(sonuc);
            	 $('.x_content').html(sonuc);

            	 }

            	});
							});

                  </script>


<?php } else if (isset($_POST['urunfiltreleadmin'])){

$filtre_marka = $_POST['markasec'];
$filtre_kategori = $_POST['kategorisec'];
$filtre_search = trim($_POST['searchsec']);
$searchquery = '';

if (!empty($filtre_search)) {
	
	 $searchquery = " and (urun_id='$filtre_search' or urun_ad LIKE '$filtre_search%' or urun_ad LIKE '%$filtre_search%' or urun_ad LIKE '%$filtre_search') ";


}

$sayfa=1;
$kacar=20;

if ($filtre_marka=='tumu' and $filtre_kategori=='tumu') {


	$uruntestsec=$db->prepare("SELECT * from urunler where urun_kaldirildi='0' $searchquery");
   $uruntestsec->execute();
   $uruntestsay=$uruntestsec->rowCount();
   $sayfasayisi=ceil($uruntestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
   $urunsecc=$db->prepare("SELECT * from urunler where urun_kaldirildi='0' $searchquery order by urun_zaman DESC limit $baslangic,$kacar");
   $urunsecc->execute();
   if ($uruntestsay==0) {
   	echo '<h4 align="center">Ürün bulunamadı.</h4>';
   	exit;
   }
	

} else if ($filtre_marka=='tumu'){

$uruntestsec=$db->prepare("SELECT * from urunkategori where urun_kaldirildi='0' and kategori_id='$filtre_kategori' $searchquery ");
   $uruntestsec->execute();
   $uruntestsay=$uruntestsec->rowCount();
   $sayfasayisi=ceil($uruntestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
   $urunsecc=$db->prepare("SELECT * from urunkategori where urun_kaldirildi='0' and kategori_id='$filtre_kategori' $searchquery order by urun_id DESC limit $baslangic,$kacar");
   $urunsecc->execute();
   if ($uruntestsay==0) {
   	echo '<h4 align="center">Ürün bulunamadı.</h4>';
   	exit;
   }

} else if ($filtre_kategori=='tumu'){

$uruntestsec=$db->prepare("SELECT * from urunler where urun_kaldirildi='0' and marka_id='$filtre_marka' $searchquery ");
   $uruntestsec->execute();
   $uruntestsay=$uruntestsec->rowCount();
   $sayfasayisi=ceil($uruntestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
   $urunsecc=$db->prepare("SELECT * from urunler where urun_kaldirildi='0' and marka_id='$filtre_marka' $searchquery order by urun_zaman DESC limit $baslangic,$kacar");
   $urunsecc->execute();
   if ($uruntestsay==0) {
   	echo '<h4 align="center">Ürün bulunamadı.</h4>';
   	exit;
   }

} else {

$uruntestsec=$db->prepare("SELECT * from urunkategori where urun_kaldirildi='0' and marka_id='$filtre_marka' and kategori_id='$filtre_kategori' $searchquery ");
   $uruntestsec->execute();
   $uruntestsay=$uruntestsec->rowCount();
   $sayfasayisi=ceil($uruntestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
   $urunsecc=$db->prepare("SELECT * from urunkategori where urun_kaldirildi='0' and marka_id='$filtre_marka' and kategori_id='$filtre_kategori' $searchquery order by urun_id DESC limit $baslangic,$kacar");
   $urunsecc->execute();
   if ($uruntestsay==0) {
   	echo '<h4 align="center">Ürün bulunamadı.</h4>';
   	exit;
   }

} ?>


<table id="datatable" class="table table-striped table-bordered">
                      <thead>
                        <tr>
                         
                          <th>Fotoğraf</th>
                          <th>Ürün No.</th>
                          <th>Ürün Adı</th>
                          <th>Kalan Stok</th>
                          <th>İşlemler</th>
                          <th></th>
                          
                        
                          
                          
                         
                        </tr>
                      </thead>


                      <tbody>

                      	<?php 

                      while ($uruncekk=$urunsecc->fetch(PDO::FETCH_ASSOC)) { 



                        $urun_id = $uruncekk['urun_id'];

                        $urunsec=$db->prepare("SELECT * from urunler where urun_id='$urun_id'");
                        $urunsec->execute();
                        $uruncek=$urunsec->fetch(PDO::FETCH_ASSOC);
                        $urun_ad = $uruncek['urun_ad']; 
                        

                        $urunfotosec=$db->prepare("SELECT * from urunfoto where urun_id=:id and urunfoto_kapak=:kapak");
                        $urunfotosec->execute(array(

                          "kapak" => 1,
                           "id" => $urun_id

                         ));

                        $urunfotocek=$urunfotosec->fetch(PDO::FETCH_ASSOC);

                        $urunkapakfoto = $urunfotocek['urunfoto_yol'];

                        $markasec=$db->prepare("SELECT * from markalar where marka_id=:id");
                        $markasec->execute(array(
                          "id" => $uruncek['marka_id']
                        ));

                        $markacek=$markasec->fetch(PDO::FETCH_ASSOC);
                        
                        

                        ?>
                      	
                      	<tr class="urun_<?php echo $urun_id; ?>">

                      		<td class="col-md"><img class="img-responsive" style="display: block;width: 125px;" src="../../<?php echo $urunkapakfoto; ?>" alt="urun" /></td>

                      		<td><b><?php echo $urun_id; ?></b></td>

                      		<td><b><?php echo $urun_ad; ?></b></td>

                      		<td align="center"><b><?php echo $uruncek['urun_stok']; ?></b></td>

                      		<td align="right">
                            <a class="btn btn-warning btn-sm" target='_blank' href="urun-duzenle?urun_id=<?php echo $urun_id; ?>"><i class="fa fa-edit"></i> Düzenle</a>
                            
                            
                           
                             
                             <a class="btn btn-danger btn-sm urunsil" name="urun_<?php echo $urun_id; ?>" href="javascript:void(0);">Sil</a></td>

                             <td><a class="btn btn-success btn-block" target="_blank" href="ilgili-urunler?urun_id=<?php echo $urun_id; ?>"><i class="fa fa-refresh"></i> İlgili Ürünler</a></td>
                      		
                      	</tr>

                      <?php  } ?>

                      </tbody>
                    </table>



                   

                    <?php if ($uruntestsay>$kacar) { ?>

                  	<div  class="pagination-wrapper">
						
							<div  class="GridLex-grid-middle GridLex-grid-noGutter">
								
								<div class="GridLex-col-12_sm-12_xs-12">
									<nav>
										<ul class="pagination pagination-text-center-sm mb-5-xs">
											<?php $p=0; if ($sayfa!=1) { ?>
												<li>
												<a href="javascript:void(0);" name='page_<?php echo $sayfa-1; ?>' aria-label="Previous">
													<span aria-hidden="true">&laquo;</span>
												</a>
											</li>
											<?php } ?>
											
											<?php while ($p<$sayfasayisi) { $p++; 

												if ($p<=$sayfa+3 and $p>=$sayfa-3) {

													?>
												
												<li <?php if ($p==$sayfa) { ?>
													class="active"
												<?php } ?>><a href="javascript:void(0);" name="page_<?php echo $p; ?>"><?php echo $p; ?></a></li>

											<?php } } ?>

											<?php if ($sayfa!=$sayfasayisi) { ?>

												<li>
												<a href="javascript:void(0);" name="page_<?php echo $sayfa+1; ?>" aria-label="Next">
													<span aria-hidden="true">&raquo;</span>
												</a>
											</li>
												
											<?php } ?>
											
											
										</ul>
									</nav>

								</div>
							</div>

						</div>
                  	
                  <?php } ?>

                  <script type="text/javascript">
                  	
                  	$('.pagination li a').click(function(){


var id1=$(this).attr("name");
 var page=id1.substring(5);
var markasec = $('#markasec').val();
 var kategorisec = $('#kategorisec').val();
 var searchsec = $.trim($('#searchsec').val());
 $('.x_content').html('<h3 align="center">Yükleniyor...</h3>');

 $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : {'urunfiltrelemepaginationdegistir':'ok',"markasec":markasec,"kategorisec":kategorisec,"searchsec":searchsec,"page":page},
            success : function(sonuc){

            	sonuc=$.trim(sonuc);
            	 $('.x_content').html(sonuc);

            	 }

            	});
							});

                  	$('.urunsil').click(function(){

             var id1=$(this).attr("name");
                var urun_id=id1.substring(5);

                swal({
  title: "Ürünü kaldırmak istiyor musunuz?",
  text: "Bu ürün tüm listelemelerden kaldırılacak ve sayfasına erişilmeyecek.",
  icon: "warning",
  buttons: ["Vazgeç", "Sil"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

    $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'urunsil':'ok','urun_id':urun_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              if (sonuc=="ok") {

                $('.urun_'+urun_id).remove();
              }
               }

             });

     }

     })



          })

                  </script>


<?php } else if (isset($_POST['urunfiltrelemepaginationdegistir'])){

$filtre_marka = $_POST['markasec'];
$filtre_kategori = $_POST['kategorisec'];
$filtre_search = trim($_POST['searchsec']);
$searchquery = '';

if (!empty($filtre_search)) {
	
	 $searchquery = " and (urun_id='$filtre_search' or urun_ad LIKE '$filtre_search%' or urun_ad LIKE '%$filtre_search%' or urun_ad LIKE '%$filtre_search') ";


}

$sayfa=$_POST['page'];
$kacar=20;

if ($filtre_marka=='tumu' and $filtre_kategori=='tumu') {


	$uruntestsec=$db->prepare("SELECT * from urunler where urun_kaldirildi='0' $searchquery");
   $uruntestsec->execute();
   $uruntestsay=$uruntestsec->rowCount();
   $sayfasayisi=ceil($uruntestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
   $urunsecc=$db->prepare("SELECT * from urunler where urun_kaldirildi='0' $searchquery order by urun_zaman DESC limit $baslangic,$kacar");
   $urunsecc->execute();
   if ($uruntestsay==0) {
   	echo '<h4 align="center">Ürün bulunamadı.</h4>';
   	exit;
   }
	

} else if ($filtre_marka=='tumu'){

$uruntestsec=$db->prepare("SELECT * from urunkategori where urun_kaldirildi='0' and kategori_id='$filtre_kategori' $searchquery ");
   $uruntestsec->execute();
   $uruntestsay=$uruntestsec->rowCount();
   $sayfasayisi=ceil($uruntestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
   $urunsecc=$db->prepare("SELECT * from urunkategori where urun_kaldirildi='0' and kategori_id='$filtre_kategori' $searchquery order by urun_id DESC limit $baslangic,$kacar");
   $urunsecc->execute();
   if ($uruntestsay==0) {
   	echo '<h4 align="center">Ürün bulunamadı.</h4>';
   	exit;
   }

} else if ($filtre_kategori=='tumu'){

$uruntestsec=$db->prepare("SELECT * from urunler where urun_kaldirildi='0' and marka_id='$filtre_marka' $searchquery ");
   $uruntestsec->execute();
   $uruntestsay=$uruntestsec->rowCount();
   $sayfasayisi=ceil($uruntestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
   $urunsecc=$db->prepare("SELECT * from urunler where urun_kaldirildi='0' and marka_id='$filtre_marka' $searchquery order by urun_zaman DESC limit $baslangic,$kacar");
   $urunsecc->execute();
   if ($uruntestsay==0) {
   	echo '<h4 align="center">Ürün bulunamadı.</h4>';
   	exit;
   }

} else {

$uruntestsec=$db->prepare("SELECT * from urunkategori where urun_kaldirildi='0' and marka_id='$filtre_marka' and kategori_id='$filtre_kategori' $searchquery ");
   $uruntestsec->execute();
   $uruntestsay=$uruntestsec->rowCount();
   $sayfasayisi=ceil($uruntestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;
   $urunsecc=$db->prepare("SELECT * from urunkategori where urun_kaldirildi='0' and marka_id='$filtre_marka' and kategori_id='$filtre_kategori' $searchquery order by urun_id DESC limit $baslangic,$kacar");
   $urunsecc->execute();
   if ($uruntestsay==0) {
   	echo '<h4 align="center">Ürün bulunamadı.</h4>';
   	exit;
   }

} ?>


<table id="datatable" class="table table-striped table-bordered">
                      <thead>
                        <tr>
                         
                          <th>Fotoğraf</th>
                          <th>Ürün No.</th>
                          <th>Ürün Adı</th>
                          <th>Kalan Stok</th>
                          <th>İşlemler</th>
                          <th></th>
                          
                        
                          
                          
                         
                        </tr>
                      </thead>


                      <tbody>

                      	<?php 

                      while ($uruncekk=$urunsecc->fetch(PDO::FETCH_ASSOC)) { 



                        $urun_id = $uruncekk['urun_id'];

                        $urunsec=$db->prepare("SELECT * from urunler where urun_id='$urun_id'");
                        $urunsec->execute();
                        $uruncek=$urunsec->fetch(PDO::FETCH_ASSOC);
                        $urun_ad = $uruncek['urun_ad']; 
                        

                        $urunfotosec=$db->prepare("SELECT * from urunfoto where urun_id=:id and urunfoto_kapak=:kapak");
                        $urunfotosec->execute(array(

                          "kapak" => 1,
                           "id" => $urun_id

                         ));

                        $urunfotocek=$urunfotosec->fetch(PDO::FETCH_ASSOC);

                        $urunkapakfoto = $urunfotocek['urunfoto_yol'];

                        $markasec=$db->prepare("SELECT * from markalar where marka_id=:id");
                        $markasec->execute(array(
                          "id" => $uruncek['marka_id']
                        ));

                        $markacek=$markasec->fetch(PDO::FETCH_ASSOC);
                        
                        

                        ?>
                      	
                      	<tr class="urun_<?php echo $urun_id; ?>">

                      		<td class="col-md"><img class="img-responsive" style="display: block;width: 125px;" src="../../<?php echo $urunkapakfoto; ?>" alt="urun" /></td>

                      		<td><b><?php echo $urun_id; ?></b></td>

                      		<td><b><?php echo $urun_ad; ?></b></td>

                      		<td align="center"><b><?php echo $uruncek['urun_stok']; ?></b></td>

                      		<td align="right">
                            <a class="btn btn-warning btn-sm"  href="urun-duzenle?urun_id=<?php echo $urun_id; ?>" target='_blank' ><i class="fa fa-edit"></i> Düzenle</a>
                            
                            
                           
                             
                             <a class="btn btn-danger btn-sm urunsil" name="urun_<?php echo $urun_id; ?>" href="javascript:void(0);">Sil</a></td>

                             <td><a class="btn btn-success btn-block" target="_blank" href="ilgili-urunler?urun_id=<?php echo $urun_id; ?>"><i class="fa fa-refresh"></i> İlgili Ürünler</a></td>
                      		
                      	</tr>

                      <?php  } ?>

                      </tbody>
                    </table>



                   

                    <?php if ($uruntestsay>$kacar) { ?>

                  	<div  class="pagination-wrapper">
						
							<div  class="GridLex-grid-middle GridLex-grid-noGutter">
								
								<div class="GridLex-col-12_sm-12_xs-12">
									<nav>
										<ul class="pagination pagination-text-center-sm mb-5-xs">
											<?php $p=0; if ($sayfa!=1) { ?>
												<li>
												<a href="javascript:void(0);" name='page_<?php echo $sayfa-1; ?>' aria-label="Previous">
													<span aria-hidden="true">&laquo;</span>
												</a>
											</li>
											<?php } ?>
											
											<?php while ($p<$sayfasayisi) { $p++;

											if ($p<=$sayfa+3 and $p>=$sayfa-3) {

											 ?>
												
												<li <?php if ($p==$sayfa) { ?>
													class="active"
												<?php } ?>><a href="javascript:void(0);" name="page_<?php echo $p; ?>"><?php echo $p; ?></a></li>

											<?php } } ?>

											<?php if ($sayfa!=$sayfasayisi) { ?>

												<li>
												<a href="javascript:void(0);" name="page_<?php echo $sayfa+1; ?>" aria-label="Next">
													<span aria-hidden="true">&raquo;</span>
												</a>
											</li>
												
											<?php } ?>
											
											
										</ul>
									</nav>

								</div>
							</div>

						</div>
                  	
                  <?php } ?>

                  <script type="text/javascript">
                  	
                  	$('.pagination li a').click(function(){


var id1=$(this).attr("name");
 var page=id1.substring(5);
var markasec = $('#markasec').val();
 var kategorisec = $('#kategorisec').val();
 var searchsec = $.trim($('#searchsec').val());
 $('.x_content').html('<h3 align="center">Yükleniyor...</h3>');

 $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : {'urunfiltrelemepaginationdegistir':'ok',"markasec":markasec,"kategorisec":kategorisec,"searchsec":searchsec,"page":page},
            success : function(sonuc){

            	sonuc=$.trim(sonuc);
            	 $('.x_content').html(sonuc);

            	 }

            	});
							});

                  	$('.urunsil').click(function(){

             var id1=$(this).attr("name");
                var urun_id=id1.substring(5);

                swal({
  title: "Ürünü kaldırmak istiyor musunuz?",
  text: "Bu ürün tüm listelemelerden kaldırılacak ve sayfasına erişilmeyecek.",
  icon: "warning",
  buttons: ["Vazgeç", "Sil"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

    $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'urunsil':'ok','urun_id':urun_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              if (sonuc=="ok") {

                $('.urun_'+urun_id).remove();
              }
               }

             });

     }

     })



          })

                  </script>



<?php }  else if (isset($_POST['kullanicisiladmin'])){

$kullanici_id = $_POST['kullanici_id'];

$yorumsil=$db->prepare("DELETE from yorumlar where kullanici_id=:id");
$yorumsil->execute(array(
"id" => $kullanici_id
));

$sepetsil=$db->prepare("DELETE from sepetitem where kullanici_id=:id");
$sepetsil->execute(array(
"id" => $kullanici_id
));

$sepetitemseceneklersil=$db->prepare("DELETE from sepetitemsecenekler where kullanici_id=:id");
$sepetitemseceneklersil->execute(array(
"id" => $kullanici_id
));

$favorisil=$db->prepare("DELETE from favoriler where kullanici_id=:id");
$favorisil->execute(array(
"id" => $kullanici_id
));


$hazirla=$db->prepare("UPDATE kullanici set

kullanici_ban=:kullanici_ban

where kullanici_id='$kullanici_id'

	");


$derle=$hazirla->execute(array(
"kullanici_ban" => 1
));

if ($derle) {
	

	echo "ok";
}

} else if (isset($_POST['siparisdurumguncelle'])){


$siparis_id = $_POST['siparis_id'];
$siparisdurumu = $_POST['siparisdurumu'];

$hazirla=$db->prepare("UPDATE siparisler set

siparis_ulasmis=:siparis_ulasmis

where siparis_id='$siparis_id'
	");

$derle = $hazirla->execute(array(

"siparis_ulasmis" =>  $siparisdurumu

));

if ($derle) {
	
	echo "ok";
}


}  else if (isset($_POST['urunfotosil'])){

$urunfoto_id = $_POST['urunfoto_id'];

$urunfotosec=$db->prepare("SELECT * from urunfoto where urunfoto_id=:id");
$urunfotosec->execute(array(
"id" => $urunfoto_id
));

$urunfotocek=$urunfotosec->fetch(PDO::FETCH_ASSOC);

$urunfoto_kapak = $urunfotocek['urunfoto_kapak'];
$urunfoto_yol = $urunfotocek['urunfoto_yol'];

$urun_id = $urunfotocek['urun_id'];

$urunfotosil=$db->prepare("DELETE from urunfoto where urunfoto_id=:id");
$silurunfoto=$urunfotosil->execute(array(

"id" => $urunfoto_id
));

if ($silurunfoto) {
	
	unlink($urunfoto_yol);

	if ($urunfoto_kapak==1) {
		
		$urunfotosecornek=$db->prepare("SELECT * from urunfoto where urun_id=:id order by foto_sira ASC limit 1");
		$urunfotocekornek=$urunfotosecornek->execute(array(
			"id" => $urun_id
		));

		$urunfotocekornek=$urunfotosecornek->fetch(PDO::FETCH_ASSOC);

		$urunfotoornek_id = $urunfotocekornek['urunfoto_id'];

		$hazirla=$db->prepare("UPDATE urunfoto set

urunfoto_kapak=:urunfoto_kapak,
foto_sira=:foto_sira

where urunfoto_id='$urunfotoornek_id'
			");

		$derle=$hazirla->execute(array(

			"urunfoto_kapak" => 1,
			"foto_sira" => NULL
		));
	}

	echo "ok";
}






} else if (isset($_POST['urunfotoreload'])){

$urun_id = $_POST['urun_id'];

$urunsec=$db->prepare("SELECT * from urunler where urun_id=:id");
$urunsec->execute(array(
"id" => $urun_id

));


$uruncek=$urunsec->fetch(PDO::FETCH_ASSOC); ?>

<div class="row">

	
 <input type="hidden" value="<?php echo $urun_id; ?>" id="urun_id" name="">


<?php $urunfotosec=$db->prepare("SELECT * from urunfoto where urun_id=:id order by urunfoto_kapak DESC, foto_sira ASC");
           $urunfotosec->execute(array(
            "id" => $urun_id
          ));

          while ($urunfotocek=$urunfotosec->fetch(PDO::FETCH_ASSOC)) { 
            $urunfoto_id=$urunfotocek['urunfoto_id'];
            $urunfoto_kapak = $urunfotocek['urunfoto_kapak'];
            $foto_sira = $urunfotocek['foto_sira'];
             ?>

            <div style="margin-bottom:50px;" class="col-md-3 col-sm-3 col-xs-12">

            	<div class="col-md-12 col-xs-12 col-sm-12">

                <?php if ($urunfoto_kapak==1) { ?> 

                  <input class="form-control" type="text"  value='Kapak' disabled=''>

                 <?php } else { ?>

                  <input class="form-control" type="number" min="1" id="urunfoto_<?php echo $urunfoto_id; ?>" value='<?php echo $foto_sira; ?>' name='' >


                 <?php } ?>

                 <button <?php if ($urunfoto_kapak==1) { ?>
                   disabled=''
                <?php } ?> class="btn btn-success btn-block fotosiraguncelle" name='urunfoto_<?php echo $urunfoto_id; ?>' >Sıra Güncelle</button>
                
              </div>
              
               <div style="position: relative;margin-top:15px;" class="col-md-12 col-sm-12 col-xs-12 image">
                <a class="urunfotosil" name="urunfoto_<?php echo $urunfoto_id; ?>" href="javascript:void(0);"><i class="fa fa-times-circle" style="position: absolute;top:-5px;right: 5px;font-size:20px;color:red;"></i></a>
                 <img class="img-responsive" src="../../<?php echo $urunfotocek['urunfoto_yol']; ?>">
               </div>
               <div style="margin-top:15px;" class='col-md-12 col-xs-12 col-sm-12'>
                 
                  <?php if ($urunfoto_kapak==1) { ?>

                   <h4 style="color:#707070;" align="center">Kapak Fotoğrafı</h4>
                    
                 <?php } else { ?>

                   <a name="urunfoto_<?php echo $urunfoto_id; ?>" class="btn btn-primary btn-block kapakfotodegistir" href="javascript:void(0);">Kapak Fotoğrafı Yap</a>


                  <?php } ?>
               
               </div>
             </div>

            <?php } ?>

            <div style="margin-bottom:50px;" class="col-md-3 col-sm-3 col-xs-12">
              
               <div style="position: relative;border:1px dashed;height: 200px;" class="col-md-12 col-sm-12 col-xs-12 imageadd">

                <div class="col-md-12 col-xs-12 col-sm-12" style="height: 130px;">
                  <h3 align="center">Yükle <i class="fa fa-upload"></i></h3>
                  <p style="font-size:14px;" align="center">Resim yüklemek için aşağıdan resmi seçin veya aşağıya sürükleyip bırakın. (900x590px)</p>
                </div>
                
                 <input style="height: 55px;" class="form-control urunfotoekle" type="file"   name="">
               </div>
              
             </div>


</div>

 <script type="text/javascript">

 	$('.fotosiraguncelle').click(function(){

          var id1=$(this).attr("name");
                var urunfoto_id=id1.substring(9);
                var urun_id = $('#urun_id').val();
                var sira = $('#urunfoto_'+urunfoto_id).val();

                $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'urunfotosiraguncelle':'ok','urunfoto_id':urunfoto_id,'sira':sira},
            success : function(sonuc){

              $('.x_content').html('<h3 align="center">Yükleniyor...</h3>');

              $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'urunfotoreload':'ok','urun_id':urun_id},
            success : function(sonuc){

             var sonuc = $.trim(sonuc);
              
              $('.x_content').html(sonuc);

              

               }

             });

               }

               });


        });

        $('.kapakfotodegistir').click(function(){

          var id1=$(this).attr("name");
                var urunfoto_id=id1.substring(9);
                var urun_id = $('#urun_id').val();

                swal({
  title: "Emin misiniz?",
  text: "Bu fotoğraf kapak fotoğrafı yapılsın mı?",
  icon: "info",
  buttons: ["Vazgeç", "Evet"]
})
.then((willDelete) => {
  if (willDelete) {

$.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'urunfotokapakdegistir':'ok','urunfoto_id':urunfoto_id,'urun_id':urun_id},
            success : function(sonuc){

              $('.x_content').html('<h3 align="center">Yükleniyor...</h3>');

              $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'urunfotoreload':'ok','urun_id':urun_id},
            success : function(sonuc){

             var sonuc = $.trim(sonuc);
              
              $('.x_content').html(sonuc);

              

               }

             });

               }

               })
     }

     })


        })


         
         $('.urunfotosil').click(function(){

          var id1=$(this).attr("name");
                var urunfoto_id=id1.substring(9);
                var urun_id = $('#urun_id').val();

                swal({
  title: "Emin misiniz?",
  text: "Ürünün bu fotoğrafını silmek istiyor musunuz?",
  icon: "warning",
  buttons: ["Vazgeç", "Sil"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

    $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'urunfotosil':'ok','urunfoto_id':urunfoto_id},
            success : function(sonuc){

              $('.x_content').html('<h3 align="center">Yükleniyor...</h3>');

               $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'urunfotoreload':'ok','urun_id':urun_id},
            success : function(sonuc){

             var sonuc = $.trim(sonuc);
              
              $('.x_content').html(sonuc);

              

               }

             });



               }

             });


     }

     })
         });

         $('.urunfotoekle').change(function(){

          var input = $(this);
            
           
       var urun_id = $('#urun_id').val();
      var foto = $(this).val();
      var filevalue = $(this).get(0).files[0];

      if (foto.length!=0) {

        swal({
  title: "Emin misiniz?",
  text: "Bu fotoğraf ürün galerisine eklenecek.",
  icon: "info",
  buttons: ["Vazgeç", "Ekle"]
})
.then((willDelete) => {
  if (willDelete) {


    var fotouzanti=foto.split('.').pop();

      

      var data = new FormData();
      data.append('urunfotoekle',"ok");
      data.append("file",filevalue);
      data.append('urun_id',urun_id);

      if (fotouzanti!='jpg' && fotouzanti!='jpeg' && fotouzanti!='png'){


           swal({

  title: "Bilgi",
  text: "Sadece .jpg, .jpeg, .png uzantılı dosyaları yükleyebilirsiniz.",
  icon: "info",
  button: "OK",
});


               } else {

                $('.imageadd').html('<h3 style="margin-top:80px;" align="center">Ekleniyor...</h3>');

               $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            enctype : 'multipart/form-data',
            data : data,
            processData: false,
            contentType: false,
            cache: false,
            success : function(sonuc){

            sonuc=$.trim(sonuc);

           if (sonuc=="ok") {

$('.x_content').html('<h3 align="center">Yükleniyor...</h3>');

               $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'urunfotoreload':'ok','urun_id':urun_id},
            success : function(sonuc){

             var sonuc = $.trim(sonuc);
              
              $('.x_content').html(sonuc);

              

               }

             });
           } else {

            location.reload();
           }

             }

          })

                 }



     }

     })

        
      
        }

         })

       </script>

<?php } else if (isset($_POST['urunfotosiraguncelle'])){

$urunfoto_id = $_POST['urunfoto_id'];
$foto_sira = $_POST['sira'];

$hazirla=$db->prepare("UPDATE urunfoto set

foto_sira=:foto_sira

where urunfoto_id='$urunfoto_id'

	");

$derle=$hazirla->execute(array(
"foto_sira" => $foto_sira
));



} else if (isset($_POST['urunfotokapakdegistir'])){

$urunfoto_id=$_POST['urunfoto_id'];
$urun_id=$_POST['urun_id'];

$hazirla=$db->prepare("UPDATE urunfoto set

urunfoto_kapak=:urunfoto_kapak,
foto_sira=:foto_sira

where urun_id='$urun_id' and urunfoto_kapak='1'


	");

$derle=$hazirla->execute(array(

"urunfoto_kapak" => 0,
"foto_sira" => 1

));

$hazirla=$db->prepare("UPDATE urunfoto set

urunfoto_kapak=:urunfoto_kapak,
foto_sira=:foto_sira

where urunfoto_id='$urunfoto_id'
	");

$derle=$hazirla->execute(array(

"urunfoto_kapak" => 1,
"foto_sira" => NULL

));





} else if (isset($_POST['urunfotoekle'])){

$urun_id = $_POST['urun_id'];
$urunfotosec=$db->prepare("SELECT * from urunfoto where urun_id=:id");
$urunfotosec->execute(array(

"id" => $urun_id

));

$urunfotosay=$urunfotosec->rowCount();

if ($urunfotosay==0) {
	
	$urun_kapakfoto=1;

} else {
    
    $urun_kapakfoto=0;

}

$name=$_FILES['file']['name'];
$uzanti=ext($_FILES['file']['name']);
$tmpname=$_FILES['file']['tmp_name'];
$depodosya = 'dimg/urunfoto';

$image = new SimpleImage();
	$image->load($tmpname);
	$image->resize(800,800);
	$image->save($tmpname);
	$uniq=uniqid();
	$refimgyol=$depodosya."/".$uniq.".".$uzanti;
	@move_uploaded_file($tmpname, "$depodosya/$uniq.$uzanti");

	$hazirla=$db->prepare("INSERT into urunfoto set

urunfoto_yol=:urunfoto_yol,
urun_id=:urun_id,
urunfoto_kapak=:urunfoto_kapak,
foto_sira=:foto_sira

		");

	$derle=$hazirla->execute(array(

"urunfoto_yol" => $refimgyol,
"urun_id" => $urun_id,
"urunfoto_kapak" => $urun_kapakfoto,
"foto_sira" => $urunfotosay

));

	if ($derle) {
		
		echo "ok";
	}




} else if (isset($_POST['ekipuyeekle'])){

$uye_adsoyad = trim($_POST['uye_adsoyad']);
 $uye_gorev = trim($_POST['uye_gorev']);
 $uye_gorev_eng = trim($_POST['uye_gorev_eng']);
 $uye_sira = $_POST['uye_sira'];
 

 $name=$_FILES['uye_foto']['name'];

 $uzanti=ext($_FILES['uye_foto']['name']);
$tmp_name=$_FILES['uye_foto']['tmp_name'];
$depodosya = 'dimg/uyefoto';

$image = new SimpleImage();
	$image->load($tmp_name);
	$image->resize(128,128);
	$image->save($tmp_name);



$uniq=uniqid();
$refimgyol=$depodosya."/".$uniq.".".$uzanti;

@move_uploaded_file($tmp_name, "$depodosya/$uniq.$uzanti");

$hazirla = $db->prepare("INSERT ekipuyeleri set

uye_adsoyad=:uye_adsoyad,
uye_gorev=:uye_gorev,
uye_gorev_eng=:uye_gorev_eng,
uye_foto=:uye_foto,
uye_sira=:uye_sira

 	");

 $derle=$hazirla->execute(array(

"uye_adsoyad" => htmlspecialchars($uye_adsoyad),
"uye_gorev" => htmlspecialchars($uye_gorev),
"uye_gorev_eng" => htmlspecialchars($uye_gorev_eng),
"uye_foto" => $refimgyol,
"uye_sira" => $uye_sira

 )); 


header("Location:nedmin/production/ekip-ayarlari");


 } else if (isset($_POST['ekipuyesil'])){

$uye_id = $_POST['uye_id'];

$ekipuyesil = $db->prepare("DELETE from ekipuyeleri where uye_id=:id");
$silekipuye = $ekipuyesil->execute(array(
"id" => $uye_id
));

if ($silekipuye) {
	
	echo "ok";
}

 } else if (isset($_POST['ekipuyeduzenle'])){

 $uye_adsoyad = trim($_POST['uye_adsoyad']);
 $uye_gorev = trim($_POST['uye_gorev']);
 $uye_gorev_eng = trim($_POST['uye_gorev_eng']);
 $uye_id = $_POST['uye_id'];
 $uye_sira = $_POST['uye_sira'];

 $name=$_FILES['uye_foto']['name'];

 

if (strlen($name)==0) {

	$hazirla = $db->prepare("UPDATE ekipuyeleri set

uye_adsoyad=:uye_adsoyad,
uye_gorev=:uye_gorev,
uye_sira=:uye_sira,
uye_gorev_eng=:uye_gorev_eng

where uye_id='$uye_id'
 	");

 $derle=$hazirla->execute(array(

"uye_adsoyad" => htmlspecialchars($uye_adsoyad),
"uye_gorev" => htmlspecialchars($uye_gorev),
"uye_sira" => $uye_sira,
"uye_gorev_eng" => htmlspecialchars($uye_gorev_eng)

 ));
	
	

} else {

$uzanti=ext($_FILES['uye_foto']['name']);
$tmp_name=$_FILES['uye_foto']['tmp_name'];
$uye_sira = $_POST['uye_sira'];
$depodosya = 'dimg/uyefoto';

$image = new SimpleImage();
	$image->load($tmp_name);
	$image->resize(128,128);
	$image->save($tmp_name);



$uniq=uniqid();
$refimgyol=$depodosya."/".$uniq.".".$uzanti;

@move_uploaded_file($tmp_name, "$depodosya/$uniq.$uzanti");
 

 $hazirla = $db->prepare("UPDATE ekipuyeleri set

uye_adsoyad=:uye_adsoyad,
uye_gorev=:uye_gorev,
uye_gorev_eng=:uye_gorev_eng,
uye_foto=:uye_foto,
uye_sira=:uye_sira

where uye_id='$uye_id'

 	");

 $derle=$hazirla->execute(array(

"uye_adsoyad" => htmlspecialchars($uye_adsoyad),
"uye_gorev" => htmlspecialchars($uye_gorev),
"uye_gorev_eng" => htmlspecialchars($uye_gorev_eng),
"uye_foto" => $refimgyol,
"uye_sira" => $uye_sira

 )); 

}

header("Location:nedmin/production/ekip-ayarlari");



 } else if (isset($_POST['sorukaldir'])){

$soru_id = $_POST['soru_id'];

$sorusil=$db->prepare("DELETE from sss where soru_id='$soru_id'");
$silsoru=$sorusil->execute();

if ($silsoru) {
  
  echo "ok";
}

 } else if (isset($_POST['ikonlistekaldir'])){

$ikonliste_id = $_POST['ikonliste_id'];

$ikonlistesil=$db->prepare("DELETE from ikonliste where ikonliste_id='$ikonliste_id'");
$silikonliste=$ikonlistesil->execute();

if ($silikonliste) {
  
  echo "ok";
}

 } else if (isset($_POST['sekmetitleduzenle'])){


$hazirla=$db->prepare("UPDATE seoayarlar set

anasayfa_title=:anasayfa_title,
hakkimizda_title=:hakkimizda_title,
iletisim_title=:iletisim_title,
blog_title=:blog_title,
ekip_title=:ekip_title,
sss_title=:sss_title


  ");

$derle=$hazirla->execute(array(

"anasayfa_title" => htmlspecialchars(trim($_POST['anasayfa_title'])),
"hakkimizda_title" => htmlspecialchars(trim($_POST['hakkimizda_title'])),
"iletisim_title" => htmlspecialchars(trim($_POST['iletisim_title'])),
"blog_title" => htmlspecialchars(trim($_POST['blog_title'])),
"ekip_title" => htmlspecialchars(trim($_POST['ekip_title'])),
"sss_title" => htmlspecialchars(trim($_POST['sss_title']))

));

if ($derle) {
  
  echo "ok";
}


 } else if (isset($_POST['menubaslikduzenle'])){


$hazirla=$db->prepare("UPDATE seoayarlar set

menu_anasayfa=:menu_anasayfa,
menu_hakkimizda=:menu_hakkimizda,
menu_iletisim=:menu_iletisim,
menu_blog=:menu_blog,
menu_ekip=:menu_ekip,
menu_sss=:menu_sss


  ");

$derle=$hazirla->execute(array(

"menu_anasayfa" => htmlspecialchars(trim($_POST['menu_anasayfa'])),
"menu_hakkimizda" => htmlspecialchars(trim($_POST['menu_hakkimizda'])),
"menu_iletisim" => htmlspecialchars(trim($_POST['menu_iletisim'])),
"menu_blog" => htmlspecialchars(trim($_POST['menu_blog'])),
"menu_ekip" => htmlspecialchars(trim($_POST['menu_ekip'])),
"menu_sss" => htmlspecialchars(trim($_POST['menu_sss']))

));

if ($derle) {
  
  echo "ok";
}


 } else if (isset($_POST['sssduzenle'])){

$sorusec=$db->prepare("SELECT * from sss");
$sorusec->execute();

while ($sorucek=$sorusec->fetch(PDO::FETCH_ASSOC)) { 
  
  $soru_id = $sorucek['soru_id'];

  $hazirla=$db->prepare("UPDATE sss set

soru_baslik=:soru_baslik,
soru_aciklama=:soru_aciklama,
soru_sira=:soru_sira

where soru_id='$soru_id'
    ");

  $derle=$hazirla->execute(array(
"soru_baslik" => $_POST['soru_baslik_'.$soru_id],
"soru_aciklama" => $_POST['soru_aciklama_'.$soru_id],
"soru_sira" => $_POST['soru_sira_'.$soru_id]
  ));


}

if ($derle) {
  
  echo "ok";
}

 } else if (isset($_POST['soruekle'])){

$soru_baslik = trim($_POST['soru_baslik']);
$soru_aciklama = trim($_POST['soru_aciklama']);
$soru_sira = $_POST['soru_sira'];

$hazirla=$db->prepare("INSERT into sss set

soru_sira=:soru_sira,
soru_aciklama=:soru_aciklama,
soru_baslik=:soru_baslik

  ");


$derle=$hazirla->execute(array(
"soru_sira" =>$soru_sira,
"soru_aciklama" =>$soru_aciklama,
"soru_baslik" => $soru_baslik
));

header("Location:nedmin/production/sss");

 } else if (isset($_POST['hakkimizdalistguncelle'])){


$ikonlistesec=$db->prepare("SELECT * from ikonliste");
$ikonlistesec->execute();
while ($ikonlistecek=$ikonlistesec->fetch(PDO::FETCH_ASSOC)) {

    $ikonliste_id = $ikonlistecek['ikonliste_id'];
	$ikonliste_baslik = htmlspecialchars(trim($_POST['ikonliste_baslik_'.$ikonliste_id]));
	$ikonliste_sira = $_POST['ikonliste_sira_'.$ikonliste_id];
	$ikonliste_aciklama = htmlspecialchars(trim($_POST['ikonliste_aciklama_'.$ikonliste_id]));
	$ikon_templatead = $_POST['ikon_templatead_'.$ikonliste_id];
	
	$hazirla=$db->prepare("UPDATE ikonliste set


ikonliste_baslik=:ikonliste_baslik,
ikonliste_sira=:ikonliste_sira,
ikonliste_aciklama=:ikonliste_aciklama,
ikon_templatead=:ikon_templatead

where ikonliste_id='$ikonliste_id'

		");

	$derle=$hazirla->execute(array(

"ikonliste_baslik" => $ikonliste_baslik,
"ikonliste_sira" => $ikonliste_sira,
"ikonliste_aciklama" => $ikonliste_aciklama,
"ikon_templatead" => $ikon_templatead

	));



}

echo "ok";


 } else if (isset($_POST['googlemapsduzenle'])){

$googlemaps_api = trim($_POST['googlemaps_api']);

$hazirla=$db->prepare("UPDATE genelayarlar set

googlemaps_api=:googlemaps_api

	");

$derle=$hazirla->execute(array(

"googlemaps_api" => $googlemaps_api,

));

if ($derle) {
	
	echo "ok";
}

} else if (isset($_POST['googleanalyticsduzenle'])){

	

$googleanalytics_api = trim($_POST['googleanalytics_api']);

$hazirla=$db->prepare("UPDATE genelayarlar set

googleanalytics_api=:googleanalytics_api

	");

$derle=$hazirla->execute(array(

"googleanalytics_api" => $googleanalytics_api,

));

if ($derle) {
	
	echo "ok";
}

} else if (isset($_POST['referanslogosil'])){

$referans_id = $_POST['referans_id'];

$referanssec=$db->prepare("SELECT * from referanslar where referans_id=:id");
$referanssec->execute(array(
"id" => $referans_id
));

$referanscek=$referanssec->fetch(PDO::FETCH_ASSOC);


$referans_logo = $referanscek['referans_logo'];



$referanslogosil=$db->prepare("DELETE from referanslar where referans_id=:id");
$silreferanslogo=$referanslogosil->execute(array(

"id" => $referans_id
));

if ($silreferanslogo) {
	
	unlink($referans_logo);

	echo "ok";
}






} else if (isset($_POST['hakkimizdaeditadmin'])){

$hakkimizda_baslik = trim($_POST['hakkimizda_baslik']);
$hakkimizda_text = $_POST['hakkimizda_text'];

$hazirla=$db->prepare("UPDATE genelayarlar set

hakkimizda_baslik=:hakkimizda_baslik,
hakkimizda_text=:hakkimizda_text
	");


$derle=$hazirla->execute(array(

"hakkimizda_baslik" => htmlspecialchars($hakkimizda_baslik),
"hakkimizda_text" => $hakkimizda_text
));

if ($derle) {
	
	echo "ok";
}



} else if (isset($_POST['iletisimbaslikduzenle'])){

$ayar_iletisimbaslik = trim($_POST['ayar_iletisimbaslik']);

$hazirla=$db->prepare("UPDATE genelayarlar set

ayar_iletisimbaslik=:ayar_iletisimbaslik

  ");

$derle=$hazirla->execute(array(

"ayar_iletisimbaslik" => htmlspecialchars($ayar_iletisimbaslik),

));

if ($derle) {
  
  echo "ok";
}

} else if (isset($_POST['mailbaslikduzenle'])){

$ayar_mailbaslik = trim($_POST['ayar_mailbaslik']);

$hazirla=$db->prepare("UPDATE genelayarlar set

ayar_mailbaslik=:ayar_mailbaslik

  ");

$derle=$hazirla->execute(array(

"ayar_mailbaslik" => htmlspecialchars($ayar_mailbaslik),

));

if ($derle) {
  
  echo "ok";
}

} else if (isset($_POST['ekipbaslikduzenle'])){

$ayar_ekipbaslik = $_POST['ayar_ekipbaslik'];

$hazirla=$db->prepare("UPDATE genelayarlar set

ayar_ekipbaslik=:ayar_ekipbaslik

  ");


$derle=$hazirla->execute(array(
"ayar_ekipbaslik" => htmlspecialchars($ayar_ekipbaslik)
));

if ($derle) {
  
  echo "ok";
}

} else if (isset($_POST['referanslarbaslikduzenle'])){

$ayar_referanslarbaslik = $_POST['ayar_referanslarbaslik'];

$hazirla=$db->prepare("UPDATE genelayarlar set

ayar_referanslarbaslik=:ayar_referanslarbaslik

  ");


$derle=$hazirla->execute(array(
"ayar_referanslarbaslik" => htmlspecialchars($ayar_referanslarbaslik)
));

if ($derle) {
  
  echo "ok";
}

} else if (isset($_POST['sssbaslikduzenleadmin'])){

$ayar_sssbaslik = trim($_POST['ayar_sssbaslik']);

$hazirla=$db->prepare("UPDATE genelayarlar set

ayar_sssbaslik=:ayar_sssbaslik

  ");

$derle=$hazirla->execute(array(

"ayar_sssbaslik" => htmlspecialchars($ayar_sssbaslik),

));

if ($derle) {
  
  echo "ok";
}

} else if (isset($_POST['mailduzenleadmin'])){

$ayar_mail = trim($_POST['ayar_mail']);
$ayar_mailsifre = $_POST['ayar_mailsifre'];

$hazirla=$db->prepare("UPDATE genelayarlar set

ayar_mail=:ayar_mail,
ayar_mailsifre=:ayar_mailsifre

	");

$derle=$hazirla->execute(array(

"ayar_mail" => htmlspecialchars($ayar_mail),
"ayar_mailsifre" => htmlspecialchars($ayar_mailsifre)

));

if ($derle) {
	
	echo "ok";
}

} else if (isset($_POST['telnoduzenleadmin'])){

$ayar_telno = trim($_POST['ayar_telno']);

$hazirla=$db->prepare("UPDATE genelayarlar set

ayar_telno=:ayar_telno

	");

$derle=$hazirla->execute(array(

"ayar_telno" => htmlspecialchars($ayar_telno),

));

if ($derle) {
	
	echo "ok";
}

} else if (isset($_POST['adresduzenleadmin'])){

$ayar_adres = trim($_POST['ayar_adres']);

$hazirla=$db->prepare("UPDATE genelayarlar set

ayar_adres=:ayar_adres

	");

$derle=$hazirla->execute(array(

"ayar_adres" => htmlspecialchars($ayar_adres),

));

if ($derle) {
	
	echo "ok";
}

} else if (isset($_POST['ustkategorisec'])){

$kategori_id=$_POST['kategori_id']; ?>

                           <option selected="" hidden="" value="secilmedi">Kategori Seçin</option>

                           <?php $kategorisec=$db->prepare("SELECT * from kategoriler where kategori_ust=:ust");
                           $kategorisec->execute(array(
                           	"ust" => $kategori_id
                           ));

                           while ($kategoricek=$kategorisec->fetch(PDO::FETCH_ASSOC)) { ?>
                              <option value="<?php echo $kategoricek['kategori_id']; ?>"><?php echo $kategoricek['kategori_ad']; ?></option>
                            <?php } ?>



<?php } else if (isset($_POST['girisfotoguncelle'])){

$name=$_FILES['file']['name'];
$ayar_girisfotolink = htmlspecialchars(trim($_POST['ayar_girisfotolink']));

if (strlen($name)==0) {
	

	$hazirla=$db->prepare("UPDATE genelayarlar set


ayar_girisfotolink=:ayar_girisfotolink

	");

$derle=$hazirla->execute(array(


"ayar_girisfotolink" => $ayar_girisfotolink

));


} else {

	$uzanti=ext($_FILES['file']['name']);
$tmp_name=$_FILES['file']['tmp_name'];
$depodosya = 'dimg/girisfoto';





$uniq=uniqid();
$refimgyol=$depodosya."/".$uniq.".".$uzanti;

@move_uploaded_file($tmp_name, "$depodosya/$uniq.$uzanti");

$hazirla=$db->prepare("UPDATE genelayarlar set

ayar_girisfoto=:ayar_girisfoto,
ayar_girisfotolink=:ayar_girisfotolink

	");

$derle=$hazirla->execute(array(

"ayar_girisfoto" => $refimgyol,
"ayar_girisfotolink" => $ayar_girisfotolink

));


}

echo "ok";

} else if (isset($_POST['kargoduzenleadmin'])){

$kargo_ucreti = trim($_POST['kargo_ucreti']);
$ayar_kargosirketi = $_POST['ayar_kargosirketi'];
$kargo_iadekodu = trim($_POST['kargo_iadekodu']);
$iade_adsoyad = trim($_POST['iade_adsoyad']);
$iade_adres = trim($_POST['iade_adres']);

if (empty(trim($_POST['kargobedava_limit']))) {
	
	$kargobedava_limit = NULL;

} else {

	$kargobedava_limit = trim($_POST['kargobedava_limit']);
}



$hazirla=$db->prepare("UPDATE genelayarlar set


kargobedava_limit=:kargobedava_limit,
ayar_kargosirketi=:ayar_kargosirketi,
kargo_iadekodu=:kargo_iadekodu,
iade_adsoyad=:iade_adsoyad,
iade_adres=:iade_adres

	");

$derle=$hazirla->execute(array(

"kargobedava_limit" => $kargobedava_limit,
"ayar_kargosirketi" => $ayar_kargosirketi,
"kargo_iadekodu" => htmlspecialchars($kargo_iadekodu),
"iade_adsoyad" => htmlspecialchars($iade_adsoyad),
"iade_adres" => htmlspecialchars($iade_adres)

));

if ($derle) {
	
	echo "ok";
}

} else if (isset($_POST['urunozelliksil'])){

$urunozellik_id = $_POST['urunozellik_id'];

$silozellik = $db->prepare('DELETE from urunozellik where urunozellik_id=:id');
$ozelliksil = $silozellik->execute(array(
"id" => $urunozellik_id
));

if ($ozelliksil) {
	
	echo "ok";
}

} else if (isset($_POST['altseceneksil'])){

$altsecenek_id = $_POST['altsecenek_id'];

$seceneksil = $db->prepare('DELETE from altsecenekler where altsecenek_id=:id');
$silsecenek = $seceneksil->execute(array(
"id" => $altsecenek_id
));

$urunseceneksil=$db->prepare("DELETE from urunsecenekler where altsecenek_id=:id");
$urunseceneksil->execute(array(
"id" => $altsecenek_id
));

if ($silsecenek) {
	
	echo "ok";
}

} else if (isset($_POST['seceneksil'])){

$secenek_id = $_POST['secenek_id'];

$seceneksil = $db->prepare('DELETE from secenekler where secenek_id=:id');
$silsecenek = $seceneksil->execute(array(
"id" => $secenek_id
));

$altseceneksil = $db->prepare('DELETE from altsecenekler where secenek_id=:id');
$altsilsecenek = $altseceneksil->execute(array(
"id" => $secenek_id
));

$urunseceneksil=$db->prepare("DELETE from urunsecenekler where secenek_id=:id");
$urunseceneksil->execute(array(
"id" => $secenek_id
));

$urunaltseceneksil=$db->prepare("DELETE from urunaltsecenekler where secenek_id=:id");
$urunaltseceneksil->execute(array(
"id" => $secenek_id
));

$kategoriseceneksil=$db->prepare("DELETE from kategorisecenekler where secenek_id=:id");
$kategoriseceneksil->execute(array(
"id" => $secenek_id
));

if ($silsecenek) {
	
	echo "ok";
}

} else if (isset($_POST['secenekekle'])){


$secenek_ad = trim($_POST['secenek_ad']);
$secenek_name = seo($secenek_ad);

$hazirla=$db->prepare("INSERT into secenekler set


secenek_ad=:secenek_ad,
secenek_name=:secenek_name

	");

$derle=$hazirla->execute(array(

"secenek_ad" => $secenek_ad,
"secenek_name" => $secenek_name
));

if ($derle) {
	
	header("Location:nedmin/production/secenek-ayarlari");
}



} else if (isset($_POST['altsecenekekle'])){

$secenek_id = $_POST['secenek_id'];
$secenek_ad = $_POST['altsecenek_ad'];

$hazirla=$db->prepare("INSERT into altsecenekler set

secenek_id=:secenek_id,
altsecenek_ad=:altsecenek_ad

	");

$derle=$hazirla->execute(array(
"secenek_id" => $secenek_id,
"altsecenek_ad" => $secenek_ad
));

if ($derle) {
	
	echo "ok";
}



} else if (isset($_POST['kategoriseceneksec'])){


$seceneksec=$db->prepare("SELECT * from secenekler");
$seceneksec->execute();

echo '<h4 style="margin-bottom:25px;" align="center">İşaretleme yapmadığınız seçenek türleri ürün sayfasında gözükmez.</h4>';


while ($secenekcek=$seceneksec->fetch(PDO::FETCH_ASSOC)) { 


$altseceneksec=$db->prepare("SELECT * from altsecenekler where secenek_id=:id order by altsecenek_ad ASC");
$altseceneksec->execute(array(
"id" =>  $secenekcek['secenek_id']
));



	?>

	
	
	<h3 align="center"><?php echo $secenekcek['secenek_ad']; ?> Seçenekleri<hr></h3>

 <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">
                        </label>
                        <div align="center" class="col-md-7 col-sm-7 col-xs-12">

<?php while ($altsecenekcek=$altseceneksec->fetch(PDO::FETCH_ASSOC)) { 

$altsecenek_ad = $altsecenekcek['altsecenek_ad'];
	?>

 
    
    


  

                         <div align="left" class="col-md-4" > 

     <label class="checklabell"><?php  echo $altsecenek_ad; ?>
  <input name="secenek_id_<?php echo $secenekcek['secenek_id']; ?>[]" value="<?php  echo $altsecenekcek['altsecenek_id']; ?>"  type="checkbox">
  <span class="checkmark"></span>
</label>

<br>




</div>

                          
                        
  
   

<?php } ?>

</div>
</div>

<br>


<?php } } else if (isset($_POST['kategoriseceneksecduzenle'])){



$urun_id =  $_POST['urun_id'];


$seceneksec=$db->prepare("SELECT * from secenekler");
$seceneksec->execute();

echo '<h4 style="margin-bottom:25px;" align="center">İşaretleme yapmadığınız seçenek türleri ürün sayfasında gözükmez.</h4>';



while ($secenekcek=$seceneksec->fetch(PDO::FETCH_ASSOC)) { 

$secenek_id = $secenekcek['secenek_id'];

$altseceneksec=$db->prepare("SELECT * from altsecenekler where secenek_id=:id order by altsecenek_ad ASC");
$altseceneksec->execute(array(
"id" =>  $secenekcek['secenek_id']
));





	?>


<h3 align="center"><?php echo $secenekcek['secenek_ad']; ?> Seçenekleri<hr></h3>

 <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">
                        </label>
                        <div align="center" class="col-md-7 col-sm-7 col-xs-12">

<?php while ($altsecenekcek=$altseceneksec->fetch(PDO::FETCH_ASSOC)) { 

$altsecenek_ad = $altsecenekcek['altsecenek_ad'];

$urunaltseceneksor=$db->prepare("SELECT * from urunaltsecenekler where urun_id=:urunid and secenek_id=:secenekid and altsecenek_ad=:ad");

$urunaltseceneksor->execute(array(

"urunid" => $urun_id,
"secenekid" => $secenekcek['secenek_id'],
"ad" => $altsecenek_ad

));

$urunaltseceneksay=$urunaltseceneksor->rowCount();

	?>

 
    
    


  

                         <div align="left" class="col-md-4" > 

     <label class="checklabell"><?php  echo $altsecenek_ad; ?>
  <input <?php if ($urunaltseceneksay==1) { ?>
  	checked=''
  <?php } ?> name="secenek_id_<?php echo $secenek_id ?>[]" value="<?php  echo $altsecenekcek['altsecenek_id']; ?>"  type="checkbox">
  <span class="checkmark"></span>
</label>

<br>




</div>

                          
                        
  
   

<?php } ?>

</div>
</div>

<br>

 <?php } } else if (isset($_POST['listesil'])){

$liste_id = $_POST['liste_id'];

$listesil=$db->prepare("DELETE from anasayfaurunliste where anasayfaurunliste_id='$liste_id'");
$silliste=$listesil->execute();

$listesil2=$db->prepare("DELETE from anasayfalisteurun where anasayfaurunliste_id='$liste_id'");
$silliste2=$listesil2->execute();

if ($silliste2) {
	
	echo "ok";
}


} else if (isset($_POST['kampanyasil'])){

$kampanya_id = $_POST['kampanya_id'];

$kampanyasil=$db->prepare("DELETE from kampanyalar where kampanya_id='$kampanya_id'");
$silkampanya=$kampanyasil->execute();

$kampanyasil2=$db->prepare("DELETE from kampanyaurun where kampanya_id='$kampanya_id'");
$silkampanya2=$kampanyasil2->execute();

if ($silkampanya2) {
	
	echo "ok";
}


} else if (isset($_POST['kampanyamenudegistir'])){

$kampanya_id = $_POST['kampanya_id'];
$checkboxdeger = $_POST['checkboxdeger'];

$hazirla=$db->prepare("UPDATE kampanyalar set

kampanya_menu=:kampanya_menu

where kampanya_id='$kampanya_id'
	");

$derle=$hazirla->execute(array(
"kampanya_menu" => $checkboxdeger
));

if ($derle) {
	
	echo "ok";
}

} else if (isset($_POST['anasayfalisteduzenle'])){


$liste_baslik = trim($_POST['liste_baslik']);
$liste_turu = $_POST['liste_turu'];
$liste_id = $_POST['liste_id'];

$hazirla=$db->prepare("UPDATE anasayfaurunliste set


liste_baslik=:liste_baslik,
liste_turu=:liste_turu

where anasayfaurunliste_id='$liste_id'
	");


$derle=$hazirla->execute(array(


"liste_baslik" => $liste_baslik,
"liste_turu" => $liste_turu

));

if ($derle) {
	
	echo "ok";
}

} else if (isset($_POST['kampanyaduzenle'])){


$kampanya_baslik = trim($_POST['kampanya_baslik']);
$kampanya_id = $_POST['kampanya_id'];
$kampanya_seourl = seo($kampanya_baslik);

$kampanyasec=$db->prepare("SELECT * from kampanyalar where kampanya_baslik='$kampanya_baslik'");
$kampanyasec->execute();

$kampanyasay=$kampanyasec->rowCount();

if ($kampanyasay==1) {
	
	echo "mevcutbaslik";

} else {




$hazirla=$db->prepare("UPDATE kampanyalar set


kampanya_baslik=:kampanya_baslik,
kampanya_seourl=:kampanya_seourl

where kampanya_id='$kampanya_id'
	");


$derle=$hazirla->execute(array(


"kampanya_baslik" => $kampanya_baslik,
"kampanya_seourl" => $kampanya_seourl

));

if ($derle) {
	
	echo "ok";
}

}

} else if (isset($_POST['listeurunsil'])){

$listeurun_id = $_POST['listeurun_id'];

$listeurunsil=$db->prepare("DELETE from anasayfalisteurun where anasayfalisteurun_id='$listeurun_id'");
$sillisteurun=$listeurunsil->execute();

if ($sillisteurun) {
	
	echo "ok";
}

} else if (isset($_POST['kampanyaurunsil'])){

$kampanyaurun_id = $_POST['kampanyaurun_id'];

$kampanyaurunsil=$db->prepare("DELETE from kampanyaurun where kampanyaurun_id='$kampanyaurun_id'");
$silkampanyaurun=$kampanyaurunsil->execute();

if ($silkampanyaurun) {
	
	echo "ok";
}

} else if (isset($_POST['ilgiliurunsil'])){

$ilgiliurun_id = $_POST['ilgiliurun_id'];

$ilgiliurunsil=$db->prepare("DELETE from ilgiliurunler where id='$ilgiliurun_id'");
$sililgiliurun=$ilgiliurunsil->execute();

if ($sililgiliurun) {
	
	echo "ok";
}

} else if (isset($_POST['listeurunsiraguncelle'])){

$listeurun_id = $_POST['listeurun_id'];
$sira = $_POST['sira'];

$hazirla=$db->prepare("UPDATE anasayfalisteurun set

urun_sira=:urun_sira

where anasayfalisteurun_id='$listeurun_id'
	");

$derle=$hazirla->execute(array(
"urun_sira" => $sira
));

if ($derle) {
	
	echo "ok";
}

} else if (isset($_POST['kampanyaurunsiraguncelle'])){

$kampanyaurun_id = $_POST['kampanyaurun_id'];
$sira = $_POST['sira'];

$hazirla=$db->prepare("UPDATE kampanyaurun set

urun_sira=:urun_sira

where kampanyaurun_id='$kampanyaurun_id'
	");

$derle=$hazirla->execute(array(
"urun_sira" => $sira
));

if ($derle) {
	
	echo "ok";
}

} else if (isset($_POST['ilgiliurunsiraguncelle'])){

$ilgiliurun_id = $_POST['ilgiliurun_id'];
$sira = $_POST['sira'];

$hazirla=$db->prepare("UPDATE ilgiliurunler set

urun_sira=:urun_sira

where id='$ilgiliurun_id'
	");

$derle=$hazirla->execute(array(
"urun_sira" => $sira
));

if ($derle) {
	
	echo "ok";
}

} else if (isset($_POST['kampanyasiraguncelle'])){

$kampanya_id = $_POST['kampanya_id'];
$sira = $_POST['sira'];

$hazirla=$db->prepare("UPDATE kampanyalar set

kampanya_sira=:kampanya_sira

where kampanya_id='$kampanya_id'
	");

$derle=$hazirla->execute(array(
"kampanya_sira" => $sira
));

if ($derle) {
	
	echo "ok";
}

} else if (isset($_POST['kategorisiraguncelle'])){

$kategori_id = $_POST['kategori_id'];
$sira = $_POST['sira'];

$hazirla=$db->prepare("UPDATE kategoriler set

kategori_sira=:kategori_sira

where kategori_id='$kategori_id'
	");

$derle=$hazirla->execute(array(
"kategori_sira" => $sira
));

if ($derle) {
	
	echo "ok";
}

} else if (isset($_POST['kategoriadguncelle'])){

$kategori_id = $_POST['kategori_id'];
$ad = $_POST['ad'];

$hazirla=$db->prepare("UPDATE kategoriler set

kategori_ad=:kategori_ad

where kategori_id='$kategori_id'
	");

$derle=$hazirla->execute(array(
"kategori_ad" => $ad
));

if ($derle) {
	
	echo "ok";
}

} else if (isset($_POST['anasayfalistesiraguncelle'])){

$liste_id = $_POST['liste_id'];
$sira = $_POST['sira'];

$hazirla=$db->prepare("UPDATE anasayfaurunliste set

liste_sira=:liste_sira

where anasayfaurunliste_id='$liste_id'
	");

$derle=$hazirla->execute(array(
"liste_sira" => $sira
));

if ($derle) {
	
	echo "ok";
}

} else if (isset($_POST['listeurunekle'])){

$liste_id = $_POST['liste_id'];
$urunler = $_POST['urun_id'];
$siralar = $_POST['urun_sira'];

$say=0;

foreach ($urunler as $urun_id) {
	
    $urun_id = trim($urun_id);
	$urun_sira = trim($siralar[$say]);

	$urunsec=$db->prepare("SELECT * from urunler where urun_id=:id");
    $urunsec->execute(array(
        "id" => $urun_id
    ));

    $urunsay = $urunsec->rowCount();


    $listeurunsec=$db->prepare("SELECT * from anasayfalisteurun where anasayfaurunliste_id='$liste_id' and urun_id='$urun_id'");

    $listeurunsec->execute();

    $listeurunsay = $listeurunsec->rowCount();

    if ($urunsay==1 and $listeurunsay==0) {
    	
    	$hazirla=$db->prepare("INSERT into anasayfalisteurun set

urun_id=:urun_id,
anasayfaurunliste_id=:anasayfaurunliste_id,
urun_sira=:urun_sira

    		");


    	$derle = $hazirla->execute(array(

"urun_id" => $urun_id,
"anasayfaurunliste_id" => $liste_id,
"urun_sira" => $urun_sira

    	));
    }

    $say++;
}

echo "ok";

} else if (isset($_POST['kampanyaurunekle'])){

$kampanya_id = $_POST['kampanya_id'];
$urunler = $_POST['urun_id'];
$siralar = $_POST['urun_sira'];

$say=0;

foreach ($urunler as $urun_id) {
	
    $urun_id = trim($urun_id);
	$urun_sira = trim($siralar[$say]);

	$urunsec=$db->prepare("SELECT * from urunler where urun_id=:id");
    $urunsec->execute(array(
        "id" => $urun_id
    ));

    $urunsay = $urunsec->rowCount();


    $kampanyaurunsec=$db->prepare("SELECT * from kampanyaurun where kampanya_id='$kampanya_id' and urun_id='$urun_id'");

    $kampanyaurunsec->execute();

    $kampanyaurunsay = $kampanyaurunsec->rowCount();

    if ($urunsay==1 and $kampanyaurunsay==0) {
    	
    	$hazirla=$db->prepare("INSERT into kampanyaurun set

urun_id=:urun_id,
kampanya_id=:kampanya_id,
urun_sira=:urun_sira

    		");


    	$derle = $hazirla->execute(array(

"urun_id" => $urun_id,
"kampanya_id" => $kampanya_id,
"urun_sira" => $urun_sira

    	));
    }

    $say++;
}

echo "ok";

} else if (isset($_POST['ilgiliurunekle'])){

$urun_id = $_POST['urun_id'];
$urunler = $_POST['ilgiliurun_id'];
$siralar = $_POST['urun_sira'];

$say=0;

foreach ($urunler as $ilgiliurun_id) {
	
    $ilgiliurun_id = trim($ilgiliurun_id);
	$urun_sira = trim($siralar[$say]);

	$urunsec=$db->prepare("SELECT * from urunler where urun_id=:id and urun_kaldirildi='0'");
    $urunsec->execute(array(
        "id" => $ilgiliurun_id
    ));

    $urunsay = $urunsec->rowCount();


    $ilgiliurunsec=$db->prepare("SELECT * from ilgiliurunler where ilgiliurun_id='$ilgiliurun_id' and urun_id='$urun_id'");

    $ilgiliurunsec->execute();

    $ilgiliurunsay = $ilgiliurunsec->rowCount();

    if ($urunsay==1 and $ilgiliurunsay==0) {
    	
    	$hazirla=$db->prepare("INSERT into ilgiliurunler set

urun_id=:urun_id,
ilgiliurun_id=:ilgiliurun_id,
urun_sira=:urun_sira

    		");


    	$derle = $hazirla->execute(array(

"urun_id" => $urun_id,
"ilgiliurun_id" => $ilgiliurun_id,
"urun_sira" => $urun_sira

    	));
    }

    $say++;
}

echo "ok";

} else if (isset($_POST['anasayfalisteekle'])){

$liste_baslik = trim($_POST['liste_baslik']);
$liste_sira = $_POST['liste_sira'];
$liste_turu = $_POST['liste_turu'];

$hazirla=$db->prepare("INSERT into anasayfaurunliste set

liste_baslik=:liste_baslik,
liste_sira=:liste_sira,
liste_turu=:liste_turu

	");

$derle=$hazirla->execute(array(
"liste_sira" => $liste_sira,
"liste_baslik" => htmlspecialchars($liste_baslik),
"liste_turu" => $liste_turu

));

if ($derle) {
	
	$liste_id = $db->lastInsertId();
	$urunler = $_POST['urun_id'];
    $siralar = $_POST['urun_sira'];


    $say=0;

foreach ($urunler as $urun_id) {
	
    $urun_id = trim($urun_id);
	$urun_sira = trim($siralar[$say]);

	$urunsec=$db->prepare("SELECT * from urunler where urun_id='$urun_id' and urun_kaldirildi='0'");
    $urunsec->execute();

    $urunsay = $urunsec->rowCount();


    $listeurunsec=$db->prepare("SELECT * from anasayfalisteurun where anasayfaurunliste_id='$liste_id' and urun_id='$urun_id'");

    $listeurunsec->execute();

    $listeurunsay = $listeurunsec->rowCount();

    if ($urunsay==1 and $listeurunsay==0) {
    	
    	$hazirla=$db->prepare("INSERT into anasayfalisteurun set

urun_id=:urun_id,
anasayfaurunliste_id=:anasayfaurunliste_id,
urun_sira=:urun_sira

    		");


    	$derle = $hazirla->execute(array(

"urun_id" => $urun_id,
"anasayfaurunliste_id" => $liste_id,
"urun_sira" => $urun_sira

    	));
    }

    $say++;
}


echo "ok";


}

} else if (isset($_POST['kampanyaekle'])){

$kampanya_baslik = trim($_POST['kampanya_baslik']);
$kampanya_sira = $_POST['kampanya_sira'];
$kampanya_menu = $_POST['kampanya_menu'];
$kampanya_seourl = seo($kampanya_baslik);

$kampanyasec=$db->prepare("SELECT * from kampanyalar where kampanya_baslik='$kampanya_baslik'");
$kampanyasec->execute();

$kampanyasay=$kampanyasec->rowCount();

if ($kampanyasay==1) {
	
	echo "mevcutbaslik";

} else {

$hazirla=$db->prepare("INSERT into kampanyalar set

kampanya_baslik=:kampanya_baslik,
kampanya_sira=:kampanya_sira,
kampanya_menu=:kampanya_menu,
kampanya_seourl=:kampanya_seourl

	");

$derle=$hazirla->execute(array(
"kampanya_sira" => $kampanya_sira,
"kampanya_baslik" => htmlspecialchars($kampanya_baslik),
"kampanya_menu" => $kampanya_menu,
"kampanya_seourl" => $kampanya_seourl

));

if ($derle) {
	
	$kampanya_id = $db->lastInsertId();
	$urunler = $_POST['urun_id'];
    $siralar = $_POST['urun_sira'];


    $say=0;

foreach ($urunler as $urun_id) {
	
    $urun_id = trim($urun_id);
	$urun_sira = trim($siralar[$say]);

	$urunsec=$db->prepare("SELECT * from urunler where urun_id=:id and urun_kaldirildi='0'");
    $urunsec->execute(array(
        "id" => $urun_id
    ));

    $urunsay = $urunsec->rowCount();


    $kampanyaurunsec=$db->prepare("SELECT * from kampanyaurun where kampanya_id='$kampanya_id' and urun_id='$urun_id'");

    $kampanyaurunsec->execute();

    $kampanyaurunsay = $kampanyaurunsec->rowCount();

    if ($urunsay==1 and $kampanyaurunsay==0) {
    	
    	$hazirla=$db->prepare("INSERT into kampanyaurun set

urun_id=:urun_id,
kampanya_id=:kampanya_id,
urun_sira=:urun_sira

    		");


    	$derle = $hazirla->execute(array(

"urun_id" => $urun_id,
"kampanya_id" => $kampanya_id,
"urun_sira" => $urun_sira

    	));
    }

    $say++;
}


echo "ok";


}

 }

} else if (isset($_POST['kargoucretduzenleadmin'])){

$kargoucretisec=$db->prepare("SELECT * from kargoucretleri");
$kargoucretisec->execute();

while ($kargoucreticek=$kargoucretisec->fetch(PDO::FETCH_ASSOC)) {
	
	$kargoucret_id = $kargoucreticek['kargoucret_id'];

	$min_desi = trim($_POST['min_desi_'.$kargoucret_id]);
	$max_desi = trim($_POST['max_desi_'.$kargoucret_id]);
	$kargo_ucreti = trim($_POST['kargo_ucreti_'.$kargoucret_id]);

	$hazirla=$db->prepare("UPDATE kargoucretleri set

min_desi=:min_desi,
max_desi=:max_desi,
kargo_ucreti=:kargo_ucreti

where kargoucret_id = '$kargoucret_id'

		");


	$derle=$hazirla->execute(array(

"min_desi" => $min_desi,
"max_desi" => $max_desi,
"kargo_ucreti" => $kargo_ucreti

	));
}

echo "ok";

} else if (isset($_POST['kargoucretsil'])){

$kargoucret_id = $_POST['kargoucret_id'];

$kargoucretsil = $db->prepare("DELETE from kargoucretleri where kargoucret_id='$kargoucret_id'");
$silkargoucret = $kargoucretsil->execute();

if ($silkargoucret) {
	
	echo "ok";
}

} else if (isset($_POST['kargoucretiekle'])){

$min_desi = trim($_POST['min_desi']);
$max_desi = trim($_POST['max_desi']);
$kargo_ucreti = trim($_POST['kargo_ucreti']);

$hazirla=$db->prepare("INSERT into kargoucretleri set

min_desi=:min_desi,
max_desi=:max_desi,
kargo_ucreti=:kargo_ucreti

	");


$derle=$hazirla->execute(array(

"min_desi" => $min_desi,
"max_desi" => $max_desi,
"kargo_ucreti" => $kargo_ucreti

));

if ($derle) {
	
	header("Location:nedmin/production/kargo-ayarlari");
}

} else if (isset($_POST['vadefarkiduzenle'])){

 $taksitseceneksec=$db->prepare("SELECT * from taksitsecenekleri where secenek_ad!='1' order by secenek_ad ASC");
                    $taksitseceneksec->execute();

                    while ($taksitsecenekcek=$taksitseceneksec->fetch(PDO::FETCH_ASSOC)) { 

                    	$secenek_id=$taksitsecenekcek['secenek_id'];
                    	$secenek_vadefarki = $_POST['secenek_id_'.$secenek_id];

                    	$hazirla=$db->prepare("UPDATE taksitsecenekleri set

secenek_vadefarki=:secenek_vadefarki

where secenek_id='$secenek_id'

                    		");

                    	$derle = $hazirla->execute(array(

"secenek_vadefarki" => $secenek_vadefarki

                    	));



                    	 } 

                    	 echo "ok";



} else if (isset($_POST['taksitaralikekle'])){

$taksit_altdeger = $_POST['taksit_altdeger'];
$taksit_ustdeger = $_POST['taksit_ustdeger'];

$hazirla=$db->prepare("INSERT into taksitler set

taksit_altdeger=:taksit_altdeger,
taksit_ustdeger=:taksit_ustdeger

	");


$derle=$hazirla->execute(array(
"taksit_altdeger" => $taksit_altdeger,
"taksit_ustdeger" => $taksit_ustdeger
));

if ($derle) {
	
	$taksit_id = $db->lastInsertId();

	$secenekler = $_POST['secenek_id'];

	foreach ($secenekler as $secenek_id) {
		
		$hazirla=$db->prepare("INSERT into taksitaraliksecenekleri set

secenek_id=:secenek_id,
taksit_id=:taksit_id

			");

		$derle=$hazirla->execute(array(

"secenek_id" => $secenek_id,
"taksit_id" => $taksit_id

		));
	}

	header("Location:nedmin/production/taksit-ayarlari");
}

} else if (isset($_POST['taksitaraliksil'])){

$taksit_id = $_POST['taksit_id'];

$taksitsil=$db->prepare("DELETE from taksitler where taksit_id='$taksit_id'");
$taksitsil->execute();

$taksitaralikseceneklerisil=$db->prepare("DELETE from taksitaraliksecenekleri where taksit_id='$taksit_id'");
$siltaksitaraliksecenekleri=$taksitaralikseceneklerisil->execute();

if ($siltaksitaraliksecenekleri) {
	
	echo "ok";
}


} else if (isset($_POST['taksitaralikduzenleadmin'])){

$taksitaraliksil=$db->prepare("DELETE from taksitaraliksecenekleri");
$taksitaraliksil->execute();

$taksitsec=$db->prepare("SELECT * from taksitler");
$taksitsec->execute();

while ($taksitcek=$taksitsec->fetch(PDO::FETCH_ASSOC)) {
	
	$taksit_id = $taksitcek['taksit_id'];
	$taksit_altdeger=$_POST['taksit_altdeger_'.$taksit_id]; 
	$taksit_ustdeger=$_POST['taksit_ustdeger_'.$taksit_id]; 

	$hazirla=$db->prepare("UPDATE taksitler set

taksit_altdeger=:taksit_altdeger,
taksit_ustdeger=:taksit_ustdeger

where taksit_id='$taksit_id'

		");

	$derle=$hazirla->execute(array(

"taksit_altdeger" => $taksit_altdeger,
"taksit_ustdeger" => $taksit_ustdeger

	));

	$secenekler = $_POST['secenek_id_'.$taksit_id];

	if (count($secenekler)!=0) {
		

	foreach ($secenekler as $secenek_id) {
		
		 $hazirla=$db->prepare("INSERT into taksitaraliksecenekleri set

taksit_id=:taksit_id,
secenek_id=:secenek_id

		 	");


		 $derle = $hazirla->execute(array(

"taksit_id" => $taksit_id,
"secenek_id" => $secenek_id

		 ));
	}

	}
}

echo "ok";

} else if (isset($_POST['iadekabul'])){

$siparisitem_id = $_POST['siparisitem_id'];

$siparisitemsec=$db->prepare("SELECT * from siparisitem where siparisitem_id='$siparisitem_id'");
$siparisitemsec->execute();
$siparisitemcek=$siparisitemsec->fetch(PDO::FETCH_ASSOC);
$kullanici_id = $siparisitemcek['kullanici_id'];
$urun_id = $siparisitemcek['urun_id'];

$urunsec=$db->prepare("SELECT * from urunler where urun_id='$urun_id'");
$urunsec->execute();
$uruncek=$urunsec->fetch(PDO::FETCH_ASSOC);


$kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_id='$kullanici_id'");
$kullanicisec->execute();
$kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

$kullanici_ad = $kullanicicek['kullanici_ad'];
$kullanici_mail = $kullanicicek['kullanici_mail'];
$urun_ad=$uruncek['urun_ad'];
$urun_marka=$uruncek['marka_ad'];
$iade_sebebi=$siparisitemcek['iade_text'];
$iade_miktar=$siparisitemcek['iade_miktar'];
$iade_tutar=$siparisitemcek['iade_tutar'];

$hazirla=$db->prepare("UPDATE siparisitem set

urun_iade=:urun_iade

where siparisitem_id='$siparisitem_id'
	");


$derle=$hazirla->execute(array(
"urun_iade" => 2
));


if ($derle) {

	$genelayarsec=$db->prepare("SELECT * from genelayarlar");
            $genelayarsec->execute();

            $genelayarcek=$genelayarsec->fetch(PDO::FETCH_ASSOC);
            $ayar_mail = $genelayarcek['ayar_mail'];
            $ayar_mailsifre = $genelayarcek['ayar_mailsifre'];
            $ayar_mailbaslik = $genelayarcek['ayar_mailbaslik'];
            $ayar_logo = $genelayarcek['ayar_logo'];

            require("phpmailer/class/class.phpmailer.php");

    $mail = new PHPMailer(); // Sinifimizi $mail degiskenine atadik
 $mail->CharSet  ="utf-8";
 $mail->Encoding="base64";
$mail->IsSMTP();  // Mailimizin SMTP ile gönderilecegini belirtiyoruz
$mail->Host     = "smtpout.secureserver.net";//"localhost"; //SMTP server adresi
$mail->Port     = '80'; 
$mail->SMTPAuth = true; //SMTP server'a kullanici adi ile baglanilcagini belirtiyoruz.
$mail->Username = $ayar_mail;//"admin@localhost"; //SMTP kullanici adi
$mail->Password = $ayar_mailsifre;//""; //SMTP mailinizin sifresi
$mail->SMTPSecure = 'SSL';
$mail->From     = $ayar_mail;//"admin@localhost"; //Gönderen kisminda yer alacak e-mail adresi
$mail->FromName = $ayar_mailbaslik;//"PHP Mailer";//gönderenin ismi
$mail->AddEmbeddedImage($ayar_logo, 'logo');
$mail->AddAddress($kullanici_mail); // Mail gönderilecek adresleri ekliyoruz.
$mail->IsHTML(true); //Mailimizin HTML formatinda hazirlanacagini bildiriyoruz.
$mail->Subject  = 'İade Talebiniz Kabul Edildi';//"Deneme Maili"; // Mailin Konusu Konu


    $mail->Body = "<div align='center'>

    <div style='width:90%;padding:20px;'>

 <div style='width:100%;'>
 <img src='cid:logo'>
 </div>
 <hr>

 <p style='text-align:center;'><b>Merhaba ".$kullanici_ad.",</b><br><br><b>
".$urun_marka." ".$urun_ad." (".$iade_miktar." Adet)</b> için yaptığınız iade talebi kabul edildi. <b>".$iade_tutar." TL</b> hesabınıza yansıtılacaktır. Bankaların işlem sürecine göre iade tutarının yatması 2-4 iş günü sürebilmektedir.<br><br>

".$ayar_mailbaslik." web sitesinden hesabınıza giriş yaparak tüm siparişlerinizi rahatlıkla yönetebilirsiniz.<hr>

İade Sebebiniz : '".$iade_sebebi."'</p>

    </div>

    

    
</div>

    ";

    $mail->Send();
	
	echo "ok";
}

} else if (isset($_POST['iadered'])){

$siparisitem_id = $_POST['siparisitem_id'];

$siparisitemsec=$db->prepare("SELECT * from siparisitem where siparisitem_id='$siparisitem_id'");
$siparisitemsec->execute();
$siparisitemcek=$siparisitemsec->fetch(PDO::FETCH_ASSOC);
$kullanici_id = $siparisitemcek['kullanici_id'];
$urun_id = $siparisitemcek['urun_id'];

$urunsec=$db->prepare("SELECT * from urunler where urun_id='$urun_id'");
$urunsec->execute();
$uruncek=$urunsec->fetch(PDO::FETCH_ASSOC);


$kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_id='$kullanici_id'");
$kullanicisec->execute();
$kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

$kullanici_ad = $kullanicicek['kullanici_ad'];
$kullanici_mail = $kullanicicek['kullanici_mail'];
$urun_ad=$uruncek['urun_ad'];
$urun_marka=$uruncek['marka_ad'];
$iade_sebebi=$siparisitemcek['iade_text'];
$iade_miktar=$siparisitemcek['iade_miktar'];

$hazirla=$db->prepare("UPDATE siparisitem set

urun_iade=:urun_iade

where siparisitem_id='$siparisitem_id'
	");


$derle=$hazirla->execute(array(
"urun_iade" => 3
));

if ($derle) {

	$genelayarsec=$db->prepare("SELECT * from genelayarlar");
            $genelayarsec->execute();

            $genelayarcek=$genelayarsec->fetch(PDO::FETCH_ASSOC);
            $ayar_mail = $genelayarcek['ayar_mail'];
            $ayar_mailsifre = $genelayarcek['ayar_mailsifre'];
            $ayar_mailbaslik = $genelayarcek['ayar_mailbaslik'];
            $ayar_logo = $genelayarcek['ayar_logo'];

            require("phpmailer/class/class.phpmailer.php");

    $mail = new PHPMailer(); // Sinifimizi $mail degiskenine atadik
 $mail->CharSet  ="utf-8";
 $mail->Encoding="base64";
$mail->IsSMTP();  // Mailimizin SMTP ile gönderilecegini belirtiyoruz
$mail->Host     = "smtpout.secureserver.net";//"localhost"; //SMTP server adresi
$mail->Port     = '80'; 
$mail->SMTPAuth = true; //SMTP server'a kullanici adi ile baglanilcagini belirtiyoruz.
$mail->Username = $ayar_mail;//"admin@localhost"; //SMTP kullanici adi
$mail->Password = $ayar_mailsifre;//""; //SMTP mailinizin sifresi
$mail->SMTPSecure = 'SSL';
$mail->From     = $ayar_mail;//"admin@localhost"; //Gönderen kisminda yer alacak e-mail adresi
$mail->FromName = $ayar_mailbaslik;//"PHP Mailer";//gönderenin ismi
$mail->AddEmbeddedImage($ayar_logo, 'logo');
$mail->AddAddress($kullanici_mail); // Mail gönderilecek adresleri ekliyoruz.
$mail->IsHTML(true); //Mailimizin HTML formatinda hazirlanacagini bildiriyoruz.
$mail->Subject  = 'İade Talebiniz Reddedildi';//"Deneme Maili"; // Mailin Konusu Konu


    $mail->Body = "<div align='center'>

    <div style='width:90%;padding:20px;'>

 <div style='width:100%;'>
 <img src='cid:logo'>
 </div>
 <hr>

 <p style='text-align:center;'><b>Merhaba ".$kullanici_ad.",</b><br><br><b>
".$urun_marka." ".$urun_ad." (".$iade_miktar." Adet)</b> için yaptığınız iade talebinin reddedildiğini bildirmek isteriz. <br><br>

".$ayar_mailbaslik." web sitesinden hesabınıza giriş yaparak tüm siparişlerinizi ve iade işlemlerinizi rahatlıkla yönetebilirsiniz.<hr>

İade Sebebiniz : '".$iade_sebebi."'
</p>

    </div>

    

    
</div>

    ";

    $mail->Send();
	
	echo "ok";
}

} else if (isset($_POST['kategorimarkaduzenle'])){


$kategori_id = $_POST['kategori_id'];

$kategorimarkasil = $db->prepare("DELETE from kategorimarka where kategori_id='$kategori_id'");
$silkategorimarka = $kategorimarkasil->execute();
$markalar = $_POST['marka_id_'.$kategori_id];

if ($silkategorimarka && count($markalar)!=0) {
	
	

	foreach ($markalar as $marka_id) {
		
		$hazirla=$db->prepare("INSERT into kategorimarka set

kategori_id=:kategori_id,
marka_id=:marka_id

			");

		$derle=$hazirla->execute(array(

"kategori_id" => $kategori_id,
"marka_id" => $marka_id

		));
	}

	
}

echo "ok";



} else if (isset($_POST['kategorifiltreduzenle'])){




$kategorifiltresil = $db->prepare("DELETE from kategorifiltreler");
$silkategorifiltre = $kategorifiltresil->execute();

if ($silkategorifiltre) {
	
	$filtreler = $_POST['filtreler'];

	if (count($filtreler)!=0) {
	

	foreach ($filtreler as $filtrebaslik_id) {



		$filtrebasliksec=$db->prepare("SELECT * from filtrebasliklar where filtrebaslik_id='$filtrebaslik_id'");

		$filtrebasliksec->execute();

		$filtrebaslikcek = $filtrebasliksec->fetch(PDO::FETCH_ASSOC);
		$filtrebaslik_sira = $filtrebaslikcek['filtrebaslik_sira'];
		
		$hazirla=$db->prepare("INSERT into kategorifiltreler set

filtrebaslik_id=:filtrebaslik_id,
filtrebaslik_sira=:filtrebaslik_sira

			");

		$derle=$hazirla->execute(array(

"filtrebaslik_id" => $filtrebaslik_id,
"filtrebaslik_sira" => $filtrebaslik_sira

		));
	}

	}

	echo "ok";
}



} else if (isset($_POST['markafiltreduzenle'])){




$markafiltresil = $db->prepare("DELETE from markafiltreler");
$silmarkafiltre = $markafiltresil->execute();

if ($silmarkafiltre) {
	
	$filtreler = $_POST['filtreler'];

	if (count($filtreler)!=0) {

	foreach ($filtreler as $filtrebaslik_id) {

		

		$filtrebasliksec=$db->prepare("SELECT * from filtrebasliklar where filtrebaslik_id='$filtrebaslik_id'");

		$filtrebasliksec->execute();

		$filtrebaslikcek = $filtrebasliksec->fetch(PDO::FETCH_ASSOC);
		$filtrebaslik_sira = $filtrebaslikcek['filtrebaslik_sira'];
		
		$hazirla=$db->prepare("INSERT into markafiltreler set

filtrebaslik_id=:filtrebaslik_id,
filtrebaslik_sira=:filtrebaslik_sira

			");

		$derle=$hazirla->execute(array(

"filtrebaslik_id" => $filtrebaslik_id,
"filtrebaslik_sira" => $filtrebaslik_sira

		));
	}

   }

	echo "ok";
}



} else if (isset($_POST['anasayfamarkaduzenle'])){




$anasayfamarkasil = $db->prepare("DELETE from anasayfamarkalar");
$silanasayfamarka = $anasayfamarkasil->execute();
$markalar = $_POST['marka_id'];

if ($silanasayfamarka && count($markalar)!=0) {
	
	

	foreach ($markalar as $marka_id) {

		$markasec=$db->prepare("SELECT * from markalar where marka_id='$marka_id'");
		$markasec->execute();
		$markacek=$markasec->fetch(PDO::FETCH_ASSOC);
		$marka_ad = $markacek['marka_ad'];
		
		$hazirla=$db->prepare("INSERT into anasayfamarkalar set

marka_ad=:marka_ad,
marka_id=:marka_id

			");

		$derle=$hazirla->execute(array(

"marka_ad" => $marka_ad,
"marka_id" => $marka_id

		));
	}

	
}

echo "ok";

} else if (isset($_POST['girisfotokaldir'])){

	$genelayarsec=$db->prepare("SELECT * from genelayarlar");
	$genelayarsec->execute();
	$genelayarcek=$genelayarsec->fetch(PDO::FETCH_ASSOC);

	$ayar_girisfoto = $genelayarcek['ayar_girisfoto'];

	unlink($ayar_girisfoto);
 
$hazirla=$db->prepare("UPDATE genelayarlar set

ayar_girisfoto=:ayar_girisfoto

 ");

$derle=$hazirla->execute(array(

"ayar_girisfoto" => NULL

));

if ($derle) {
	
	echo "ok";
}

} else if (isset($_POST['ikonlisteekle'])){



	$ikon_templatead = $_POST['ikon_templatead'];

$ikonliste_sira = $_POST['ikonliste_sira'];
$ikonliste_baslik = htmlspecialchars(trim($_POST['ikonliste_baslik']));
$ikonliste_aciklama = htmlspecialchars(trim($_POST['ikonliste_aciklama']));


$hazirla = $db->prepare("INSERT into ikonliste set


ikon_templatead=:ikon_templatead,
ikonliste_baslik=:ikonliste_baslik,
ikonliste_aciklama=:ikonliste_aciklama,
ikonliste_sira=:ikonliste_sira


	");

$derle=$hazirla->execute(array(

"ikon_templatead" => $ikon_templatead,
"ikonliste_baslik" => $ikonliste_baslik,
"ikonliste_aciklama" => $ikonliste_aciklama,
"ikonliste_sira" => $ikonliste_sira
));


if ($derle) {
	
	header("Location:nedmin/production/hakkimizda-liste");
}





}  ?>

 

 