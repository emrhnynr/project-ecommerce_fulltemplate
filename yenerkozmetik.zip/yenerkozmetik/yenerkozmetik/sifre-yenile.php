
<?php require_once 'header.php';

$kullanici_uniq=$_GET['u'];
$kullanici_id=$_GET['id'];

$kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_id=:id and kullanici_uniq=:uniq");
$kullanicisec->execute(array(
"uniq" => $kullanici_uniq,
"id" => $kullanici_id
));

$kullanicisay=$kullanicisec->rowCount();

if ($kullanicisay==0) {
  
  header("Location:/");
  exit;
}

$kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

 ?>

  <title>Şifre Yenile | Yener Kozmetik</title>


        

        <!--==================== Registration Form Start ====================-->
        <div style="padding-top: 0px;" class="full-row">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="woocommerce">
                            <div class="row">
                                <div class="col-lg-6 col-md-8 col-12 mx-auto">
                                    <div class="registration-form">
                                        <h3 style="font-family: arial;font-weight: 200;">Şifre Yenile</h3>
                                        

                                        <hr>
                                        <form onsubmit="return false;" id="resetpasswordform">
                                           

                                            <p>
                                                <label for="reg_email">E-Posta Adresiniz&nbsp;<span class="required">*</span></label>
                                                <input type="email" disabled="" value="<?php echo $kullanicicek['kullanici_mail'] ?>" maxlength="100" class="form-control"  id="kullanici_mail" />
                                            </p>

                                            <p>
                                                <label for="reg_email">Yeni Şifreniz&nbsp;<span class="required">*</span></label>
                                                <input type="password" placeholder="Minimum 8 karakter"  maxlength="100" class="form-control"  id="yeni_sifre" name="yeni_sifre" />
                                            </p>

                                            <p>
                                                <label for="reg_email">Yeni Şifre Tekrar&nbsp;<span class="required">*</span></label>
                                                <input type="password" placeholder="Yeni şifrenizi tekrar girin"  maxlength="100" class="form-control"  id="yeni_sifre_tekrar" name="yeni_sifre_tekrar" />
                                            </p>

                                          

                                            
                                        
                                            <input type="hidden" name="disableFill" value="">

                                            <div style="display: none;" class="alert alert-warning uyari"><i class="fa fa-info-circle"></i></div>

                                            
                                             <input type="hidden" value="<?php echo $kullanicicek['kullanici_id']; ?>" name="kullanici_id">

                      <input type="hidden" value="<?php echo $kullanicicek['kullanici_uniq']; ?>" name="kullanici_uniq">

                                            
                                            <p>
                                                <button type="submit" class="btn btn-primary rounded-0 resetpasswordbutton">Yenile</button>
                                            </p>

                                            
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--==================== Registration Form Start ====================-->

       <?php require_once 'footer.php'; ?>

<script type="text/javascript">
        
        $('#resetpasswordform').submit(function(){




    $('.resetpasswordbutton').prop('disabled', true);
     $('.resetpasswordbutton').html('Yenileniyor...');

     var data = $("#resetpasswordform").serializeArray();
data.push({name: "sifreyenile",value: "ok"});

 $.ajax({
            type : 'POST',
            url : 'musteriislem.php',
            data : $.param(data),
            success : function(sonuc){

              sonuc=$.trim(sonuc);



               if(sonuc=="kisasifre"){

$('.resetpasswordbutton').prop('disabled', false);
$('.resetpasswordbutton').html('Yenile');

$('.uyari').show();
$('.uyari').html('<i class="fas fa-info-circle"></i> Şifreniz minimum 8 karakter içermelidir.');
 
              } else if(sonuc=="uyusmayansifre"){


$('.resetpasswordbutton').prop('disabled', false);
$('.resetpasswordbutton').html('Yenile');

$('.uyari').show();
$('.uyari').html('<i class="fas fa-info-circle"></i> Girdiğiniz yeni şifreler uyuşmuyor.');

              }  else if(sonuc=="ok"){




window.location='../';





              }

              
               
            }
        })

 

        });


        
    </script>