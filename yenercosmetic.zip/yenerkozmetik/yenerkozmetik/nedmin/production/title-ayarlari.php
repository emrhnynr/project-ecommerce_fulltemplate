<?php require_once 'header.php';

$seoayarsec=$db->prepare("SELECT * from seoayarlar");
$seoayarsec->execute();

 $seoayarcek=$seoayarsec->fetch(PDO::FETCH_ASSOC);

 $anasayfa_title = $seoayarcek['anasayfa_title'];
 $hakkimizda_title = $seoayarcek['hakkimizda_title'];
  $iletisim_title = $seoayarcek['iletisim_title'];
   $projeler_title = $seoayarcek['projeler_title'];
   $blog_title = $seoayarcek['blog_title'];
   $urunler_title = $seoayarcek['urunler_title'];
   $ekip_title = $seoayarcek['ekip_title'];
   $sss_title = $seoayarcek['sss_title'];



  ?>



        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              

              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                 
                  <div class="x_content">
                    <br />

                  

                    <form id="sekmetitleform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

                      <h3 align="center">Sekme Title Ayarları</h3>
                      <h5 align="center">Bu title'lar, sayfanın sekme kısmında yer alacak başlıklardır.</h5>
                      
                      <hr>


                     
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Anasayfa 
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="anasayfa_title" value="<?php echo $seoayarcek['anasayfa_title']; ?>" name="anasayfa_title" maxlength="200"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Hakkımızda 
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="hakkimizda_title" value="<?php echo $seoayarcek['hakkimizda_title']; ?>" name="hakkimizda_title" maxlength="200"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">İletişim
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="iletisim_title" value="<?php echo $seoayarcek['iletisim_title']; ?>" name="iletisim_title" maxlength="200"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Blog 
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="blog_title" value="<?php echo $seoayarcek['blog_title']; ?>" name="blog_title" maxlength="200"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Ekip 
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="ekip_title" value="<?php echo $seoayarcek['ekip_title']; ?>" name="ekip_title" maxlength="200"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>


                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">SSS
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="sss_title" value="<?php echo $seoayarcek['sss_title']; ?>" name="sss_title" maxlength="200"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>


                      

                      

                     

                

                      <input type="hidden" name="sekmetitleduzenle">


                      
                      
                      <div class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">

                       
                          
                          <button type="submit" class="btn btn-success sekmetitlebuton">Düzenle</button>
                        </div>
                      </div>

                    </form>

                    

                   


                    
                  </div>
                </div>
              </div>
            </div>

            <?php require_once 'footer.php'; ?>



            <script type="text/javascript">

             

            $('#sekmetitleform').submit(function(){

             


              $('.sekmetitlebuton').prop('disabled',true);

              

                $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : $('#sekmetitleform').serialize(),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

              if (sonuc=="ok") {

                
                $('.sekmetitlebuton').prop('disabled',false);


                swal({

  title: "Başarılı",
  text: "Sekme başlıkları düzenlendi!",
  icon: "success",
  button: "OK",
});



              }
                

              }


            })

                 

                 });

            


            

            </script>

              
             