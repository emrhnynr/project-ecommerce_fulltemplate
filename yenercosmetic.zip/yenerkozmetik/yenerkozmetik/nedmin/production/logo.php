<?php require_once 'header.php';

$genelayarsec=$db->prepare("SELECT * from genelayarlar");
$genelayarsec->execute();

 $genelayarcek=$genelayarsec->fetch(PDO::FETCH_ASSOC);

 $ayar_logo=$genelayarcek['ayar_logo'];
 $ayar_favicon = $genelayarcek['ayar_favicon'];
 ?>

        

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Logo</h3>
              </div>

              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div  class="x_panel">
                  
                  <div style="margin-bottom: 30px;" class="col-xs-12 col-md-8 col-sm-8">

                   
                    <h4 align="center">Logo Güncelle<hr></h4>

                    <label>Mevcut Logo <i class="fa fa-sort-desc"></i></label><br><br>
                    <img style="margin-bottom:20px;" src="../../<?php echo $ayar_logo; ?>">

                   

                   
                    <input type="file" id="ayar_logo" class="form-control" name="ayar_logo">

                    <br>

                    <div style="display: none;" class="alert alert-warning uyarilogo"></div>

                    <a id="logoguncellebuton" class="btn btn-success" href="javascript:void(0);">Güncelle</a>
                  </div>

                  
                  <div class="col-xs-12 col-md-8 col-sm-8">

                   
                    <h4 align="center">Favicon Güncelle (48x48px)<hr></h4>

                    <label>Mevcut Favicon <i class="fa fa-sort-desc"></i></label><br><br>
                    <img style="width: 48px;height: 48px;margin-bottom:20px;" src="../../<?php echo $ayar_favicon; ?>">

                    <input type="file" id="ayar_favicon" class="form-control" name="ayar_favicon">

                    <br>

                    <div style="display: none;" class="alert alert-warning uyarifavicon"></div>

                    <a id="faviconguncellebuton" class="btn btn-success" href="javascript:void(0);">Güncelle</a>
                  </div>
                 
                </div>
              </div>
            </div>

            <?php require_once 'footer.php'; ?>
            <script type="text/javascript">
              
$('#logoguncellebuton').click(function(){

var input = $('#ayar_logo');
var foto = $('#ayar_logo').val();
var filevalue = $('#ayar_logo').get(0).files[0];
var fotouzanti = foto.split('.').pop();

var data = new FormData();
data.append('logoguncelleadmin',"ok");
data.append("file",filevalue);



if ($('#ayar_logo').val().length==0){

 $('.uyarilogo').show();
$('.uyarilogo').html('<i class="fa fa-info-circle"></i> Lütfen logo yükleyin.');

  } else if (fotouzanti!='jpg' && fotouzanti!='jpeg' && fotouzanti!='png'){

$('.uyarilogo').show();
$('.uyarilogo').html('<i class="fa fa-info-circle"></i> Sadece .jpg, .jpeg, .png uzantılı dosyaları yükleyebilirsiniz.');

} else {

  $('#logoguncellebuton').prop('disabled',true);
  $('#logoguncellebuton').html('Güncelleniyor...');

   $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            enctype : 'multipart/form-data',
            data : data,
            processData: false,
            contentType: false,
            cache: false,
            success : function(sonuc){

      sonuc=$.trim(sonuc);
      
      if (sonuc=="ok") {

        location.reload();
      }

 }

 });


}

});

//Beyaz Logo Güncelleme -------


$('#beyazlogoguncellebuton').click(function(){

var input = $('#ayar_beyazlogo');
var foto = $('#ayar_beyazlogo').val();
var filevalue = $('#ayar_beyazlogo').get(0).files[0];
var fotouzanti = foto.split('.').pop();

var data = new FormData();
data.append('beyazlogoguncelleadmin',"ok");
data.append("file",filevalue);



if ($('#ayar_beyazlogo').val().length==0){

 $('.uyaribeyazlogo').show();
$('.uyaribeyazlogo').html('<i class="fa fa-info-circle"></i> Lütfen bir beyaz logo yükleyin.');

  } else if (fotouzanti!='jpg' && fotouzanti!='jpeg' && fotouzanti!='png'){

$('.uyaribeyazlogo').show();
$('.uyaribeyazlogo').html("<i class='fa fa-info-circle'></i> Sadece <b>.jpg, .jpeg, .png</b> uzantılı dosyaları yükleyebilirsiniz.");

} else {

  $('#beyazlogoguncellebuton').prop('disabled',true);
  $('#beyazlogoguncellebuton').html('Güncelleniyor...');

   $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            enctype : 'multipart/form-data',
            data : data,
            processData: false,
            contentType: false,
            cache: false,
            success : function(sonuc){

      sonuc=$.trim(sonuc);
      
      if (sonuc=="ok") {

        location.reload();
      }

 }

 });


}

})


$('#mobillogoguncellebuton').click(function(){

var input = $('#ayar_mobillogo');
var foto = $('#ayar_mobillogo').val();
var filevalue = $('#ayar_mobillogo').get(0).files[0];
var fotouzanti = foto.split('.').pop();

var data = new FormData();
data.append('mobillogoguncelleadmin',"ok");
data.append("file",filevalue);



if ($('#ayar_mobillogo').val().length==0){

 $('.uyarimobillogo').show();
$('.uyarimobillogo').html('<i class="fa fa-info-circle"></i> Lütfen mobil logo yükleyin.');

  } else if (fotouzanti!='jpg' && fotouzanti!='jpeg' && fotouzanti!='png'){

$('.uyarimobillogo').show();
$('.uyarimobillogo').html('<i class="fa fa-info-circle"></i> Sadece .jpg, .jpeg, .png uzantılı dosyaları yükleyebilirsiniz.');

} else {

  $('#mobillogoguncellebuton').prop('disabled',true);
  $('#mobillogoguncellebuton').html('Güncelleniyor...');

   $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            enctype : 'multipart/form-data',
            data : data,
            processData: false,
            contentType: false,
            cache: false,
            success : function(sonuc){

      sonuc=$.trim(sonuc);
      
      if (sonuc=="ok") {

        location.reload();
      }

 }

 });


}

});


$('#faviconguncellebuton').click(function(){

var input = $('#ayar_favicon');
var foto = $('#ayar_favicon').val();
var filevalue = $('#ayar_favicon').get(0).files[0];
var fotouzanti = foto.split('.').pop();

var data = new FormData();
data.append('faviconguncelleadmin',"ok");
data.append("file",filevalue);



if ($('#ayar_favicon').val().length==0){

 $('.uyarifavicon').show();
$('.uyarifavicon').html('<i class="fa fa-info-circle"></i> Lütfen favicon yükleyin.');

  } else if (fotouzanti!='jpg' && fotouzanti!='jpeg' && fotouzanti!='png' && fotouzanti!='ico' && fotouzanti!='ICO'){

$('.uyarifavicon').show();
$('.uyarifavicon').html('<i class="fa fa-info-circle"></i> Sadece .jpg, .jpeg, .png, .ico uzantılı dosyaları yükleyebilirsiniz.');

} else {

  $('#faviconguncellebuton').prop('disabled',true);
  $('#faviconguncellebuton').html('Güncelleniyor...');

   $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            enctype : 'multipart/form-data',
            data : data,
            processData: false,
            contentType: false,
            cache: false,
            success : function(sonuc){

      sonuc=$.trim(sonuc);
      
      if (sonuc=="ok") {

        location.reload();
      }

 }

 });


}

})

            </script>


            