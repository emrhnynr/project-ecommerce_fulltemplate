
<?php require_once 'header.php';

if (isset($_SESSION['kullanicioturum'])) {
    
    header("location:index");
}

 ?>

  <title>Şifremi Unuttum | Yener Saat</title>


        

        <!--==================== Registration Form Start ====================-->
        <div style="padding-top: 0px;" class="full-row">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="woocommerce">
                            <div class="row">
                                <div class="col-lg-6 col-md-8 col-12 mx-auto">
                                    <div class="registration-form">
                                        <h3 style="font-family: arial;font-weight: 200;">Şifremi Unuttum</h3>
                                        <p>Mail adresinize bir şifre yenileme bağlantısı göndereceğiz.</p>

                                        <hr>
                                        <form onsubmit="return false;" id="restoreform">
                                           

                                            <p>
                                                <label for="reg_email">E-Posta Adresiniz&nbsp;<span class="required">*</span></label>
                                                <input type="email" maxlength="100" class="form-control" name="kullanici_mail" id="kullanici_mail" />
                                            </p>

                                           <input type="hidden" value="<?php echo $_SERVER['SERVER_NAME']; ?>" name="domain">

                                            
                                        
                                            <input type="hidden" name="disableFill" value="">

                                            <div style="display: none;" class="alert alert-warning uyari"><i class="fa fa-info-circle"></i></div>

                                            <div style="display: none;" class="alert alert-success uyari2"><i class="fas fa-check"></i></div>

                                            
                                            <p>
                                                <button type="submit" class="btn btn-primary rounded-0 restorebuton">Gönder</button>
                                            </p>

                                            
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--==================== Registration Form Start ====================-->

       <?php require_once 'footer.php'; ?>
       
<script type="text/javascript">
        
        $('#restoreform').submit(function(){


 var kullanici_mail = $.trim($('#kullanici_mail').val());



 if (kullanici_mail.length<2) {

$('.uyari').show();
$('.uyari').html('<i class="fa fa-info-circle"></i> Lütfen mail adresinizi doğru girin.');
$('.uyari2').hide();

 } else {

     $('.restorebuton').prop('disabled',true);
     $('.uyari').hide();
     $('.restorebuton').html('Gönderiliyor...');

     var data = $("#restoreform").serializeArray();
        data.push({name: "sifremiunuttum",value: "ok"});

 $.ajax({
            type : 'POST',
            url : 'musteriislem.php',
            data : $.param(data),
            success : function(sonuc){

              sonuc = $.trim(sonuc);


           if (sonuc=='kullanicibulunamadi') {

$('.uyari').show();
$('.uyari').html("<i class='fa fa-info-circle'></i> Bu e-posta adresine kayıtlı bir hesap bulunmuyor.");
$('.uyari2').hide();
$('.restorebuton').prop('disabled',false);
$('.restorebuton').html("Gönder");

              } else if (sonuc=='ok'){

                $('.uyari2').show();
                $('.uyari').hide();
$('.uyari2').html("<i class='fas fa-check'></i> Şifrenizi yenilemek için mailinize bir bağlantı yolladık. Lütfen kontrol edin.");
$('.restorebuton').prop('disabled',false);
$('.restorebuton').html("Gönder");
$('#kullanici_mail').val('');

           
              };

             
              
              }
        })

 }

        });


        
    </script>