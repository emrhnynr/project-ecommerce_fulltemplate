<!--==================== Footer Section Start ====================-->
        <footer class="full-row bg-dark">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <div class="footer-widget mb-5">
                            <div  class="footer-logo mb-4">
                                <a href="../">
                                    <div style="padding: 5px;background-color: white;"><img src="<?php echo $ayar_logo; ?>" alt="Yener Kozmetik Logo" /></div></a>
                            </div>
                            <div class="widget-ecommerce-contact">
                                <span class="font-medium font-500 text-white"><?php echo $genelayarcek['ayar_footertext']; ?></span>
                                <a href="tel:<?php echo $genelayarcek['ayar_telno']; ?>"><div class="text-white font-500 h4"><?php echo $genelayarcek['ayar_telno']; ?></div></a>
                                
                            </div>
                        </div>
                        
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-widget category-widget mb-5">
                            <h6 class="widget-title mb-4">Bizi Takip Edin</h6>
                            <ul>
                                <li><a href="iletisim"><?php echo $seoayarcek['menu_iletisim']; ?></a></li>
                                <li><a href="sss"><?php echo $seoayarcek['menu_sss']; ?></a></li>
                                <li><a href="kullanim-kosullari">Kullanım Koşulları ve Kişisel Verilerin Korunması</a></li>
                                
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-widget category-widget mb-5">
                            <h6 class="widget-title mb-4 xs-mx-none">Yener Kozmetik</h6>
                            <ul>
                                <li><a href="hakkimizda"><?php echo $seoayarcek['menu_hakkimizda']; ?></a></li>
                                <li><a href="kargo-iade">Kargo ve İade İşlemleri</a></li>
                                <li><a href="blog"><?php echo $seoayarcek['menu_blog']; ?></a></li>

                                
                                
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-6">
                        <div class="footer-widget widget-nav mb-5">
                            <h6 class="widget-title mb-4">Sosyal Medya</h6>
                            <div class="footer-widget media-widget mb-5">

                            <?php  if (!empty($genelayarcek['ayar_instagram'])) { ?> 

                            <a target="_blank" href="<?php echo $genelayarcek['ayar_instagram']; ?>"><i class="fab fa-instagram"></i></a>
                          
                          <?php } ?>


                            <?php  if (!empty($genelayarcek['ayar_facebook'])) { ?> 

                            <a target="_blank" href="<?php echo $genelayarcek['ayar_facebook']; ?>"><i class="fab fa-facebook-f"></i></a>
                          
                          <?php } ?>

                             <?php  if (!empty($genelayarcek['ayar_twitter'])) { ?> 

                            <a target="_blank" href="<?php echo $genelayarcek['ayar_twitter']; ?>"><i class="fab fa-twitter"></i></a>
                          
                          <?php } ?>
                             <?php  if (!empty($genelayarcek['ayar_youtube'])) { ?> 

                            <a target="_blank" href="<?php echo $genelayarcek['ayar_youtube']; ?>"><i class="fab fa-youtube"></i></a>
                          
                          <?php } ?>

                             
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!--==================== Footer Section End ====================-->

        <!--==================== Copyright Section Start ====================-->
        <div class="full-row copyright py-3" style="background-color: #101112;">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <span class="text-white font-500 sm-mb-10 d-block"><?php echo $genelayarcek['ayar_footerdesc']; ?></span>
                    </div>
                    <div class="col-md-6">
                        <ul class="list-ml-30 d-flex align-items-center justify-content-md-end">
                            <li>
                                <a ><img src="assets/images/cards/1.png" alt=""></a>
                            </li>
                            <li>
                                <a ><img src="assets/images/cards/2.png" alt=""></a>
                            </li>
                            <li>
                                <a ><img src="assets/images/cards/3.png" alt=""></a>
                            </li>
                            
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!--==================== Copyright Section End ====================-->

        <!-- Scroll to top -->
        <a href="#" class="bg-primary text-white" id="scroll"><i class="fa fa-angle-up"></i></a>
        <!-- End Scroll To top -->



    </div>



    <!-- Include Scripts -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/greensock.js"></script>
    <script src="assets/js/layerslider.transitions.js"></script>
    <script src="assets/js/layerslider.kreaturamedia.jquery.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery.fancybox.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script type="text/javascript" src="sweetalert.all.min.js"></script>
    <script src="assets/js/wow.js"></script>
    <script src="assets/js/jquery.elevatezoom.js"></script>
    <script src="assets/js/jquery.countdown.js"></script>
    <script src="assets/js/custom.js"></script>

    <!-- Initializing the slider -->
    <script>

         //initiate the plugin and pass the id of the div containing gallery images
        $("#single-image-zoom").elevateZoom({
            gallery: 'gallery_09',
            zoomType: "inner",
            cursor: "crosshair",
            galleryActiveClass: 'active',
            imageCrossfade: true,
            loadingIcon: 'http://www.elevateweb.co.uk/spinner.gif'
        });
        //pass the images to Fancybox
        $("#single-image-zoom").bind("click", function(e) {
            var ez = $('#single-image-zoom').data('elevateZoom');
            $.fancybox(ez.getGalleryList());
            return false;
        });

        $(document).ready(function() {
            $('#slider').layerSlider({
                sliderVersion: '6.0.0',
                type: 'fullwidth',
                responsiveUnder: 0,
                layersContainer: 1200,
                hideUnder: 0,
                hideOver: 100000,
                skin: 'v6',
                globalBGColor: '#ffffff',
                navStartStop: false,
                skinsPath: 'assets/skins/',
                height: 497
            });
        });


        $('.headersepetitemsil').click(function(){

 var id1=$(this).attr("name");
       var sepetitem_id=id1.substring(10);
       

        swal({
  title: "Emin misiniz?",
  text: "Bu ürünü sepetinizden kaldırmak istediğinize emin misiniz?",
  icon: "info",
  buttons: ["Vazgeç", "Sil"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

      $.ajax({

   type : 'POST',
            url : 'musteriislem.php',
            data : {'sepetitemsilheader':'ok','sepetitem_id':sepetitem_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

             

             $('.cart-area').html(sonuc);



                





               }

             });


     }

     })

});

        $('#searchform').submit(function(){

var form = $(this);
var searchquery = $.trim($('#searchquery').val());

if (searchquery.length==0) {

form.css('border','1px solid #E50A18');

} else {

    location.href='search?q='+encodeURIComponent(searchquery).replace('%20','+');
}



        });


         $('#searchform2').submit(function(){

var form = $(this);
var searchquery = $.trim($('#searchquery2').val());

if (searchquery.length==0) {

form.css('border','1px solid #E50A18');

} else {

    location.href='search?q='+encodeURIComponent(searchquery).replace('%20','+');
}



        })

        
    </script>

</body>

</html>