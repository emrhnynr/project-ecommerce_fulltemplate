<?php require_once 'header.php'; 


if (empty($_GET['q'])) {
    
    header("Location:../");
    exit;
}

$query = $_GET['q'];


$uruntestsec=$db->prepare("SELECT * from urunler where (urun_id='$query' and urun_kaldirildi='0') or (urun_kaldirildi='0' and (urun_ad LIKE '$query%' or urun_ad LIKE '%$query%' or urun_ad LIKE '%$query' or marka_ad LIKE '$query%' or marka_ad LIKE '%$query%' or marka_ad LIKE '%$query'))");
         $uruntestsec->execute();

         $uruntestsay = $uruntestsec->rowCount();


                  $sayfa=@$_GET['s'];
    if (empty($_GET['s'])) {
      $sayfa=1;
    };

$kacar=20;
$sayfasayisi=ceil($uruntestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;

 if ($uruntestsay!=0 and ($sayfa>$sayfasayisi or $sayfa<1)) {
     
     header("Location:/");
 } 

 ?>

<title>'<?php echo $query; ?>' için arama sonuçları | Yener Kozmetik</title>

        <!-- breadcrumb -->

        <?php if ($uruntestsay>0) { ?>


        <div class="full-row py-5">
            <div class="container">
                <div class="row text-center">
                    <div class="col-12">
                        <h3 style="font-family: arial;font-weight: 200;" class="mb-2">'<?php echo $query; ?>' için arama sonuçları</h3>
                    </div>
                   
                </div>
            </div>
        </div>
        <!-- breadcrumb -->

        <div class="full-row pt-0">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="products-header d-flex justify-content-between align-items-center py-10 px-20 bg-light md-mt-30">
                            <div class="products-header-left d-flex align-items-center">
                                <h6 style="font-family: arial;" class="woocommerce-products-header__title page-title">Tüm Ürünler </h6>
                                <div style="font-family: arial;" class="woocommerce-result-count"> ( <?php echo $uruntestsay." Ürün"; ?> )</div>
                                
                            </div>
                            <div class="products-header-right"></div>
                        </div>
                        <div class="showing-products pt-30 pb-50 border-2 border-bottom border-light">
                            <div class="row row-cols-xl-4 row-cols-md-3 row-cols-sm-2 row-cols-1 product-style-3 e-hover-image-zoom e-image-bg-light g-4">

                                <?php 

                                $urunsec=$db->prepare("SELECT * from urunler where (urun_id='$query' and urun_kaldirildi='0') or (urun_kaldirildi='0' and (urun_ad LIKE '$query%' or urun_ad LIKE '%$query%' or urun_ad LIKE '%$query' or marka_ad LIKE '$query%' or marka_ad LIKE '%$query%' or marka_ad LIKE '%$query')) limit $baslangic,$kacar");
                        $urunsec->execute();

                        while ($uruncek=$urunsec->fetch(PDO::FETCH_ASSOC)) {

                        $urun_id = $uruncek['urun_id'];

                  $urun_marka = $uruncek['marka_id'];

                  $urunseceneklersec=$db->prepare("SELECT * from urunsecenekler where urun_id=:id");
                                           $urunseceneklersec->execute(array(
                                            "id" => $urun_id
                                          ));

                                           $urunseceneklersay=$urunseceneklersec->rowCount();



                  $urunfotosec=$db->prepare("SELECT * from urunfoto where urun_id=:id and urunfoto_kapak=:kapak");
                        $urunfotosec->execute(array(

                          "kapak" => 1,
                           "id" => $urun_id

                         ));

                        $urunfotocek=$urunfotosec->fetch(PDO::FETCH_ASSOC);

                        $urunkapakfoto = $urunfotocek['urunfoto_yol'];

                        $markasec=$db->prepare("SELECT * from markalar where marka_id='$urun_marka'");
                        $markasec->execute();
                        $markacek=$markasec->fetch(PDO::FETCH_ASSOC);
                        $marka_ad=$markacek['marka_ad'];

                          ?>
                                
                               <div class="col">
                                    <div class="product type-product">
                                        <div class="product-wrapper">
                                            <div class="product-image">
                                                <a href="urun-<?php echo seo($uruncek['urun_ad'])."-".$urun_id; ?>" class="woocommerce-LoopProduct-link"><img src="<?php echo $urunkapakfoto; ?>" alt="Product Image"></a>

                                                <?php if ($uruncek['urun_indirim']==1) {

                                                $indirim_miktari = $uruncek['urun_indirimsizfiyat']-$uruncek['urun_fiyat'];
                                                $indirim_yuzdesi = round(($indirim_miktari*100)/$uruncek['urun_indirimsizfiyat']);

                                                    ?>

                                                <div class="product-labels">
                                                    <div <?php if ($indirim_yuzdesi<40) { ?>

                                                        style='background-color:#F3612E;'

                                                    <?php } else { ?>

                                                        style='background-color:#D4102E;'


                                                    <?php } ?> class="badge1"><span>- %<?php echo $indirim_yuzdesi; ?></span></div>
                                                </div>

                                            <?php } ?>
                                            </div>
                                            <div class="product-info">
                                                <h3 class="product-title"><a style="font-family: arial;font-weight: 600;"><?php echo $uruncek['marka_ad']; ?></a></h3>
                                                <h3 class="product-title"><a style="font-weight: 200;font-family: arial;font-size: 16px;" href="urun-<?php echo seo($uruncek['urun_ad'])."-".$urun_id; ?>"><?php echo $uruncek['urun_ad']; ?></a></h3>
                                                <div class="product-price">
                                                    <div class="price">

                                                        <?php if ($uruncek['urun_indirim']==1) { ?>

                                                            <ins <?php if ($indirim_yuzdesi<40) { ?>

                                                        style='color:#F3612E;'

                                                    <?php } else { ?>

                                                        style='color:#D4102E;'


                                                    <?php } ?>><b><?php echo $uruncek['urun_fiyat']; ?> TL</b></ins>

                                                    <del><b><?php echo $uruncek['urun_indirimsizfiyat']; ?> TL</b></del>


                                                        <?php } else { ?>

                                                             
                                                            <ins style="color:black;"><b><?php echo $uruncek['urun_indirimsizfiyat']; ?> TL</b></ins>



                                                        <?php } ?>

                                                        
                                                    </div>
                                                </div>
                                                
                                                <div class="shipping-feed-back">
                                                    <div class="star-rating">
                                                        <div class="rating-wrap">
                                                            
                                                        </div>
                                                        <div class="rating-counts-wrap">
                                                            <a href="#"></a>
                                                        </div>
                                                    </div>
                                                    <div class="sold-items">
                                                        <span></span> <span></span>
                                                    </div>
                                                </div>
                                                <div class="hover-area">

                                                    <?php if ($urunseceneklersay==0 and $uruncek['urun_stok']>0) { ?>

                                                    <div class="cart-button">
                                                        <a href="javascript:void(0);" class="button add_to_cart_button sepeteeklebuton" name="urun_<?php echo $urun_id;?>">Hemen Al</a>
                                                    </div>

                                                <?php } ?>

                                                    <div class="wishlist-button wishlist_<?php echo $urun_id; ?>"></div>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            <?php } ?>
                            </div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center pt-3">
                            <div class="showing-result"></div>

                            <?php if ($uruntestsay>$kacar) { ?>

                            <div class="pagination-style-one">
                                <nav aria-label="Page navigation example">
                                    <ul class="pagination">

                                        <?php $p=0; if ($sayfa!=1) { ?>

                                        <li class="page-item">
                                            <a class="page-link" href="search?q=<?php echo str_replace(' ','+',$query); ?>&s=<?php echo $sayfa-1; ?>" aria-label="Previous">
                                                <span aria-hidden="true">&laquo;</span>
                                            </a>
                                        </li>

                                           <?php } ?>

                                           <?php while ($p<$sayfasayisi) { $p++;

                                    if ($p<=$sayfa+3 and $p>=$sayfa-3) {

                                     ?>

                                        <li class="page-item <?php if($p==$sayfa){ ?>

                                        active

                                   <?php } ?>">

                                            <a <?php if($p==$sayfa){ ?> 

                                    style='color:white;' <?php  } ?> class="page-link" href="search?q=<?php echo str_replace(' ','+',$query); ?>&s=<?php echo $p; ?>"><?php echo $p; ?></a>

                                        </li>

                                    <?php } } ?>

                                         <?php if ($sayfa!=$sayfasayisi) { ?>
                                        
                                        <li class="page-item">
                                            <a class="page-link" href="search?q=<?php echo str_replace(' ','+',$query); ?>&s=<?php echo $sayfa+1; ?>" aria-label="Next">
                                                <span aria-hidden="true">&raquo;</span>
                                            </a>
                                        </li>

                                    <?php } ?>

                                    </ul>
                                </nav>
                            </div>
                        
                        <?php } ?>

                        </div>


                       
                    </div>
                </div>
            </div>
        </div>

    <?php } else { ?>


        <div class="full-row py-5">
            <div class="container">
                <div class="row text-center">
                    <div class="col-12">
                        <h3 style="font-weight: 300;font-family: arial;" class="mb-2">'<?php echo $query; ?>' için sonuç bulunamadı.</h3>
                    </div>
                    
                </div>
            </div>
        </div>



    <?php } ?>

        <?php require_once 'footer.php'; ?>
        