<?php require_once 'header.php';

$kategorilersec=$db->prepare("SELECT * from kategoriler order by kategori_enust ASC");
$kategorilersec->execute();



$markalarsec=$db->prepare("SELECT * from markalar");
$markalarsec->execute();


 ?>

 <style type="text/css">
   

   @media screen and (max-width: 768px) {
    .inputlarr {
        margin-bottom: 15px;
    }
}

 </style>
        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              

             
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Ürünler</h2>

                    <div  class="col-xs-12 col-sm-2 col-md-2 nav navbar-right panel_toolbox">
                       <a href="urun-ekle" class="btn btn-success btn-block"><i class="fa fa-plus"></i> Ürün Ekle</a>
                    </div>

                    <ul style="width: 100%;margin-top:30px;" class="nav navbar-right panel_toolbox">


                      
                     <div  align="right" class="row">
                       
                       <div class="col-md-3 col-xs-12 col-sm-12">
                         <input class="form-control inputlarr" maxlength="300" placeholder="Ürün Adı veya Ürün No." type="text" id="searchsec" name="searchsec">
                       </div>
                       <div class="col-md-3 col-xs-12 col-sm-12">

                        <select name="markasec" id="markasec" class="form-control inputlarr">
                          <option selected="" value="tumu">Marka Seçin</option>
                          <option value="tumu">Hepsi</option>
                          <?php while ($markalarcek=$markalarsec->fetch(PDO::FETCH_ASSOC)) { ?>
                            
                            <option value="<?php echo $markalarcek['marka_id']; ?>"><?php echo $markalarcek['marka_ad']; ?></option>

                         <?php } ?>

                        </select>

                      </div>

                       <div class="col-md-3 col-xs-12 col-sm-12">

                        <select name="kategorisec" id="kategorisec" class="form-control inputlarr">
                          <option selected="" value="tumu">Kategori Seçin</option>
                          <option value="tumu">Hepsi</option>

                          <?php while ($kategorilercek=$kategorilersec->fetch(PDO::FETCH_ASSOC)) { 

                            $kategori_enust = $kategorilercek['kategori_enust'];

                            $enustkategorisec = $db->prepare("SELECT * from kategoriler where kategori_id='$kategori_enust'");
                            $enustkategorisec->execute();

                            $enustkategoricek=$enustkategorisec->fetch(PDO::FETCH_ASSOC);

                            $enust_ad = $enustkategoricek['kategori_ad'];

                            if ($kategorilercek['kategori_ust']==0) { ?>

                               <option value="<?php echo $kategorilercek['kategori_id']; ?>"><?php echo $kategorilercek['kategori_ad']; ?></option>

                             <?php } else { ?>


                           
                            <option value="<?php echo $kategorilercek['kategori_id']; ?>"><?php echo $kategorilercek['kategori_ad']." (".$enust_ad.")"; ?></option>
                            

                         <?php } } ?>

                        </select>

                      </div>


                        <div class="col-md-3 col-xs-12 col-sm-12"><button id="urunfiltrelebuton" class="btn btn-primary btn-block"><i class="fa fa-filter"></i> Filtrele</button></div>


                     </div>
                      
                     
                      
                    </ul>


                    
                    <div class="clearfix"></div>
                    
                  </div>
                  <div class="x_content"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <?php require_once 'footer.php'; ?>
        <script type="text/javascript">

          $('#urunfiltrelebuton').click(function(){

            var buton = $(this);

            buton.prop('disabled',true);
            $('input').prop('disabled',true);
            $('select').prop('disabled',true);

      var markasec = $('#markasec').val();
      var kategorisec = $('#kategorisec').val();
      var searchsec = $.trim($('#searchsec').val());

      $('.x_content').html('<h3 align="center">Yükleniyor...</h3>');

 $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : {'urunfiltreleadmin':'ok','markasec':markasec,'kategorisec':kategorisec,'searchsec':searchsec},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              $('.x_content').html(sonuc);

              buton.prop('disabled',false);
            $('input').prop('disabled',false);
            $('select').prop('disabled',false);

               }

              });



      }).click();



          


          
         

        </script>