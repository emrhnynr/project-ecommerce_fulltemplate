<?php require_once 'header.php'; 

$kampanya_seourl = $_GET['sef'];

$kampanyasec=$db->prepare("SELECT * from kampanyalar where kampanya_seourl='$kampanya_seourl'");
$kampanyasec->execute();



$kampanyasay=$kampanyasec->rowCount();

if ($kampanyasay==0) {
    
    header("Location:/");
    exit;
}

$kampanyacek=$kampanyasec->fetch(PDO::FETCH_ASSOC);

$kampanya_baslik = $kampanyacek['kampanya_baslik'];
$kampanya_id = $kampanyacek['kampanya_id'];


$uruntestsec=$db->prepare("SELECT * from kampanyaurun where urun_kaldirildi='0' and kampanya_id='$kampanya_id'");
         $uruntestsec->execute();

         $uruntestsay = $uruntestsec->rowCount();


                  $sayfa=@$_GET['s'];
    if (empty($_GET['s'])) {
      $sayfa=1;
    };

$kacar=20;
$sayfasayisi=ceil($uruntestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;

 if ($uruntestsay!=0 and ($sayfa>$sayfasayisi or $sayfa<1)) {
     
     header("Location:/");
 }

 ?>

<head>

 <meta name="description" content="<?php echo $kampanyacek['kampanya_description']; ?>">

</head>


 <title><?php echo $kampanya_baslik; ?> | Yener Saat</title>

        <!-- breadcrumb -->

        


        <div class="full-row py-5">
            <div class="container">
                <div class="row text-center">
                    <div class="col-12">
                        <h3 style="font-family: arial;font-weight: 200;" class="mb-2"><?php echo $kampanya_baslik; ?></h3>
                    </div>
                   
                </div>
            </div>
        </div>
        <!-- breadcrumb -->

        <div class="full-row pt-0">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="products-header d-flex justify-content-between align-items-center py-10 px-20 bg-light md-mt-30">
                            <div class="products-header-left d-flex align-items-center">
                                <h6 style="font-family: arial;" class="woocommerce-products-header__title page-title">Tüm Ürünler </h6>
                                <div style="font-family: arial;" class="woocommerce-result-count"> ( <?php echo $uruntestsay." Ürün"; ?> )</div>
                                
                            </div>
                            <div class="products-header-right"></div>
                        </div>
                        <div class="showing-products pt-30 pb-50 border-2 border-bottom border-light">
                            <div class="row row-cols-xl-4 row-cols-md-3 row-cols-sm-2 row-cols-1 product-style-3 e-hover-image-zoom e-image-bg-light g-4">

                                <?php 

                                $kampanyaurunsec=$db->prepare("SELECT * from kampanyaurun where urun_kaldirildi='0' and kampanya_id='$kampanya_id' order by urun_sira ASC limit $baslangic,$kacar");
                        $kampanyaurunsec->execute();

                        while ($kampanyauruncek=$kampanyaurunsec->fetch(PDO::FETCH_ASSOC)) {

                        $urun_id = $kampanyauruncek['urun_id'];

                  $urunsec = $db->prepare("SELECT * from urunler where urun_id='$urun_id'");
                  $urunsec->execute();

                  $uruncek=$urunsec->fetch(PDO::FETCH_ASSOC);

                  $urun_id = $uruncek['urun_id'];

                  $urun_marka = $uruncek['marka_id'];

                  $urunseceneklersec=$db->prepare("SELECT * from urunsecenekler where urun_id=:id");
                                           $urunseceneklersec->execute(array(
                                            "id" => $urun_id
                                          ));

                                           $urunseceneklersay=$urunseceneklersec->rowCount();



                  $urunfotosec=$db->prepare("SELECT * from urunfoto where urun_id=:id and urunfoto_kapak=:kapak");
                        $urunfotosec->execute(array(

                          "kapak" => 1,
                           "id" => $urun_id

                         ));

                        $urunfotocek=$urunfotosec->fetch(PDO::FETCH_ASSOC);

                        $urunkapakfoto = $urunfotocek['urunfoto_yol'];

                        $markasec=$db->prepare("SELECT * from markalar where marka_id='$urun_marka'");
                        $markasec->execute();
                        $markacek=$markasec->fetch(PDO::FETCH_ASSOC);
                        $marka_ad=$markacek['marka_ad'];

                          ?>
                                
                               <div class="col">
                                    <div class="product type-product">
                                        <div class="product-wrapper">
                                            <div class="product-image">
                                                <a href="urun-<?php echo seo($uruncek['urun_ad'])."-".$urun_id; ?>" class="woocommerce-LoopProduct-link"><img src="<?php echo $urunkapakfoto; ?>" alt="Product Image"></a>

                                                <?php if ($uruncek['urun_indirim']==1) {

                                                $indirim_miktari = $uruncek['urun_indirimsizfiyat']-$uruncek['urun_fiyat'];
                                                $indirim_yuzdesi = round(($indirim_miktari*100)/$uruncek['urun_indirimsizfiyat']);

                                                    ?>

                                                <div class="product-labels">
                                                    <div <?php if ($indirim_yuzdesi<40) { ?>

                                                        style='background-color:#F3612E;'

                                                    <?php } else { ?>

                                                        style='background-color:#D4102E;'


                                                    <?php } ?> class="badge1"><span>- %<?php echo $indirim_yuzdesi; ?></span></div>
                                                </div>

                                            <?php } ?>
                                            </div>
                                            <div class="product-info">
                                                <h3 class="product-title"><a style="font-family: arial;font-weight: 600;"><?php echo $uruncek['marka_ad']; ?></a></h3>
                                                <h3 class="product-title"><a style="font-weight: 200;font-family: arial;font-size: 16px;" href="urun-<?php echo seo($uruncek['urun_ad'])."-".$urun_id; ?>"><?php echo $uruncek['urun_ad']; ?></a></h3>
                                                <div class="product-price">
                                                    <div class="price">

                                                        <?php if ($uruncek['urun_indirim']==1) { ?>

                                                            <ins <?php if ($indirim_yuzdesi<40) { ?>

                                                        style='color:#F3612E;'

                                                    <?php } else { ?>

                                                        style='color:#D4102E;'


                                                    <?php } ?>><b><?php echo $uruncek['urun_fiyat']; ?> TL</b></ins>

                                                    <del><b><?php echo $uruncek['urun_indirimsizfiyat']; ?> TL</b></del>


                                                        <?php } else { ?>

                                                             
                                                            <ins style="color:black;"><b><?php echo $uruncek['urun_indirimsizfiyat']; ?> TL</b></ins>



                                                        <?php } ?>

                                                        
                                                    </div>
                                                </div>
                                                
                                                <div class="shipping-feed-back">
                                                    <div class="star-rating">
                                                        <div class="rating-wrap">
                                                            
                                                        </div>
                                                        <div class="rating-counts-wrap">
                                                            <a href="#"></a>
                                                        </div>
                                                    </div>
                                                    <div class="sold-items">
                                                        <span></span> <span></span>
                                                    </div>
                                                </div>
                                                <div class="hover-area">

                                                    <?php if ($urunseceneklersay==0 and $uruncek['urun_stok']>0) { ?>

                                                    <div class="cart-button">
                                                        <a href="javascript:void(0);" class="button add_to_cart_button sepeteeklebuton" name="urun_<?php echo $urun_id;?>">Hemen Al</a>
                                                    </div>

                                                <?php } ?>

                                                    <div class="wishlist-button wishlist_<?php echo $urun_id; ?>"></div>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            <?php } ?>
                            </div>
                        </div>
                        
                        <div class="d-flex justify-content-between align-items-center pt-3">
                            <div class="showing-result"></div>

                             <?php if ($uruntestsay>$kacar) { ?>


                            <div class="pagination-style-one">
                                <nav aria-label="Page navigation example">
                                    <ul class="pagination">

                                         <?php $p=0; if ($sayfa!=1) { ?>

                                        <li class="page-item">
                                            <a class="page-link" href="kampanya-<?php echo $kampanya_seourl;?>?s=<?php echo $sayfa-1; ?>" aria-label="Previous">
                                                <span aria-hidden="true">&laquo;</span>
                                            </a>
                                        </li>

                                    <?php } ?>

                                     <?php while ($p<$sayfasayisi) { $p++; 

                                        if ($p<=$sayfa+3 and $p>=$sayfa-3) { ?>

                                        <li class="page-item <?php if($p==$sayfa){ ?>

                                        active

                                   <?php } ?>"><a <?php if($p==$sayfa){ ?> 

                                    style='color:white;' <?php  } ?> class="page-link" href="kampanya-<?php echo $kampanya_seourl;?>?s=<?php echo $p; ?>"><?php echo $p; ?></a></li>

                                    <?php } } ?>

                                        <?php if ($sayfa!=$sayfasayisi) { ?>
                                        
                                        <li class="page-item">
                                            <a class="page-link" href="kampanya-<?php echo $kampanya_seourl;?>?s=<?php echo $sayfa+1; ?>" aria-label="Next">
                                                <span aria-hidden="true">&raquo;</span>
                                            </a>
                                        </li>

                                    <?php } ?>

                                    </ul>
                                </nav>
                            </div>

                        <?php } ?>

                        </div>


                       
                    </div>
                </div>
            </div>
        </div>

    

        <?php require_once 'footer.php'; ?>

        <script type="text/javascript">
           
           $('.sepeteeklebuton').click(function(){

            
var id1=$(this).attr("name");
         var urun_id=id1.substring(5);
             

              

               

                    $('.sepeteeklebuton').prop('disabled',true);

$.ajax({
            type : 'POST',
            url : 'musteriislem.php',
            data : {'hemensepeteekle':'ok','urun_id':urun_id},
            success : function(sonuc){

              sonuc = $.trim(sonuc);


        

     
            window.location = 'sepetim';
                


            
              
              }
        })



                


        });


           $('.favorieklebuton').click(function(){

                

var buton = $(this);


var id1=$(this).attr("name");
var urun_id=id1.substring(5);


              

                    buton.prop('disabled',true);

$.ajax({
            type : 'POST',
            url : 'musteriislem.php',
            data : {'favorilereekle':'ok','urun_id':urun_id},
            success : function(sonuc){

              sonuc = $.trim(sonuc);

           
              


          

         if (sonuc=="ok") {

          

          $('.wishlist_'+urun_id).replaceWith('<span style="color:green;font-size:15px;margin-top:8px;"><i class="far fa-heart"></i> Favorilere Eklendi</span>');



        



         }

                

                  

               

                

                



                


            
              
              }
        })


                



        });


           $('.favoricikarbuton').click(function(){

                

var buton = $(this);


var id1=$(this).attr("name");
var urun_id=id1.substring(5);


              

                    buton.prop('disabled',true);

$.ajax({
            type : 'POST',
            url : 'musteriislem.php',
            data : {'favorilerdencikar':'ok','urun_id':urun_id},
            success : function(sonuc){

              sonuc = $.trim(sonuc);

           
              


          

         if (sonuc=="ok") {

          

          $('.wishlist_'+urun_id).replaceWith('<span style="color:green;font-size:15px;margin-top:8px;"><i class="fas fa-ban"></i> Favorilerden Çıkarıldı</span>');



        



         }

                

                  

               

                

                



                


            
              
              }
        })


                



        });

                    


       </script>
        