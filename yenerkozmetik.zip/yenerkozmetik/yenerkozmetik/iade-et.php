<?php require_once 'header.php';

$siparisitem_id=$_GET['siparisurun'];

$siparisitemsec=$db->prepare("SELECT * from siparisitem where siparisitem_id=:id");
$siparisitemsec->execute(array(
"id" => $siparisitem_id
));

$siparisitemsay=$siparisitemsec->rowCount();

$siparisitemcek=$siparisitemsec->fetch(PDO::FETCH_ASSOC);

$urun_id = $siparisitemcek['urun_id'];
$urun_iade = $siparisitemcek['urun_iade'];
$siparis_id = $siparisitemcek['siparis_id'];

$siparissec=$db->prepare("SELECT * from siparisler where siparis_id='$siparis_id'");
$siparissec->execute();
$sipariscek=$siparissec->fetch(PDO::FETCH_ASSOC);
$siparis_ulasmis = $sipariscek['siparis_ulasmis'];


if ($siparis_ulasmis!='1' or $urun_iade!='0' or empty($_SESSION['kullanicioturum'])) {
    
    header("location:index");
    exit;
}


$urunsec=$db->prepare("SELECT * from urunler where urun_id='$urun_id'");
$urunsec->execute();  


$toplammiktar=$siparisitemcek['urun_miktar'];



 ?>

 <title>Ürün İadesi Oluştur | Yener Kozmetik</title>

    

        <div id="main-content" class="full-row site-content">
            <div class="container">
                <div class="row ">
                    <div id="primary" class="content-area col-md-12">
                        <article id="post-19" class="post-19 page type-page status-publish hentry">
                            <div class="entry-content">
                                <div class="woocommerce">
                                    


                                    


                                    <form onsubmit="return false;" id="iadeform" class="woocommerce-checkout">
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="col2-set" id="customer_details">
                                                    <div class="woocommerce-billing-fields">
                                                        <h3 style="font-family: Arial;font-weight: 200;">Ürün İadesi Oluştur</h3>
                                                        


                        <hr>


                        <div id="yith-wcwl-form" class="table-responsive-lg">

                                                                


                                                            <table class="shop_table cart wishlist_table wishlist_view traditional table">
                                <thead>
                                    <tr>
                                        
                                        <th class="product-name"> <span class="nobr">Ürün No</span></th>
                                        <th class="product-name"> <span class="nobr">Ürün</span></th>
                                        <th class="product-name"> <span class="nobr">Satın Alınan Adet</span></th>
                                        <th class="product-price"> <span class="nobr">Birim Fiyatı</span></th>
                                        
                                        
                                        
                                    </tr>
                                </thead>
                                <tbody class="wishlist-items-wrapper">

                                    <?php


                              

                             $siparisitemseceneksec = $db->prepare("SELECT * from siparisitemsecenekler where siparisitem_id='$siparisitem_id'");

                          $siparisitemseceneksec->execute();


      $urunsec=$db->prepare("SELECT * from urunler where urun_id=:id");
                        $urunsec->execute(array(

                            "id" => $siparisitemcek['urun_id']
                        ));

                        $uruncek = $urunsec->fetch(PDO::FETCH_ASSOC);

                        $urun_id = $siparisitemcek['urun_id'];

                        $urun_fiyat = $siparisitemcek['urun_fiyat'];

                        $urun_toplamfiyat = $siparisitemcek['urun_toplam'];

                        

                        $urun_ad=$uruncek['urun_ad'];
                            ?>

                                              
                                    <tr id="yith-wcwl-row-97" data-row-id="97">
                                        
                                        
                                        <td class="product-name"> <?php echo $urun_id; ?></td>
                                        <td class="product-name"> <a target="_blank" href='urun-<?php echo seo($urun_ad)."-".$uruncek['urun_id']; ?>'><?php if (strlen($urun_ad)>85) { ?>
                            <?php echo substr($urun_ad,0,85)."..."; ?>
                        <?php } else { 

                         echo $urun_ad; 
                         } ?></a><br>

                        <?php while ($siparisitemsecenekcek=$siparisitemseceneksec->fetch(PDO::FETCH_ASSOC)) { 
                $secenek_ad = $siparisitemsecenekcek['secenek_ad'];
                $altsecenek_ad = $siparisitemsecenekcek['altsecenek_ad']; ?> 


                <?php echo "<span style='font-weight:500;'>".$secenek_ad."</span> : ".$altsecenek_ad."<br>"; ?>
                            

              <?php } ?>
</td>
                                        <td class="product-name"> <?php echo $siparisitemcek['urun_miktar']; ?></td>
                                        <td class="product-price"> <span class="woocommerce-Price-amount amount"><bdi><?php echo $urun_fiyat; ?> TL</bdi>
                                            </span>
                                        </td>
                                       
                                        

                                        
                            
                            
                   
                                       
                                    </tr>

                                
                                </tbody>
                            </table>

                        </div>

                                                        
                                                        
                                                    </div>
                                                    
                                                    <div class="woocommerce-additional-fields">
                                                        <div class="woocommerce-additional-fields__field-wrapper">

                                                            <?php if ($toplammiktar>1) { ?>

                                                                <p class="form-row notes" id="order_comments_field" data-priority=""><label style="color:black;" for="order_comments" class="">İade Adedi&nbsp;<abbr class="required" title="required">*</abbr></label><span class="woocommerce-input-wrapper">




                                                             
                                                             <select name="iade_miktar" class="form-control">

                                                             <?php $miktarsay=0;
                                                                   

                                                             while ($miktarsay<$toplammiktar) {
                                                                  
                                                                  $miktarsay++; ?>


                                                                  <option value="<?php echo $miktarsay; ?>"><?php echo $miktarsay; ?></option>


                                                             <?php  } ?>

                                                                 
                                                             </select>

                                                            </span></p>
                                                                
                                                            <?php } else { ?>


                                                            <input type="hidden" value="1" name="iade_miktar">


                                                            <?php } ?>

                                                            

                                                            <p class="form-row notes" id="order_comments_field" data-priority=""><label style="color:black;" for="order_comments" class="">İade Sebebi&nbsp;<abbr class="required" title="required">*</abbr></label><span class="woocommerce-input-wrapper"><textarea name="iade_text" class="input-text " id="iade_text" placeholder="Bu ürünü neden iade etmek istediğinizi yazın." maxlength="1000" rows="5" cols="5"></textarea></span></p>

                                                            
                                                        </div>


                                                    </div>

                                                    <input type="hidden" id="siparisitem_id" value="<?php echo $siparisitem_id; ?>" name="siparisitem_id">

                                                    <input type="hidden" name="urun_fiyat" value="<?php echo $urun_fiyat; ?>">


                                                    <input type="hidden" name="disableFill" value="">

                                                    

                                                    <div style="display: none;" class="alert alert-warning uyari"></div>


                                                                <button type="submit" class="button alt iadebuton" name="woocommerce_checkout_place_order" id="place_order">İade Oluştur</button>


                                                </div>
                                            </div>
                                            
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <!-- .entry-content -->
                        </article>
                        <!-- #post-## -->
                    </div>
                    <!-- .entry-content-wrapper -->
                </div>
                <!-- .row -->
            </div>
            <!-- .container -->
        </div>
    
    <?php require_once 'footer.php'; ?>
    <script type="text/javascript">
        
        $('#iadeform').submit(function(){

         var siparisitem_id = $('#siparisitem_id').val();
         var iade_text = $.trim($('#iade_text').val());

      if (iade_text.length<5) {

      $('.uyari').show();
      $('.uyari').html('<i class="fas fa-info-circle"></i> Lütfen iade sebebini biraz daha doldurun.');


      } else {

        $('.iadebuton').prop('disabled',true);
        $('.iadebuton').html('Gönderiliyor...');
        $('.uyari').hide();

        var data = $("#iadeform").serializeArray();
        data.push({name: "uruniadeform",value: "ok"});

         $.ajax({
            type : 'POST',
            url : 'musteriislem.php',
            data : $.param(data),
            success : function(sonuc){

              sonuc = $.trim(sonuc);


        if (sonuc=="ok") {

             location.href='iade-detaylari?siparisurun='+siparisitem_id;


             } 


              }
        })
      

      }




        })

    </script>