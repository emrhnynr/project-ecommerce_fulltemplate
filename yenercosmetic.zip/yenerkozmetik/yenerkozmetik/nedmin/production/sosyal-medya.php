<?php require_once 'header.php';

$genelayarsec=$db->prepare("SELECT * from genelayarlar");
$genelayarsec->execute();

 $genelayarcek=$genelayarsec->fetch(PDO::FETCH_ASSOC);

 $ayar_facebook = $genelayarcek['ayar_facebook'];
 $ayar_youtube = $genelayarcek['ayar_youtube'];
  $ayar_instagram = $genelayarcek['ayar_instagram'];
   $ayar_twitter = $genelayarcek['ayar_twitter'];
   $ayar_ios = $genelayarcek['ayar_ios'];
   $ayar_googleplay = $genelayarcek['ayar_googleplay'];



  ?>



        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              

              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                 
                  <div class="x_content">
                    <br />

                  

                    <form id="sosyalduzenleform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

                      <h3 align="center">Sosyal Medya</h3>
                      
                      <hr>


                     
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Facebook 
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="ayar_facebook" value="<?php echo $genelayarcek['ayar_facebook']; ?>" name="ayar_facebook" placeholder="https:// dahil tüm url'yi kopyalayıp yapıştırın." maxlength="500"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Twitter
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="ayar_twitter" value="<?php echo $genelayarcek['ayar_twitter']; ?>" name="ayar_twitter" placeholder="https:// dahil tüm url'yi kopyalayıp yapıştırın." maxlength="500"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Youtube
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="ayar_youtube" placeholder="https:// dahil tüm url'yi kopyalayıp yapıştırın." value="<?php echo $genelayarcek['ayar_youtube']; ?>" name="ayar_youtube" maxlength="500"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Instagram
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="ayar_instagram" placeholder="https:// dahil tüm url'yi kopyalayıp yapıştırın." value="<?php echo $genelayarcek['ayar_instagram']; ?>" name="ayar_instagram" maxlength="500"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">App Store
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="ayar_ios" placeholder="https:// dahil tüm url'yi kopyalayıp yapıştırın." value="<?php echo $genelayarcek['ayar_ios']; ?>" name="ayar_ios" maxlength="500"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Google Play
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="ayar_googleplay" placeholder="https:// dahil tüm url'yi kopyalayıp yapıştırın." value="<?php echo $genelayarcek['ayar_googleplay']; ?>" name="ayar_googleplay" maxlength="500"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      

                      

                     

                

                      <input type="hidden" name="sosyalmedyaduzenle">


                      
                      
                      <div class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">

                       
                          
                          <button type="submit" class="btn btn-success sosyalduzenlebuton">Düzenle</button>
                        </div>
                      </div>

                    </form>

                    

                   


                    
                  </div>
                </div>
              </div>
            </div>

            <?php require_once 'footer.php'; ?>



            <script type="text/javascript">

             

            $('#sosyalduzenleform').submit(function(){

             


              $('.sosyalduzenlebuton').prop('disabled',true);

              

                $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : $('#sosyalduzenleform').serialize(),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

              if (sonuc=="ok") {

                
                $('.sosyalduzenlebuton').prop('disabled',false);


                swal({

  title: "Başarılı",
  text: "Sosyal medya hesapları başarıyla güncellendi!",
  icon: "success",
  button: "OK",
});



              }
                

              }


            })

                 

                 });

            


            

            </script>

              
             