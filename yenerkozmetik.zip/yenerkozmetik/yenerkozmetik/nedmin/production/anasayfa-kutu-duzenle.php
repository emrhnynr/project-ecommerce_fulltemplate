<?php require_once 'header.php';

 $kutu_id=$_GET['kutu_id'];
 $kutusec=$db->prepare("SELECT * from anasayfakutular where kutu_id=:id");
 $kutusec->execute(array(
"id" => $kutu_id
 ));

 $kutusay=$kutusec->rowCount();

 if ($kutusay==0) {
   
   header("Location:index");
   exit;
 }

 $kutucek=$kutusec->fetch(PDO::FETCH_ASSOC);

 ?>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              

              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Kutu <?php echo $kutucek['kutu_sira']; ?> Düzenle</h2>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />

                    <form id="kutufotoduzenleform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

                   

                    

                    <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">
                        Kutu Resim *</label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <img class="img-responsive" src="../../<?php echo $kutucek['kutu_foto']; ?>">
                        </div>
                      </div>



                      <div class="form-group">
                       
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="file" id="kutu_foto" name="kutu_foto"  class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>

                      <div align="left" class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                          <div style="display: none;" class="alert alert-warning uyarikutufoto"></div>
                          
                          <button type="submit" class="btn btn-success kutufotobuton">Güncelle</button>
                        </div>
                      </div>

                    </form>

                    <hr>

                    <form id="kutuduzenleform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

                      
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Kutu Sıra <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="number" id="kutu_sira" value="<?php echo $kutucek['kutu_sira']; ?>" name="kutu_sira"  class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>

                      

                       <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Kutu Link
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" id="kutu_link" value="<?php echo $kutucek['kutu_link']; ?>" placeholder="Doldurmazsanız, kutu tıklanamaz olacak." maxlength="500" name="kutu_link"  class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>

                      <input type="hidden" name="kutuduzenleadmin">
                      <input type="hidden" id="kutu_id" value="<?php echo $kutucek['kutu_id'] ?>" name="kutu_id">
                      
                      
                      <div class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                          <div style="display: none;" class="alert alert-warning uyari"></div>
                          
                          <button type="submit" class="btn btn-success kutuduzenlebuton">Düzenle</button>
                        </div>
                      </div>

                    </form>
                  </div>
                </div>
              </div>
            </div>

            <?php require_once 'footer.php'; ?>
            <script type="text/javascript">

              $('.kutufotobuton').click(function(){

               var input = $('#kutu_foto');
var foto = $('#kutu_foto').val();
var filevalue = $('#kutu_foto').get(0).files[0];
var fotouzanti = foto.split('.').pop();
var kutu_id = $('#kutu_id').val();



var data = new FormData();
data.append('kutufotoduzenle',"ok");
data.append('kutu_id',kutu_id);
data.append("file",filevalue);

if ($('#kutu_foto').val().length==0){

 $('.uyarikutufoto').show();
$('.uyarikutufoto').html('<i class="fa fa-info-circle"></i> Lütfen bir resim yükleyin.');

  } else if (fotouzanti!='jpg' && fotouzanti!='jpeg' && fotouzanti!='png' && fotouzanti!='JPG' && fotouzanti!='PNG'){

$('.uyarikutufoto').show();
$('.uyarikutufoto').html('<i class="fa fa-info-circle"></i> Sadece <b>.jpg, .jpeg, .png</b> uzantılı dosyaları yükleyebilirsiniz.');

} else {

  $('.kutufotobuton').prop('disabled',true);
  $('.kutufotobuton').html('Güncelleniyor...');

  $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            enctype : 'multipart/form-data',
            data : data,
            processData: false,
            contentType: false,
            cache: false,
            success : function(sonuc){

      sonuc=$.trim(sonuc);
      
      if (sonuc=='ok') {

        location.reload();
      }

 }

 });


   }

              });
              
              $('#kutuduzenleform').submit(function(){
          
          var kutu_sira = $('#kutu_sira').val();
        
    
      var form = $('#kutuduzenleform')[0];
             var data = new FormData(form);

               if (kutu_sira.length==0){

$('.uyari').show();
$('.uyari').html('<i class="fa fa-info-circle"></i> Lütfen kutunun kaçıncı sırada listeleneceğini belirtin.');

      } else {

       
       $('.uyari').hide();
$('.kutuduzenlebuton').prop('disabled',true);
$('.kutuduzenlebuton').html('Düzenleniyor...');

$.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : $('#kutuduzenleform').serialize(),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

              if (sonuc=="ok") {

                swal({

  title: "Başarılı",
  text: "Kutu düzenlendi!",
  icon: "success",
  button: "OK",
}).then((willDelete) => {
  if (willDelete) {

    window.location = 'anasayfa-kutular';

     }

   });
              }
              }
        })

      }



              });

            </script>

            