<?php require_once 'header.php';

 $slayt_id=$_GET['slayt_id'];
 $slaytsec=$db->prepare("SELECT * from slaytlar where slayt_id=:id");
 $slaytsec->execute(array(
"id" => $slayt_id
 ));

 $slaytsay=$slaytsec->rowCount();

 if ($slaytsay==0) {
   
   header("Location:index");
   exit;
 }

 $slaytcek=$slaytsec->fetch(PDO::FETCH_ASSOC);

 ?>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              

              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Slayt <?php echo $slaytcek['slayt_sira']; ?> Düzenle</h2>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />

                    <form id="slaytfotoduzenleform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

                   

                    

                    <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">
                        Resim (1366 x 504px)</label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <img class="img-responsive" src="../../<?php echo $slaytcek['slayt_foto']; ?>">
                        </div>
                      </div>



                      <div class="form-group">
                       
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="file" id="slayt_foto" name="slayt_foto"  class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>

                      <div align="left" class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                          <div style="display: none;" class="alert alert-warning uyarislaytfoto"></div>
                          
                          <button type="submit" class="btn btn-success slaytfotobuton">Güncelle</button>
                        </div>
                      </div>

                    </form>

                    <hr>

                    <form id="slaytduzenleform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

                      
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Slayt Sıra <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="number" id="slayt_sira" value="<?php echo $slaytcek['slayt_sira']; ?>" name="slayt_sira"  class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Slayt Başlık
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" id="slayt_baslik" value="<?php echo $slaytcek['slayt_baslik']; ?>" maxlength="300" name="slayt_baslik"  class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Slayt Metin
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                         <textarea class="form-control" rows="7" name="slayt_aciklama"><?php echo $slaytcek['slayt_aciklama']; ?></textarea>
                        </div>
                      </div>

                       <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Slayt Link
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" id="slayt_link" value="<?php echo $slaytcek['slayt_link']; ?>" placeholder="Doldurmazsanız, slayt resmi tıklanamaz olacak." maxlength="300" name="slayt_link"  class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>

                      <input type="hidden" name="slaytduzenleadmin">
                      <input type="hidden" id="slayt_id" value="<?php echo $slaytcek['slayt_id'] ?>" name="slayt_id">
                      
                      
                      <div class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                          <div style="display: none;" class="alert alert-warning uyari"></div>
                          
                          <button type="submit" class="btn btn-success slaytduzenlebuton">Düzenle</button>
                        </div>
                      </div>

                    </form>
                  </div>
                </div>
              </div>
            </div>

            <?php require_once 'footer.php'; ?>
            <script type="text/javascript">

              $('.slaytfotobuton').click(function(){

               var input = $('#slayt_foto');
var foto = $('#slayt_foto').val();
var filevalue = $('#slayt_foto').get(0).files[0];
var fotouzanti = foto.split('.').pop();
var slayt_id = $('#slayt_id').val();



var data = new FormData();
data.append('slaytfotoduzenle',"ok");
data.append('slayt_id',slayt_id);
data.append("file",filevalue);

if ($('#slayt_foto').val().length==0){

 $('.uyarislaytfoto').show();
$('.uyarislaytfoto').html('<i class="fa fa-info-circle"></i> Lütfen bir resim yükleyin.');

  } else if (fotouzanti!='jpg' && fotouzanti!='jpeg' && fotouzanti!='png' && fotouzanti!='JPG' && fotouzanti!='PNG'){

$('.uyarislaytfoto').show();
$('.uyarislaytfoto').html('<i class="fa fa-info-circle"></i> Sadece <b>.jpg, .jpeg, .png</b> uzantılı dosyaları yükleyebilirsiniz.');

} else {

  $('.slaytfotobuton').prop('disabled',true);
  $('.slaytfotobuton').html('Güncelleniyor...');

  $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            enctype : 'multipart/form-data',
            data : data,
            processData: false,
            contentType: false,
            cache: false,
            success : function(sonuc){

      sonuc=$.trim(sonuc);
      
      if (sonuc=='ok') {

        location.reload();
      }

 }

 });


   }

              });
              
              $('#slaytduzenleform').submit(function(){
          
          var slayt_sira = $('#slayt_sira').val();
        
    
      var form = $('#slaytekleform')[0];
             var data = new FormData(form);

               if (slayt_sira.length==0){

$('.uyari').show();
$('.uyari').html('<i class="fa fa-info-circle"></i> Lütfen slaytın kaçıncı sırada listeleneceğini belirtin.');

      } else {

       
       $('.uyari').hide();
$('.slaytduzenlebuton').prop('disabled',true);
$('.slaytduzenlebuton').html('Düzenleniyor...');

$.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : $('#slaytduzenleform').serialize(),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

              if (sonuc=="ok") {

                swal({

  title: "Başarılı",
  text: "Slayt düzenlendi!",
  icon: "success",
  button: "OK",
}).then((willDelete) => {
  if (willDelete) {

    window.location = 'slayt-ayarlari';

     }

   });
              }
              }
        })

      }



              });

            </script>

            