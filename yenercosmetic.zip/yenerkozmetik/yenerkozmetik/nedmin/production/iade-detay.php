<?php require_once 'header.php';

$siparisitem_id=$_GET['siparisurun'];

$siparisitemsec=$db->prepare("SELECT * from siparisitem where siparisitem_id=:id and urun_iade!='0'");
$siparisitemsec->execute(array(
"id" => $siparisitem_id
));

$siparisitemsay=$siparisitemsec->rowCount();

$siparisitemcek=$siparisitemsec->fetch(PDO::FETCH_ASSOC);

$urun_id = $siparisitemcek['urun_id'];
$urun_iade = $siparisitemcek['urun_iade'];
$siparis_id = $siparisitemcek['siparis_id'];
$iade_text = $siparisitemcek['iade_text'];
$iade_miktar = $siparisitemcek['iade_miktar'];
$iade_tutar = $siparisitemcek['iade_tutar'];

if ($siparisitemsay==0) {
  
  header("location:index");
  exit;
}

$urunsec=$db->prepare("SELECT * from urunler where urun_id='$urun_id'");
$urunsec->execute();

                $kullanici_id = $siparisitemcek['kullanici_id'];

               $kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_id=:id");
               $kullanicisec->execute(array(
                "id" => $kullanici_id

              ));

               $kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);


                
 ?>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
           

            <div class="clearfix"></div>

            <div class="row">
             

              <div class="clearfix"></div>

              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Ürün İade Detayları</h2>

                    <ul class="nav navbar-right panel_toolbox">
                      
                      <?php 

                      switch ($urun_iade) {

                         case '1': ?>

                           <button class="btn btn-success iadekabul"  name="iade_<?php echo $siparisitem_id; ?>" href="javascript:void(0);"><i class="fa fa-check"></i> İade Et</button>

                      <button class="btn btn-danger iadered" name="iade_<?php echo $siparisitem_id; ?>" href="javascript:void(0);"><i class="fa fa-times"></i> İadeyi Reddet</button>

                           <?php break;

                           case '2': ?>

                           <span style="color:green;font-size: 16.5px;"><i class="fa fa-check"></i> İade Edildi</span>

                           <?php break;

                           case '3': ?>

                           <span style="color:#CA0725;font-size: 16.5px;"><i class="fa fa-times"></i> İade Reddedildi</span>

                           <?php break;
                         
                        
                       } ?>

                    </ul>
                    
                    <div class="clearfix"></div>
                  </div>

                  <div class="x_content">

                     <div class="table-responsive">
                      <table class="table table-striped jambo_table bulk_action">
                        <thead>
                          <tr class="headings">
                            
                            <th class="column-title">İade Tarihi</th>
                            <th class="column-title">Müşteri</th>
                            <th class="column-title">Ürün </th>
                            <th class="column-title">İade Adedi </th>
                            <th class="column-title">Birim Fiyat</th>
                            <th class="column-title">İade Tutarı</th>
                            <th class="column-title">Sipariş</th>
                            

                            
                            
                            
                            
                            
                          </tr>
                        </thead>

                        <tbody>
                          
                          <?php 
                         
                        


                          

                            
                       $iade_zaman = $siparisitemcek['iade_tarihi'];
                       $d = new DateTime($iade_zaman);
                        $zamanson =  $d->format('d/m/Y H:i');

                        
                        $uruncek=$urunsec->fetch(PDO::FETCH_ASSOC);

                        $siparisitemseceneksec = $db->prepare("SELECT * from siparisitemsecenekler where siparisitem_id='$siparisitem_id'");

                          $siparisitemseceneksec->execute();

                        $urun_ad = $uruncek['urun_ad'];
                      

                      $urun_fiyat=$siparisitemcek['urun_fiyat'];
                      $urun_miktar=$siparisitemcek['urun_miktar'];
                      $urun_toplam=$siparisitemcek['urun_toplam'];
                      $kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_yetki=:yetki and kullanici_id=:id");
                      $kullanicisec->execute(array(
                        "yetki" => 1,
                        "id" => $kullanici_id
                      ));

                      $kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

                      $kullanici_ad = $kullanicicek['kullanici_ad']." ".substr($kullanicicek['kullanici_soyad'], 0,1).".";

                
                            ?>
                            
                          <tr class="even pointer">
                            
                            <td><?php echo $zamanson ?></td>
                            <td><a target="_blank" href="uye-detay?uye_id=<?php echo $kullanici_id; ?>"><?php echo $kullanici_ad; ?></a></td>
                            <td><a target="_blank" href='../../urun-<?php echo seo($urun_ad)."-".$uruncek['urun_id']; ?>'><?php if (strlen($urun_ad)>85) { ?>
              <?php echo substr($urun_ad,0,85)."..."; ?>
            <?php } else { 

                         echo $urun_ad; 
             } ?></a><br>

           <?php while ($siparisitemsecenekcek=$siparisitemseceneksec->fetch(PDO::FETCH_ASSOC)) { 
                $secenek_ad = $siparisitemsecenekcek['secenek_ad'];
                $altsecenek_ad = $siparisitemsecenekcek['altsecenek_ad']; ?> 


                <?php echo $secenek_ad." : ".$altsecenek_ad."<br>"; ?>
                            

              <?php } ?></td>
                            <td><?php echo $iade_miktar; ?></td>
                            <td>₺ <?php echo $urun_fiyat; ?></td>
                            <td>₺ <?php echo $iade_tutar; ?></td>
                            <td><a target="_blank" class="btn btn-xs btn-success" href="siparis-detay?siparis_id=<?php echo $siparis_id; ?>">Siparişi Gör</a></td>
                           
                          

                          </tr>

                                 
                        
                        </tbody>
                      </table>
                    </div>

                    <hr>

                    <div class="col-md-12 col-xs-12 col-sm-12">
            <label>İade Sebebi</label>
             <textarea rows="8" readonly="" class="form-control"><?php echo $siparisitemcek['iade_text']; ?></textarea>
           </div>

         

                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->


      </div>
    </div>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="../vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- Sweet Alert -->

    <script type="text/javascript" src="../../sweetalert.min.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
  </body>
</html>

 <script type="text/javascript">
         
         $('.iadekabul').click(function(){

           var buton = $(this);
           var id1=$(this).attr("name");
           var siparisitem_id=id1.substring(5);

                

               swal({
  title: "İade talebini onaylıyor musunuz?",
  icon: "info",
  buttons: ["Vazgeç", "Onayla"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

    $('.iadekabul').prop('disabled',true);
    buton.html('Lütfen Bekleyin...');

    $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'iadekabul':'ok','siparisitem_id':siparisitem_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              if (sonuc=="ok") {

                location.reload();
              }

               }

             });


     }

     })
         });

         $('.iadered').click(function(){

           var buton = $(this);
            var id1=$(this).attr("name");
                var siparisitem_id=id1.substring(5);

               swal({
  title: "İade talebini reddediyor musunuz?",
  icon: "info",
  buttons: ["Vazgeç", "Reddet"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

    $('.iadered').prop('disabled',true);
    buton.html('Lütfen Bekleyin...');

    $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'iadered':'ok','siparisitem_id':siparisitem_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              if (sonuc=="ok") {

                location.reload();
              }

               }

             });


     }

     })
         });

  </script>