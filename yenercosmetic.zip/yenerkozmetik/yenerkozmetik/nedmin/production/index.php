
<?php require_once 'header.php'; ?>




        <!-- page content -->
        <div class="right_col" role="main">
          <!-- top tiles -->
          

            <h3 align="center">Yeni Aktiviteler<hr></h3>

            <div class="row tile_count">

            <div align="center" class="col-md-3 col-sm-3 col-xs-6 tile_stats_count">



   

               <a href="siparisler"><span class="count_top"><i class="fa fa-cubes"></i> Görülmemiş Siparişler</span>
              <div class="count green"><?php echo $gorulmemissiparissay; ?></div></a>
              
            </div>

            <div align="center" class="col-md-3 col-sm-3 col-xs-6 tile_stats_count">



   

               <a href="iadeler"><span class="count_top"><i class="fa fa-refresh"></i> Görülmemiş İade Talepleri</span>
              <div class="count green"><?php echo $gorulmemisiadesay; ?></div></a>
              
            </div>

            <div align="center" class="col-md-3 col-sm-3 col-xs-6 tile_stats_count">

   

              <a href="yorumlar"><span class="count_top"><i class="fa fa-comments"></i> Görülmemiş Yorumlar</span>
              <div class="count green"><?php echo $gorulmemisyorumsay; ?></div></a>
              
            </div>

             <div align="center" class="col-md-3 col-sm-3 col-xs-6 tile_stats_count">

   

              <a href='uyeler'><span class="count_top"><i class="fa fa-user"></i> Görülmemiş Üyeler</span>
              <div class="count green"><?php echo $gorulmemisuyesay; ?></div></a>
              
            </div>

          </div>



            <h3 style="margin-top:30px;" align="center">Sipariş Raporları<hr></h3>

            <div class="row tile_count">

              <div align="center" class="col-md-3 col-sm-4 col-xs-6 tile_stats_count">

   <?php 
   $siparissec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis");
   $siparissec->execute(array(
    "ulasmis" => 0
  ));

  $siparissay=$siparissec->rowCount(); ?>

              <a href="siparisler?filtrele=bekleyen"><span class="count_top"><i class="fa fa-cubes"></i> Hazırlanan Siparişler</span>
              <div class="count green"><?php echo $siparissay; ?></div></a>
              
            </div>

            <div align="center" class="col-md-3 col-sm-4 col-xs-6 tile_stats_count">

   <?php 
   $siparissec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis");
   $siparissec->execute(array(
    "ulasmis" => 2
  ));

  $siparissay=$siparissec->rowCount(); ?>

              <a href="siparisler?filtrele=kargoda"><span class="count_top"><i class="fa fa-truck"></i> Kargodaki Siparişler</span>
              <div class="count green"><?php echo $siparissay; ?></div></a>
              
            </div>

        <div align="center" class="col-md-3 col-sm-4 col-xs-6 tile_stats_count">

   <?php 
   $siparissec=$db->prepare("SELECT * from siparisler where siparis_ulasmis=:ulasmis");
   $siparissec->execute(array(
    "ulasmis" => 1
  ));

  $siparissay=$siparissec->rowCount(); ?>

              <a href="siparisler?filtrele=teslimedilen"><span class="count_top"><i class="fa fa-check"></i> Teslim Edilen Siparişler</span>
              <div class="count green"><?php echo $siparissay; ?></div></a>
              
            </div>

            <div align="center" class="col-md-3 col-sm-4 col-xs-6 tile_stats_count">

   <?php 
   $siparissec=$db->prepare("SELECT * from siparisler");
   $siparissec->execute();

  $siparissay=$siparissec->rowCount(); ?>

              <a href="siparisler"><span class="count_top"><i class="fa fa-cubes"></i> Toplam Sipariş</span>
              <div class="count green"><?php echo $siparissay; ?></div></a>
              
            </div>

         

            



            </div>

            

            <h3 style="margin-top:30px;" align="center">Genel Raporlar<hr></h3>

            <div align="center" class="row tile_count">

              <div align="center" class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">

   <?php 
   $kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_yetki=:yetki");
   $kullanicisec->execute(array(
    "yetki" => 1
  ));

  $kullanicisay=$kullanicisec->rowCount(); ?>

              <a href="uyeler"><span class="count_top"><i class="fa fa-user"></i> Toplam Üye</span>
              <div class="count green"><?php echo $kullanicisay; ?></div></a>
              
            </div>

            <div align="center" class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">

   <?php 
   $yorumsec=$db->prepare("SELECT * from yorumlar");
   $yorumsec->execute();

  $yorumsay=$yorumsec->rowCount(); ?>

              <a href="yorumlar"><span class="count_top"><i class="fa fa-comments"></i> Toplam Yorum</span>
              <div class="count green"><?php echo $yorumsay; ?></div></a>
              
            </div>

            <div align="center" class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">

   <?php 
   $urunsec=$db->prepare("SELECT * from urunler where urun_kaldirildi=:kaldirildi");
   $urunsec->execute(array(
    "kaldirildi" => 0
  ));

  $urunsay=$urunsec->rowCount(); ?>

              <a href="urun-ayarlari"><span class="count_top"><i class="fa fa-table"></i> Toplam Ürün</span>
              <div class="count green"><?php echo $urunsay; ?></div></a>
              
            </div>

            <div align="center" class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">

   <?php 
   $kategorisec=$db->prepare("SELECT * from kategoriler");
   $kategorisec->execute();

  $kategorisay=$kategorisec->rowCount(); ?>

              <a href="kategori-ayarlari"><span class="count_top"><i class="fa fa-align-justify"></i> Toplam Kategori</span>
              <div class="count green"><?php echo $kategorisay; ?></div></a>
              
            </div>

            <div align="center" class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">

   <?php 
   $markasec=$db->prepare("SELECT * from markalar");
   $markasec->execute();

  $markasay=$markasec->rowCount(); ?>

              <a href="marka-ayarlari"><span class="count_top"><i class="fa fa-bars"></i> Toplam Marka</span>
              <div class="count green"><?php echo $markasay; ?></div></a>
              
            </div>

            <div align="center" class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">

   <?php 
   $kampanyasec=$db->prepare("SELECT * from kampanyalar");
   $kampanyasec->execute();

  $kampanyasay=$kampanyasec->rowCount(); ?>

              <a href="kampanyalar"><span class="count_top"><i class="fa fa-check-square"></i> Toplam Kampanya</span>
              <div class="count green"><?php echo $kampanyasay; ?></div></a>
              
            </div>

            </div>

           

             

            

           

          


            

            

          </div>
          <!-- /top tiles -->

         
         

        
        </div>
        <!-- /page content -->

       <?php require_once 'footer.php'; ?>