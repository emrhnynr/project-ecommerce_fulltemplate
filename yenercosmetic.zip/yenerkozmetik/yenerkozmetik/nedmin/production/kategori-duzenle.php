<?php require_once 'header.php';

 $kategori_id=$_GET['kategori_id'];
 $kategorisec=$db->prepare("SELECT * from kategoriler where kategori_id=:id");
 $kategorisec->execute(array(
"id" => $kategori_id
 ));

 $kategorisay=$kategorisec->rowCount();

 if ($kategorisay==0) {
   
   header("Location:index");
   exit;
 }

 $kategoricek=$kategorisec->fetch(PDO::FETCH_ASSOC);

 ?>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              

              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Kategori Düzenle : <?php echo $kategoricek['kategori_ad']; ?></h2>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />

                    

                    <form id="kategoriduzenleform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

                      
                     

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Kategori Adı <span class="required">*</span>
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="kategori_ad" value="<?php echo $kategoricek['kategori_ad']; ?>" maxlength="400" name="kategori_ad"  class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>

                      

                      <input type="hidden" name="kategoriduzenleadmin">
                      <input type="hidden" id="kategori_id" value="<?php echo $kategoricek['kategori_id'] ?>" name="kategori_id">
                      
                      
                      <div class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                          <div style="display: none;" class="alert alert-warning uyari"></div>
                          
                          <button type="submit" class="btn btn-success kategoriduzenlebuton">Düzenle</button>
                        </div>
                      </div>

                    </form>
                  </div>
                </div>
              </div>
            </div>

            <?php require_once 'footer.php'; ?>
            <script type="text/javascript">

              
              
              $('#kategoriduzenleform').submit(function(){
          
          var kategori_ad = $.trim($('#kategori_ad').val());
        
    
      var form = $('#slaytekleform')[0];
             var data = new FormData(form);

               if (kategori_ad.length==0){

$('.uyari').show();
$('.uyari').html('<i class="fa fa-info-circle"></i> Kategori adı boş bırakılamaz.');

      } else {

       
       $('.uyari').hide();
$('.kategoriduzenlebuton').prop('disabled',true);
$('.kategoriduzenlebuton').html('Düzenleniyor...');

$.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : $('#kategoriduzenleform').serialize(),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

              

              if (sonuc=="ok") {

                swal({

  title: "Başarılı",
  text: "Kategori düzenlendi!",
  icon: "success",
  button: "OK",
}).then((willDelete) => {
  if (willDelete) {

    window.location = 'kategori-ayarlari';

     }

   });
              }
              }
        })

      }



              });

            </script>

            