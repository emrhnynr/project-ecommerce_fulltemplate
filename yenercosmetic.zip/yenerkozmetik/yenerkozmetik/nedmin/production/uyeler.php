<?php require_once 'header.php'; 

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_goruldu=:kullanici_goruldu

where kullanici_goruldu='0' and kullanici_yetki='1'

");

$derle=$hazirla->execute(array(
"kullanici_goruldu" => 1
));

?>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
           

            <div class="clearfix"></div>

            <div class="row">
             

              <div class="clearfix"></div>

              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Kayıtlı Üyeler</h2>

                    <div  class="col-xs-12 col-sm-3 col-md-3 nav navbar-right panel_toolbox">
                       <select id="siralamaolcutu" name="siralamaolcutu" class="form-control">
                        <option disabled="">Sıralama Ölçütü:</option>
                        <option selected="" value="kayitsondanbasa">Kayıt Tarihi (Yeniden Eskiye)</option>
                        <option value="kayitbastansona">Kayıt Tarihi (Eskiden Yeniye)</option>
                        
                      </select>
                    </div>
                   
                    
                    <div class="clearfix"></div>


                  </div>

                  <div class="x_content">

                    
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->


      </div>
    </div>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="../vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- Sweet Alert -->

    <script type="text/javascript" src="../../sweetalert.min.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
  </body>
</html>

 <script type="text/javascript">
         
         $('#siralamaolcutu').change(function(){

 var siralamaolcutu = $(this).val();

 $('.x_content').html('<h3 align="center">Yükleniyor...</h3>');

 $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : {'uyelersiralamaolcutudegistir':'ok','siralamaolcutu':siralamaolcutu},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              $('.x_content').html(sonuc);

               }

              });



      }).change();

         

       </script>