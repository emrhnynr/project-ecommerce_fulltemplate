<?php require_once 'header.php'; ?>

<head>

<meta name="description" content="<?php echo $seoayarcek['iletisim_description']; ?>">

</head>

<title><?php echo $seoayarcek['iletisim_title']; ?></title>

        

        <!--==================== Map Section Start ====================-->
        <div style="padding-top: 40px;" class="full-row">
            <div class="container-fluid">

                <h3 align="center" style="font-weight: 200;font-family: arial;"><?php echo $genelayarcek['ayar_iletisimbaslik']; ?></h3><br>
                <div class="row">
                    <div id="map" style="height: 500px; width: 100%; overflow: hidden;">
                        
                        <?php echo $genelayarcek['googlemaps_api']; ?>

                    </div>
                </div>
            </div>
        </div>
        <!--==================== Map Section End ====================-->

        <!--==================== Contact Section Start ====================-->
        <div style="padding-top:15px;" class="full-row">
            <div class="container">
                <div class="row">
                    <div class="col-lg-7 col-md-7">
                        <h3 style="font-weight: 200;font-family: arial;" class="down-line mb-5">Mesaj Gönder</h3>
                        <div class="form-simple mb-5">
                            <form onsubmit="return false;" id="mailgonderform">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label>Ad & Soyad:</label>
                                            <input id="name" type="text" maxlength="150" class="form-control bg-gray" name="kullanici_adsoyad">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label>E-Posta:</label>
                                            <input id="email" type="email" maxlength="150" class="form-control bg-gray" name="kullanici_mail">
                                        </div>
                                    </div>
                                   
                                    <div class="col-md-12">
                                        <div class="mb-3">
                                            <label>Mesajınız:</label>
                                            <textarea id="text" class="form-control bg-gray" name="mail_icerik" maxlength="4000" rows="8"></textarea>
                                        </div>
                                    </div>

                                    <div style="margin-bottom: 15px;" class="col-12 col-12 m-0 pl-md-2">
                            <span class="form-alert"></span>
                        </div>

                        <input type="hidden" name="disableFill" value="">

                                    <div style="margin-top: 12px;" class="col-md-12">
                                        <button class="btn btn-primary mailgonderbuton" type="submit">Gönder</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-lg-5 col-md-5">
                        <h3 style="font-weight: 200;font-family: arial;" class="down-line mb-5">İletişim Bilgileri</h3>
                        
                        <div class="d-flex mb-3">
                            <ul>
                                <li class="mb-3">
                                    <strong>Adres :</strong><br> <?php echo $genelayarcek['ayar_adres']; ?>
                                </li>
                                <li class="mb-3">
                                    <strong>Telefon Numarası :</strong> <a style="color: #707070;" href="tel:<?php echo $genelayarcek['ayar_telno']; ?>"><?php echo $genelayarcek['ayar_telno']; ?></a>
                                </li>
                                <li class="mb-3">
                                    <strong>E-Posta Adresi :</strong><br> <a style="color: #707070;" href="mailto:<?php echo $genelayarcek['ayar_mail']; ?>"><?php echo $genelayarcek['ayar_mail']; ?></a>
                                </li>
                            </ul>
                        </div>
                       
                    </div>
                </div>
            </div>
        </div>
        <!--==================== Contact Section End ====================-->

       <?php require_once 'footer.php'; ?>


        <script type="text/javascript">





            
        
        $('#mailgonderform').submit(function(){

                var adsoyad = $.trim($('#name').val());
                var email = $.trim($('#email').val());
                var mesaj = $.trim($('#text').val());

               

                $('.mailgonderbuton').prop('disabled',true);

                if (adsoyad.length<2) {

    
    $('.form-alert').html('<i class="fa fa-info-circle"></i> Lütfen ad soyad kısmını doldurun.');
    $('.form-alert').css('color','#990308');
    $('.mailgonderbuton').prop('disabled',false);

              } else if (email.length<6) {

     
    $('.form-alert').html('<i class="fa fa-info-circle"></i> Lütfen mail adresinizi doğru girin.');
    $('.form-alert').css('color','#990308');
    $('.mailgonderbuton').prop('disabled',false);

              } else if (mesaj.length<6){

                
    $('.form-alert').html('<i class="fa fa-info-circle"></i> Lütfen mesaj kısmını biraz daha doldurun.');
    $('.form-alert').css('color','#990308');
    $('.mailgonderbuton').prop('disabled',false);

                 } else {

 $('.form-alert').hide();
 $('.mailgonderbuton').html('Gönderiliyor...');
 
 var data = $("#mailgonderform").serializeArray();
data.push({name: "kullanicimailgonder",value: "ok"});



$.ajax({
            type : 'POST',
            url : 'musteriislem.php',
            data : $.param(data),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

             

              if (sonuc=="ok") {

                $('input,textarea').val('');
                
                $('.mailgonderbuton').prop('disabled',false);
                $('.mailgonderbuton').html('Gönder');
                $('.form-alert').show();
                $('.form-alert').css('color','green');
                $('.form-alert').html('<i class="fa fa-check"></i> Mesajınız başarıyla gönderildi. Teşekkür ederiz.');
                


                



              } else if (sonuc=='hata') {

                $('.mailgonderbuton').prop('disabled',false);
                $('.mailgonderbuton').html('Gönder');
                $('.form-alert').show();
                $('.form-alert').css('color','#990308');
                $('.form-alert').html('<i class="fa fa-info-circle"></i> Bir şeyler ters gitti. Lütfen tekrar deneyin.');
                


                


              }
                

              

                 }

                

              })

  }

  })

</script>