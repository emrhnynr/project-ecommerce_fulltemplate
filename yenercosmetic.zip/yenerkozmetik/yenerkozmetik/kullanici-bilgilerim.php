
<?php require_once 'header.php';

if (empty($_SESSION['kullanicioturum'])) {
    
    header("location:index");
}
 ?>

  <title>Kullanıcı Bilgilerim | Yener Saat</title>


        

        <!--==================== Registration Form Start ====================-->
        <div style="padding-top: 0px;" class="full-row">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="woocommerce">
                            <div class="row">
                                <div class="col-lg-6 col-md-8 col-12 mx-auto">
                                    <div class="registration-form">
                                        <h3 style="font-family: arial;font-weight: 200;">Kullanıcı Bilgilerim</h3>
                                       
                                        <hr>
                                        <form id="registerform" onsubmit="return false;">

                                           <p>
                                                <label for="reg_email">E-Posta Adresiniz&nbsp;<span class="required">*</span></label>
                                                <input type="email" value="<?php echo $kullanicioturumcek['kullanici_mail']; ?>" maxlength="100" class="form-control" name="kullanici_mail" id="kullanici_mail" />
                                            </p>


                                            <p>
                                                <label for="reg_email">Adınız&nbsp;<span class="required">*</span></label>
                                                <input type="text" value="<?php echo $kullanicioturumcek['kullanici_ad']; ?>" maxlength="100" class="form-control" name="kullanici_ad" id="kullanici_ad" />
                                            </p>

                                            <p>
                                                <label for="reg_email">Soyadınız&nbsp;<span class="required">*</span></label>
                                                <input type="text" maxlength="100" value="<?php echo $kullanicioturumcek['kullanici_soyad']; ?>" class="form-control" name="kullanici_soyad" id="kullanici_soyad" />
                                            </p>

                                            <input type="hidden" name="disableFill" value="">

                                           
                                            

                                          

                                            <div style="display: none;" class="alert alert-warning uyari"><i class="fa fa-info-circle"></i></div>

                                            <div style="display: none;" class="alert alert-success uyari2"></div>

                                            
                                            <p>
                                                <button type="submit" class="btn btn-primary rounded-0 submitbuton" name="kulguncelleT">Güncelle</button>
                                            </p>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--==================== Registration Form Start ====================-->

       <?php require_once 'footer.php'; ?>

       <script type="text/javascript">
            
            $('#registerform').submit(function(){

 var kullanici_ad = $.trim($('#kullanici_ad').val());
 var kullanici_soyad = $.trim($('#kullanici_soyad').val());
 var kullanici_mail = $.trim($('#kullanici_mail').val());


 if (kullanici_ad.length<2) {

$('.uyari').show();
$('.uyari').html('<i class="fa fa-info-circle"></i> Lütfen adınızı doğru girin.');

 } else if (kullanici_soyad.length<2) {

$('.uyari').show();
$('.uyari').html('<i class="fa fa-info-circle"></i> Lütfen soyadınızı doğru girin.');

 } else if (kullanici_mail.length<2) {

$('.uyari').show();
$('.uyari').html('<i class="fa fa-info-circle"></i> Lütfen mail adresinizi kontrol edin.');

 } else {

     $('.submitbuton').prop('disabled',true);
     $('.uyari').hide();
     $('.submitbuton').html('Güncelleniyor...');

     var data = $("#registerform").serializeArray();
       data.push({name: "uyeguncelle",value: "ok"});

 $.ajax({
            type : 'POST',
            url : 'musteriislem.php',
            data : $.param(data),
            success : function(sonuc){

              sonuc = $.trim(sonuc);


         if (sonuc!='bot') {
           

              if (sonuc=="mevcutmail") {

                 $('.submitbuton').prop('disabled',false);

                $('.uyari').show();
$('.uyari').html('<i class="fa fa-info-circle"></i> Bu mail adresi zaten mevcut.');
$('.submitbuton').html('Güncelle');

               } else {

              
               $('.uyari').hide();
               $('.uyari2').show();
             $('.uyari2').html('<i class="fas fa-check"></i> Kullanıcı bilgileriniz başarıyla güncellendi.');
               $('.submitbuton').prop('disabled',false);
               $('.submitbuton').html('Güncelle');
               

               } 
              
              }

              }
        })

 }

        })

        </script>