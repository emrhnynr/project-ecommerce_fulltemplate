<?php require_once 'header.php'; ?>
        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              

             
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Anasayfa Kutular</h2>

                    <ul class="nav navbar-right panel_toolbox">
                      <a class="btn btn-success"  href="anasayfa-kutu-ekle">Yeni Kutu Ekle +</a>
                      
                     
                      
                    </ul>


                    
                    <div class="clearfix"></div>
                    
                  </div>
                  <div class="x_content">

                    <div class="row">

                      <?php $kutusec=$db->prepare("SELECT * from anasayfakutular order by kutu_sira ASC");
                      $kutusec->execute();
                      $kutusay=$kutusec->rowCount();

                      if ($kutusay==0) { ?>
                       <h4 align="center">Henüz kutu ögesi eklenmemiş.</h4>
                     <?php }

                      while ($kutucek=$kutusec->fetch(PDO::FETCH_ASSOC)) { 

                        $kutu_id = $kutucek['kutu_id']; 
                        $kutu_sira = $kutucek['kutu_sira']; 

                        ?>

                        <div class="col-md-55 kutu_<?php echo $kutu_id; ?>">
                        <div class="thumbnail">
                          <div class="image view view-first">
                            <img style="width: 100%; display: block;" src="../../<?php echo $kutucek['kutu_foto']; ?>" alt="kutu" />
                            <div class="mask no-caption">
                              <div class="tools tools-bottom">
                                
                                <a href="anasayfa-kutu-duzenle?kutu_id=<?php echo $kutu_id; ?>"><i class="fa fa-pencil"></i></a>
                                <a class="kutusil" name="kutu_<?php echo $kutu_id; ?>" href="javascript:void(0);"><i class="fa fa-times"></i></a>
                              </div>
                            </div>
                          </div>
                          <div class="caption">
                            <p><strong>Kutu <?php echo $kutu_sira; ?></strong>
                            </p>
                            
                          </div>
                        </div>
                      </div>
                         
                       <?php } ?>

                     

                     
                      
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <?php require_once 'footer.php'; ?>
        <script type="text/javascript">
          
          $('.kutusil').click(function(){

             var id1=$(this).attr("name");
                var kutu_id=id1.substring(5);

                swal({
  title: "Bu kutuyu silmek istiyor musunuz?",
  icon: "warning",
  buttons: ["Vazgeç", "Sil"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

   

    $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'kutuogesil':'ok','kutu_id':kutu_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              

              if (sonuc=="ok") {

                $('.kutu_'+kutu_id).remove();
              }

              

               }

             });

     }

     })



          })

        </script>