<?php require_once 'header.php'; ?>

<title>Favori Ürünlerim | Yener Saat</title>

<input id="sepeturunsayhidden" value="<?php echo $sepeturunsayheader; ?>" type="hidden" name="">

        <!-- breadcrumb -->
        <div class="full-row bg-light py-5">
            <div class="container">
                <div class="row text-secondary">
                    <div class="col-sm-6">
                        <h3 style="font-family: arial;font-weight: 200;" class="mb-2 text-secondary">Favori Ürünlerim (<span id="favorisaybaslik"><?php echo $favorilersay; ?></span>)</h3>
                    </div>
                    <div class="col-sm-6">
                        <nav aria-label="breadcrumb" class="d-flex justify-content-sm-end align-items-center h-100">
                            <ol class="breadcrumb mb-0 d-inline-flex bg-transparent p-0">
                                <li class="breadcrumb-item"><a href="../"><i class="fas fa-home me-1"></i>Anasayfa</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Favoriler</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <!-- breadcrumb -->

        <!--==================== Wishlist Section Start ====================-->
        <div style="padding-top: 10px;" class="full-row">
            <div class="container">
                <div class="row">
                    <div class="col-12">

                        <?php if (empty($_SESSION['kullanicioturum'])) { ?>

                            <h5 style="font-family: Arial;" align="center">Favorilere ürün ekleyebilmek için <a href="uye-ol"><u>üye olmalı</u></a> veya <a href="giris-yap"><u>giris yapmalısınız.</u></a></h5>
                           

                        <?php } else if ($favorilersay==0){ ?>

                            <h5 style="font-family: Arial;" align="center">Favorilere henüz ürün eklememişsiniz. <a href="../"><u>Alışverişe devam et</u></a></h5>


                        <?php } else { ?>


<form id="yith-wcwl-form" class="table-responsive-lg">
                            <table class="shop_table cart wishlist_table wishlist_view traditional table" data-pagination="no" data-per-page="5" data-page="1" data-id="3989" data-token="G5CZRAZPRKEY">
                                <thead>
                                    <tr>
                                        <th class="product-remove"> <span class="nobr"> </span></th>
                                        <th class="product-thumbnail"></th>
                                        <th class="product-name"> <span class="nobr"> Ürün </span></th>
                                        <th class="product-price"> <span class="nobr"> Fiyat </span></th>
                                        
                                        <th class="product-add-to-cart"> <span class="nobr"> </span></th>
                                    </tr>
                                </thead>
                                <tbody class="wishlist-items-wrapper">

                                    <?php while($favorilercek=$favorilersec->fetch(PDO::FETCH_ASSOC)){ 

        $urunsec=$db->prepare("SELECT * from urunler where urun_id=:id");
        $urunsec->execute(array(
            "id" => $favorilercek['urun_id']
        ));

        $uruncek=$urunsec->fetch(PDO::FETCH_ASSOC);
        
        $urun_marka = $uruncek['marka_id'];
        $urun_ad = $uruncek['urun_ad'];
        $urun_id = $uruncek['urun_id'];

        $urunseceneklersec=$db->prepare("SELECT * from urunsecenekler where urun_id=:id");
        $urunseceneklersec->execute(array(
        "id" => $urun_id
        ));

        $urunseceneklersay=$urunseceneklersec->rowCount();

        $urunfotosec=$db->prepare("SELECT * from urunfoto where urun_id=:id and urunfoto_kapak=:kapak");
        $urunfotosec->execute(array(
            "kapak" => 1,
            "id" => $urun_id
        ));

        $urunfotocek=$urunfotosec->fetch(PDO::FETCH_ASSOC);

        $markasec=$db->prepare("SELECT * from markalar where marka_id='$urun_marka'");
                        $markasec->execute();
                        $markacek=$markasec->fetch(PDO::FETCH_ASSOC);
                        $marka_ad=$markacek['marka_ad'];
                                        ?>

                                    <tr class="favori_<?php echo $favorilercek['favori_id']; ?>" id="yith-wcwl-row-103" data-row-id="103">
                                        <td class="product-remove">
                                            <div>
                                                <a href="javascript:void(0);" name="favori_<?php echo $favorilercek['favori_id']; ?>" class="remove remove_from_wishlist" title="Favorilerden Kaldır">×</a>
                                            </div>
                                        </td>
                                        <td class="product-thumbnail">
                                            <a target="_blank" href="urun-<?php echo seo($urun_ad)."-".$urun_id; ?>"> <img src="<?php echo $urunfotocek['urunfoto_yol']; ?>" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt=""> </a>
                                        </td>
                                        <td class="product-name"> 
                                            <a style="font-weight: 600;"><?php echo $marka_ad; ?></a><br>
                                            <a target="_blank" href="urun-<?php echo seo($urun_ad)."-".$urun_id; ?>"><?php echo $urun_ad; ?></a></td>
                                        <td class="product-price"> 

                                            <?php if ($uruncek['urun_indirim']==1) { ?>


                                            <del><span class="woocommerce-Price-amount amount"><bdi><?php echo $uruncek['urun_indirimsizfiyat']." TL"; ?></bdi></span></del> <ins><span class="woocommerce-Price-amount amount"><bdi><?php echo $uruncek['urun_fiyat']." TL"; ?></bdi></span></ins>

                                        <?php } else { ?>

                                            <span class="woocommerce-Price-amount amount"><bdi><?php echo $uruncek['urun_indirimsizfiyat']." TL"; ?></bdi>
                                            </span>


                                        <?php } ?>
                                        </td>
                                       
                                        <td class="product-add-to-cart">

                                            <?php if ($urunseceneklersay==0 and $uruncek['urun_stok']>0) { ?>

                                            <a href="javascript:void(0);" data-quantity="1" class="button add_to_cart_button ajax_add_to_cart add_to_cart alt sepeteeklebuton" name="urun_<?php echo $urun_id;?>">Sepete Ekle</a>

                                            <?php } ?>
                                            
                                        </td>
                                    </tr>
                                    
                                    <?php } ?>
                                </tbody>
                            </table>
                        </form>

                            <?php } ?>
                        
                    </div>
                </div>
            </div>
        </div>
        <!--==================== Wishlist Section End ====================-->

        <?php require_once 'footer.php'; ?>

        <script type="text/javascript">

             $('.sepeteeklebuton').click(function(){

            
         var id1=$(this).attr("name");
         var urun_id=id1.substring(5);

         var buton = $(this);
             

              

               

                    $('.sepeteeklebuton').prop('disabled',true);

$.ajax({
            type : 'POST',
            url : 'musteriislem.php',
            data : {'sepeteuruneklefavori':'ok','urun_id':urun_id},
            success : function(sonuc){

              sonuc = $.trim(sonuc);

              if (sonuc!='gecersizistek') {


                  buton.html('Ekleniyor...');

                    buton.replaceWith('<a style="background-color:green;color:white;" href="javascript:void(0);" class="button add_to_cart_button ajax_add_to_cart add_to_cart alt" aria-label="Add “Navy Blue-Silver-White Multifunction Analog Watch” to your cart" rel="nofollow"><i class="fas fa-check"></i> Sepete Eklendi</a>');


                    $('.cart-popup').html(sonuc);
                    var sepeturunsayheader = $('#sepeturunsayhidden').val();
                    $('.sepetitemsayisi').html(parseInt(sepeturunsayheader)+1);
                    $('#sepeturunsayhidden').val(parseInt(sepeturunsayheader)+1);


                

         }
            
              
              }
        })



                


        });
            
            $('.favorisil').click(function(){


  var buton = $(this);
  var id1=$(this).attr("name");
    var favori_id=id1.substring(7);
    var favorisayisi = $('.wishlist-items-wrapper tr').length;
    var favorisayisiyeni = favorisayisi-1;


    
    $.ajax({

   type : 'POST',
            url : 'musteriislem.php',
            data : {'favorisil2':'ok','favori_id':favori_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              if (sonuc=="ok") {

$('.favori_'+favori_id).remove();
$('#favorisaybaslik').html(favorisayisiyeni);
$('.favorikaldirildi').show();
                
                


              }



               }

             });

    if (favorisayisiyeni==0) {

$('.table-responsive-lg').replaceWith('<h5 style="font-family: Arial;" align="center">Favorilere henüz ürün eklememişsiniz. <a href="../"><u>Alışverişe devam et</u></a></h5>');

    }



               });

        </script>