<?php require_once 'header.php';

$sorusec=$db->prepare("SELECT * from sss order by soru_sira ASC");
$sorusec->execute();
$sorusay = $sorusec->rowCount();

$genelayarsec=$db->prepare("SELECT * from genelayarlar");
$genelayarsec->execute();

 $genelayarcek=$genelayarsec->fetch(PDO::FETCH_ASSOC);


  ?>



        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              

              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Sık Sorulan Sorular</h2>

                    
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <div style="margin-bottom:50px;" align="right" class="col-md-12 col-sm-12 col-xs-12">
                        <a class="btn btn-success" data-toggle='modal' href="#yenisoru">+ Yeni Soru</a>
                      </div>
                    <br />

                    <div class="modal fade" id="yenisoru"> 
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

      

        <div style="padding: 50px;" class="modal-body">

          <h3>Yeni Soru Ekle<hr></h3>

          <form action="../../adminislem.php" method="POST" id="soruekleform" enctype="multipart/form-data">
         <div class="row">

          <div style="margin-top:20px;" class="col-md-12 col-xs-12 col-sm-12">
            <label>Sıra*</label>
             <input class="form-control" required="" min="1" maxlength="300" type="number" name="soru_sira">
           </div>



          
           
           <div style="margin-top:20px;" class="col-md-12 col-xs-12 col-sm-12">
            <label>Soru Başlık*</label>
             <input class="form-control" required="" maxlength="300" type="text" name="soru_baslik">
           </div>



           

            <div style="margin-top:20px;" class="col-md-12 col-xs-12 col-sm-12">
            <label>Metin*</label>
             <textarea class="form-control" required="" rows="6" name="soru_aciklama"></textarea>
           </div>

          

           


          

          

         


        
           

         </div>

        </div>

     
       
    <div class="modal-footer">


  
    
    <button class="btn btn-success" name="soruekle" type="submit">Ekle</button>

     </form>
    <button class="btn btn-danger" data-dismiss="modal">Kapat</button>

    
</div>





  

     
    </div>

  </div>

</div>


<form id="sssbaslikduzenleform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

                      <h3 align="center">SSS Başlık</h3><hr>


                     
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Başlık

                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="ayar_title" value="<?php echo $genelayarcek['ayar_sssbaslik']; ?>" name="ayar_sssbaslik" maxlength="300"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                    

                     

                      

                     

                

                      <input type="hidden" name="sssbaslikduzenleadmin">


                      
                      
                      <div class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">

                          
                          
                          <button type="submit" class="btn btn-success sssbaslikduzenlebuton">Düzenle</button>
                        </div>
                      </div>

                    </form>

                 

                 

                    <h3 align="center">SSS<hr></h3>

                    <?php if ($sorusay==0) { ?>
                     

                     <h4 align="center">Henüz SSS ögesi eklenmemiş. <a data-toggle='modal' href="#yenisoru" style="text-decoration: underline;">Hemen Ekle +</a></h4>


                   <?php } else { ?>

                    <form id="sssform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">


                     
                      <?php 

                      while ($sorucek=$sorusec->fetch(PDO::FETCH_ASSOC)) { ?>
                        <div class="soru_<?php echo $sorucek['soru_id']; ?> sorularr">
                         <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Soru Başlık* 
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="soru_baslik_<?php echo $sorucek['soru_id']; ?>" value="<?php echo $sorucek['soru_baslik']; ?>" name="soru_baslik_<?php echo $sorucek['soru_id']; ?>" maxlength="300"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Sıra* 
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="number" min='0' id="soru_sira" value="<?php echo $sorucek['soru_sira']; ?>" name="soru_sira_<?php echo $sorucek['soru_id']; ?>"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Metin* 
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <textarea class="form-control" rows="7" name="soru_aciklama_<?php echo $sorucek['soru_id']; ?>" maxlength="1000" id="soru_aciklama"><?php echo $sorucek['soru_aciklama']; ?></textarea>
                          
                        </div>
                      </div>

                      <div align="right" class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <a class="btn btn-danger sorukaldir" name="soru_<?php echo $sorucek['soru_id']; ?>" href="javascript:void(0);"><i class="fa fa-trash-o"></i> Kaldır</a>
                          
                        </div>
                      </div>

                      <hr>
                      </div>
                      <?php } ?>

                      

          

                      <input type="hidden" name="sssduzenle">


                      
                        
                        <div class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                          <div style="display: none;" class="alert alert-warning uyarisss"></div>
                          
                          <button type="submit" class="btn btn-success sssbuton">Düzenle</button>
                        </div>
                      </div>

                     
                      
                      
                      

                    </form>


                   <?php } ?>

                   

                   
                  </div>
                </div>
              </div>
            </div>

            <?php require_once 'footer.php'; ?>
            <script type="text/javascript">


      $('#sssbaslikduzenleform').submit(function(){

             
              


              $('.sssbaslikduzenlebuton').prop('disabled',true);


               

                $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : $('#sssbaslikduzenleform').serialize(),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

              if (sonuc=="ok") {

               
                $('.sssbaslikduzenlebuton').prop('disabled',false);


                swal({

  title: "Başarılı",
  text: "SSS Başlığı Güncellendi!",
  icon: "success",
  button: "OK",
});



              }
                

              }


            })
              

               });
              
              
             

              $('.sorukaldir').click(function(){

var id1=$(this).attr("name");
                var soru_id=id1.substring(5);


                swal({
  title: "Bu soruyu kaldırmak istiyor musunuz?",
  icon: "warning",
  buttons: ["Vazgeç", "Kaldır"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

    $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'sorukaldir':'ok','soru_id':soru_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              if (sonuc=="ok") {

                $('.soru_'+soru_id).remove();
              }


              var sorusay = $('.sorularr').length;


              if (sorusay==0) {

                $('.sssbuton').remove();
              }
               }

             });

     }

     })

              });

              $('#sssform').submit(function(){

 


                
         
       
        
      var form = $('#sssform')[0];
             var data = new FormData(form);

            

       
       
$('.sssbuton').prop('disabled',true);
$('.sssbuton').html('Düzenleniyor...');

  $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
             enctype : 'multipart/form-data',
            data : data,
            processData: false,
            contentType: false,
            cache: false,
            success : function(sonuc){

              sonuc = $.trim(sonuc);

             if (sonuc=="ok") {

$('.sssbuton').prop('disabled',false);
$('.sssbuton').html('Düzenle');

              swal({

  title: "Başarılı",
  text: "Düzenleme işlemi başarılı!",
  icon: "success",
  button: "OK",
});

             }

             
              }
        })

      



              });


             
             

            </script>

            