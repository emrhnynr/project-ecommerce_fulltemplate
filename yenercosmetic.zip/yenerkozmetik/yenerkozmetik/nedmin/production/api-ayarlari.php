<?php require_once 'header.php';

$genelayarsec=$db->prepare("SELECT * from genelayarlar");
$genelayarsec->execute();

 $genelayarcek=$genelayarsec->fetch(PDO::FETCH_ASSOC);

 $googlemaps_api = $genelayarcek['googlemaps_api'];
 $googleanalytics_api = $genelayarcek['googleanalytics_api'];

  ?>



        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              

              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>API Ayarları</h2>

                    
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />

                  

                    

                    <form id="googlemapsform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

                      <h3 align="center">Google Maps API</h3> <hr>


                     
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">API

                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <textarea rows="10" id="googlemaps_api" name="googlemaps_api" class="form-control col-md-10 col-xs-12"><?php echo $genelayarcek['googlemaps_api']; ?></textarea>
                        </div>
                      </div>

                    

                     

                      

                     

                

                      <input type="hidden" name="googlemapsduzenle">


                      
                      
                      <div class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">

                          <div style="display: none;" class="alert alert-warning uyarigooglemaps"></div>
                          
                          <button type="submit" class="btn btn-success googlemapsbuton">Düzenle</button>
                        </div>
                      </div>

                    </form>

                    <form id="googleanalyticsform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

                      <h3 align="center">Google Analytics API</h3> <hr>


                     
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">API

                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <textarea rows="10" id="googleanalytics_api" name="googleanalytics_api" class="form-control col-md-10 col-xs-12"><?php echo $genelayarcek['googleanalytics_api']; ?></textarea>
                        </div>
                      </div>

                    

                     

                      

                     

                

                      <input type="hidden" name="googleanalyticsduzenle">


                      
                      
                      <div class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">

                          <div style="display: none;" class="alert alert-warning uyarigoogleanalytics"></div>
                          
                          <button type="submit" class="btn btn-success googleanalyticsbuton">Düzenle</button>
                        </div>
                      </div>

                    </form>

                    
                  </div>
                </div>
              </div>
            </div>

            <?php require_once 'footer.php'; ?>



            <script type="text/javascript">




             $('#googlemapsform').submit(function(){

              var googlemaps_api = $.trim($('#googlemaps_api').val());
              


              $('.googlemapsbuton').prop('disabled',true);

              

                

                $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : $('#googlemapsform').serialize(),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

              if (sonuc=="ok") {

               
                $('.googlemapsbuton').prop('disabled',false);


                swal({

  title: "Başarılı",
  text: "Google Maps API düzenlendi!",
  icon: "success",
  button: "OK",
});



              }
                

              }


            })
              

               });

              $('#googleanalyticsform').submit(function(){

              var googlemaps_api = $.trim($('#googlemaps_api').val());
              


              $('.googleanalyticsbuton').prop('disabled',true);

              

                

                $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : $('#googleanalyticsform').serialize(),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

              if (sonuc=="ok") {

               
                $('.googleanalyticsbuton').prop('disabled',false);


                swal({

  title: "Başarılı",
  text: "Google Analytics API düzenlendi!",
  icon: "success",
  button: "OK",
});



              }
                

              }


            })
              

               });

            



            </script>

              
             