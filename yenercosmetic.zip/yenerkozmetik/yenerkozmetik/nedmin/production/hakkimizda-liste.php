<?php require_once 'header.php';

$ikonlistesec=$db->prepare("SELECT * from ikonliste order by ikonliste_sira ASC");
$ikonlistesec->execute();
$ikonlistesay=$ikonlistesec->rowCount();

  ?>



        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              

              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Hakkımızda İkon Listesi</h2>

                    <ul class="nav navbar-right panel_toolbox">
                     
                      <a class="btn btn-success" data-toggle='modal' href="#ikonekle">İkon Ekle +</a>
                    </ul>

                    <div class="modal fade" id="ikonekle"> 
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

      

        <div style="padding: 50px;" class="modal-body">

          <h3>Yeni İkon Ekle<hr></h3>

          <form action="../../adminislem.php" method="POST" id="ikonekleform">
         <div class="row">


         <div style="margin-top:20px;" class="col-md-12 col-xs-12 col-sm-12">
            <label>Sıra*</label>
             <input class="form-control" required="" min="1" type="number" name="ikonliste_sira">
           </div>
          
           
           <div style="margin-top:20px;" class="col-md-12 col-xs-12 col-sm-12">
            <label>İkon</label>
            <select class="form-control" name="ikon_templatead">
              
              <?php $templateikonsec = $db->prepare("SELECT * from templateikonlar order by ikon_ad ASC");
              $templateikonsec->execute();

              while ($templateikoncek=$templateikonsec->fetch(PDO::FETCH_ASSOC)) { ?>
                 
                 <option value="<?php echo $templateikoncek['ikon_templatead']; ?>"><?php echo $templateikoncek['ikon_ad']; ?></option>

               <?php } ?>

            </select>
           </div>


           <div style="margin-top:20px;" class="col-md-12 col-xs-12 col-sm-12">
            <label>Başlık</label>

            <input class="form-control" maxlength="300" type="text" name="ikonliste_baslik">

           </div>


           <div style="margin-top:20px;" class="col-md-12 col-xs-12 col-sm-12">
            <label>Açıklama</label>

            <textarea class="form-control" maxlength="500" rows="4" name="ikonliste_aciklama"></textarea>

           </div>



           

          

           


          

          

         


        
           

         </div>

        </div>

     
       
    <div class="modal-footer">


  
    
    <button class="btn btn-success" name="ikonlisteekle" type="submit">Ekle</button>

     </form>
    <button class="btn btn-danger" data-dismiss="modal">Kapat</button>

    
</div>





  

     
    </div>

  </div>

</div>

                   
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />


                    <?php if ($ikonlistesay==0) { ?>
                      
                      <h4 align="center">Herhangi bir ikon ögesi eklenmemiş.</h4>

                    <?php } else { ?>

                      <form id="hakkimizdalistform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

                      <h3 align="center">Liste</h3>
                      
                      <hr>

                      <?php  while ($ikonlistecek=$ikonlistesec->fetch(PDO::FETCH_ASSOC)) { ?>
                        
                     <div id="ikonliste_<?php echo $ikonlistecek['ikonliste_id'] ?>" class='ikonlarr'>


                     
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Sıra
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="ikonliste_sira" value="<?php echo $ikonlistecek['ikonliste_sira']; ?>" name="ikonliste_sira_<?php echo $ikonlistecek['ikonliste_id']; ?>" class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">İkon
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                           <select class="form-control" name="ikon_templatead_<?php echo $ikonlistecek['ikonliste_id']; ?>">
              
              <?php $templateikonsec = $db->prepare("SELECT * from templateikonlar order by ikon_ad ASC");
              $templateikonsec->execute();

              while ($templateikoncek=$templateikonsec->fetch(PDO::FETCH_ASSOC)) { ?>
                 
                 <option <?php if ($templateikoncek['ikon_templatead']==$ikonlistecek['ikon_templatead']) { ?>
                   selected=''
                <?php } ?> value="<?php echo $templateikoncek['ikon_templatead']; ?>"><?php echo $templateikoncek['ikon_ad']; ?></option>

               <?php } ?>

            </select>
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Başlık 
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input class="form-control" type="text" maxlength="300" id="ikonliste_baslik" name="ikonliste_baslik_<?php echo $ikonlistecek['ikonliste_id']; ?>" value="<?php echo $ikonlistecek['ikonliste_baslik']; ?>">
                         

                          
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Açıklama 
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <textarea id="ikonliste_aciklama" rows="5" name="ikonliste_aciklama_<?php echo $ikonlistecek['ikonliste_id']; ?>" maxlength="500" class="form-control"><?php echo $ikonlistecek['ikonliste_aciklama']; ?></textarea>

                          
                        </div>
                      </div>

                       <div align="right" class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <a class="btn btn-danger ikonkaldir" name="ikonliste_<?php echo $ikonlistecek['ikonliste_id']; ?>" href="javascript:void(0);"><i class="fa fa-trash-o"></i> Kaldır</a>
                          
                        </div>
                      </div>

                      </div>



                       

                      <br>


                       <?php } ?>

                      

                      

                     

                

                      <input type="hidden" name="hakkimizdalistguncelle">


                      
                      
                      <div class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">

                     
                          
                          <button type="submit" class="btn btn-success hakkimizdalistbuton">Düzenle</button>
                        </div>
                      </div>

                    </form>


                    <?php } ?>

                  

                    

                   
                  </div>
                </div>
              </div>
            </div>

            <?php require_once 'footer.php'; ?>



            <script type="text/javascript">

              

            $('#hakkimizdalistform').submit(function(){

             


              $('.hakkimizdalistbuton').prop('disabled',true);

              

                

                $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : $('#hakkimizdalistform').serialize(),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

             if (sonuc=="ok") {

              $('.hakkimizdalistbuton').prop('disabled',false);


                swal({

  title: "Başarılı",
  text: "Hakkımızda liste düzenlendi!",
  icon: "success",
  button: "OK",
});

             }



              }


            })

                 

                  

                 

                 });


            $('.ikonkaldir').click(function(){

var id1=$(this).attr("name");
                var ikonliste_id=id1.substring(10);




                swal({
  title: "Bu ögeyi kaldırmak istiyor musunuz?",
  icon: "warning",
  buttons: ["Vazgeç", "Kaldır"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

    $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'ikonlistekaldir':'ok','ikonliste_id':ikonliste_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              if (sonuc=="ok") {

                $('#ikonliste_'+ikonliste_id).remove();
              }

              var ikonsay = $('.ikonlarr').length;


              if (ikonsay==0) {

                $('.hakkimizdalistbuton').remove();
              }

              
               }

             });

     }

     })

              });

           

             


            </script>

              
             