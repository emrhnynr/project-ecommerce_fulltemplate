<?php require_once 'header.php';


$marka_seourl = $_GET['sef'];

$markasec=$db->prepare("SELECT * from markalar where marka_seourl='$marka_seourl'");
$markasec->execute();



$markasay=$markasec->rowCount();

if ($markasay==0) {
    
    header("Location:/");
    exit;
}

$markacek=$markasec->fetch(PDO::FETCH_ASSOC);

$marka_ad = $markacek['marka_ad'];
$marka_id = $markacek['marka_id'];

$filtrebasliksor=$db->prepare("SELECT * from filtrebasliklar");
$filtrebasliksor->execute();
$getkontrol=0;
while ($filtrebaslikcekk=$filtrebasliksor->fetch(PDO::FETCH_ASSOC)) {
$filtrebaslik_seo = $filtrebaslikcekk['filtrebaslik_seo'];

if (isset($_GET[$filtrebaslik_seo])) {
  $getkontrol=$getkontrol+1;
  break;
}

}

if ($getkontrol>0 or isset($_GET['price'])) {

  
  $query = "SELECT * from urunler where urun_kaldirildi='0' and marka_id='$marka_id'";


  $selectfilter = $db->prepare("SELECT * from filtrebasliklar");
  $selectfilter->execute();
  while($fetchfilter = $selectfilter->fetch(PDO::FETCH_ASSOC)){

 $filtrebaslik_seo = $fetchfilter['filtrebaslik_seo'];
 $urun_data = $fetchfilter['urun_data'];

 if (isset($_GET[$filtrebaslik_seo])) {

  $getfiltre = $_GET[$filtrebaslik_seo];

  if ($filtrebaslik_seo=='cinsiyet') {

    if (count($getfiltre)==3) {
  
   $query .= " AND ".$urun_data." IN ('e','k','c','u') ";




} else if (count($getfiltre)==2){



  

if (in_array('e', $getfiltre) and in_array('k', $getfiltre)) {
  
$query .= " AND ".$urun_data." IN ('e','k','u') ";

} else if (in_array('c', $getfiltre) and in_array('k', $getfiltre)){

$query .= " AND ".$urun_data." IN ('k','c','u') ";

} else if (in_array('e', $getfiltre) and in_array('c', $getfiltre)){

$query .= " AND ".$urun_data." IN ('e','c','u') ";

}

} else if (count($getfiltre)==1){


  

if (in_array('e', $getfiltre)) {
 
  
$query .= " AND ".$urun_data." IN ('e','u') ";

} else if (in_array('k', $getfiltre)){


$query .= " AND ".$urun_data." IN ('k','u') ";

} else if (in_array('c', $getfiltre)){

 
$query .= " AND ".$urun_data." IN ('c') ";

}

}

     } else {


$filtrebaslik = implode("','", $_GET[$filtrebaslik_seo]);
  $query .= " AND ".$urun_data." IN ('".$filtrebaslik."') ";


     }
  
  

 }

  }

  switch ($_GET['price']) {

    case '1':
     
     $query .= " AND urun_nihaifiyat BETWEEN '".$_GET['min-price']."' and '".$_GET['max-price']."' ";

      break;


      case '2':
     
     $query .= " AND urun_nihaifiyat >= '".$_GET['min-price']."' ";

      break;


      case '3':
     
     $query .= " AND urun_nihaifiyat <= '".$_GET['max-price']."' ";

      break;
    

  }

  $uruntestsec = $db->prepare($query);
  $uruntestsec->execute();


  

} else {

  $uruntestsec = $db->prepare("SELECT * from urunler where urun_kaldirildi='0' and marka_id='$marka_id'");
  $uruntestsec->execute();

}


 $uruntestsay=$uruntestsec->rowCount();
         
         
         
        


                  $sayfa=@$_GET['s'];
    if (empty($_GET['s'])) {
      $sayfa=1;
    };

$kacar=30;
$sayfasayisi=ceil($uruntestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;

 if ($uruntestsay!=0 and ($sayfa>$sayfasayisi or $sayfa<1)) {
     
     header("Location:/");
 }

  ?>

  <head>

 <meta name="description" content="<?php echo $markacek['marka_description']; ?>">

</head>

<title><?php echo $marka_ad." Ürünleri"; ?> | Yener Kozmetik</title>

        <!-- breadcrumb -->
        <div class="full-row py-5">
            <div class="container">
                <div class="row text-left">
                    <div class="col-12">
                        <h3 style="font-weight: 200;font-family: arial;" class="mb-2"><?php echo $marka_ad." Ürünleri"; ?></h3>
                    </div>
                    <div class="col-12">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb mb-0 d-inline-flex bg-transparent p-0">
                                <li class="breadcrumb-item"><a href="../">Anasayfa</a></li>
                                <li class="breadcrumb-item"><a href="markalar">Markalar</a></li>
                                <li class="breadcrumb-item active" aria-current="page"><?php echo $marka_ad; ?></li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <!-- breadcrumb -->

        <div class="full-row pt-0">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3">
                        <form id="filtreleform" action="" method="GET">

                            <button type="submit" style="width: 100%;margin-bottom: 25px;" class="btn btn-block btn-primary filtrelebuton"><i class="fas fa-filter"></i> Filtrele</button>

                        <div id="sidebar" class="widget-title-bordered-full">




                            
                            <div id="bigbazar-price-filter-list-1" class="widget bigbazar_widget_price_filter_list widget_layered_nav">
                                <h2 style="font-family: arial;font-size: 19px;" class="widget-title">Sıralama Ölçütü</h2>
                               
                               <select style="border:1px solid #e7e7e7;" class="form-control" name="sortby">
                      
                      
                        
                        <option <?php if (empty($_GET['sortby']) or $_GET['sortby']=='timedesc') { ?>
                          selected=''
                      <?php } ?> value="timedesc">Varsayılan</option>

                    
                      <option <?php if ($_GET['sortby']=='priceasc') { ?>
                        selected=''
                      <?php } ?> value="priceasc">Fiyat (Artan Sırada)</option>

                      <option <?php if ($_GET['sortby']=='pricedesc') { ?>
                        selected=''
                      <?php } ?> value="pricedesc">Fiyat (Azalan Sırada)</option>

                      <option <?php if ($_GET['sortby']=='sale') { ?>
                        selected=''
                      <?php } ?> value="sale">Önce İndirimliler</option>

                    </select>

                            </div>


                            <div id="bigbazar-price-filter-list-1" class="widget bigbazar_widget_price_filter_list widget_layered_nav">
                                <h2 style="font-family: arial;font-size: 19px;" class="widget-title">Fiyat Aralığı</h2>
                               
                               <input min="0" max="99999" style="border: 1px solid rgba(112,112,112,0.3);" type="number" value="<?php echo $_GET['min-price']; ?>" placeholder="Min TL" class="form-control priceinputs minpriceinput" name="min-price">
                                    <input min="0" max='99999' style="border: 1px solid rgba(112,112,112,0.3);margin-top:10px;" type="number" value="<?php echo $_GET['max-price']; ?>" placeholder="Max TL" class="form-control priceinputs maxpriceinput" name="max-price">
                                    <input type="hidden" value="" class="pricestatus" name="price">

                            </div>

                            <?php $markafiltresec = $db->prepare("SELECT * from markafiltreler order by filtrebaslik_sira ASC");

                            $markafiltresec->execute();

                            if ($markafiltresec->rowCount()>0) {
                                
                            

                            while ($markafiltrecek=$markafiltresec->fetch(PDO::FETCH_ASSOC)) { 

                                $filtrebaslik_id=$markafiltrecek['filtrebaslik_id'];

                                $filtrebasliksec = $db->prepare("SELECT * from filtrebasliklar where filtrebaslik_id='$filtrebaslik_id'");
                                $filtrebasliksec->execute();
                                $filtrebaslikcek = $filtrebasliksec->fetch(PDO::FETCH_ASSOC);

                                $filtrebaslik_ad = $filtrebaslikcek['filtrebaslik_ad'];
                                $filtrebaslik_id = $filtrebaslikcek['filtrebaslik_id'];
                                $filtrebaslik_seo = $filtrebaslikcek['filtrebaslik_seo']; ?>


                            <div id="bigbazar-price-filter-list-1" class="widget bigbazar_widget_price_filter_list widget_layered_nav">
                                <h2 style="font-family: arial;font-size: 19px;" class="widget-title"><?php echo $filtrebaslik_ad; ?></h2>
                               
                               <?php $filtresec=$db->prepare("SELECT * from filtreler where filtrebaslik_id='$filtrebaslik_id' order by filtre_sira ASC");
                                    $filtresec->execute();

                                    while($filtrecek=$filtresec->fetch(PDO::FETCH_ASSOC)){ 

                                        $filtre_ad = $filtrecek['filtre_ad'];
                                        $filtre_value = $filtrecek['filtre_value'];

                                        $checked = [];
                                        if (isset($_GET[$filtrebaslik_seo])) {
                                            
                                            $checked = $_GET[$filtrebaslik_seo];
                                        };

                                        if ($filtre_value!='u' or $filtrebaslik_seo!='cinsiyet') { ?>


                                            <label><input <?php if (in_array($filtre_value, $checked)) { ?>
                                            checked=''
                                        <?php } ?> type="checkbox" value="<?php echo $filtre_value; ?>" name="<?php echo $filtrebaslik_seo; ?>[]"> <?php echo $filtre_ad; ?></label><br>

                                        <?php } } ?>

                            </div>

                        <?php } } ?>
                            
                        </div>
                    </form>
                    </div>
                    <div class="col-lg-9">
                        <div class="products-header d-flex justify-content-between align-items-center py-10 px-20 bg-light md-mt-30">
                            <div class="products-header-left d-flex align-items-center">
                                <h6 style="font-size: 16px;font-family: arial;" class="woocommerce-products-header__title page-title">Tüm Ürünler</h6>
                                <div class="woocommerce-result-count"> ( <?php echo $uruntestsay." Ürün"; ?> ) <?php if ($getkontrol>0 or isset($_GET['price'])) { ?>
                                  <a href="markalar-<?php echo seo($marka_ad); ?>" style="color: #AD0B06;">Filtreleri Temizle</a>
                                <?php } ?> </div>
                            </div>
                            <div class="products-header-right"></div>
                        </div>
                        <div class="showing-products pt-30 pb-50 border-2 border-bottom border-light">
                            <div class="row row-cols-xxl-3 row-cols-md-2 row-cols-1 product-style-3 product-list e-hover-image-zoom after-border-two gy-3 gx-0">

                                <?php 

                                $sort = $_GET['sortby'];

                                if (!empty($sort)) {
                                  
                                  switch ($sort) {

                                  case 'timedesc':
                                    
                                 $orderby = " order by urun_zaman DESC ";

                                    break;

                                    case 'priceasc':
                                    
                                 $orderby = " order by urun_nihaifiyat ASC ";

                                    break;

                                    case 'pricedesc':
                                    
                                 $orderby = " order by urun_nihaifiyat DESC ";

                                    break;

                                    case 'sale':
                                    
                                 $orderby = " order by urun_indirim DESC,urun_zaman DESC ";

                                    break;
                                  
                                  
                                }

                                } else {

                                  $orderby = " order by urun_zaman DESC ";

                                }

                                

                                if ($getkontrol>0 or isset($_GET['price'])) {

  
  $query = "SELECT * from urunler where urun_kaldirildi='0' and marka_id='$marka_id'";


  $selectfilter = $db->prepare("SELECT * from filtrebasliklar");
  $selectfilter->execute();
  while($fetchfilter = $selectfilter->fetch(PDO::FETCH_ASSOC)){

 $filtrebaslik_seo = $fetchfilter['filtrebaslik_seo'];
 $urun_data = $fetchfilter['urun_data'];

 if (isset($_GET[$filtrebaslik_seo])) {

  $getfiltre = $_GET[$filtrebaslik_seo];

  if ($filtrebaslik_seo=='cinsiyet') {

    if (count($getfiltre)==3) {
  
   $query .= " AND ".$urun_data." IN ('e','k','c','u') ";




} else if (count($getfiltre)==2){



  

if (in_array('e', $getfiltre) and in_array('k', $getfiltre)) {
  
$query .= " AND ".$urun_data." IN ('e','k','u') ";

} else if (in_array('c', $getfiltre) and in_array('k', $getfiltre)){

$query .= " AND ".$urun_data." IN ('k','c','u') ";

} else if (in_array('e', $getfiltre) and in_array('c', $getfiltre)){

$query .= " AND ".$urun_data." IN ('e','c','u') ";

}

} else if (count($getfiltre)==1){


  

if (in_array('e', $getfiltre)) {
 
  
$query .= " AND ".$urun_data." IN ('e','u') ";

} else if (in_array('k', $getfiltre)){


$query .= " AND ".$urun_data." IN ('k','u') ";

} else if (in_array('c', $getfiltre)){

 
$query .= " AND ".$urun_data." IN ('c') ";

}

}

   } else {

$filtrebaslik = implode("','", $_GET[$filtrebaslik_seo]);
  $query .= " AND ".$urun_data." IN ('".$filtrebaslik."') ";

   }
  
  

 }

  }

  switch ($_GET['price']) {

    case '1':
     
     $query .= " AND urun_nihaifiyat BETWEEN '".$_GET['min-price']."' and '".$_GET['max-price']."' ";

      break;


      case '2':
     
     $query .= " AND urun_nihaifiyat >= '".$_GET['min-price']."' ";

      break;


      case '3':
     
     $query .= " AND urun_nihaifiyat <= '".$_GET['max-price']."' ";

      break;
    

  }

  $query .= " $orderby limit $baslangic,$kacar ";



  $markaurunsec = $db->prepare($query);
  $markaurunsec->execute();


  

} else {

   $markaurunsec=$db->prepare("SELECT * from urunler where urun_kaldirildi='0' and marka_id='$marka_id' $orderby limit $baslangic,$kacar");
   $markaurunsec->execute();

}



                               

                        while ($markauruncek=$markaurunsec->fetch(PDO::FETCH_ASSOC)) {

                        $urun_id = $markauruncek['urun_id'];

                  $urunsec = $db->prepare("SELECT * from urunler where urun_id='$urun_id'");
                  $urunsec->execute();

                  $uruncek=$urunsec->fetch(PDO::FETCH_ASSOC);

                  $urun_id = $uruncek['urun_id'];

                  $urun_marka = $uruncek['marka_id'];

                  $urunseceneklersec=$db->prepare("SELECT * from urunsecenekler where urun_id=:id");
                                           $urunseceneklersec->execute(array(
                                            "id" => $urun_id
                                          ));

                                           $urunseceneklersay=$urunseceneklersec->rowCount();



                  $urunfotosec=$db->prepare("SELECT * from urunfoto where urun_id=:id and urunfoto_kapak=:kapak");
                        $urunfotosec->execute(array(

                          "kapak" => 1,
                           "id" => $urun_id

                         ));

                        $urunfotocek=$urunfotosec->fetch(PDO::FETCH_ASSOC);

                        $urunkapakfoto = $urunfotocek['urunfoto_yol'];

                        $markasec=$db->prepare("SELECT * from markalar where marka_id='$urun_marka'");
                        $markasec->execute();
                        $markacek=$markasec->fetch(PDO::FETCH_ASSOC);
                        $marka_ad=$markacek['marka_ad'];

                          ?>
                                
                                <div class="col">
                                    <div class="product type-product">
                                        <div class="product-wrapper">
                                            <div class="product-image">
                                                <a href="urun-<?php echo seo($uruncek['urun_ad'])."-".$urun_id; ?>" class="woocommerce-LoopProduct-link"><img src="<?php echo $urunkapakfoto; ?>" alt="<?php echo $uruncek['urun_ad']; ?>"></a>
                                                
                                                <?php if ($uruncek['urun_indirim']==1) {

                                                $indirim_miktari = $uruncek['urun_indirimsizfiyat']-$uruncek['urun_fiyat'];
                                                $indirim_yuzdesi = round(($indirim_miktari*100)/$uruncek['urun_indirimsizfiyat']);

                                                    ?>
                                                
                                                <div class="product-labels">
                                                    <div <?php if ($indirim_yuzdesi<40) { ?>

                                                        style='background-color:#F3612E;'

                                                    <?php } else { ?>

                                                        style='background-color:#D4102E;'


                                                    <?php } ?> class="badge1">

                                                        <span> - %<?php echo $indirim_yuzdesi;?> </span>

                                                    </div>
                                                </div>

                                            <?php } ?>

                                            </div>
                                            <div class="product-info">
                                                <div><a style="font-weight: 600;"><?php echo $marka_ad; ?></a></div>
                                                <h3 class="product-title"><a style="font-family: arial;font-size: 17px;font-weight: 200;" href="urun-<?php echo seo($uruncek['urun_ad'])."-".$urun_id; ?>"><?php echo $uruncek['urun_ad']; ?></a></h3>
                                                <div class="product-price">
                                                    <div class="price">

                                                        <?php if ($uruncek['urun_indirim']==1) { ?>

                                                            <ins <?php if ($indirim_yuzdesi<40) { ?>

                                                        style='color:#F3612E;'

                                                    <?php } else { ?>

                                                        style='color:#D4102E;'


                                                    <?php } ?>><b><?php echo $uruncek['urun_fiyat']; ?> TL</b></ins>

                                                    <del style="font-size: 16px;"><?php echo $uruncek['urun_indirimsizfiyat']; ?> TL</del>

                                                        <?php } else { ?>

                                                            <ins style="color: black;"><b><?php echo $uruncek['urun_indirimsizfiyat']; ?> TL</b></ins>


                                                        <?php } ?>
                                                        
                                                    </div>
                                                </div>
                                                
                                                <div class="shipping-feed-back">
                                                    <div class="star-rating"></div>
                                                    <div class="sold-items">
                                                        <span></span> <span></span>
                                                    </div>
                                                </div>
                                                <div class="hover-area">
                                                    <div class="cart-button">
                                                        <?php if ($urunseceneklersay==0 and $uruncek['urun_stok']>0) { ?>
                                                        <a href="javascript:void(0);" class="button add_to_cart_button sepeteeklebuton" name="urun_<?php echo $urun_id;?>">Hemen Al</a>
                                                    <?php } ?>
                                                    </div>
                                                    <div class="wishlist-button wishlist_<?php echo $urun_id; ?>">

                                                        <?php if (isset($_SESSION['kullanicioturum'])) { 

                                                             $favorikontrolsec=$db->prepare("SELECT * from favoriler where kullanici_id=:kulid and urun_id=:urunid");
                                                    $favorikontrolsec->execute(array(
                                                        "kulid" => $_SESSION['kullanici_id'],
                                                       "urunid" => $urun_id
                                                           ));

                                                    $favorikontrolsay=$favorikontrolsec->rowCount(); ?>

                                                    <?php if ($favorikontrolsay>0) { ?>



                                                 <a style="color: green;" class="add_to_wishlist favoridencikar favoricikarbuton" href="javascript:void(0);" title="Favorilerden Çıkar" name="urun_<?php echo $urun_id; ?>">Favoriler</a>


                                                    <?php } else { ?>


                                                   <a class="add_to_wishlist favorieklebuton" href="javascript:void(0);" title="Favorilere Ekle" name="urun_<?php echo $urun_id; ?>">Favoriler</a>



                                                <?php } } else { ?>

                                      <a class="add_to_wishlist" href="favoriler" target="_blank" title="Favorilere Ekle">Favoriler</a>


                                                <?php } ?>
                                                        
                                                    </div>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            <?php } ?>

                            </div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center pt-3">
                            <div class="showing-result"></div>

                            
                            
                            <?php if ($uruntestsay>$kacar) { 

                                 $key = 's';
    $current_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

   $filteredURL = preg_replace('~(\?|&)'.$key.'=[^&]*~', '$1', $current_url);

   ?>


                            <div class="pagination-style-one">
                                <nav aria-label="Page navigation example">
                                    <ul class="pagination">

                                        <?php $p=0; if ($sayfa!=1) { ?>


                                        <li class="page-item">
                                            <a <?php if ($getkontrol>0 or isset($_GET['price']) or isset($_GET['sortby'])) {?>


                                               href="<?php echo $filteredURL; ?>s=<?php echo $sayfa-1; ?>"

                                               <?php } else { ?>

                                                href="markalar-<?php echo $marka_seourl;?>?s=<?php echo $sayfa-1; ?>"


                                               <?php } ?> class="page-link" aria-label="Previous">
                                                <span aria-hidden="true">&laquo;</span>
                                            </a>
                                        </li>

                                    <?php } ?>

                                    <?php while ($p<$sayfasayisi) { $p++;

                                    if ($p<=$sayfa+3 and $p>=$sayfa-3) {

                                     ?>


                                        <li class="page-item <?php if($p==$sayfa){ ?>

                                        active

                                   <?php } ?>"><a 

                                    <?php if($p==$sayfa){ ?> 

                                    style='color:white;' <?php  } ?>

                                    <?php if ($getkontrol>0 or isset($_GET['price']) or isset($_GET['sortby'])){
                                      
                                      if (empty($_GET['s'])) { ?>

                                   href="<?php echo $filteredURL; ?>&s=<?php echo $p; ?>"
                                        
                                      <?php } else { ?>


                                    href="<?php echo $filteredURL; ?>s=<?php echo $p; ?>"



                                   <?php } } else { ?>

                                      href="markalar-<?php echo $marka_seourl;?>?s=<?php echo $p; ?>"


                                   <?php } ?>

                                     class="page-link"><?php echo $p; ?></a></li>


                                        <?php } } if ($sayfa!=$sayfasayisi) { ?>


                                        <li class="page-item">
                                            <a <?php if ($getkontrol>0 or isset($_GET['price']) or isset($_GET['sortby'])) {

                                              if (empty($_GET['s'])) { ?>
                                               
                                           href="<?php echo $filteredURL; ?>&s=<?php echo $sayfa+1; ?>"

                                              <?php } else { ?>


                                           href="<?php echo $filteredURL; ?>s=<?php echo $sayfa+1; ?>"



                                            <?php } } else { ?>


                                              href="markalar-<?php echo $marka_seourl;?>?s=<?php echo $sayfa+1; ?>"


                                            <?php } ?> class="page-link" aria-label="Next">
                                                <span aria-hidden="true">&raquo;</span>
                                            </a>
                                        </li>

                                    <?php } ?>

                                    </ul>
                                </nav>
                            </div>

                        <?php } ?>
                        </div>


                        
                    </div>
                </div>
            </div>
        </div>

        <?php require_once 'footer.php'; ?>

        <script type="text/javascript">
            
            $('.priceinputs').keypress(function(key){

if(key.charCode < 48 || key.charCode > 57){

return false;

}

       });

       $('#filtreleform').submit(function(){

        $('.filtrelebuton').attr('disabled',true);

        var minprice = $('.minpriceinput').val().length;
        var maxprice = $('.maxpriceinput').val().length;

        if (minprice==0 && maxprice==0) {

 $('.pricestatus').removeAttr('name');

        } else if (minprice==0){

$('.pricestatus').val('3');

        } else if (maxprice==0){

$('.pricestatus').val('2');

        } else {

          $('.pricestatus').val('1');

        };

        //Farklı bir işlem

   if (minprice==0) {

$('.minpriceinput').removeAttr('name');

   }

   if (maxprice==0) {

$('.maxpriceinput').removeAttr('name');

   }

       });


           
           $('.sepeteeklebuton').click(function(){

            
var id1=$(this).attr("name");
         var urun_id=id1.substring(5);
             

              

               

                    $('.sepeteeklebuton').prop('disabled',true);

$.ajax({
            type : 'POST',
            url : 'musteriislem.php',
            data : {'hemensepeteekle':'ok','urun_id':urun_id},
            success : function(sonuc){

              sonuc = $.trim(sonuc);


        

     
            window.location = 'sepetim';
                


            
              
              }
        })



                


        });


           $('.favorieklebuton').click(function(){

                

var buton = $(this);


var id1=$(this).attr("name");
var urun_id=id1.substring(5);

buton.prop('disabled',true);

$.ajax({
            type : 'POST',
            url : 'musteriislem.php',
            data : {'favorilereekle':'ok','urun_id':urun_id},
            success : function(sonuc){

              sonuc = $.trim(sonuc);

           
              


          

         if (sonuc=="ok") {

          

          $('.wishlist_'+urun_id).replaceWith('<span style="color:green;font-size:15px;margin-top:8px;"><i class="far fa-heart"></i> Favorilere Eklendi</span>');



        



         }

                

                  

               

                

                



                


            
              
              }
        })


                



              

                  


        });


           $('.favoricikarbuton').click(function(){

                

var buton = $(this);


var id1=$(this).attr("name");
var urun_id=id1.substring(5);


              

                    buton.prop('disabled',true);

$.ajax({
            type : 'POST',
            url : 'musteriislem.php',
            data : {'favorilerdencikar':'ok','urun_id':urun_id},
            success : function(sonuc){

              sonuc = $.trim(sonuc);

           
              


          

         if (sonuc=="ok") {

          

          $('.wishlist_'+urun_id).replaceWith('<span style="color:green;font-size:15px;margin-top:8px;"><i class="fas fa-ban"></i> Favorilerden Çıkarıldı</span>');



        



         }

                

                  

               

                

                



                


            
              
              }
        })


                



        });


        </script>