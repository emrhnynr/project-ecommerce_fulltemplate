<?php require_once 'header.php'; 

$hazirla=$db->prepare("UPDATE siparisitem set

iade_goruldu=:iade_goruldu

where iade_goruldu='0' and urun_iade!='0'

");

$derle=$hazirla->execute(array(
"iade_goruldu" => 1
));

?>

<style type="text/css">
   

   @media screen and (max-width: 768px) {
    #sort {
        margin-top: 15px;
    }
}

 </style>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
           

            <div class="clearfix"></div>

            <div class="row">
             

              <div class="clearfix"></div>

              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>İadeler</h2>

                    

                    

                    <div  class="col-xs-12 col-sm-3 col-md-3 nav navbar-right panel_toolbox">
                       <select id="sort" name="sort" class="form-control">
                        
                        <option selected="" value="yenideneskiye">İade Tarihi (Yeniden Eskiye)</option>
                        <option value="eskidenyeniye">İade Tarihi (Eskiden Yeniye)</option>
                        
                        
                      </select>
                    </div>

                    <div  class="col-xs-12 col-sm-3 col-md-3 nav navbar-right panel_toolbox">
                       <select id="siralamaolcutu" name="siralamaolcutu" class="form-control">
                       
                        <option selected="" value="cevapbekleyen">Cevap Bekleyenler</option>
                        <option value="iadekabul">İade Edilenler</option>
                        <option value="iadered">İadesi Reddedilenler</option>
                        
                      </select>
                    </div>
                   
                    
                    <div class="clearfix"></div>


                  </div>

                  <div class="x_content">

                    
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->


      </div>
    </div>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="../vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- Sweet Alert -->

    <script type="text/javascript" src="../../sweetalert.min.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
  </body>
</html>

 <script type="text/javascript">
         
         $('#siralamaolcutu,#sort').change(function(){

 var siralamaolcutu = $('#siralamaolcutu').val();
 var sort = $('#sort').val();

 $('.x_content').html('<h3 align="center">Yükleniyor...</h3>');

 $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : {'iadelersiralamaolcutudegistir':'ok','siralamaolcutu':siralamaolcutu,'sort':sort},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              $('.x_content').html(sonuc);

               }

              });



      }).change();

         

       </script>