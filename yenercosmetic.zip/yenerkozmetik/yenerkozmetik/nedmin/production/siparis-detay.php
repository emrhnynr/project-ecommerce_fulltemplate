<?php require_once 'header.php';

$siparis_id=$_GET['siparis_id'];

$siparissec=$db->prepare("SELECT * from siparisler where siparis_id=:id");
$siparissec->execute(array(
"id" => $siparis_id
));

$sipariscek=$siparissec->fetch(PDO::FETCH_ASSOC);
$siparis_ulasmis = $sipariscek['siparis_ulasmis'];

$siparissay=$siparissec->rowCount();

if ($siparissay==0) {
  
  header("Location:index");
  exit;
}

$siparis_zaman = $sipariscek['siparis_zaman'];
                 $d = new DateTime($siparis_zaman);
                 $zamanson =  $d->format('d/m/Y H:i');


                $siparisitemsec=$db->prepare("SELECT * from siparisitem where siparis_id=:id order by urun_fiyat DESC");
                $siparisitemsec->execute(array(
           "id" => $siparis_id
                ));

                $siparisitemsay=$siparisitemsec->rowCount();

                $kullanici_id = $sipariscek['kullanici_id'];

               $kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_id=:id");
               $kullanicisec->execute(array(
                "id" => $kullanici_id

              ));

               $kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);


                
 ?>

 <style type="text/css">
   

   @media screen and (max-width: 768px) {
    .guncellebutonx {
        margin-top: 15px;
    }
}

 </style>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
           

            <div class="clearfix"></div>

            <div class="row">
             

              <div class="clearfix"></div>

              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Sipariş Detayları</h2>



                    <div class="col-xs-12 col-sm-5 col-md-5 nav navbar-right panel_toolbox guncellebutonx">


                      <button  class="btn btn-block btn-success siparisdurumguncelle">Güncelle</button>
                      
                    </div>

                    <div class="col-xs-12 col-sm-5 col-md-5 nav navbar-right panel_toolbox">
                        <select id="siparisdurumu" name="siparisdurumu" class="form-control">
                        
                        <option disabled="">Sipariş Durumu:</option>
                        <option <?php if ($siparis_ulasmis=='0') { ?>
                          selected=''
                        <?php } ?> value="0">Hazırlanıyor</option>
                        <option <?php if ($siparis_ulasmis=='2') { ?>
                          selected=''
                        <?php } ?> value="2">Kargoya Verildi</option>
                        <option <?php if ($siparis_ulasmis=='1') { ?>
                          selected=''
                        <?php } ?> value="1">Teslim Edildi</option>
                        
                      </select>
                    </div>
                    
                    <div class="clearfix"></div>
                  </div>

                  <div class="x_content">

                     <div class="row">

                      <div style="margin-top:10px;" class="col-md-6 col-xs-12 col-sm-12">
            <label>Sipariş No.</label>
             <input class="form-control siparisid" value="<?php echo $siparis_id; ?>" readonly="" type="text" >
           </div>
           
           <div style="margin-top:10px;" class="col-md-6 col-xs-12 col-sm-12">
            <label>Sipariş Veren</label>
             <input class="form-control" value="<?php echo $kullanicicek['kullanici_ad']." ".$kullanicicek['kullanici_soyad']; ?>" readonly="" type="text" name="">
           </div>

          

           <div style="margin-top:10px;" class="col-md-6 col-xs-12 col-sm-12">
            <label>Sipariş Tarihi</label>
             <input class="form-control" value="<?php echo $zamanson; ?>" readonly="" type="text" name="">
           </div>

           <div style="margin-top:10px;" class="col-md-6 col-xs-12 col-sm-12">
            <label>Ürün Sayısı</label>
             <input class="form-control" value="<?php echo $siparisitemsay; ?>" readonly="" type="text" name="">
           </div>

           <div style="margin-top:10px;" class="col-md-6 col-xs-12 col-sm-12">
            <label>E-Posta Adresi</label>
             <input class="form-control" value="<?php echo $sipariscek['siparis_mail']; ?>" readonly="" type="text" name="kullanici_mail">
           </div>

            <div style="margin-top:10px;" class="col-md-6 col-xs-12 col-sm-12">
            <label>Telefon Numarası</label>
             <input class="form-control" value="<?php echo $sipariscek['siparis_telno']; ?>" readonly="" type="text" name="">
           </div>

            <div style="margin-top:10px;" class="col-md-6 col-xs-12 col-sm-12">
            <label>Ara Toplam</label>
             <input class="form-control" value="₺ <?php echo $sipariscek['siparis_aratoplam']; ?>" readonly="" type="text" name="">
           </div>

           <div style="margin-top:10px;" class="col-md-6 col-xs-12 col-sm-12">
            <label>Kargo Ücreti</label>
             <input class="form-control" value="₺ <?php echo $sipariscek['siparis_kargoucreti']; ?>" readonly="" type="text" name="">
           </div>

           <div style="margin-top:10px;" class="col-md-6 col-xs-12 col-sm-12">
            <label>Taksit</label>
             <input class="form-control" value="<?php if($sipariscek['siparis_taksit']=='1'){

           echo "Tek Çekim";

             } else {

        echo $sipariscek['siparis_taksit']; 

             } ?>" readonly="" type="text" name="">
           </div>

           <div style="margin-top:10px;" class="col-md-6 col-xs-12 col-sm-12">
            <label>Vade Farkı</label>
             <input class="form-control" value="₺ <?php echo $sipariscek['siparis_vadefarki']; ?>" readonly="" type="text" name="">
           </div>

           

            <div style="margin-top:10px;" class="col-md-6 col-xs-12 col-sm-12">
            <label>Toplam</label>
             <input class="form-control" value="₺ <?php echo $sipariscek['siparis_toplam']; ?>" readonly="" type="text" name="">
           </div>

            <div style="margin-top:10px;" class="col-md-6 col-xs-12 col-sm-12">
            <label>Şehir</label>
             <input class="form-control" value="<?php echo $sipariscek['siparis_sehir']; ?>" readonly="" type="text" name="">
           </div>

            <div style="margin-top:10px;" class="col-md-6 col-xs-12 col-sm-12">
            <label>İlçe</label>
             <input class="form-control" value="<?php echo $sipariscek['siparis_ilce']; ?>" readonly="" type="text" name="">
           </div>

            <div style="margin-top:10px;" class="col-md-12 col-xs-12 col-sm-12">
            <label>Teslimat Adresi</label>
             <textarea rows="6" readonly="" class="form-control"><?php echo $sipariscek['siparis_adres']; ?></textarea>
           </div>

            <?php if (!empty($sipariscek['siparis_not'])) { ?>
             
          <div style="margin-top:10px;" class="col-md-12 col-xs-12 col-sm-12">
            <label>Sipariş Notu</label>
             <textarea rows="6" readonly="" class="form-control"><?php echo $sipariscek['siparis_not']; ?></textarea>
           </div>

            <?php } ?>

           



          

       


         </div>

         <hr>

         <h3>Ürünler</h3>

        <?php 

$siparislerimsec=$db->prepare("SELECT * from siparisler where kullanici_id=:id order by siparis_zaman DESC");
$siparislerimsec->execute(array(
"id" => $kullanici_id
));

$siparislerimsay=$siparislerimsec->rowCount(); ?>



        

        <div class="table-responsive">
                      <table class="table table-striped jambo_table bulk_action">
                        <thead>
                          <tr class="headings">
                           
                            <th>Ürün No.</th>
              <th>Ürün</th>
              
              <th>Adet</th>
              <th>Birim Fiyat</th>
              <th>Toplam</th>



                            

                            
                            
                          </tr>
                        </thead>

                        <tbody>
                          


            <?php while ($siparisitemcek=$siparisitemsec->fetch(PDO::FETCH_ASSOC)) { 


              $siparisitem_id = $siparisitemcek['siparisitem_id']; 

               $siparisitemseceneksec = $db->prepare("SELECT * from siparisitemsecenekler where siparisitem_id='$siparisitem_id'");

                          $siparisitemseceneksec->execute();


      $urunsec=$db->prepare("SELECT * from urunler where urun_id=:id");
            $urunsec->execute(array(

              "id" => $siparisitemcek['urun_id']
            ));

            $uruncek = $urunsec->fetch(PDO::FETCH_ASSOC);

            $urun_id = $siparisitemcek['urun_id'];

            $urun_fiyat = $siparisitemcek['urun_fiyat'];

            $urun_toplamfiyat = $siparisitemcek['urun_toplam'];

            

            $urun_ad=$uruncek['urun_ad'];
              ?>
              
              <tr>
              <td><?php echo $urun_id; ?></td>
              <td><a target="_blank" href='../../urun-<?php echo seo($urun_ad)."-".$uruncek['urun_id']; ?>'><?php if (strlen($urun_ad)>85) { ?>
              <?php echo substr($urun_ad,0,85)."..."; ?>
            <?php } else { 

                         echo $urun_ad; 
             } ?></a><br>

           <?php while ($siparisitemsecenekcek=$siparisitemseceneksec->fetch(PDO::FETCH_ASSOC)) { 
                $secenek_ad = $siparisitemsecenekcek['secenek_ad'];
                $altsecenek_ad = $siparisitemsecenekcek['altsecenek_ad']; ?> 


                <?php echo $secenek_ad." : ".$altsecenek_ad."<br>"; ?>
                            

              <?php } ?>

            </td>
              
              <td><?php echo $siparisitemcek['urun_miktar']; ?></td>
              <td>₺ <?php echo $urun_fiyat; ?></td>
              <td>₺ <?php echo $urun_toplamfiyat; ?></td>
            </tr>

            <?php } ?>
            
            
            
          

                        </tbody>
                      </table>
                    </div>

                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->


      </div>
    </div>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="../vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- Sweet Alert -->

    <script type="text/javascript" src="../../sweetalert.min.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
  </body>
</html>

 <script type="text/javascript">

   $('.siparisdurumguncelle').click(function(){

var siparis_id = $('.siparisid').val();
var siparisdurumu = $('#siparisdurumu').val();


$('.siparisdurumguncelle').prop('disabled',true);
    $('.siparisdurumguncelle').html('Güncelleniyor...');

    $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'siparisdurumguncelle':'ok','siparisdurumu':siparisdurumu,'siparis_id':siparis_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              if (sonuc=="ok") {

                swal({
  title: "Başarılı",
  text: "Sipariş durumu başarıyla güncellendi!",
  icon: "success"

});

                $('.siparisdurumguncelle').prop('disabled',false);
    $('.siparisdurumguncelle').html('Güncelle');

              }

               }

             });



   });
         
        

          

  </script>