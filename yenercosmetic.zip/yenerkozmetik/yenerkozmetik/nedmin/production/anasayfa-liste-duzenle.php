<?php require_once 'header.php'; 

$liste_id = $_GET['liste_id'];

$listesec=$db->prepare("SELECT * from anasayfaurunliste where anasayfaurunliste_id=:id");
$listesec->execute(array(
"id" => $liste_id
));

$listesay=$listesec->rowCount();

if ($listesay==0) {
  
  header("Location:index");
  exit;
}

$listecek=$listesec->fetch(PDO::FETCH_ASSOC);

$liste_baslik = $listecek['liste_baslik'];
$liste_sira = $listecek['liste_sira'];
$liste_turu = $listecek['liste_turu'];




?>


        

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Anasayfa > <?php echo $liste_baslik; ?></h3>
              </div>

              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                 
                  <div class="x_content">
                    <br />
                   <form id="anasayfalisteduzenleform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

                      
                       

                       <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Liste Başlık
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input  type="text" maxlength="300" id="liste_baslik" name="liste_baslik"  value="<?php echo $liste_baslik; ?>"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Liste Türü <span class="required">*</span>
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <select id="liste_turu" name="liste_turu" class="form-control">
                            
                            
                            <option <?php if ($liste_turu=='liste') { ?>
                              selected=''
                          <?php } ?> value="liste">Normal Liste</option>
                            
                            <option <?php if ($liste_turu=='slayt') { ?>
                              selected=''
                          <?php } ?> value="slayt">Tek Sıra Slayt</option>

                          </select>
                        </div>
                      </div>

                     
                     

                      

                     <input type="hidden" value="<?php echo $liste_id; ?>" name="liste_id">

                      

                     

                

                      <input type="hidden" name="anasayfalisteduzenle">
                      


                      
                      
                      <div class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">

                          <div style="display: none;" class="alert alert-warning uyari"></div>
                          
                          <button type="submit" class="btn btn-success listeduzenlebuton">Düzenle</button>
                        </div>
                      </div>

                    </form>

                    <h3 align="center">Ürünler <a class="btn btn-success" href="#listeurunekle">Ekle +</a><hr></h3>

                    <table id="datatable" class="table table-striped table-bordered">
                      <thead>
                        <tr>
                         
                          <th>Ürün Ad</th>
                          <th>Sıra</th>

                         
                         
                          <th></th>
                          
                          
                          
                         
                        </tr>
                      </thead>


                      <tbody>

        <?php $anasayfalisteurunsec=$db->prepare("SELECT * from anasayfalisteurun where urun_kaldirildi=:kaldirildi and anasayfaurunliste_id=:id order by urun_sira ASC");
            $anasayfalisteurunsec->execute(array(

              
              "kaldirildi" => 0,
              "id" => $liste_id
            ));

            while ($anasayfalisteuruncek=$anasayfalisteurunsec->fetch(PDO::FETCH_ASSOC)) {

           
            $urun_id = $anasayfalisteuruncek['urun_id'];

            $urunsec = $db->prepare("SELECT * from urunler where urun_id='$urun_id'");
            $urunsec->execute();

            $uruncek=$urunsec->fetch(PDO::FETCH_ASSOC);

            $urun_id = $uruncek['urun_id'];

            $urun_ad = $uruncek['urun_ad'];

            $urun_sira = $anasayfalisteuruncek['urun_sira'];



            ?>

        <tr class="listeurun_<?php echo $anasayfalisteuruncek['anasayfalisteurun_id']; ?>">
                          
                          <td><a target="_blank" href="../../urun-<?php echo seo($urun_ad)."-".$urun_id; ?>"><?php echo $urun_ad; ?></a></td>
                          <td><div class="col-md-8"><input id="listeurun_<?php echo $anasayfalisteuruncek['anasayfalisteurun_id']; ?>" class="form-control" type="number" min="1" step="any" value="<?php echo $urun_sira; ?>" name=""></div><div class="col-md-4"><a href="javascript:void(0);" class="btn btn-success btn-block siraguncelle" name="listeurun_<?php echo $anasayfalisteuruncek['anasayfalisteurun_id']; ?>">Güncelle</a></div></td>

                          


                      
                          
                          <td align="right"><a class="btn btn-danger btn-sm listeurunsil" href="javascript:void(0);"  name="listeurun_<?php echo $anasayfalisteuruncek['anasayfalisteurun_id']; ?>">Sil</a></td>
                        
                          
                          
                        </tr>
          
        <?php } ?>

                        
                        
                        
                      </tbody>
                    </table>

                    <h3 id="listeurunekle" style="margin-top:100px;" align="center">Listeye Ürün Ekle<hr></h3>

                    <form id="listeurunekleform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">


                      <h4 align="center">Ürün no. larına <a target="_blank" href='urun-ayarlari'>buradan</a> ulaşabilirsiniz.</h4>



                      <div style="margin-bottom:40px;" class="urunno">

                       
                      
                       

                       <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Ürün No. <span class="required">*</span>
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input  type="text" maxlength="30"  name="urun_id[]"  placeholder="Ürün no. sunu yazın"  class="form-control col-md-10 col-xs-12 inputt">
                        </div>
                      </div>

                     
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Sıra <span class="required">*</span>
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="number" placeholder="Ürünün bu listede kaçıncı sırada listeleneceğini girin"  name="urun_sira[]" step='any'  class="form-control col-md-10 col-xs-12 inputt">
                        </div>
                      </div>

                      

                    </div>


                      <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name"></span>
                        </label>
                        <a href="javascript:void(0);" class="dahafazlaurun"><div align="center" class="form-group">
                        <div style="margin-bottom: 80px;border:1px solid #d7d7d7;" class="col-md-7 col-sm-7 col-xs-12">
                          <h3>Daha Fazla Ürün +</h3>
                        </div></a>

                      

                     <input type="hidden" value="<?php echo $liste_id; ?>" name="liste_id">

                      

                     

                

                      <input type="hidden" name="listeurunekle">
                      


                      
                      
                      <div style="margin-top:30px;" class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">

                          <div style="display: none;" class="alert alert-warning uyariurunekle"></div>
                          
                          <button type="submit" class="btn btn-success listeuruneklebuton">Ekle</button>
                        </div>
                      </div>

                    </form>
                  </div>
                </div>
              </div>
            </div>

            <?php require_once 'footer.php'; ?>
            <script type="text/javascript">
              
              $('#anasayfalisteduzenleform').submit(function(){
          
         
        
    
      var form = $('#anasayfalisteduzenleform')[0];
             var data = new FormData(form);

               

       
       $('.uyari').hide();
$('.listeduzenlebuton').prop('disabled',true);
$('.listeduzenlebuton').html('Düzenleniyor...');

$.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : $('#anasayfalisteduzenleform').serialize(),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

              if (sonuc=="ok") {

                swal({

  title: "Başarılı",
  text: "Liste düzenlendi!",
  icon: "success",
  button: "OK",
}).then((willDelete) => {
  if (willDelete) {

    window.location = 'anasayfa-urun-listeler';

     }

   });
              }
              }
        })

      



              });


              $('.listeurunsil').click(function(){

           var buton = $(this);
            var id1=$(this).attr("name");
                var listeurun_id=id1.substring(10);

               swal({
  title: "Emin misiniz?",
  text: "Listeden bu ürünü kaldırmak istiyor musunuz?",
  icon: "warning",
  buttons: ["Vazgeç", "Sil"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

    buton.html('Siliniyor...');

    $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'listeurunsil':'ok','listeurun_id':listeurun_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              if (sonuc=="ok") {

                $('.listeurun_'+listeurun_id).remove();
              }

               }

             });


     }

     })
         });

              $('.siraguncelle').click(function(){

var buton = $(this);
            var id1=$(this).attr("name");
                var listeurun_id=id1.substring(10);
                var sira = $.trim($('#listeurun_'+listeurun_id).val());

                $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'listeurunsiraguncelle':'ok','listeurun_id':listeurun_id,'sira':sira},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              if (sonuc=="ok") {

                swal({

  title: "Başarılı",
  text: "Ürün sırası güncellendi!",
  icon: "success",
  button: "OK",
});
              }

               }

             });
              });


              $('.dahafazlaurun').click(function(){

                var urunsayisi = $('.urunno').length;
                var yeniurunsayisi = urunsayisi+1;

                $('.urunno').last().after('<div style="margin-bottom:40px;" class="urunno urunno_'+yeniurunsayisi+'"><div class="form-group"><label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Ürün No. <span class="required">*</span></label><div class="col-md-7 col-sm-7 col-xs-12"><input  type="text" maxlength="30"  name="urun_id[]"  placeholder="Ürün no. sunu yazın"  class="form-control col-md-10 col-xs-12 inputt"></div></div><div class="form-group"><label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Sıra <span class="required">*</span></label><div class="col-md-7 col-sm-7 col-xs-12"><input type="number" placeholder="Ürünün bu listede kaçıncı sırada listeleneceğini girin"  name="urun_sira[]" step="any"  class="form-control col-md-10 col-xs-12 inputt"></div></div><div class="form-group"><label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name"></label><div align="center" class="col-md-7 col-sm-7 col-xs-12"><a class="btn btn-danger urunkaldir" name="urunkaldir_'+yeniurunsayisi+'" href="javascript:void(0);"><i class="fa fa-trash-o"></i> Kaldır</a></div></div></div>');

                $('.urunkaldir').click(function(){

           var buton = $(this);
            var id1=$(this).attr("name");
                var urunno=id1.substring(11);

                $('.urunno_'+urunno).remove();

                });

              });


              $('#listeurunekleform').submit(function(){

                

                var bosinputsayisi = $('.inputt').filter(function(){
    return !$.trim($(this).val());
}).length;
                
                if (bosinputsayisi>0) {

           $('.uyariurunekle').show();
           $('.uyariurunekle').html('<i class="fa fa-info-circle"></i> Tüm alanları doldurmanız gerekmektedir.');

                } else {

                  $('.uyariurunekle').hide();
$('.listeuruneklebuton').prop('disabled',true);
$('.listeuruneklebuton').html('Ekleniyor...');

$.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : $('#listeurunekleform').serialize(),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

             
             if (sonuc=="ok") {

              location.reload();
             }

              }
        });
                }



              })



            </script>


            