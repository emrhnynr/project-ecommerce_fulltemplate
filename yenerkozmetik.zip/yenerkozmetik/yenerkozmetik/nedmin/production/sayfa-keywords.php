<?php require_once 'header.php';

$seoayarsec=$db->prepare("SELECT * from seoayarlar");
$seoayarsec->execute();

 $seoayarcek=$seoayarsec->fetch(PDO::FETCH_ASSOC);

 $anasayfa_keywords = $seoayarcek['anasayfa_keywords'];
 $hakkimizda_keywords = $seoayarcek['hakkimizda_keywords'];
  $iletisim_keywords = $seoayarcek['iletisim_keywords'];
   $blog_keywords = $seoayarcek['blog_keywords'];
   $ekip_keywords = $seoayarcek['ekip_keywords'];
   $sss_keywords = $seoayarcek['sss_keywords'];



  ?>



        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              

              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                 
                  <div class="x_content">
                    <br />

                  

                    <form id="keywordsform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

                      <h3 align="center">SEO Uyumlu Anahtar Kelimeler</h3>
                      <h5 align="center">Doğru anahtar kelimeler, sayfanızın Google'daki aramalarla eşleşmesini ve Google'da yükselmesini sağlar.</h5>
                      
                      <hr>


                     
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Anasayfa 
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="anasayfa_keywords" value="<?php echo $anasayfa_keywords; ?>" name="anasayfa_keywords" maxlength="300"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Hakkımızda 
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="hakkimizda_keywords" value="<?php echo $hakkimizda_keywords; ?>" name="hakkimizda_keywords" maxlength="300"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">İletişim
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="iletisim_keywords" value="<?php echo $iletisim_keywords; ?>" name="iletisim_keywords" maxlength="300"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Blog 
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="blog_keywords" value="<?php echo $blog_keywords; ?>" name="blog_keywords" maxlength="300"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Ekip 
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="ekip_keywords" value="<?php echo $ekip_keywords; ?>" name="ekip_keywords" maxlength="300"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>


                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">SSS
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="sss_keywords" value="<?php echo $sss_keywords; ?>" name="sss_keywords" maxlength="300"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>


                      

                      

                     

                

                      <input type="hidden" name="keywordsduzenle">


                      
                      
                      <div class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">

                       
                          
                          <button style="margin-bottom: 25px;" type="submit" class="btn btn-success keywordsbuton">Düzenle</button>



                          <h4 align="center">Ürün, tekli blog, marka ve kategorilerin anahtar kelimelerini kendi düzenleme sayfalarından değiştirebilirsiniz.</h4>
                        </div>
                      </div>

                    </form>



                    

                   


                    
                  </div>
                </div>
              </div>
            </div>

            <?php require_once 'footer.php'; ?>



            <script type="text/javascript">

             

            $('#keywordsform').submit(function(){

             


              $('.keywordsbuton').prop('disabled',true);

              

                $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : $('#keywordsform').serialize(),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

              if (sonuc=="ok") {

                
                $('.keywordsbuton').prop('disabled',false);


                swal({

  title: "Başarılı",
  text: "Anahtar kelimeler düzenlendi!",
  icon: "success",
  button: "OK",
});



              }
                

              }


            })

                 

                 });

            


            

            </script>

              
             