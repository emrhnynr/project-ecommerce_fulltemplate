<?php session_start();

if (isset($_SESSION['admin_oturum'])) {
	
	unset($_SESSION['admin_oturum']);
Header("Location:login");

} else {

	Header("Location:login");
}


 ?>