<?php require_once 'header.php';


 
$siparis_filtre=$_GET['filtrele'];

                   $hazirla=$db->prepare("UPDATE siparisler set

siparis_goruldu=:siparis_goruldu

where siparis_goruldu='0'

");

$derle=$hazirla->execute(array(
"siparis_goruldu" => 1
));

 ?>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
           

            <div class="clearfix"></div>

            <div class="row">
             

              <div class="clearfix"></div>

              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Siparişler</h2>

                    

                    <div  class="col-xs-12 col-sm-5 col-md-5 nav navbar-right panel_toolbox">
                       <select id="siralamaolcutu" name="siralamaolcutu" class="form-control">
                        
                        <option <?php if ($siparis_filtre!='kargoda' and $siparis_filtrele!='bekleyen' and $siparis_filtrele!='teslimedilen') { ?>
                          selected=""
                        <?php } ?> value="kayitsondanbasa">Tüm Durumlar</option>
                        
                        <option <?php if ($siparis_filtre=='teslimedilen') { ?>
                          selected=''
                        <?php } ?> value="teslimedildi">Teslim Edilen</option>
                        <option <?php if ($siparis_filtre=='kargoda') { ?>
                          selected=''
                        <?php } ?> value="kargoyaverildi">Kargoda</option>
                        <option <?php if ($siparis_filtre=='bekleyen') { ?>
                         selected=''
                       <?php } ?> value="bekleniyor">Hazırlanıyor</option>
                        
                      </select>
                    </div>

                    <div  class="col-xs-12 col-sm-5 col-md-5 nav navbar-right panel_toolbox">
                       <select id="zamanfiltresi" name="zamanfiltresi" class="form-control">
                        
                        <option selected="" value="tumzamanlar">Tüm Zamanlar</option>
                        <option value="bugun">Bugün</option>
                        <option value="buhafta">Son 7 Gün</option>
                        <option value="buay">Bu Ay</option>
                        <option value="gecenay">Geçen Ay</option>
                        
                      </select>
                    </div>
                    
                    <div class="clearfix"></div>
                  </div>

                  <div class="x_content">

                   

                    
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->


      </div>
    </div>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="../vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- Sweet Alert -->

    <script type="text/javascript" src="../../sweetalert.min.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
  </body>
</html>

 <script type="text/javascript">
   
$('#siralamaolcutu,#zamanfiltresi').change(function(){

 var siralamaolcutu = $('#siralamaolcutu').val();
 var zamanfiltresi = $('#zamanfiltresi').val();

 $('.x_content').html('<h3 align="center">Yükleniyor...</h3>');

 $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : {'siparislersiralamaolcutudegistir':'ok','siralamaolcutu':siralamaolcutu,'zamanfiltresi':zamanfiltresi},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              $('.x_content').html(sonuc);

               }

              });



      }).change();

 </script>