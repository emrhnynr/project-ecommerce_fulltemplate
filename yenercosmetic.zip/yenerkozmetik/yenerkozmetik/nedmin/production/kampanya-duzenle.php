<?php require_once 'header.php'; 

$kampanya_id = $_GET['kampanya_id'];

$kampanyasec=$db->prepare("SELECT * from kampanyalar where kampanya_id=:id");
$kampanyasec->execute(array(
"id" => $kampanya_id
));

$kampanyasay=$kampanyasec->rowCount();

if ($kampanyasay==0) {
  
  header("Location:index");
  exit;
}

$kampanyacek=$kampanyasec->fetch(PDO::FETCH_ASSOC);

$kampanya_baslik = $kampanyacek['kampanya_baslik'];
$kampanya_sira = $kampanyacek['kampanya_sira'];
$kampanya_menu = $kampanyacek['kampanya_menu'];




?>


        

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Kampanya > <?php echo $kampanya_baslik; ?></h3>
              </div>

              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                 
                  <div class="x_content">
                    <br />
                   <form id="kampanyaduzenleform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

                      
                       

                       <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Kampanya Başlık <span class="required">*</span>
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input  type="text" maxlength="400" id="kampanya_baslik" name="kampanya_baslik"  value="<?php echo $kampanya_baslik; ?>"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                     
                     

                      

                     <input type="hidden" value="<?php echo $kampanya_id; ?>" name="kampanya_id">

                      

                     

                

                      <input type="hidden" name="kampanyaduzenle">
                      


                      
                      
                      <div class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">

                          <div style="display: none;" class="alert alert-warning uyari"></div>
                          
                          <button type="submit" class="btn btn-success kampanyaduzenlebuton">Düzenle</button>
                        </div>
                      </div>

                    </form>

                    <h3 align="center">Ürünler <a class="btn btn-success" href="#kampanyaurunekle">Ekle +</a><hr></h3>

                    <table id="datatable" class="table table-striped table-bordered">
                      <thead>
                        <tr>
                         
                          <th>Ürün Ad</th>
                          <th>Sıra</th>

                         
                         
                          <th></th>
                          
                          
                          
                         
                        </tr>
                      </thead>


                      <tbody>

        <?php $kampanyaurunsec=$db->prepare("SELECT * from kampanyaurun where urun_kaldirildi=:kaldirildi and kampanya_id=:id order by urun_sira ASC");
            $kampanyaurunsec->execute(array(

              
              "kaldirildi" => 0,
              "id" => $kampanya_id
            ));

            while ($kampanyauruncek=$kampanyaurunsec->fetch(PDO::FETCH_ASSOC)) {

           
            $urun_id = $kampanyauruncek['urun_id'];

            $urunsec = $db->prepare("SELECT * from urunler where urun_id='$urun_id'");
            $urunsec->execute();

            $uruncek=$urunsec->fetch(PDO::FETCH_ASSOC);

            $urun_id = $uruncek['urun_id'];

            $urun_ad = $uruncek['urun_ad'];

            $urun_sira = $kampanyauruncek['urun_sira'];



            ?>

        <tr class="kampanyaurun_<?php echo $kampanyauruncek['kampanyaurun_id']; ?>">
                          
                          <td><a target="_blank" href="../../urun-<?php echo seo($urun_ad)."-".$urun_id; ?>"><?php echo $urun_ad; ?></a></td>
                          <td><div class="col-md-8"><input id="kampanyaurun_<?php echo $kampanyauruncek['kampanyaurun_id']; ?>" class="form-control" type="number" min="1" step="any" value="<?php echo $urun_sira; ?>" name=""></div><div class="col-md-4"><a href="javascript:void(0);" class="btn btn-success btn-block siraguncelle" name="kampanyaurun_<?php echo $kampanyauruncek['kampanyaurun_id']; ?>">Güncelle</a></div></td>

                          


                      
                          
                          <td align="right"><a class="btn btn-danger btn-sm kampanyaurunsil" href="javascript:void(0);"  name="kampanyaurun_<?php echo $kampanyauruncek['kampanyaurun_id']; ?>">Sil</a></td>
                        
                          
                          
                        </tr>
          
        <?php } ?>

                        
                        
                        
                      </tbody>
                    </table>

                    <h3 id="kampanyaurunekle" style="margin-top:100px;" align="center">Kampanyaya Ürün Ekle<hr></h3>

                    <form id="kampanyaurunekleform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">


                      <h4 align="center">Ürün no. larına <a target="_blank" href='urun-ayarlari'>buradan</a> ulaşabilirsiniz.</h4>



                      <div style="margin-bottom:40px;" class="urunno">

                       
                      
                       

                       <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Ürün No. <span class="required">*</span>
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input  type="text" maxlength="30"  name="urun_id[]"  placeholder="Ürün no. sunu yazın"  class="form-control col-md-10 col-xs-12 inputt">
                        </div>
                      </div>

                     
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Sıra <span class="required">*</span>
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="number" placeholder="Ürünün bu listede kaçıncı sırada listeleneceğini girin"  name="urun_sira[]" step='any'  class="form-control col-md-10 col-xs-12 inputt">
                        </div>
                      </div>

                      

                    </div>


                      <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name"></span>
                        </label>
                        <a href="javascript:void(0);" class="dahafazlaurun"><div align="center" class="form-group">
                        <div style="margin-bottom: 80px;border:1px solid #d7d7d7;" class="col-md-7 col-sm-7 col-xs-12">
                          <h3>Daha Fazla Ürün +</h3>
                        </div></a>

                      

                     <input type="hidden" value="<?php echo $kampanya_id; ?>" name="kampanya_id">

                      

                     

                

                      <input type="hidden" name="kampanyaurunekle">
                      


                      
                      
                      <div style="margin-top:30px;" class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">

                          <div style="display: none;" class="alert alert-warning uyariurunekle"></div>
                          
                          <button type="submit" class="btn btn-success kampanyauruneklebuton">Ekle</button>
                        </div>
                      </div>

                    </form>
                  </div>
                </div>
              </div>
            </div>

            <?php require_once 'footer.php'; ?>
            <script type="text/javascript">
              
              $('#kampanyaduzenleform').submit(function(){


              var kampanya_baslik = $.trim($('#kampanya_baslik').val());
          
         
        
    
      var form = $('#kampanyaduzenleform')[0];
             var data = new FormData(form);

             if (kampanya_baslik.length<2) {

        $('.uyari').show();
        $('.uyari').html('<i class="fa fa-info-circle"></i> Kampanya başlığı 2 karakterden kısa olamaz.');


         } else {     

       
       $('.uyari').hide();
$('.kampanyaduzenlebuton').prop('disabled',true);
$('.kampanyaduzenlebuton').html('Düzenleniyor...');

$.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : $('#kampanyaduzenleform').serialize(),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

              if (sonuc=='mevcutbaslik') {

                swal({

  title: "Uyarı",
  text: "Aynı başlıkta kampanya mevcut.",
  icon: "warning",
  button: "OK",
});

                $('.kampanyaduzenlebuton').prop('disabled',false);
                $('.kampanyaduzenlebuton').html('Düzenle');


              } else if (sonuc=="ok"){

if (sonuc=="ok") {

                swal({

  title: "Başarılı",
  text: "Kampanya düzenlendi!",
  icon: "success",
  button: "OK",
}).then((willDelete) => {
  if (willDelete) {

    window.location = 'kampanyalar';

     }

   });
              }
              }
              }
        })

      

}

              });


              $('.kampanyaurunsil').click(function(){

           var buton = $(this);
            var id1=$(this).attr("name");
                var kampanyaurun_id=id1.substring(13);

               swal({
  title: "Emin misiniz?",
  text: "Kampanyadan bu ürünü kaldırmak istiyor musunuz?",
  icon: "warning",
  buttons: ["Vazgeç", "Sil"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

    buton.html('Siliniyor...');

    $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'kampanyaurunsil':'ok','kampanyaurun_id':kampanyaurun_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              if (sonuc=="ok") {

                $('.kampanyaurun_'+kampanyaurun_id).remove();
              }

               }

             });


     }

     })
         });

              $('.siraguncelle').click(function(){

var buton = $(this);
            var id1=$(this).attr("name");
                var kampanyaurun_id=id1.substring(13);
                var sira = $.trim($('#kampanyaurun_'+kampanyaurun_id).val());

                $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'kampanyaurunsiraguncelle':'ok','kampanyaurun_id':kampanyaurun_id,'sira':sira},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              if (sonuc=="ok") {

                swal({

  title: "Başarılı",
  text: "Ürün sırası güncellendi!",
  icon: "success",
  button: "OK",
});
              }

               }

             });
              });


              $('.dahafazlaurun').click(function(){

                var urunsayisi = $('.urunno').length;
                var yeniurunsayisi = urunsayisi+1;

                $('.urunno').last().after('<div style="margin-bottom:40px;" class="urunno urunno_'+yeniurunsayisi+'"><div class="form-group"><label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Ürün No. <span class="required">*</span></label><div class="col-md-7 col-sm-7 col-xs-12"><input  type="text" maxlength="30"  name="urun_id[]"  placeholder="Ürün no. sunu yazın"  class="form-control col-md-10 col-xs-12 inputt"></div></div><div class="form-group"><label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Sıra <span class="required">*</span></label><div class="col-md-7 col-sm-7 col-xs-12"><input type="number" placeholder="Ürünün bu listede kaçıncı sırada listeleneceğini girin"  name="urun_sira[]" step="any"  class="form-control col-md-10 col-xs-12 inputt"></div></div><div class="form-group"><label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name"></label><div align="center" class="col-md-7 col-sm-7 col-xs-12"><a class="btn btn-danger urunkaldir" name="urunkaldir_'+yeniurunsayisi+'" href="javascript:void(0);"><i class="fa fa-trash-o"></i> Kaldır</a></div></div></div>');

                $('.urunkaldir').click(function(){

           var buton = $(this);
            var id1=$(this).attr("name");
                var urunno=id1.substring(11);

                $('.urunno_'+urunno).remove();

                });

              });


              $('#kampanyaurunekleform').submit(function(){

                

                var bosinputsayisi = $('.inputt').filter(function(){
    return !$.trim($(this).val());
}).length;
                
                if (bosinputsayisi>0) {

           $('.uyariurunekle').show();
           $('.uyariurunekle').html('<i class="fa fa-info-circle"></i> Tüm alanları doldurmanız gerekmektedir.');

                } else {

                  $('.uyariurunekle').hide();
$('.kampanyauruneklebuton').prop('disabled',true);
$('.kampanyauruneklebuton').html('Ekleniyor...');

$.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : $('#kampanyaurunekleform').serialize(),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

             
             if (sonuc=="ok") {

              location.reload();
             }

              }
        });
                }



              })



            </script>


            