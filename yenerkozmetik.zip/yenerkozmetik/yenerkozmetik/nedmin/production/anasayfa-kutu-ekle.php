<?php require_once 'header.php'; ?>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              

              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Anasayfa Kutu Ekle</h2>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />
                    <form id="kutuekleform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

                      <h4 align="center"><i class="fa fa-info-circle"></i> Harika görünüm için tüm resimlerin aynı boyutta olmasına dikkat edin.</h4><hr>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Kutu Resim <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="file" id="kutu_foto" name="kutu_foto" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Kutu Sıra <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="number" id="kutu_sira" placeholder="Kutunun kaçıncı sırada listeleneceğini girin." name="kutu_sira"  class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>

                      

                    

                       <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Kutu Link
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" id="kutu_link" placeholder="Doldurmazsanız kutu tıklanamaz olur." maxlength="500" name="kutu_link"  class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>

                      <input type="hidden" name="kutuekleadmin">
                      
                      
                      <div class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                          <div style="display: none;" class="alert alert-warning uyari"></div>
                          
                          <button type="submit" class="btn btn-success kutueklebuton">Ekle</button>
                        </div>
                      </div>

                    </form>
                  </div>
                </div>
              </div>
            </div>

            <?php require_once 'footer.php'; ?>
            <script type="text/javascript">
              
              $('#kutuekleform').submit(function(){
          
          var kutu_sira = $('#kutu_sira').val();
         var kutu=$('#kutu_foto').val();
      var kutuuzanti=kutu.split('.').pop();
      var form = $('#kutuekleform')[0];
             var data = new FormData(form);

             if (kutu=="") {

   

$('.uyari').show();
$('.uyari').html('<i class="fa fa-info-circle"></i> Lütfen bir kutu resmi yükleyin.');


      } else if (kutuuzanti!='jpg' && kutuuzanti!='jpeg' && kutuuzanti!='png'){



$('.uyari').show();
$('.uyari').html('<i class="fa fa-info-circle"></i> Sadece <b>.jpg, .jpeg, .png</b> uzantılı dosyaları yükleyebilirsiniz.');

      } else if (kutu_sira.length==0){

$('.uyari').show();
$('.uyari').html('<i class="fa fa-info-circle"></i> Lütfen kutunun kaçıncı sırada listeleneceğini belirtin.');

      } else {

       
       $('.uyari').hide();
$('.kutueklebuton').prop('disabled',true);

$.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            enctype : 'multipart/form-data',
            data : data,
            processData: false,
            contentType: false,
            cache: false,
            success : function(sonuc){

                sonuc=$.trim(sonuc);



                if (sonuc=="ok") {

                  swal({

  title: "Başarılı",
  text: "Kutu ekleme başarılı!",
  icon: "success",
  button: "OK",
}).then((willDelete) => {
  if (willDelete) {

    window.location = 'anasayfa-kutular';

     }

   });
                }

                 }

               });


      }



              });

            </script>

            