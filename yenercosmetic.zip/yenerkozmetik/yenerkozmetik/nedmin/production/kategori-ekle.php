<?php require_once 'header.php'; 

if (empty($_GET['kategori_ust']) or $_GET['kategori_ust']=='0') {
  
  $kategori_ust = 0;
  $kategori_ust2 = 0;

} else {

  $kategori_ust = $_GET['kategori_ust'];
  $kategori_ust2 = $_GET['kategori_ust'];
  
}





$kategorisor2=$db->prepare("SELECT * from kategoriler where kategori_id='$kategori_ust'");
$kategorisor2->execute();

$kategorisay2=$kategorisor2->rowCount();

$kategoricek2=$kategorisor2->fetch(PDO::FETCH_ASSOC);


if ($kategorisay2==0 and $kategori_ust!=0) {
  header("Location:kategori-ayarlari");
  exit;
}


$say=0;
                      $dizi = array();

                 while ($say<5) {
                    
                    $say++;

                    $kategorisec=$db->prepare("SELECT * from kategoriler where kategori_id='$kategori_ust2'");
                    $kategorisec->execute();
                    $kategoricek=$kategorisec->fetch(PDO::FETCH_ASSOC);

                    $kategori_id = $kategoricek['kategori_id'];

                    if ($kategoricek['kategori_ust']==0) {
                      
                      array_push($dizi, $kategori_id);
                      break;

                    } else {

                      array_push($dizi, $kategori_id);

                    }

                    $kategori_ust2 = $kategoricek['kategori_ust'];

                  };

                  


?>


        

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Kategori Ekle</h3>
              </div>



              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                 
                  <div class="x_content">
                    <br />
                   <form id="kategoriekleform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

                      
                       

                       <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Üst Kategori <i class="fa fa-arrow-right"></i>
                        </label>
                        <div class="col-md-9 col-sm-9 col-xs-12">
                          <h4><?php if($kategori_ust==0){

                            echo "<b>En Üst</b>";

                          } else {

                            $dizibasla = count($dizi);

                          while ($dizibasla>0) {
                        
                        $dizibasla--;

                        $kategori_id = $dizi[$dizibasla];

                        $kategorisec=$db->prepare("SELECT * from kategoriler where kategori_id='$kategori_id'");
                        $kategorisec->execute();

                        $kategoricek=$kategorisec->fetch(PDO::FETCH_ASSOC); ?>

                        <?php 

                        if ($dizibasla==0) {
                           
                           echo "<b>".$kategoricek['kategori_ad']."</b>";

                         } else {

                          echo $kategoricek['kategori_ad']." >";
                         } ?>

                        

                             

                          <?php } } ?></h4>
                        </div>
                      </div>

                      <input type="hidden" value="<?php echo $kategori_ust; ?>" id="kategori_ust" name="kategori_ust">

                     
                      

                      

                      

                     

                

                      
                      


                      
                      
                      

                    

                    

                    <h3 id="listeurunekle" style="margin-top:50px;" align="center">Kategori Ekle<hr></h3>

                    


                      



                      <div style="margin-bottom:40px;" class="kategorino">
                      
                       

                       <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Kategori Adı <span class="required">*</span>
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input  type="text" maxlength="400"  name="kategori_ad[]"  placeholder="Kategori adını yazın."  class="form-control col-md-10 col-xs-12 inputt">
                        </div>
                      </div>


                     

                     
                      

                    </div>


                      <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name"></span>
                        </label>
                        <a href="javascript:void(0);" class="dahafazlakategori"><div align="center" class="form-group">
                        <div style="margin-bottom: 80px;border:1px solid #d7d7d7;" class="col-md-7 col-sm-7 col-xs-12">
                          <h3>Daha Fazla Kategori +</h3>
                        </div></a>

                      

                     

                      

                     

                

                      <input type="hidden" name="kategoriekle">
                      


                      
                      
                      <div style="margin-top:30px;" class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">

                          <div style="display: none;" class="alert alert-warning uyari"></div>
                          
                          <button type="submit" class="btn btn-success kategorieklebuton">Ekle</button>
                        </div>
                      </div>

                    </form>

                    
                  </div>
                </div>
              </div>
            </div>

            <?php require_once 'footer.php'; ?>
            <script type="text/javascript">
              
              


            


              $('.dahafazlakategori').click(function(){

                var kategorisayisi = $('.kategorino').length;
                var yenikategorisayisi = kategorisayisi+1;

                $('.kategorino').last().after('<div style="margin-bottom:40px;" class="kategorino kategorino_'+yenikategorisayisi+'"><div class="form-group"><label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Kategori Adı <span class="required">*</span></label><div class="col-md-7 col-sm-7 col-xs-12"><input  type="text" maxlength="400"  name="kategori_ad[]"  placeholder="Kategori adını yazın."  class="form-control col-md-10 col-xs-12 inputt"></div></div><div class="form-group"><label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name"></label><div align="center" class="col-md-7 col-sm-7 col-xs-12"><a class="btn btn-danger kategorikaldir" name="kategorikaldir_'+yenikategorisayisi+'" href="javascript:void(0);"><i class="fa fa-trash-o"></i> Kaldır</a></div></div></div>');

                $('.kategorikaldir').click(function(){

           var buton = $(this);
            var id1=$(this).attr("name");
                var kategorino=id1.substring(15);

                

                $('.kategorino_'+kategorino).remove();

                });

              });


             


              $('#kategoriekleform').submit(function(){
          
          
        
    
      var form = $('#kategoriekleform')[0];
             var data = new FormData(form);

             var bosinputsayisi = $('.inputt').filter(function(){
    return !$.trim($(this).val());
}).length;

              var kategori_ust = $.trim($('#kategori_ust').val());
                
                

                 if (bosinputsayisi>0){


$('.uyari').show();
  $('.uyari').html('<i class="fa fa-info-circle"></i> Tüm kategori adı alanlarını doldurmanız gerekmektedir.');


      } else {



       
       $('.uyari').hide();
$('.kategorieklebuton').prop('disabled',true);
$('.kategorieklebuton').html('Ekleniyor...');

$.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : $('#kategoriekleform').serialize(),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

             
            
              

               if (sonuc=="ok"){

                swal({

  title: "Başarılı",
  text: "Kategori/kategoriler eklendi!",
  icon: "success",
  button: "OK",
}).then((willDelete) => {
  if (willDelete) {

    window.location = 'kategori-ayarlari?kategori_ust='+kategori_ust;

     }

   });

              }

               
              }
        })

      }





              });



            </script>


            