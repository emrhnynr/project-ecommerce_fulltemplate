<?php require_once 'header.php';


$referanssec=$db->prepare("SELECT * from referanslar");
$referanssec->execute();

$genelayarsec=$db->prepare("SELECT * from genelayarlar");
$genelayarsec->execute();

 $genelayarcek=$genelayarsec->fetch(PDO::FETCH_ASSOC);

 $ayar_referanslarbaslik = $genelayarcek['ayar_referanslarbaslik'];




 ?>
        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <div class="row">
                      <div class="col-md-4 col-xs-12"><input maxlength="150" class="form-control" id="ayar_referanslarbaslik" type="text" value="<?php echo $ayar_referanslarbaslik; ?>" name="" ></div>
                      <div class="col-md-2 col-xs-12"><a class="btn btn-success btn-block baslikguncellebuton" href="javascript:void(0);">Güncelle</a></div>
                    </div>
                   
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <div class="row">

                      
                      

           <?php 
          
          while ($referanscek=$referanssec->fetch(PDO::FETCH_ASSOC)) { 
            $referans_logo = $referanscek['referans_logo'];
            $referans_id = $referanscek['referans_id'];
             ?>
             <div style="margin-bottom:50px;" class="col-md-3 col-sm-3 col-xs-12">
              
               <div style="position: relative;" class="col-md-12 col-sm-12 col-xs-12 image">
                <a class="referanslogosil" name="referans_<?php echo $referans_id; ?>" href="javascript:void(0);"><i class="fa fa-times-circle" style="position: absolute;top:-5px;right: 5px;font-size:20px;color:red;"></i></a>
                 <img style="height: 120px;width: 150px;" class="img-responsive" src="../../<?php echo $referans_logo; ?>">
               </div>
              
             </div>
                      
          <?php } ?>

          <div style="margin-bottom:50px;" class="col-md-3 col-sm-3 col-xs-12">
              
               <div style="position: relative;border:1px dashed;height: 200px;" class="col-md-12 col-sm-12 col-xs-12 imageadd">

                <div class="col-md-12 col-xs-12 col-sm-12" style="height: 130px;">
                  <h3 align="center">Yükle <i class="fa fa-upload"></i></h3>
                  <p style="font-size:14px;" align="center">Yeni referans logosu yüklemek için aşağıdan resmi seçin veya sürükleyip bırakın.</p>
                </div>
                
                 <input style="height: 55px;" class="form-control referanslogoekle" type="file"   name="">
               </div>
              
             </div>
            

                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
       
       <?php require_once 'footer.php'; ?>
       <script type="text/javascript">

        $('.baslikguncellebuton').click(function(){

var ayar_referanslarbaslik = $.trim($('#ayar_referanslarbaslik').val());

$('.baslikguncellebuton').prop('disabled',true);


$.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : {'referanslarbaslikduzenle':'ok','ayar_referanslarbaslik':ayar_referanslarbaslik},
            success : function(sonuc){

              sonuc = $.trim(sonuc);

              if (sonuc=="ok") {

                


                swal({

  title: "Başarılı",
  text: "Referanslar başlık güncellendi!",
  icon: "success",
  button: "OK",
});



              }
                

              }


            })



          });

         
         $('.referanslogosil').click(function(){

          var id1=$(this).attr("name");
                var referans_id=id1.substring(9);
                

                swal({
  title: "Emin misiniz?",
  text: "Bu referans logosunu silmek istiyor musunuz?",
  icon: "warning",
  buttons: ["Vazgeç", "Sil"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

    $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'referanslogosil':'ok','referans_id':referans_id},
            success : function(sonuc){

              $('.x_content').html('<h3 align="center">Yükleniyor...</h3>');

               $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'referansgalerireload':'ok'},
            success : function(sonuc){

             var sonuc = $.trim(sonuc);
              
              $('.x_content').html(sonuc);

              

               }

             });
              


               }

             });


     }

     });
         });



$('.referanslogoekle').change(function(){

          var input = $(this);
            
           
       
      var foto = $(this).val();
      var filevalue = $(this).get(0).files[0];

      if (foto.length!=0) {

        swal({
  title: "Emin misiniz?",
  text: "Bu logo referans galerisine eklenecek.",
  icon: "info",
  buttons: ["Vazgeç", "Ekle"]
})
.then((willDelete) => {
  if (willDelete) {


    var fotouzanti=foto.split('.').pop();

      

      var data = new FormData();
      data.append('referanslogoekle',"ok");
      data.append("file",filevalue);
    

      if (fotouzanti!='jpg' && fotouzanti!='jpeg' && fotouzanti!='png'){


           swal({

  title: "Bilgi",
  text: "Sadece .jpg, .jpeg, .png uzantılı dosyaları yükleyebilirsiniz.",
  icon: "info",
  button: "OK",
});


               } else {

                $('.imageadd').html('<h3 style="margin-top:80px;" align="center">Ekleniyor...</h3>');

               $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            enctype : 'multipart/form-data',
            data : data,
            processData: false,
            contentType: false,
            cache: false,
            success : function(sonuc){

            sonuc=$.trim(sonuc);

           if (sonuc=="ok") {

 $('.x_content').html('<h3 align="center">Yükleniyor...</h3>');

              

               $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'referansgalerireload':'ok'},
            success : function(sonuc){

             var sonuc = $.trim(sonuc);
              
              $('.x_content').html(sonuc);

              

               }

             });

 
           } else {

            location.reload();
           }

             }

          })

                 }



     }

     })

        
      
        }

         })
         
        

       </script>