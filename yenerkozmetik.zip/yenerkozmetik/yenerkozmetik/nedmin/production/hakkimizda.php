<?php require_once 'header.php';

$genelayarsec=$db->prepare("SELECT * from genelayarlar");
$genelayarsec->execute();

 $genelayarcek=$genelayarsec->fetch(PDO::FETCH_ASSOC);

 $hakkimizda_baslik = $genelayarcek['hakkimizda_baslik'];
 $hakkimizda_text = $genelayarcek['hakkimizda_text'];
 $ayar_hakkimizdabanner = $genelayarcek['ayar_hakkimizdabanner']; ?>



        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              

              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Hakkımızda</h2>

                    <ul class="nav navbar-right panel_toolbox">
                     
                      <a target="_blank" class="btn btn-success" href="../../hakkimizda">Hakkımızda Sayfası </a>
                    </ul>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />

                    <div style="margin-bottom: 30px;" class="col-xs-12 col-md-12 col-sm-12">

                   
                    <h3 align="center">Hakkımızda Banner <br><br><span>(Önerilen genişlik : 900px)</span><hr></h3>

                    <label>Mevcut Banner <i class="fa fa-sort-desc"></i></label><br><br>
                    <img class="img-responsive" src="../../<?php echo $ayar_hakkimizdabanner; ?>">

                   

                   
                    <input type="file" id="ayar_hakkimizdabanner" class="form-control" name="ayar_hakkimizdabanner">

                    <br>

                    <div style="display: none;" class="alert alert-warning uyaribanner"></div>

                    <a id="hakkimizdabannerguncellebuton" class="btn btn-success" href="javascript:void(0);">Güncelle</a>
                  </div>



                    <form id="hakkimizdaform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">


                     
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Başlık 
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="hakkimizda_baslik" value="<?php echo $hakkimizda_baslik; ?>" name="hakkimizda_baslik" maxlength="500"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                      

                     

                     

                     

                      

                      
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Hakkımızda Metin
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <textarea id="inputt" name="hakkimizda_text" class="form-control col-md-10 col-xs-12 ckeditor"><?php echo $hakkimizda_text; ?></textarea>
                        </div>
                      </div>

                      <script type="text/javascript">
                        
                        CKEDİTOR.replace('inputt');

                      </script>

                      










                      <input type="hidden" name="hakkimizdaeditadmin">
                      
                      
                      <div class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                          <div style="display: none;" class="alert alert-warning uyari"></div>
                          
                          <button type="submit" class="btn btn-success hakkimizdabuton">Düzenle</button>
                        </div>
                      </div>

                    </form>
                  </div>
                </div>
              </div>
            </div>

            <?php require_once 'footer.php'; ?>
            <script type="text/javascript">

               $('#hakkimizdabannerguncellebuton').click(function(){

var input = $('#ayar_hakkimizdabanner');
var foto = $('#ayar_hakkimizdabanner').val();
var filevalue = $('#ayar_hakkimizdabanner').get(0).files[0];
var fotouzanti = foto.split('.').pop();

var data = new FormData();
data.append('hakkimizdabannerguncelle',"ok");
data.append("file",filevalue);



if ($('#ayar_hakkimizdabanner').val().length==0){

 $('.uyaribanner').show();
$('.uyaribanner').html('<i class="fa fa-info-circle"></i> Lütfen banner yükleyin.');

  } else if (fotouzanti!='jpg' && fotouzanti!='jpeg' && fotouzanti!='png'){

$('.uyaribanner').show();
$('.uyaribanner').html('<i class="fa fa-info-circle"></i> Sadece <b>.jpg</b>, <b>.jpeg,</b> <b>.png</b>, uzantılı dosyaları yükleyebilirsiniz.');

} else {

  $('#hakkimizdabannerguncellebuton').prop('disabled',true);
  $('#hakkimizdabannerguncellebuton').html('Güncelleniyor...');

   $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            enctype : 'multipart/form-data',
            data : data,
            processData: false,
            contentType: false,
            cache: false,
            success : function(sonuc){

      sonuc=$.trim(sonuc);
      
      if (sonuc=="ok") {

        location.reload();
      }

 }

 });


}

});

              
              
              $('#hakkimizdaform').submit(function(){

 for (instance in CKEDITOR.instances) {
            CKEDITOR.instances[instance].updateElement();
    }


                
         var hakkimizda_baslik = $.trim($('#hakkimizda_baslik').val()); 
        var hakkimizda_text = $('#inputt').val();
       
        
      var form = $('#hakkimizdaform')[0];
             var data = new FormData(form);

            

       
       $('.uyari').hide();
$('.hakkimizdabuton').prop('disabled',true);
$('.hakkimizdabuton').html('Düzenleniyor...');

  $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
             enctype : 'multipart/form-data',
            data : data,
            processData: false,
            contentType: false,
            cache: false,
            success : function(sonuc){

              sonuc = $.trim(sonuc);

             if (sonuc=="ok") {

              swal({

  title: "Başarılı",
  text: "Hakkımızda metni düzenlendi!",
  icon: "success",
  button: "OK",
}).then((willDelete) => {
  if (willDelete) {

    location.reload();

     }

   });
             }

             
              }
        })

      



              });

            </script>

            