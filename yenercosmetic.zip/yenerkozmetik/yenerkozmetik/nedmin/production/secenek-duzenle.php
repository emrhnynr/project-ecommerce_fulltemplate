<?php require_once 'header.php'; 

$secenek_id=$_GET['secenek_id'];
$seceneksec=$db->prepare("SELECT * from secenekler where secenek_id=:id");
$seceneksec->execute(array(
"id" => $secenek_id
));

$seceneksay=$seceneksec->rowCount();

if ($seceneksay==0) {
  
  header("Location:index");
  exit;
}

$secenekcek=$seceneksec->fetch(PDO::FETCH_ASSOC);

$secenek_ad = $secenekcek['secenek_ad'];



?>



        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              

              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2><?php echo $secenek_ad." Seçenekleri"; ?></h2>


                    
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">



                    <h5 align="center">Bu seçenekler hiçbir ürüne ait değildir. Sadece ürün ekleme ve düzenleme sayfasında seçenek olarak görünürler. Bu yüzden silmeniz tavsiye edilmez.</h5>
                    <br />
                    <form id="secenekduzenleform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

                     



<h3 class="urunozelliklerititle" align="center">Alt Seçenekler<hr></h3>

<?php $altseceneksec=$db->prepare("SELECT * from altsecenekler where secenek_id=:id order by altsecenek_ad ASC");
$altseceneksec->execute(array(
"id" => $_GET['secenek_id']
));



$altseceneksay=0;

while ($altsecenekcek=$altseceneksec->fetch(PDO::FETCH_ASSOC)) { 

  $altseceneksay++; ?>

   <div style="margin-bottom:40px;position: relative;" class="altsecenek altsecenek_<?php echo $altsecenekcek['altsecenek_id']; ?>">
   
  <h4 align="center"><b>Seçenek <?php echo $altseceneksay; ?></b> <a class="btn btn-xs btn-danger altseceneksil" name="altsecenek_<?php echo $altsecenekcek['altsecenek_id']; ?>" href="javascript:void(0);"><i class="fa fa-trash"></i> Kaldır</a></h4>



<div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name"></span>
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input readonly="" type="text" id="ozellik_baslik" value="<?php echo $altsecenekcek['altsecenek_ad']; ?>" maxlength="200"  class="form-control col-md-10 col-xs-12">
                        </div>
                      </div>

                     
</div>

 <?php } ?>

 <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name"></span>
                        </label>
                        <a data-toggle='modal' href="#modalac" class="secenekekle"><div align="center" class="form-group">
                        <div style="margin-bottom: 80px;border:1px solid #d7d7d7;" class="col-md-7 col-sm-7 col-xs-12">
                          <h3>Ekle +</h3>
                        </div></a>
                      </div>

                      <div class="modal fade" id="modalac"> 
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

      <form onsubmit="return false;" id="secenekekleform">

      

        <div style="padding: 50px;" class="modal-body">

         <div class="row">
           
           <div class="col-md-12 col-xs-12 col-sm-12">
            <label>Seçenek Adı *</label>
             <input required="" class="form-control" name="altsecenek_ad" id="secenekekle_ad"  placeholder="Yeni Alt Seçenek"  type="text" >
           </div>

           <input type="hidden"  value="<?php echo $_GET['secenek_id']; ?>"  id='secenek_id' name="secenek_id">

          

           

         </div>

        </div>

     
       
    <div class="modal-footer">


  
    
    <button type="submit" class="btn btn-success secenekeklebuton">Ekle</button>

    </form>

    
</div>



  

     
    </div>

  </div>

</div>






               

                      
                      
                      
                      

                    </form>
                  </div>
                </div>
              </div>
            </div>

            <?php require_once 'footer.php'; ?>
            <script type="text/javascript">
              $('.altseceneksil').click(function(){

           var buton = $(this);
            var id1=$(this).attr("name");
                var altsecenek_id=id1.substring(11);

                swal({
  title: "Bilgi",
  text: "Bu seçenek tanımlandığı tüm ürünlerden kaldırılacak.",
  icon: "warning",
  buttons: ["Vazgeç", "Kaldır"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

    buton.prop('disabled',true);
               buton.html('Kaldırılıyor...');

               $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'altseceneksil':'ok','altsecenek_id':altsecenek_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              if (sonuc=="ok") {

                $('.altsecenek_'+altsecenek_id).remove();
              }

               }

             });

     }

     });

               

               });

$('.secenekeklebuton').click(function(){

  var secenek_id = $('#secenek_id').val();
  var altsecenek_ad = $.trim($('#secenekekle_ad').val());

  if (altsecenek_ad.length<1) {

alert("Alanı doldurmalısınız.");

  } else {

$('.secenekeklebuton').prop('disabled',true);
               $('.secenekeklebuton').html('Ekleniyor...');

                $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'altsecenekekle':'ok','secenek_id':secenek_id,'altsecenek_ad':altsecenek_ad},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

             if (sonuc=="ok") {

              location.reload();
             }

               }

             });

              


  }




})

            </script>
           
           

            