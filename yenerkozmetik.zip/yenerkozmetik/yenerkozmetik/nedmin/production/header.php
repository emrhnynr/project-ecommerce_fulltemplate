
<?php require_once '../../db.php';
include '../../fonksiyon.php';
ob_start();
session_start();
date_default_timezone_set('Europe/Istanbul');




if (empty($_SESSION['admin_oturum'])) {
    
    Header("Location:login");

  };

$adminsessionsec=$db->prepare("SELECT * from kullanici where kullanici_mail=:mail");
$adminsessionsec->execute(array(

"mail" => $_SESSION['admin_oturum']

));

$adminsessioncek=$adminsessionsec->fetch(PDO::FETCH_ASSOC);


$headerbildirimler = array();

$gorulmemissiparissec=$db->prepare("SELECT * from siparisler where siparis_goruldu=:goruldu");
$gorulmemissiparissec->execute(array(
"goruldu" => 0
));

$gorulmemissiparissay=$gorulmemissiparissec->rowCount();

if ($gorulmemissiparissay>0) {
  array_push($headerbildirimler,'siparis');
}


$gorulmemisiadesec=$db->prepare("SELECT * from siparisitem where iade_goruldu=:goruldu and urun_iade!='0'");
$gorulmemisiadesec->execute(array(
"goruldu" => 0
));

$gorulmemisiadesay=$gorulmemisiadesec->rowCount();

if ($gorulmemisiadesay>0) {
  array_push($headerbildirimler,'iade');
}


$gorulmemisyorumsec=$db->prepare("SELECT * from yorumlar where yorum_goruldu=:goruldu");
$gorulmemisyorumsec->execute(array(
"goruldu" => 0
));

$gorulmemisyorumsay=$gorulmemisyorumsec->rowCount();

if ($gorulmemisyorumsay>0) {
  array_push($headerbildirimler,'yorum');
}



$gorulmemisuyesec=$db->prepare("SELECT * from kullanici where kullanici_yetki=:yetki and kullanici_ban=:ban and kullanici_goruldu=:goruldu");
$gorulmemisuyesec->execute(array(
"goruldu" => 0,
"ban" => 0,
"yetki" => 1
));

$gorulmemisuyesay=$gorulmemisuyesec->rowCount();

if ($gorulmemisuyesay>0) {
  array_push($headerbildirimler,'uye');
}

$headerbildirimsayisi = count($headerbildirimler);


   ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Yönetim Paneli</title>

    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
   
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-progressbar -->
    <link href="../vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
    <!-- JQVMap -->
    <link href="../vendors/jqvmap/dist/jqvmap.min.css" rel="stylesheet"/>
    <!-- bootstrap-daterangepicker -->
    <link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">

    <!-- CK EDITOR -->

     <script src="ckeditor/ckeditor.js"></script>

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
              <a href="index" class="site_title"><i class="fa fa-laptop"></i> <span>Yönetim Paneli</span></a>
            </div>

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
            <div class="profile clearfix">
              
              <div class="profile_info">
                <span>Hoşgeldiniz,</span>
                <h2><?php echo $adminsessioncek['kullanici_ad']." ".$adminsessioncek['kullanici_soyad']; ?></h2>
              </div>
            </div>
            <!-- /menu profile quick info -->

            <br />

            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <h3>PANEL</h3>
                <ul class="nav side-menu">
                  

                  <li><a href="index"><i class="fa fa-info-circle"></i> Raporlar</a></li>
                  <li><a><i class="fa fa-cogs"></i> Genel Ayarlar <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      
                      <li><a href="menu-ayarlari"><i class="fa fa-bars"></i> Header Menü Ayarları</a></li>
                       <li><a href="title-ayarlari"><i class="fa fa-tag"></i> Sekme Title Ayarları</a></li>
                      <li><a href="sayfa-descriptionlar"><i class="fa fa-tags"></i> SEO Sayfa Açıklamaları</a></li>
                      
                      <li><a href="hakkimizda"><i class="fa fa-edit"></i>Hakkımızda</a></li>
                      <li><a href="iletisim"><i class="fa fa-phone"></i>İletişim Bilgileri</a></li>
                      <li><a href="sosyal-medya"><i class="fa fa-comments"></i>Sosyal Medya</a></li>
                      <li><a href="logo"><i class="fa fa-paw"></i>Logo</a></li>
                      
                      
                      <li><a href="ekip-ayarlari"><i class="fa fa-group"></i> Ekip</a></li>
                      <li><a href="sss"><i class="fa fa-info-circle"></i> SSS</a></li>
                      <li><a href="hakkimizda-liste"><i class="fa fa-list"></i> Hakkımızda Liste</a></li>
                      <li><a href="referanslar"><i class="fa fa-check"></i> Referanslar</a></li>
                      <li><a href="api-ayarlari"><i class="fa fa-toggle-on"></i> API Ayarları</a></li>
                      

                    </ul>
                  </li>


                  <li><a><i class="fa fa-home"></i> Anasayfa Ayarları <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="homepage"><i class="fa fa-home"></i>Anasayfa Genel</a></li>
                      <li><a href="slayt-ayarlari"><i class="fa fa-photo"></i> Slaytlar</a></li>
                      <li><a href="anasayfa-urun-listeler"><i class="fa fa-tasks"></i>Anasayfa Ürün Listeleri</a></li>
                      <li><a href="anasayfa-markalar"><i class="fa fa-bars"></i>Anasayfa Markalar</a></li>
                      <li><a href="anasayfa-kutular"><i class="fa fa-th"></i>Anasayfa Kutular</a></li>
                      
                      

                    </ul>
                  </li>

                  <li><a><i class="fa fa-filter"></i> Filtreleme Ayarları <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">



                      <li><a href="kategori-sayfa-filtreleme"><i class="fa fa-align-justify"></i>Kategori Sayfası</a></li>
                      <li><a href="marka-sayfa-filtreleme"><i class="fa fa-bars"></i>Marka Sayfası</a></li>
                      
                      
                      

                    </ul>
                  </li>

                  

                  <li><a href="uyeler"><i class="fa fa-user"></i> Üyeler <?php if ($gorulmemisuyesay>0) { ?>
                    <div class="badge" style="background-color: green;"><?php echo $gorulmemisuyesay; ?></div>
                  <?php } ?></a></li>

                  

                  <li><a href="siparisler"><i class="fa fa-cubes"></i> Siparişler <?php if ($gorulmemissiparissay>0) { ?>
                    <div class="badge" style="background-color: green;"><?php echo $gorulmemissiparissay; ?></div>
                  <?php } ?></a></li>

                  <li><a href="iadeler"><i class="fa fa-refresh"></i> İadeler <?php if ($gorulmemisiadesay>0) { ?>
                    <div class="badge" style="background-color: green;"><?php echo $gorulmemisiadesay; ?></div>
                  <?php } ?></a></li>

                  <li><a href="yorumlar"><i class="fa fa-comments"></i> Yorumlar <?php if ($gorulmemisyorumsay) { ?>
                    <div class="badge" style="background-color: green;"><?php echo $gorulmemisyorumsay; ?></div>
                  <?php } ?></a></li>
                   <li><a href="urun-ayarlari"><i class="fa fa-table"></i> Ürünler</a></li>

                   <li><a href="kategori-ayarlari"><i class="fa fa-align-justify"></i> Kategoriler</a></li>
                   <li><a href="marka-ayarlari"><i class="fa fa-bars"></i> Markalar</a></li>
                  
                   <li><a href="secenek-ayarlari"><i class="fa fa-hand-o-up"></i> Ürün Seçenek Ayarları </a></li>

                   <li><a href="kampanyalar"><i class="fa fa-check-square"></i>Kampanyalar</a></li>

                  
                  
                  <li><a href="kargo-ayarlari"><i class="fa fa-truck"></i>Kargo Ayarları</a></li>

                  <li><a href="taksit-ayarlari"><i class="fa fa-credit-card"></i>Taksit Ayarları</a></li>

                  <li><a href="sanalpos-ayarlari"><i class="fa fa-cc-stripe"></i> Sanal Pos Ayarları</a></li>
                  
                  

                    
                  
                 

                    
               
                 
                  
                </ul>
              </div>
              <div class="menu_section"></div>

            </div>
            <!-- /sidebar menu -->

          
          </div>
        </div>

        <!-- top navigation -->
        <div class="top_nav">
          <div class="nav_menu">
            <nav>
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>

              <ul class="nav navbar-nav navbar-right">
                <li class="">
                  <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    <?php echo $adminsessioncek['kullanici_ad']." ".$adminsessioncek['kullanici_soyad']; ?>
                    <span class=" fa fa-angle-down"></span>
                  </a>
                  <ul class="dropdown-menu dropdown-usermenu pull-right">
                    <li><a href="sifre-degistir"> Şifre Değiştir</a></li>
                  
                    
                    <li><a href="logout"><i class="fa fa-sign-out pull-right"></i> Çıkış Yap</a></li>
                  </ul>
                </li>

                <li role="presentation" class="dropdown">
                  <a href="javascript:;" class="dropdown-toggle info-number" data-toggle="dropdown" aria-expanded="false">
                    <i class="fa fa-envelope-o"></i>
                    <span class="badge bg-green"><?php echo $headerbildirimsayisi; ?></span>
                  </a>
                  <?php if ($headerbildirimsayisi==0) { ?>

                     <ul id="menu1" class="dropdown-menu list-unstyled msg_list" role="menu">
                    
                <h4 align="center">Bildirim yok.</h4>

              </ul>

                 <?php } else { ?>

                  

                <ul id="menu1" class="dropdown-menu list-unstyled msg_list" role="menu">

                    <?php foreach ($headerbildirimler as $bildirim) { ?>
                   
                  
                    <?php switch ($bildirim) {

                      case 'uye': ?>
                        
                        <li>
                      <a href="uyeler">
                        
                         
                       
                        <span style="text-align: center;font-size: 14px;" class="message">
                         <i class="fa fa-user"></i> Görmediğiniz yeni üye kayıt/kayıtlar var. Görmek için tıklayın.
                        </span>
                      </a>
                    </li>

                       <?php break; 

                        case 'yorum': ?>

                        <li>
                      <a href="yorumlar">
                        
                         
                       
                        <span style="text-align: center;font-size: 14px;" class="message">
                         <i class="fa fa-comments"></i> Ürününüze yapılan bazı yorumları görmediniz. Görmek için tıklayın.
                        </span>
                      </a>
                    </li>

                       <?php break;

                       case 'siparis': ?>

                       <li>
                      <a href="siparisler">
                        
                         
                       
                        <span style="text-align: center;font-size: 14px;" class="message">
                         <i class="fa fa-cubes"></i> Görmediğiniz yeni sipariş/siparişler var. Görmek için tıklayın.
                        </span>
                      </a>
                    </li>

                    <?php break;

                       case 'iade': ?>

                       <li>
                      <a href="iadeler">
                        
                         
                       
                        <span style="text-align: center;font-size: 14px;" class="message">
                         <i class="fa fa-refresh"></i> Görmediğiniz yeni iade talep/talepleri var. Görmek için tıklayın.
                        </span>
                      </a>
                    </li>


                      
                     
                    <?php } ?>
                    
                    

                    <?php } ?>
                    
                  </ul>


                <?php } ?>
                </li>
              </ul>
            </nav>
          </div>
        </div>
        <!-- /top navigation -->