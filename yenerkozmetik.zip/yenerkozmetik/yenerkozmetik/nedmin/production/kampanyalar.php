<?php require_once 'header.php'; 

$domain =  $_SERVER['SERVER_NAME'];

?>
        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
           

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Kampanyalar</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <a class="btn btn-success" href="kampanya-ekle">Kampanya Ekle +</a>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <?php $kampanyasec=$db->prepare("SELECT * from kampanyalar order by kampanya_sira ASC");
        $kampanyasec->execute();
        $kampanyasay = $kampanyasec->rowCount();
        if ($kampanyasay==0) { ?>
           
<h4 align="center">Henüz kampanya oluşturulmamış.</h4>

        <?php } else { ?>

 <table id="datatable" class="table table-striped table-bordered">
                      <thead>
                        <tr>
                         
                          <th>Kampanya Başlık</th>
                          <th>Link</th>
                          <th>Sıra</th>
                          <th>Menüde Yer Alsın</th>
                          <th></th>
                          
                        
                          
                          
                         
                        </tr>
                      </thead>


                      <tbody>

        <?php 

        while ($kampanyacek=$kampanyasec->fetch(PDO::FETCH_ASSOC)) { 

          $kampanya_id = $kampanyacek['kampanya_id'];
          
          $kampanya_baslik = $kampanyacek['kampanya_baslik'];
          $kampanya_sira = $kampanyacek['kampanya_sira'];
          $kampanya_menu = $kampanyacek['kampanya_menu'];

         

           

          



         ?>

        <tr class="kampanya_<?php echo $kampanya_id; ?>">
                          
                          
                          <td><?php echo $kampanya_baslik; ?></td>
                          <td><?php echo "http://".$domain."/kampanya-".seo($kampanya_baslik); ?></td>
                          <td><div class="col-md-8"><input id="kampanya_<?php echo $kampanya_id; ?>" class="form-control" type="number" min="1" step="any" value="<?php echo $kampanya_sira; ?>" name=""></div><div class="col-md-4"><a href="javascript:void(0);" class="btn btn-success btn-block siraguncelle" name="kampanya_<?php echo $kampanya_id; ?>">Güncelle</a></div></td>
                          <td align="center">
                            <?php if ($kampanya_menu==1) { ?>

                              <input style="height: 17px;width: 17px;" checked="" value="1" class="kampanyamenu" type="checkbox" name="kampanya_<?php echo $kampanya_id; ?>">

                            <?php } else { ?>

                              <input style="height: 17px;width: 17px;" value="0" class="kampanyamenu" type="checkbox" name="kampanya_<?php echo $kampanya_id; ?>">

                              <?php  } ?>
                          </td>
                          <td align="right"><a class="btn btn-warning btn-sm" href="kampanya-duzenle?kampanya_id=<?php echo $kampanya_id; ?>">Düzenle</a><a class="btn btn-danger btn-sm kampanyasil" name="kampanya_<?php echo $kampanya_id; ?>" href="javascript:void(0);">Sil</a></td>
                         
                         
                        
                          
                          
                        </tr>
          
        <?php } ?>

                        
                        
                        
                      </tbody>
                    </table>

        <?php } ?>
                   
                    
                  </div>
                </div>
              </div>

              <!-- Bitiyor -->

              

            </div>
          </div>
        </div>
        <!-- /page content -->

       <?php require_once 'footer.php'; ?>
        <script type="text/javascript">

          $('.kampanyamenu').change(function(){

var buton = $(this);
            var id1=$(this).attr("name");
                var kampanya_id=id1.substring(9);


$(this).prop('disabled',true);

  if (this.checked) {



$(this).val('1');

  } else {



$(this).val('0');


  };

  var checkboxdeger=$(this).val();

  $.ajax({
            type : 'POST',
            url : '../../adminislem.php',
            data : {'kampanyamenudegistir':'ok','kampanya_id':kampanya_id,'checkboxdeger':checkboxdeger},
            success : function(sonuc){

              
              buton.prop('disabled',false);

               }


})

          });
         
         $('.kampanyasil').click(function(){

           var buton = $(this);
            var id1=$(this).attr("name");
                var kampanya_id=id1.substring(9);

               swal({
  title: "Emin misiniz?",
  text: "Bu kampanya silinsin mi?",
  icon: "warning",
  buttons: ["Vazgeç", "Sil"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

    buton.html('Siliniyor...');

    $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'kampanyasil':'ok','kampanya_id':kampanya_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              if (sonuc=="ok") {

                location.reload();
              }

               }

             });


     }

     })
         });


         $('.siraguncelle').click(function(){

var buton = $(this);
            var id1=$(this).attr("name");
                var kampanya_id=id1.substring(9);
                var sira = $.trim($('#kampanya_'+kampanya_id).val());

                $.ajax({

   type : 'POST',
            url : '../../adminislem.php',
            data : {'kampanyasiraguncelle':'ok','kampanya_id':kampanya_id,'sira':sira},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              if (sonuc=="ok") {

                swal({

  title: "Başarılı",
  text: "Kampanya sırası güncellendi!",
  icon: "success",
  button: "OK",
});
              }

               }

             });
              });

       </script>