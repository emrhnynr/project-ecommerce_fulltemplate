<?php 	

Header("Location:production/index.php");

 ?>