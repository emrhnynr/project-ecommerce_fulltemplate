
<?php require_once 'header.php';

if (empty($_SESSION['kullanicioturum'])) {
    
    header("location:index");
}

 ?>

  <title>Şifre Güncelle | Yener Kozmetik</title>


        

        <!--==================== Registration Form Start ====================-->
        <div style="padding-top: 0px;" class="full-row">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="woocommerce">
                            <div class="row">
                                <div class="col-lg-6 col-md-8 col-12 mx-auto">
                                    <div class="registration-form">
                                        <h3 style="font-family: arial;font-weight: 200;">Şifre Güncelle</h3>

                                        <hr>
                                        <form onsubmit="return false;" id="loginform">
                                           

                                            <p>
                                                <label for="reg_email">Mevcut Şifreniz&nbsp;<span class="required">*</span></label>
                                                <input type="password" maxlength="100" class="form-control" name="kullanici_mevcutsifre" id="kullanici_mevcutsifre" />
                                            </p>

                                            <p>
                                                <label for="reg_email">Yeni Şifreniz&nbsp;<span class="required">*</span></label>
                                                <input type="password" maxlength="100" class="form-control" name="kullanici_password" id="kullanici_sifre" />
                                            </p>


                                            <p>
                                                <label for="reg_email">Şifre Tekrar&nbsp;<span class="required">*</span></label>
                                                <input type="password" maxlength="100" class="form-control" name="kullanici_sifretekrar" id="kullanici_sifretekrar" />
                                            </p>

                                            
                                        
                                            <input type="hidden" name="disableFill" value="">

                                            <div style="display: none;" class="alert alert-warning uyari"><i class="fa fa-info-circle"></i></div>

                                            <div style="display: none;" class="alert alert-success uyari2"></div>

                                            
                                            <p>
                                                <button type="submit" class="btn btn-primary rounded-0 submitbuton" name="sifreupdateT">Güncelle</button>
                                            </p>

                                            
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--==================== Registration Form Start ====================-->

       <?php require_once 'footer.php'; ?>

       <script type="text/javascript">
            
            $('#loginform').submit(function(){

var kullanici_sifre = $('#kullanici_sifre').val();
var kullanici_mevcutsifre = $('#kullanici_mevcutsifre').val();
var kullanici_sifretekrar = $('#kullanici_sifretekrar').val();


  if (kullanici_mevcutsifre.length<8) {

$('.uyari').show();
$('.uyari').html('<i class="fa fa-info-circle"></i> Lütfen mevcut şifrenizi doğru girin.');

 } else if (kullanici_sifre.length<8) {

$('.uyari').show();
$('.uyari').html('<i class="fa fa-info-circle"></i> Yeni şifreniz en az 8 karakter içermelidir.');

 } else if (kullanici_sifre!=kullanici_sifretekrar) {

$('.uyari').show();
$('.uyari').html('<i class="fa fa-info-circle"></i> Şifreler uyuşmuyor.');

 } else {

     $('.submitbuton').prop('disabled',true);
     $('.uyari').hide();
     $('.submitbuton').html('Güncelleniyor...');

     var data = $("#loginform").serializeArray();
       data.push({name: "sifreguncelle",value: "ok"});

 $.ajax({
            type : 'POST',
            url : 'musteriislem.php',
            data : $.param(data),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

              if (sonuc!='bot') {
   

             if (sonuc=="yanlissifre") {

                 $('.submitbuton').prop('disabled',false);

                $('.uyari').show();
$('.uyari').html('<i class="fa fa-info-circle"></i> Lütfen mevcut şifrenizi doğru girin.');
$('.submitbuton').html('Güncelle');

               } else {

              
               $('.uyari').hide();
               $('.uyari2').show();
             $('.uyari2').html('<i class="fas fa-check"></i> Şifreniz başarıyla güncellendi.');
               $('.submitbuton').prop('disabled',false);
               $('.submitbuton').html('Güncelle');

               $('#loginform input').val('');
               

               } 
              
              }

              }
        })

 }

        })

        </script>