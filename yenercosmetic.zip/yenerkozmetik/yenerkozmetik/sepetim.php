<?php require_once 'header.php'; ?>

 <title>Sepetim | Yener Saat</title>

        

        <!--==================== Cart Section Start ====================-->
        <div style="padding-top: 15px;" class="full-row">
            <div class="container cart-page-area">

                <?php if ($sepeturunsayheader==0) { ?>

                     <h4 style="font-family: Arial;margin-top: 30px;" align="center">Sepetiniz henüz boş. <a href="../"><u>Alışverişe devam et.</u></a></h4>

                     <?php exit; ?>


                <?php } else { 


                    // Tüm tekil ürün id lerinin toplam sepet miktarı hesaplanıyor, eğer stoktan fazla miktarda varsa o ürün kullanıcı sepetinden siliniyor. Eğer sonunda kullanıcı sepeti boşaldıysa sepetim sayfasına geri atıyor.

$urunidler = [];

if (isset($_SESSION['kullanicioturum'])) {
  
  $sepeturunsec0 = $db->prepare("SELECT * from sepetitem where kullanici_id=:id");
$sepeturunsec0->execute(array(
"id" => $_SESSION['kullanici_id']
));

} else {

  $sepeturunsec0 = $db->prepare("SELECT * from sepetitem where kullanici_ip='$ip_adresi'");
$sepeturunsec0->execute();

}

while ($sepeturuncek0=$sepeturunsec0->fetch(PDO::FETCH_ASSOC)) {
    
    $urun_id = $sepeturuncek0['urun_id'];

    if (!in_array($urun_id, $urunidler)) {
        
        $urunidler[] = $urun_id;
    }

    

    }

    foreach ($urunidler as $urun_id) {
        
        $iddekisepeturunsayisi = 0;

        $sepetitemidler = [];


        if (isset($_SESSION['kullanici_id'])) {
          
           $sepeturunicsec = $db->prepare("SELECT * from sepetitem where urun_id=:urunid and kullanici_id=:kulid");
         $sepeturunicsec->execute(array(

"urunid" => $urun_id,
"kulid" => $_SESSION['kullanici_id']

         ));

        } else {

           $sepeturunicsec = $db->prepare("SELECT * from sepetitem where urun_id='$urun_id' and kullanici_ip='$ip_adresi'");
         $sepeturunicsec->execute();

        }

         while ($sepeturuniccek=$sepeturunicsec->fetch(PDO::FETCH_ASSOC)) {

            
               
               $sepetitemidler[] = $sepeturuniccek['sepetitem_id'];

            
        
        $iddekisepeturunsayisi = $iddekisepeturunsayisi + $sepeturuniccek['urun_miktar'];


    }

  $urunstoksec = $db->prepare("SELECT * from urunler where urun_id = '$urun_id' and urun_stok < $iddekisepeturunsayisi");
  $urunstoksec->execute();
  $urunstoksay = $urunstoksec->rowCount();



  if ($urunstoksay==1) {

    
      
    
    foreach ($sepetitemidler as $sepetitem_id) {

        $itemsepetsil = $db->prepare("DELETE from sepetitem where sepetitem_id='$sepetitem_id'");
        $itemsepetsil->execute();

        $itemsepetseceneklersil = $db->prepare("DELETE from sepetitemsecenekler where sepetitem_id='$sepetitem_id'");
        $itemsepetseceneklersil -> execute();

        
    }

    $sepetitemsilindi = '';


    

  }

    }

     //Sepette ürün kalmadıysa sayfa yenilenir.

    if (isset($_SESSION['kullanicioturum'])) {
            
            $sepeturunsec=$db->prepare("SELECT * from sepetitem where kullanici_id=:id order by urun_id DESC");
                    $sepeturunsec->execute(array(

                        "id" => $_SESSION['kullanici_id']
                    ));

          } else {

            $sepeturunsec=$db->prepare("SELECT * from sepetitem where kullanici_ip=:ip order by urun_id DESC");
                    $sepeturunsec->execute(array(

                        "ip" => $ip_adresi
                    ));


          }

          $sepeturunsayy = $sepeturunsec->rowCount();

          if ($sepeturunsayy==0) {
            header("Location:sepetim");
            exit;
          }


                } ?>
                <div class="row">
                    <div class="col-xl-8 col-lg-12 col-md-12 col-12">

                        <?php if (isset($sepetitemsilindi)) { ?>
                                                
                    <div class="alert alert-info"><i class="fa fa-info-circle"></i> Stoğu yetersiz olan bazı ürünler sepetinizden kaldırıldı.</div>

                    <?php } ?>


                        <form class="woocommerce-cart-form" action="#" method="post">
                            <table class="shop_table cart">
                                <tr>
                                    <th class="product-thumbnail">&nbsp;</th>
                                    <th class="product-name">Ürün</th>
                                    <th class="product-price">Birim Fiyat</th>
                                    <th class="product-quantity">Adet</th>
                                    <th class="product-subtotal">Toplam</th>
									<th class="product-remove">&nbsp;</th>
                                </tr>


                                <?php 

          

                    $urun_toplam = 0;
                    $toplam_desi = 0;

                     

                    while ($sepeturuncek=$sepeturunsec->fetch(PDO::FETCH_ASSOC)) {

                    $sepetitem_id = $sepeturuncek['sepetitem_id'];  

                        $urunsec=$db->prepare("SELECT * from urunler where urun_id=:id");
                        $urunsec->execute(array(

                            "id" => $sepeturuncek['urun_id']
                        ));

                        $uruncek = $urunsec->fetch(PDO::FETCH_ASSOC);

                        $urun_marka = $uruncek['marka_id'];

                        

                          $sepetitemseceneksec = $db->prepare("SELECT * from sepetitemsecenekler where sepetitem_id='$sepetitem_id'");

                          $sepetitemseceneksec->execute();

                          

                           

                              $urun_fiyat = $uruncek['urun_nihaifiyat'];

                              

                            $urun_desi = $uruncek['urun_desi'];

                        $urun_toplamfiyat = $sepeturuncek['urun_miktar']*$urun_fiyat;
                        $urun_toplamdesi = $sepeturuncek['urun_miktar']*$urun_desi;

                        $urun_toplam+=$urun_toplamfiyat;
                        $toplam_desi+=$urun_toplamdesi;

                        $urun_ad=$uruncek['urun_ad'];

                $urunfotosec=$db->prepare("SELECT * from urunfoto where urun_id=:id and urunfoto_kapak=:kapak");
                $urunfotosec->execute(array(
                    "id" => $sepeturuncek['urun_id'],
                    "kapak" => 1

                ));

                $urunfotocek=$urunfotosec->fetch(PDO::FETCH_ASSOC);

                $markasec=$db->prepare("SELECT * from markalar where marka_id='$urun_marka'");
                        $markasec->execute();
                        $markacek=$markasec->fetch(PDO::FETCH_ASSOC);
                        $marka_ad=$markacek['marka_ad'];

                ?>
                                
                                <tr id="sepetitem_<?php echo $sepeturuncek['sepetitem_id']; ?>" class="woocommerce-cart-form__cart-item cart_item">
                                    <td class="product-thumbnail">
                                        <a target="_blank" href='urun-<?php echo seo($urun_ad)."-".$uruncek['urun_id']; ?>'><img src="<?php echo $urunfotocek['urunfoto_yol']; ?>" alt="Ürün"></a>
                                    </td>
                                    <td class="product-name">
                                        <span style="font-weight: 500;"><?php echo $marka_ad; ?></span><br>
                                        <a target="_blank" href="urun-<?php echo seo($urun_ad)."-".$uruncek['urun_id']; ?>" ><?php if (strlen($urun_ad)>36) { ?>
                            <?php echo substr($urun_ad,0,36)."..."; ?>
                        <?php } else { 

                         echo $urun_ad; 
                         } ?></a>

                         <?php while ($sepetitemsecenekcek=$sepetitemseceneksec->fetch(PDO::FETCH_ASSOC)) { 
                $secenek_ad = $sepetitemsecenekcek['secenek_ad'];
                $altsecenek_ad = $sepetitemsecenekcek['altsecenek_ad']; ?> 

                                        <dl class="variation">
                                            <dt class="variation-Vendor"><?php echo $secenek_ad; ?>:</dt>
                                            <dd class="variation-Vendor"><?php echo $altsecenek_ad; ?></dd>
                                        </dl>

                        <?php } ?>
                                    </td>
                                    <td class="product-price">
                                        <span><bdi><?php echo $urun_fiyat." TL"; ?></bdi>
                                        </span>
                                    </td>
                                    <td class="product-quantity">

                                        <?php if ($sepeturuncek['urun_miktar']!=1) { ?>
                                <a style="font-size: 13px;" name="sepetitem_<?php echo $sepeturuncek['sepetitem_id']; ?>" class="quantity-minus" href="javascript:void(0);"><i class="fa fa-minus-circle"></i></a>

                                <?php  } ?>

                                        <?php echo $sepeturuncek['urun_miktar']; ?>

                                        <a style="font-size: 13px;" class="quantity-plus" href="javascript:void(0);" name="sepetitem_<?php echo $sepeturuncek['sepetitem_id']; ?>"><i class="fa fa-plus-circle"></i></a>

                                    </td>
                                    <td class="product-subtotal">
                                        <span><bdi><?php echo $urun_toplamfiyat. " TL"; ?></bdi>
                                        </span>
                                    </td>
									<td name="sepetitem_<?php echo $sepeturuncek['sepetitem_id']; ?>" class="product-remove sepetitemsil">
                                        <a href="javascript:void(0);" class="remove">×</a>
                                    </td>
                                </tr>

                            <?php } ?>
                              
                            </table>
                        </form>
                    </div>

                    <?php if (!empty($genelayarcek['kargobedava_limit'])) {
                              
                              if ($urun_toplam>$genelayarcek['kargobedava_limit']) {

               $kargo_ucreti = 0.00;

               
                                

                              } else {


                                $kargoucretisec=$db->prepare("SELECT * from kargoucretleri where 
                                  min_desi<='$toplam_desi' and max_desi>'$toplam_desi'");
                                $kargoucretisec->execute();

                                $kargoucreticek=$kargoucretisec->fetch(PDO::FETCH_ASSOC);

                                


                   $kargo_ucreti = $kargoucreticek['kargo_ucreti'];

                              }

                            } else {

                              $kargoucretisec=$db->prepare("SELECT * from kargoucretleri where 
                                  min_desi<='$toplam_desi' and max_desi>'$toplam_desi'");
                                $kargoucretisec->execute();

                                $kargoucreticek=$kargoucretisec->fetch(PDO::FETCH_ASSOC);

                                

                               $kargo_ucreti = $kargoucreticek['kargo_ucreti'];


                            } ?>



                    <div class="col-xl-4 col-lg-12 col-md-12 col-12">
                        <div class="cart-collaterals">
                            <div class="cart_totals ">
                                <h2>Sepet</h2>
                                <table>
                                    <tr>
                                        <th>Ara Toplam</th>
                                        <td>
                                            <span><bdi><b><?php echo $urun_toplam." TL"; ?></b></bdi>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Kargo Ücreti</th>
                                        <td>
                                            <span><bdi><b><?php echo $kargo_ucreti." TL"; ?></b></bdi>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr class="order-total">
                                        <th>Toplam</th>
                                        <td><strong><span class="woocommerce-Price-amount amount"><bdi><?php echo $urun_toplam+$kargo_ucreti; ?> TL</bdi></span></strong> </td>
                                    </tr>
                                </table>
                                <div class="wc-proceed-to-checkout">
                                    <a href="odeme" class="checkout-button">Ödemeyi Tamamla</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--==================== Cart Section End ====================-->

        <?php require_once 'footer.php'; ?>

        <script type="text/javascript">

            $('.quantity-plus').click(function(){

var id1=$(this).attr("name");
         var sepetitem_id=id1.substring(10);

         $.ajax({

   type : 'POST',
            url : 'musteriislem.php',
            data : {'urunmiktarplus':'ok','sepetitem_id':sepetitem_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              if (sonuc=="gecersizid"){

           location.reload();

              } else if (sonuc=="stokyok") {

                 swal({
  title: "Stok Yetersiz",
  text: "Ürünü almak istediğiniz adet kadar stok mevcut değil.",
  icon: "info",
  dangerMode: true,
});


              } else {

                $('.cart-page-area').html('<h4 style="font-family:Arial;" align="center">Sepet Güncelleniyor...</h4>');

                $('.cart-page-area').html(sonuc);

              }

            

               }

               });



});



            $('.quantity-minus').click(function(){

var id1=$(this).attr("name");
         var sepetitem_id=id1.substring(10);



         $.ajax({

   type : 'POST',
            url : 'musteriislem.php',
            data : {'urunmiktarminus':'ok','sepetitem_id':sepetitem_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              if (sonuc=="gecersizid"){

           location.reload();

              } else {

              
             
             $('.cart-page-area').html('<h3 align="center">Sepet Güncelleniyor...</h3>');
             
                $('.cart-page-area').html(sonuc);

                }

            

               }

               });

         

});

            
            $('.sepetitemsil').click(function(){


         var id1=$(this).attr("name");
         var sepetitem_id=id1.substring(10);

        swal({
  title: "Emin misiniz?",
  text: "Bu ürünü sepetinizden kaldırmak istediğinize emin misiniz?",
  icon: "info",
  buttons: ["Vazgeç", "Kaldır"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

    $.ajax({

   type : 'POST',
            url : 'musteriislem.php',
            data : {'sepetitemsil':'ok','sepetitem_id':sepetitem_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);

             

             if (sonuc=="ok") {

                 location.reload();

             }
               }

             });


     }

     })

         

    });

        </script>